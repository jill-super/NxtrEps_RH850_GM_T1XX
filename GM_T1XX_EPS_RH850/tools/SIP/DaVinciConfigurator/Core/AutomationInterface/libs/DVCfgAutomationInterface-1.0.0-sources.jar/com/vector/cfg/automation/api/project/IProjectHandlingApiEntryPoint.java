package com.vector.cfg.automation.api.project;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IProjectHandlingApiEntryPoint} is the entry point for accessing project handling interfaces.
 * <div class="extdoc" id="IProjectHandlingApiEntryPoint"><!--Label:IProjectHandlingApiEntryPoint-->The project handling API is the entry point for accessing project handling
 * interfaces. It is available for scripts of all types in the form of the {@link IProjectHandlingApi} interface.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProjectHandlingApiEntryPoint {

    /**
     * {@link #getProjects()} allows accessing the {@link IProjectHandlingApi} like a property.
     * <div class="extdoc" id="getProjects"><!--Label:IProjectHandlingApiEntryPoint.getProjects-->{@link #getProjects()} allows accessing the {@link IProjectHandlingApi} like a
     * property.</div>
     *
     * @return the {@link IProjectHandlingApi}
     */
    @PublishedMethod
    IProjectHandlingApi getProjects();

    /**
     * {@link #projects(Closure)} allows accessing the {@link IProjectHandlingApi} in a scope-like way.
     * <div class="extdoc" id="projects"><!--Label:IProjectHandlingApiEntryPoint.projects-->{@link #projects(Closure)} allows accessing the {@link IProjectHandlingApi} in a
     * scope-like way.</div>
     *
     * @param code the code (a {@link Closure}) working with the {@link IProjectHandlingApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T projects(@VDelegatesToWithClosureParam(IProjectHandlingApi.class) Closure<T> code);

}
