/**
 * AutomationInterface scripting API for client side scripts for Groovy code.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.scripting.api;