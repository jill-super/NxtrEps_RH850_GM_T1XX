package com.vector.cfg.consistency.contribution.helper.modeltraverser;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationEvents;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.contribution.IValidator;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.IRuleAlgorithm;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.IRuleAlgorithmResult;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.helper.IRuleAlgorithmResultWithValidationResult;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.helper.RuleAlgorithmResult;
import com.vector.cfg.consistency.internal.ConsistencyUtil;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidTraverserView;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.ITraverseResult;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.ITraverserView;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IValidTraverserView;
import com.vector.cfg.util.IProjectContext;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Common_Part">
 *
 * The Cfg5 provides the abstract base class {@link AbstractModelTraverserAlgorithmValidation} to simplify the usage of {@link IRuleAlgorithm IRuleAlgorithms}
 * in the context of {@link IModelTraverser IModelTraversers}. This class provides the base implementation for an {@link IRuleTraverserAlgorithm} inclusive the
 * traverse code. A {@link IRuleTraverserAlgorithm} is a specialization of on {@link IRuleAlgorithm} (see {@link IRuleTraverserAlgorithm} for more details).
 *
 * <p>
 * When you use the {@link AbstractModelTraverserAlgorithmValidation} class instead of the class {@link AbstractModelTraverserValidation} as a base class for
 * your validation rules you can use the validation rule as a precondition for other validation rules.
 *
 * <p>
 * You can implement the following methods to implement your precondition/validation logic:
 * <ul>
 * <li><code>executeAlgorithm(...)</code></li>
 * <li><code>executeAlgorithmForValidView(...)</code></li>
 * <li><code>executeAlgorithmForInvalidView(...)</code></li>
 * <ul>
 * <li>These methods are called, if a dependent rule request if this precondition is satisfied or not, or if the consistency wants to execute the validation.
 * You have to return a correct {@link IRuleAlgorithmResult}.</li>
 * </ul>
 * </ul>
 *
 * <p>
 * The three method require as return type a {@link IRuleAlgorithmResult}. You can return instead of an {@link IRuleAlgorithmResult} also an instance of
 * {@link IRuleAlgorithmResultWithValidationResult}, to report a {@link IValidationResult} in the validation case (
 * <code>ERuleTraverserAlgorithmExecutionType. VALIDATION</code>). Or you could report an {@link IValidationResult} with the {@link #getResultSink()} method,
 * but this is only permitted, when the execution type is <code>ERuleTraverserAlgorithmExecutionType. VALIDATION</code>, otherwise there is no
 * {@link IValidationResultSink} object!
 * </p>
 *
 * </div>
 *
 * <b>Note:</b> This class replaces the old implementation of {@link AbstractModelTraverserValidationWithAlgorithm}!
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IRuleTraverserAlgorithm
 * @see IRuleAlgorithm
 * @see AbstractModelTraverserValidation
 * @see IModelTraverser
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractModelTraverserAlgorithmValidation extends AbstractModelTraverserValidation implements IRuleTraverserAlgorithm {

    /** The Constant NOT_OVERRIDDEN_METHOD_CALLED indicates, that a certain method call was not overridden by the client. */
    private static final IRuleAlgorithmResult NOT_OVERRIDDEN_METHOD_CALLED = new IRuleAlgorithmResult() {

        @Override
        public boolean isConditionFulfilled() {
            throw new UnsupportedOperationException();
        }

        @Override
        public Collection<IDescriptor> getGeneralCEs() {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean algorithmExecuted() {
            throw new UnsupportedOperationException();
        }
    };

    /**
     * Constructor for AbstractModelTraverserValidationWithAlgorithm.
     *
     * @param projectContext
     * @param eventThresholdForFullValidation
     */
    @PublishedMethod
    protected AbstractModelTraverserAlgorithmValidation(IProjectContext projectContext, long eventThresholdForFullValidation) {
        super(projectContext, eventThresholdForFullValidation);
    }

    /**
     * Instantiates a new abstract model traverser validation.
     *
     * <p>
     * You have to call the method {@link #registerModelTraverser(IModelTraverser)} during the constructor call of your validation rule.
     * </p>
     *
     * <p>
     * Please use the {@link #AbstractModelTraverserValidation(IProjectContext, long)} constructor, if you can specify an event threshold!
     * </p>
     *
     * @param projectContext the project context
     */
    @PublishedMethod
    protected AbstractModelTraverserAlgorithmValidation(IProjectContext projectContext) {
        super(projectContext);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IModelTraverser getModelTraverser() {
        return super.getModelTraverser();
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Can Override this method to process non EcuC Elements.
     * </p>
     * <p>
     * This implementation will always return an empty collection, because the "start/parent" validation has already inserted all EcuC elements from the events
     * collection.
     * </p>
     * <p>
     * CodeSample:
     *
     * <pre>
     * <code>Set&lt;MIHasDefinition&gt; set= Sets.newHashSet();
     *         handleNonEcuCEvents(events, set);
     *         return set;</code>
     * </pre>
     *
     * </p>
     *
     * @param validationEvents the Consistency events to process for ModelTraverser StartElements.
     * @return the found StartElements
     */
    @PublishedMethod
    @Override
    public Set<MIHasDefinition> getEcuCStartElementsFromNonEcuCElements(IValidationEvents validationEvents) {
        /*
         * Empty collection is valid, because the "start" validation has already inserted all EcuC elements from the events collection
         */
        return Collections.emptySet();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Collection<MIHasDefinition> getAffectedContexts(IValidationEvents validationEvents) {

        final Set<MIHasDefinition> startElementsForModelTraverser = getStartElementsForModelTraverser(validationEvents);
        return getModelTraverser().startTraverse(startElementsForModelTraverser).getAffectedMainElements();

    }

    /**
     * {@inheritDoc}
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the passed traverseResult is no TraverserResult from the {@link IModelTraverser} of the validation</li>
     * </ul>
     * @exception NullPointerException
     * <ul>
     * <li>if the passed ruleEvents parameter is null</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    public final IRuleAlgorithmResult perform(MIHasDefinition contextElement, IValidationEvents validationEvents) {
        checkNotNull(validationEvents);
        checkNotNull(contextElement);

        final ITraverseResult traverseResult = getModelTraverser().startTraverse(contextElement);

        return performByTraverser(traverseResult, validationEvents);

    }

    /**
     * {@inheritDoc}
     *
     */
    @Override
    @PublishedMethod
    public final IRuleAlgorithmResult performByTraverser(ITraverseResult traverseResult, IValidationEvents validationEvents) {
        checkNotNull(validationEvents);
        checkArgument(traverseResult.getSourceTraverser() == getModelTraverser());

        setCachedValidationEvents(validationEvents);
        try {
            return performInternal(traverseResult);
        } finally {
            removeCachedValidationEvents();
        }
    }

    /**
     * {@link #performInternal(ITraverseResult, Collection)} is called, when all associated preconditions of this validation are satisfied.
     *
     * <p>
     * This method is called from {@link #perform(ITraverseResult, Collection)}
     * </p>
     *
     * <p>
     * CAUTION: the {@link IValidationEvents} must be set, before this method is called!
     * </p>
     *
     *
     * @param traverseResult the traverse result
     * @return the i rule algorithm result
     */
    private IRuleAlgorithmResult performInternal(ITraverseResult traverseResult) {
        checkState(getValidationEvents() != null);

        ITraverserView view;
        IValidTraverserView validView = null;
        IInvalidTraverserView invalidView = null;
        if (traverseResult.getValidTraverserViews().size() == 1) {
            checkArgument(traverseResult.getInvalidTraverserViews().isEmpty());

            validView = traverseResult.getValidTraverserViews().get(0);
            view = validView;
        } else {
            checkArgument(traverseResult.getValidTraverserViews().isEmpty());
            invalidView = traverseResult.getInvalidTraverserViews().get(0);
            view = invalidView;
        }

        if (!checkPreconditionRuleAlgorithmExecution(view)) {
            return RuleAlgorithmResult.NOT_PERFORMED;
        }

        final IRuleAlgorithmResult wholeResult = executeAlgorithm(traverseResult, ERuleTraverserAlgorithmExecutionType.ALGORITHM);
        if (wholeResult != NOT_OVERRIDDEN_METHOD_CALLED) {
            /*
             * The client (subclass) has created the returned "wholeResult", so we have to return it as the result of the process:
             */
            return wholeResult;
        }

        /*
         * The method was not overridden by the client so we have to call the other methods for valid and invalid views.
         */

        if (validView != null) {
            /*
             * We have one ValidView, so execute method:performOrValidateForValidView()
             */
            return executeAlgorithmForValidView(validView, ERuleTraverserAlgorithmExecutionType.ALGORITHM);

        } else if (invalidView != null) {
            return executeAlgorithmForInvalidView(invalidView, ERuleTraverserAlgorithmExecutionType.ALGORITHM);

        } else {
            throw new IllegalStateException("No View found! Internal error");
        }

    }

    /**
     * {@inheritDoc}.
     *
     * <p>
     * Please Override one of the methods
     * <ul>
     * <li>{@link #executeAlgorithm(ITraverseResult, ERuleTraverserAlgorithmExecutionType)}</li>
     * <li>{@link #executeAlgorithmForValidView(IValidTraverserView, ERuleTraverserAlgorithmExecutionType)}</li>
     * <li>{@link #executeAlgorithmForInvalidView(IInvalidTraverserView, ERuleTraverserAlgorithmExecutionType)}</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    protected final void executeValidation(ITraverseResult result) {
        /*
         * We are in the "real" validation mode, so we could have multiple views.
         */

        final IRuleAlgorithmResult wholeResult = executeAlgorithm(result, ERuleTraverserAlgorithmExecutionType.VALIDATION);
        if (wholeResult == NOT_OVERRIDDEN_METHOD_CALLED) {
            /*
             * The method was not overridden by the client so we have to call the other methods for valid and invalid views.
             */

            for (final IValidTraverserView view : result.getValidTraverserViews()) {

                if (!checkPreconditionRuleAlgorithmExecution(view)) {
                    continue;
                }

                final IRuleAlgorithmResult ruleAlgorithmResult = executeAlgorithmForValidView(view, ERuleTraverserAlgorithmExecutionType.VALIDATION);
                checkForResultAndInsertToSink(ruleAlgorithmResult);
            }

            for (final IInvalidTraverserView view : result.getInvalidTraverserViews()) {

                if (!checkPreconditionRuleAlgorithmExecution(view)) {
                    continue;
                }

                final IRuleAlgorithmResult ruleAlgorithmResult = executeAlgorithmForInvalidView(view, ERuleTraverserAlgorithmExecutionType.VALIDATION);
                checkForResultAndInsertToSink(ruleAlgorithmResult);
            }
        } else {
            /*
             * The client (subclass) has created the returned "wholeResult", so we have to process the content!
             */
            checkForResultAndInsertToSink(wholeResult);
        }
    }

    /**
     * Check for result and insert to sink.
     *
     * @param ruleAlgorithmResult the rule algorithm result
     */
    private void checkForResultAndInsertToSink(IRuleAlgorithmResult ruleAlgorithmResult) {
        if (ruleAlgorithmResult != null) {
            if (ruleAlgorithmResult.algorithmExecuted()) {
                if (!ruleAlgorithmResult.isConditionFulfilled()) {
                    if (ruleAlgorithmResult instanceof IRuleAlgorithmResultWithValidationResult) {
                        final IRuleAlgorithmResultWithValidationResult valResProvider = (IRuleAlgorithmResultWithValidationResult) ruleAlgorithmResult;

                        final IValidationResult validationResult = valResProvider.createValidationResult();
                        if (validationResult == null) {
                            throw new IllegalArgumentException("The returend IRuleAlgorithmResult of the Validation rule " + ConsistencyUtil.getValidatorOrRuleName(this)
                                    + " has no IValidatioNresult (null), but the Condition was NOT fullfilled. This is not allowed! Returned Result: " + ruleAlgorithmResult);
                        }
                        getResultSink().reportValidationResult(validationResult);

                    }
                }
            }
        }
    }

    private IRuleAlgorithmResult createOkResultForView(ITraverserView view) {
        return new RuleAlgorithmResult.ExecutedWithResult(view.getGeneralCEs(), true);
    }

    /**
     * This method is not used in the {@link AbstractModelTraverserAlgorithmValidation} class!
     *
     * @exception UnsupportedOperationException
     */
    @Override
    @PublishedMethod
    protected final void executeValidationForValidView(IValidTraverserView validView) {
        throw new UnsupportedOperationException();
    }

    /**
     * {@link #performOrValidate(ITraverseResult, Collection)} is called, when a precondition is evaluated or
     * {@link IValidator#onModelEvent(IValidationResultSink, Collection)} is called on this instance.
     *
     * <p>
     * Attention: This method is <b>ALSO</b> called, if any Precondition of this validation (see {@link #registerPreconditionRuleTraverserAlgorithms()}) is not
     * satisfied!
     *
     * If you override this method, you have to check the precondition with {@link #checkPreconditionRuleAlgorithmExecution(ITraverserView, Collection)} for
     * each {@link ITraverserView} by yourself!
     * </p>
     *
     * <p>
     * You should override this method, <b>only</b> if you want to analyze valid and invalid {@link ITraverserView}s and its connections! If you are only
     * interested in valid Views, please use {@link #performOrValidateForValidView(IValidTraverserView, Collection)}.
     *
     * If you are only interested in invalid Views, please use
     * {@link #executeAlgorithmForInvalidView(IInvalidTraverserView, Collection, ERuleTraverserAlgorithmExecutionType)}.
     * </p>
     *
     * <p>
     * This method could be called from {@link #perform(ITraverseResult, IValidationEvents} <br />
     * or from {@link #executeValidation(ITraverseResult)}
     * </p>
     *
     *
     * <p>
     * If you override this method, you must not make the following the <code> return super.performOrValidate(...);</code>. When this method is overridden, the
     * other methods are not longer called:
     * <ul>
     * <li>{@link #executeAlgorithmForValidView(IValidTraverserView, ERuleTraverserAlgorithmExecutionType)}</li>
     * <li>{@link #executeAlgorithmForInvalidView(IInvalidTraverserView, ERuleTraverserAlgorithmExecutionType)}</li>
     * </ul>
     * </p>
     *
     *
     * @param result the {@link ITraverseResult}. Note the {@link ITraverseResult} could contain more then one view!
     * @param executionType of this call. If it is a algorithm or validation call.
     */
    @PublishedMethod
    protected IRuleAlgorithmResult executeAlgorithm(ITraverseResult result, ERuleTraverserAlgorithmExecutionType executionType) {
        return NOT_OVERRIDDEN_METHOD_CALLED;
    }

    /**
     * Execute validation for each valid view.
     * <p>
     * You can override this method, if the want to validate only {@link IValidTraverserView}s. Otherwise use {@link #executeValidation(ITraverseResult)}.
     * </p>
     *
     * <p>
     * Attention: This method is not called, if any precondition of this view to validate (see {@link #registerPreconditionRuleTraverserAlgorithms()}) is not
     * satisfied.
     * </p>
     *
     * <p>
     * This method could be called from {@link #perform(ITraverseResult, IValidationEvents)} <br />
     * or from {@link #executeValidation(ITraverseResult)}
     * </p>
     *
     *
     * <p>
     * If you override the method {@link #executeAlgorithm(ITraverseResult, ERuleTraverserAlgorithmExecutionType)}, the other methods are not longer called:
     * <ul>
     * <li>{@link #executeAlgorithmForValidView(IValidTraverserView, ERuleTraverserAlgorithmExecutionType)}</li>
     * <li>{@link #executeAlgorithmForInvalidView(IInvalidTraverserView, ERuleTraverserAlgorithmExecutionType)}</li>
     * </ul>
     * </p>
     *
     * @param validView the {@link IValidTraverserView} of the TraverseResult
     * @param executionType of this call. If it is a algorithm or validation call.
     */
    @PublishedMethod
    protected IRuleAlgorithmResult executeAlgorithmForValidView(IValidTraverserView validView, ERuleTraverserAlgorithmExecutionType executionType) {
        return createOkResultForView(validView);
    }

    /**
     * Execute validation for each invalid view.
     * <p>
     * You can override this method, if the want to validate only {@link IValidTraverserView}s. Otherwise use {@link #executeValidation(ITraverseResult)}.
     * </p>
     *
     * <p>
     * Attention: This method is not called, if any precondition of this view to validate (see {@link #registerPreconditionRuleTraverserAlgorithms()}) is not
     * satisfied.
     * </p>
     *
     * <p>
     * This method could be called from {@link #perform(ITraverseResult, IValidationEvents)} <br />
     * or from {@link #executeValidation(ITraverseResult)}
     * </p>
     *
     * <p>
     * If you override the method {@link #executeAlgorithm(ITraverseResult, ERuleTraverserAlgorithmExecutionType)}, the other methods are not longer called:
     * <ul>
     * <li>{@link #executeAlgorithmForValidView(IValidTraverserView, ERuleTraverserAlgorithmExecutionType)}</li>
     * <li>{@link #executeAlgorithmForInvalidView(IInvalidTraverserView, ERuleTraverserAlgorithmExecutionType)}</li>
     * </ul>
     * </p>
     *
     * @param invalidView the {@link IInvalidTraverserView} of the TraverseResult
     * @param executionType of this call. If it is a algorithm or validation call.
     */
    @PublishedMethod
    protected IRuleAlgorithmResult executeAlgorithmForInvalidView(IInvalidTraverserView invalidView, ERuleTraverserAlgorithmExecutionType executionType) {
        return createOkResultForView(invalidView);
    }

}
