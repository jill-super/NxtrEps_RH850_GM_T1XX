package com.vector.cfg.consistency.contribution.helper.modeltraverser;

import java.util.Set;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationEvents;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.IRuleAlgorithm;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.IRuleAlgorithmResult;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.ITraverseResult;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.ITraverserView;

/**
 * {@link IRuleTraverserAlgorithm} is a special interface for the {@link IRuleAlgorithm} which is backed by an {@link IModelTraverser}.
 *
 * <p>
 * This interface enables some optimizations for the {@link IModelTraverser} execution. You should used this interface if possible. See class
 * {@link AbstractModelTraverserValidationWithAlgorithm} for a default implementation.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IRuleAlgorithm
 * @see IModelTraverser
 * @see AbstractModelTraverserValidationWithAlgorithm
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IRuleTraverserAlgorithm extends IRuleAlgorithm<MIHasDefinition> {

    /**
     * Gets the {@link IModelTraverser} of the RuleAlgorithm.
     *
     * @return the {@link IModelTraverser}
     */
    @PublishedMethod
    IModelTraverser getModelTraverser();

    /**
     * Returns the EcuC StartElements extracted form the {@link IValidationEvents}.
     *
     * <p>
     * The implementation could insert additional startElements (EcuC elements) by evaluation events from e.g. the system description.
     * </p>
     *
     * <p>
     * This method is used to improve the performance, because the Model is only traversed once, after the acquisition of the StartElements!
     * </p>
     *
     * @param validationEvents the Consistency events to process for ModelTraverser StartElements.
     * @return the found StartElements
     */
    @PublishedMethod
    Set<MIHasDefinition> getEcuCStartElementsFromNonEcuCElements(IValidationEvents validationEvents);

    /**
     * This method is executed, if this {@link IRuleTraverserAlgorithm} is called from another {@link IRuleTraverserAlgorithm} or ModelTraverser validation.
     * <p>
     * This method is a performance improvement, because the Model is only traversed once. Please do not call this method from another {@link IRuleAlgorithm},
     * used {@link #perform(MIHasDefinition, IValidationEvents)} instead!
     * </p>
     *
     * <p>
     * Attention: You can execute this method only for a {@link ITraverseResult} which contains only <b>one</b> {@link ITraverserView}
     * </p>
     *
     * @param context The {@link ITraverseResult} of the executed {@link IModelTraverser}.
     * @param validationEvents the events to process.
     * @return IRuleAlgorithmResult of the execution
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the passed traverseResult is no TraverserResult from the {@link IModelTraverser} of the validation</li>
     * <li>if the passed traverseResult contains none of more then one {@link ITraverserView}</li>
     * </ul>
     * @exception NullPointerException
     * <ul>
     * <li>if the passed ruleEvents parameter is null</li>
     * </ul>
     */
    @PublishedMethod
    IRuleAlgorithmResult performByTraverser(ITraverseResult context, IValidationEvents validationEvents);

}
