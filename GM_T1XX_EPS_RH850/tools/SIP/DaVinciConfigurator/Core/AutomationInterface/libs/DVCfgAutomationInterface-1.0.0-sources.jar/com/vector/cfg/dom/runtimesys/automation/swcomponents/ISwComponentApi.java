package com.vector.cfg.dom.runtimesys.automation.swcomponents;

import java.util.Collection;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.ar4x.swcomponenttemplate.composition.MISwComponentPrototype;
import com.vector.cfg.model.mdf.ar4x.swcomponenttemplate.composition.MISwConnector;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISwComponentApi {

    @PublishedMethod
    Collection<MISwComponentPrototype> getComponents();

    @PublishedMethod
    MISwConnector connect(@Nonnull @VDelegatesToWithClosureParam(ICreateSwConnectorApi.class) Closure<?> code);

}
