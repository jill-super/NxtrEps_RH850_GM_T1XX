package com.vector.cfg.gen.core.moduleinterface.calculation;

import java.util.Arrays;
import java.util.List;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The class {@link GenCalculationAspect} provides create methods and a builder for an {@link IGenCalculationAspect}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IGenCalculationAspect
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenCalculationAspect implements IGenCalculationAspect {

    private final List<ICalculator> calcList;

    private GenCalculationAspect(List<ICalculator> calcList) {
        this.calcList = calcList;

    }

    /**
     * Creates a {@link IGenCalculationAspect} from the passed list of {@link ICalculator}.
     *
     * @param calList the list of {@link ICalculator}s
     * @return the new {@link IGenCalculationAspect}
     */
    @PublishedMethod
    public static IGenCalculationAspect create(List<ICalculator> calList) {
        return new GenCalculationAspect(ImmutableList.copyOf(calList));
    }

    /**
     * Creates a {@link IGenCalculationAspect} from the passed {@link ICalculator}.
     *
     * @param calculators the calculators
     * @return the new {@link IGenCalculationAspect}
     */
    @PublishedMethod
    public static IGenCalculationAspect create(ICalculator... calculators) {
        return create(Arrays.asList(calculators));
    }

    /**
     *
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public List<ICalculator> getCalculators() {
        return calcList;
    }

}
