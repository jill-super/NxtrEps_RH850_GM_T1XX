package com.vector.cfg.model.access;

import static com.google.common.base.Preconditions.checkArgument;

import java.util.List;

import javax.annotation.concurrent.Immutable;

import com.google.common.base.Optional;
import com.google.common.base.Strings;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.internal.access.ModelInternalUtil;
import com.vector.cfg.model.internal.access.ObjectLinkOtherTypeData;
import com.vector.cfg.model.internal.access.ObjectLinkParameterData;
import com.vector.cfg.model.internal.access.ObjectLinkVarianceData;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.base.MIAUTOSAR;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.variants.IEvaluatedVariantSet;
import com.vector.cfg.model.variants.IPredefinedVariant;
import com.vector.cfg.model.variants.IProjectVarianceAccess;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManagerCoreInternal;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.autosar.AutosarUtil;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <h2>AsrObjectLink</h2> <!--LaTeX: \label{sec:AsrObjectLink} --> This class implements an immutable identifier for AUTOSAR objects.
 * <p>
 * An {@link AsrObjectLink} can be created for each object in the MDF AUTOSAR model tree. The main use case of object links is to identify an object unambiguously at a specific
 * point in time for logging reasons. Additionally and under specific conditions it is also possible to find the releated MDF object using its AsrObjectLink instance. But this
 * search-by-link cannot be guaranteed for each object type and after model changes (details and restrictions below).
 * </p>
 *
 * <h3>Object links depend on the MDF object type</h3>
 * <ul>
 * <li><b>Referrables</b><br/>
 * The object link is actually identical with the AUTOSAR path</li>
 * <li><b>Ecuc objects with a definition</b> (module, container and parameter)<br/>
 * The object link additionally stores the DefRef</li>
 * <li><b>Ecuc parameters</b><br/>
 * The object link additionally stores the parameters index. This is the index of all parameters with the same definition below the same parent container instance in the
 * unfiltered model view</li>
 * </ul>
 *
 * <h3>Restrictions of object links</h3>
 * <ul>
 * <li>They are immutable and will therefore become invalid when the model changes</li>
 * <li>So they don't guarantee that the related MDF object can be retrieved after the model has been changed. Search-by-link may even find another object or throw an exception
 * in this case</li>
 * </ul>
 *
 * <h3>Examples for object link strings</h3> The method {@link #getObjectLinkString()} returns for example the following strings:
 * <ul>
 * <li>For a container or module configuration object, the AUTOSAR path is returned: <code>"/ActiveEcuC/Can/CanGeneral"</code></li>
 * <li>For a parameter, the parents AUTOSAR path, the last shortname of its definition and a positional index in the list of parameters with the same definition is used:
 * <code>"/ActiveEcuC/Can/CanGeneral[2:SomeDefName]"</code></li>
 * <li>In case of variant objects, all variants, this object is visible in, are added:
 * <code>/ActiveEcuC/Can/CanConfigSet/CanHardwareObject[0:CanControllerRef]{VariantA, VariantB}</code></li>
 * </ul>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@Immutable
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class AsrObjectLink {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AsrObjectLink.class);

    private static final char PATHSEP = '/';

    private static final String REMOVED = "<REMOVED>";

    private static final String NO_SHORTNAME = "<NO-SHORTNAME>";

    private static final String NO_PARENT = ObjectLinkOtherTypeData.NO_PARENT;

    private static final String NO_ROOT = "<NO-ROOT>";

    private final String bestEffortPath;

    private final AsrPath asrPath;

    private final ObjectLinkParameterData parameterData;

    private final ObjectLinkVarianceData varianceData;

    private final boolean isParameterValueLink;

    private final boolean isReferrableLink;

    private final ObjectLinkOtherTypeData otherTypeData;

    /**
     * Returns the object link of the specified object as an instance of {@link TypedAsrObjectLink}.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return
     * @throws IllegalArgumentException if the object is <code>null</code> or the link cannot be created for other reasons.
     */
    @PublishedMethod
    @ReworkThisAtNextBreakingChange("Return TypedAsrObjectLink instead of AsrObjectLink")
    // public static <T extends MIObject> TypedAsrObjectLink<T> create(final T obj) {
    public static AsrObjectLink create(MIObject obj) {
        if (obj == null) {
            throw new IllegalArgumentException("obj is null");
        }

        final AsrObjectLink link = tryCreate(obj);
        if (link == null) {
            throw new IllegalArgumentException("cannot create object link");
        }

        return link;
    }

    /**
     * Returns the object link of the specified object as an instance of {@link TypedAsrObjectLink} or <code>null</code> if the specified object reference is <code>null</code>
     * or if it is not an AUTOSAR object.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param obj
     * @return
     */
    @PublishedMethod
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @ReworkThisAtNextBreakingChange("Return TypedAsrObjectLink instead of AsrObjectLink")
    // public static <T extends MIObject> TypedAsrObjectLink<T> tryCreate(T obj) {
    public static AsrObjectLink tryCreate(MIObject obj) {
        if (obj == null) {
            return null;
        }

        final boolean isParameterValueLink = obj instanceof MIParameterValue;
        final boolean isReferrableLink = obj instanceof MIReferrable;

        if (ModelAccessUtil.isRemovedOnly(obj)) {
            final Class<? extends MIObject> clazz = getMetaModelClass(obj);
            return new TypedAsrObjectLink(REMOVED, isParameterValueLink, isReferrableLink, clazz);
        }

        final IProjectContext projectContext = ModelAccessUtil.getProjectContext(obj);
        final IModelViewManagerCoreInternal mvm = projectContext.getService(IModelViewManagerCoreInternal.class);

        try (IModelViewExecutionContext ctx = mvm.executeUnfiltered()) {

            if (isReferrableLink) {
                return createReferrableObjectLink(mvm, (MIReferrable) obj);
            } else if (isParameterValueLink) {
                return createParameterObjectLink(projectContext, mvm, (MIParameterValue) obj);
            }

            return createOtherTypeObjectLink(mvm, obj);
        }
    }

    private static <T extends MIObject> Class<T> getMetaModelClass(MIObject obj) {
        @SuppressWarnings("unchecked")
        final Class<T> clazz = obj.mdfGetInterfaceClass();
        return clazz;
    }

    /**
     * This is no parameter and no referrable.
     *
     * @param mvm
     * @param obj
     * @return
     */
    private static <T extends MIObject> TypedAsrObjectLink<T> createOtherTypeObjectLink(IModelViewManagerCoreInternal mvm, MIObject obj) {
        if (ModelInternalUtil.isMemberOfModelTreeOutsideAutosarModel(obj)) {
            return null;
        }
        final ObjectLinkOtherTypeData otherData = ObjectLinkOtherTypeData.valueOf(mvm, obj);
        final Class<T> clazz = getMetaModelClass(obj);
        final TypedAsrObjectLink<T> link = new TypedAsrObjectLink<>(otherData, clazz);
        return link;

    }

    private static <T extends MIObject> TypedAsrObjectLink<T> createParameterObjectLink(IProjectContext projectContext, IModelViewManagerCoreInternal mvm, MIParameterValue obj) {
        final ObjectLinkVarianceData variance = ObjectLinkVarianceData.valueOf(mvm, obj);
        final String path = getBestEffortPath(obj);
        final ObjectLinkParameterData parameterData = ObjectLinkParameterData.valueOf(projectContext, obj);
        final Class<T> clazz = getMetaModelClass(obj);
        final TypedAsrObjectLink<T> link = new TypedAsrObjectLink<>(path, parameterData, variance, clazz);
        return link;
    }

    private static <T extends MIObject> TypedAsrObjectLink<T> createReferrableObjectLink(IModelViewManagerCoreInternal mvm, MIReferrable obj) {
        final ObjectLinkVarianceData variance = ObjectLinkVarianceData.valueOf(mvm, obj);
        final String path = getBestEffortPath(obj);
        final Class<T> clazz = getMetaModelClass(obj);
        final TypedAsrObjectLink<T> link = new TypedAsrObjectLink<>(path, variance, clazz);
        return link;
    }

    private static String getBestEffortPath(MIObject obj) {
        if (obj instanceof MIReferrable) {
            return getBestEffortPathOfReferrable((MIReferrable) obj);
        }
        final MIObject parent = obj.miImmediateComposite();
        if (parent == null) {
            return NO_PARENT;
        }
        return getBestEffortPath(parent);
    }

    private static String getBestEffortPathOfReferrable(MIReferrable obj) {
        MIObject refObject = obj;
        final StringBuilder path = new StringBuilder();
        boolean reachedRootObj = false;
        do {
            if (refObject instanceof MIReferrable) {
                obj = (MIReferrable) refObject;
                final String name = obj.getName();
                if (name == null || name.isEmpty()) {
                    path.insert(0, NO_SHORTNAME);
                } else {
                    path.insert(0, name);
                }
                path.insert(0, PATHSEP);
            }
            if (refObject instanceof MIAUTOSAR) {
                reachedRootObj = true;
            } else {
                refObject = refObject.miImmediateComposite(); // get parent object
                if (refObject == null) {
                    // Object not contained in the model hierarchy
                    path.insert(0, NO_ROOT);
                    return path.toString();
                }
            }
        } while (!reachedRootObj);

        return path.toString();
    }

    /**
     * Parses the string and returns the link.
     *
     * @param linkAsString
     * @return
     * @throws IllegalArgumentException if the string is <code>null</code> or the link cannot be created (e.g. wrong string format).
     */
    @PublishedMethod
    public static AsrObjectLink create(String linkAsString) {
        if (linkAsString == null) {
            throw new IllegalArgumentException("linkAsString is null");
        }
        linkAsString = linkAsString.trim();
        if (linkAsString.isEmpty()) {
            throw new IllegalArgumentException("linkAsString is empty");
        }

        final AsrObjectLink link = tryCreate(linkAsString);
        if (link == null) {
            throw new IllegalArgumentException("cannot create object link");
        }

        return link;
    }

    /**
     * Parses the string and returns the link or <code>null</code> if the link cannot be created (e.g. wrong string format).
     *
     * @param linkAsString
     * @return
     */
    @PublishedMethod
    public static AsrObjectLink tryCreate(String linkAsString) {
        if (linkAsString == null) {
            return null;
        }
        linkAsString = linkAsString.trim();
        if (linkAsString.isEmpty()) {
            return null;
        }

        if (REMOVED.equals(linkAsString)) {
            return new AsrObjectLink(REMOVED);
        } else if (NO_PARENT.equals(linkAsString) || NO_ROOT.equals(linkAsString) || NO_SHORTNAME.equals(linkAsString)) {
            return null;
        }

        final ObjectLinkOtherTypeData otherData = ObjectLinkOtherTypeData.valueOf(linkAsString);
        if (!otherData.isValid()) {
            return null; // Format error
        }
        if (!otherData.isEmpty()) {
            return new AsrObjectLink(otherData);
        }

        final ObjectLinkParameterData paramData = ObjectLinkParameterData.valueOf(linkAsString);
        final ObjectLinkVarianceData varData = ObjectLinkVarianceData.valueOf(linkAsString);

        if (!paramData.isValid() || !varData.isValid()) {
            return null; // Format error
        }

        final boolean isParameterValueLink = ObjectLinkParameterData.containsParameterData(linkAsString);

        // Get the best effort prefix (usually the AUTOSAR path)
        String bestEffortPath = null;
        if (isParameterValueLink) {
            bestEffortPath = ObjectLinkParameterData.getContainerPath(linkAsString);
        } else {
            if (!varData.isEmpty()) {
                bestEffortPath = ObjectLinkVarianceData.getContainerPath(linkAsString);
            }
        }
        if (bestEffortPath == null) {
            bestEffortPath = linkAsString;
        }

        if (!isValidBestEffortPath(bestEffortPath)) {
            return null;
        }

        if (isParameterValueLink) {
            return new AsrObjectLink(bestEffortPath, paramData, varData);
        } else {
            return new AsrObjectLink(bestEffortPath, varData);
        }
    }

    private static boolean isValidBestEffortPath(String bestEffortPath) {
        if (bestEffortPath.equals("/")) {
            return false; // Invalid absolute path
        }
        if (!bestEffortPath.startsWith("/")) {
            final boolean startsWithSpecialCasePrefix = bestEffortPath.startsWith(REMOVED) ||
                    bestEffortPath.startsWith(NO_PARENT) ||
                    bestEffortPath.startsWith(NO_ROOT) ||
                    bestEffortPath.startsWith(NO_SHORTNAME);
            return startsWithSpecialCasePrefix;
        }

        return true;
    }

    /**
     * Constructor for special cases.
     *
     * @param bestEffortPath
     */
    AsrObjectLink(String bestEffortPath) {
        this(bestEffortPath, false, false);
    }

    /**
     * Constructor for special cases (e.g. removed objects).
     *
     * @param bestEffortPath
     */
    AsrObjectLink(String bestEffortPath, boolean isParameterValueLink, boolean isReferrableLink) {
        checkArgument(bestEffortPath != null, "bestEffortPath is null");

        this.bestEffortPath = bestEffortPath;
        if (isValidShortnamePath(bestEffortPath)) {
            this.asrPath = AsrPath.create(bestEffortPath);
        } else {
            this.asrPath = null;
        }
        this.parameterData = ObjectLinkParameterData.valueOf();
        this.varianceData = ObjectLinkVarianceData.valueOf();
        this.isParameterValueLink = isParameterValueLink;
        this.isReferrableLink = isReferrableLink;

        this.otherTypeData = ObjectLinkOtherTypeData.valueOf();
    }

    /**
     * Constructor for {@link MIReferrable} links.
     *
     * @param bestEffortPath
     * @param variantNames
     */
    AsrObjectLink(String bestEffortPath, ObjectLinkVarianceData variantData) {
        checkArgument(bestEffortPath != null, "bestEffortPath is null");
        checkArgument(variantData != null, "variantData is null");

        this.bestEffortPath = bestEffortPath;
        if (isValidShortnamePath(bestEffortPath)) {
            this.asrPath = AsrPath.create(bestEffortPath);
        } else {
            this.asrPath = null;
        }
        this.parameterData = ObjectLinkParameterData.valueOf();
        this.varianceData = variantData;
        this.isParameterValueLink = false;
        this.isReferrableLink = true;

        this.otherTypeData = ObjectLinkOtherTypeData.valueOf();
    }

    /**
     * Constructor for {@link MIParameterValue} links.
     *
     * @param bestEffortPath
     * @param parameterData
     * @param variantNames
     */
    AsrObjectLink(String bestEffortPath, ObjectLinkParameterData parameterData, ObjectLinkVarianceData variantData) {
        checkArgument(bestEffortPath != null, "bestEffortPath is null");
        checkArgument(parameterData != null, "parameterData is null");
        checkArgument(variantData != null, "variantData is null");
        if (parameterData.getIndex() != null) {
            checkArgument(parameterData.getDefinitionShortname() != null, "definitionShortname is null but index is not");
        }

        this.bestEffortPath = bestEffortPath;
        if (isValidShortnamePath(bestEffortPath)) {
            this.asrPath = AsrPath.create(bestEffortPath);
        } else {
            this.asrPath = null;
        }
        this.parameterData = parameterData;
        this.varianceData = variantData;
        this.isParameterValueLink = true;
        this.isReferrableLink = false;

        this.otherTypeData = ObjectLinkOtherTypeData.valueOf();
    }

    /**
     * Constructor for types which are not parameters and not referrables.
     *
     * @param parentLink
     * @param isImmediateParent
     * @param otherObjType
     */
    AsrObjectLink(ObjectLinkOtherTypeData otherTypeData) {
        checkArgument(otherTypeData != null, "otherTypeData is null");

        this.otherTypeData = otherTypeData;

        this.bestEffortPath = ""; // To avoid null
        this.asrPath = null;
        this.parameterData = ObjectLinkParameterData.valueOf();
        this.varianceData = ObjectLinkVarianceData.valueOf();
        this.isParameterValueLink = false;
        this.isReferrableLink = false;
    }

    /**
     * Check these conditions.
     * <ul>
     * <li>Is an absolute AUTOSAR path</li>
     * <li>Does not contain {@link #NO_SHORTNAME}</li>
     * </ul>
     *
     * @param path
     * @return
     */
    private boolean isValidShortnamePath(String path) {
        if (path == null) {
            return false;
        }
        path = path.trim();
        if (path.isEmpty()) {
            return false;
        }
        if (path.charAt(0) != PATHSEP) {
            return false;
        }
        if (path.contains(NO_SHORTNAME)) {
            return false;
        }
        return true;
    }

    /**
     * Returns the AUTOSAR path of this object (if it is a referrable) or of its closest parent referrable (if not). Returns <code>null</code> if no such AUTOSAR path is
     * available.
     *
     * @return
     */
    @PublishedMethod
    public AsrPath getAsrPath() {
        if (!otherTypeData.isEmpty()) {
            final AsrObjectLink parentLink = otherTypeData.getParentLink();
            if (parentLink != null) {
                return parentLink.getAsrPath();
            }
        }
        return asrPath;
    }

    /**
     * Returns the parent object link if available.
     *
     * @return
     */
    @PublishedMethod
    public Optional<AsrObjectLink> getParentLink() {
        if (!otherTypeData.isEmpty()) {
            return Optional.fromNullable(otherTypeData.getParentLink());
        }

        if (isParameterValueLink) {
            final AsrObjectLink link = tryCreate(bestEffortPath);
            return Optional.fromNullable(link);
        } else if (isReferrableLink) {
            final String parentLinkPath = getParentLinkPath();
            final AsrObjectLink link = tryCreate(parentLinkPath);
            return Optional.fromNullable(link);
        }

        return Optional.absent();
    }

    private String getParentLinkPath() {
        if (asrPath == null) {
            if (bestEffortPath != null && bestEffortPath.charAt(0) == PATHSEP) {
                final String parentPath = AutosarUtil.getPathWithoutLastShortname(bestEffortPath);
                if (!Strings.isNullOrEmpty(parentPath)) {
                    return parentPath;
                }
            }
        } else {
            final AsrPath parentAsrPath = asrPath.getParentAsrPath();
            if (parentAsrPath != null) {
                return parentAsrPath.getAutosarPathString();
            }
        }
        return null;
    }

    /**
     * Returns all variant names, the object is visible in. If the object is visible in all variants (the object is invariant), this collection is empty. It never returns
     * <code>null</code>.
     *
     * @return
     */
    @PublishedMethod
    public List<String> getVariantNames() {
        if (!otherTypeData.isEmpty()) {
            final AsrObjectLink parentLink = otherTypeData.getParentLink();
            if (parentLink != null) {
                return parentLink.getVariantNames();
            }
        }
        return varianceData.getVariantNames();
    }

    /**
     * Returns <code>true</code> if the related object is removed from the MDF model.
     *
     * @return
     */
    @PublishedMethod
    public boolean isRemoved() {
        return bestEffortPath == REMOVED;
    }

    /**
     * Returns <code>true</code> if the related MDF model object is visible in all variants.
     *
     * @return
     */
    @PublishedMethod
    public boolean isInvariant() {
        return !varianceData.hasVariants() && !varianceData.isNeverVisible();
    }

    /**
     * Returns <code>true</code> if the related MDF model object is an instance of {@link MIParameterValue}.
     *
     * @return
     */
    @PublishedMethod
    public boolean isParameterValueLink() {
        return isParameterValueLink;
    }

    /**
     * Returns <code>true</code> if the related MDF model object is an instance of {@link MIReferrable}.
     *
     * @return
     */
    @PublishedMethod
    public boolean isReferrableLink() {
        return isReferrableLink;
    }

    /**
     * If the related model object is an instance of {@link MIParameterValue}, this method returns the shortname of the parameters definition.
     *
     * @return
     */
    @PublishedMethod
    public Optional<String> getParameterDefinitionShortname() {
        if (parameterData.hasWrongDefinition()) {
            return Optional.absent();
        }
        return Optional.fromNullable(parameterData.getDefinitionShortname());
    }

    /**
     * If the related model object is an instance of {@link MIParameterValue}, this method returns the parameters index. This is the index of all parameters with the same
     * definition below the same parent container instance in the unfiltered model view.
     *
     * @return
     */
    @PublishedMethod
    public Optional<Integer> getParameterIndex() {
        return Optional.fromNullable(parameterData.getIndex());
    }

    /**
     * Returns an AUTOSAR object which matches this link. See {@link AsrObjectLink} for details about restrictions of retrieving objects by link.
     * <p>
     * <b>Remarks concerning variance:</b>
     * <ul>
     * <li>When the link contains a variance part ("{variantA}" for example) the object is being retrieved with this visibility. The returned object may therefore be invisible
     * for the caller</li>
     * <li>When the link contains no variance part the object is being retrieved within the callers model view</li>
     * </ul>
     * </p>
     *
     * @param projectContext
     * @return
     * @throws IllegalArgumentException if the project context is <code>null</code> or disposed
     * @throws MultipleVariantObjectsException if more than one object have been found
     */
    @PublishedMethod
    public Optional<MIObject> getAutosarObject(final IProjectContext projectContext) {
        if (projectContext == null) {
            throw new IllegalArgumentException("projectContext is null");
        }
        if (projectContext.isDisposed()) {
            throw new IllegalArgumentException("projectContext is disposed");
        }

        if (asrPath == null) {
            return Optional.absent();
        }
        if (!otherTypeData.isEmpty()) {
            return Optional.absent(); // Not supported
        }

        final IModelViewManagerCoreInternal mvm = projectContext.getService(IModelViewManagerCoreInternal.class);
        if (varianceData.hasVariants()) {
            final String firstName = varianceData.getVariantNames().get(0);
            final IProjectVarianceAccess pva = projectContext.getService(IProjectVarianceAccess.class);
            final Optional<IPredefinedVariant> variant = getVariant(pva, firstName);
            if (variant.isPresent()) {
                try (IModelViewExecutionContext ctx = mvm.executeInVariant(variant.get())) {
                    // Run in the links view
                    return getAutosarObjectInternal(projectContext, mvm);
                }
            }
        } else {
            // Run in the callers view
            return getAutosarObjectInternal(projectContext, mvm);
        }
        return Optional.absent();
    }

    private Optional<MIObject> getAutosarObjectInternal(IProjectContext projectContext, IModelViewManagerCoreInternal mvm) {
        if (isReferrableLink) {
            return getReferrableObject(projectContext, mvm);
        } else if (isParameterValueLink) {
            return getParameterObject(projectContext, mvm);
        }
        return Optional.absent();
    }

    private Optional<IPredefinedVariant> getVariant(IProjectVarianceAccess pva, String variantName) {
        final Optional<IEvaluatedVariantSet> evs = pva.getEvaluatedVariantSet();
        if (evs.isPresent()) {
            return evs.get().getPredefinedVariant(variantName);
        }
        return Optional.absent();
    }

    private Optional<MIObject> getParameterObject(IProjectContext projectContext, IModelViewManagerCoreInternal mvm) {
        final MIReferrable referrable = asrPath.getAutosarObject(projectContext);
        if (referrable == null) {
            return Optional.absent();
        }
        if (referrable instanceof MIContainer) {
            final Optional<MIObject> parameterOpt = getParameterObject(mvm, projectContext.getService(IModelAccess.class), (MIContainer) referrable);
            if (parameterOpt.isPresent()) {
                if (isInvariant() || isVisibleInAllMyVariants(mvm, parameterOpt.get())) {
                    return parameterOpt;
                }
            }
        }

        return Optional.absent();
    }

    private Optional<MIObject> getParameterObject(IModelViewManagerCoreInternal mvm, IModelAccess ma, MIContainer container) {
        if (Strings.isNullOrEmpty(parameterData.getDefinitionShortname())) {
            return Optional.absent(); // No defintion specified
        }
        int i = 0; // default
        if (parameterData.getIndex() != null) {
            i = parameterData.getIndex().intValue();
        }

        // Handle the index in the unfiltered view!
        try (IModelViewExecutionContext ctx = mvm.executeUnfiltered()) {
            final List<MIHasDefinition> children = ma.getChildrenByDefinition(container, parameterData.getDefinitionShortname());
            final List<MIParameterValue> parameters = ModelInternalUtil.filterChildrenOfType(container, children, MIParameterValue.class, false);

            if (parameters.size() <= i) {
                return Optional.absent();
            }
            return Optional.of(parameters.get(i));
        }
    }

    private Optional<MIObject> getReferrableObject(IProjectContext projectContext, IModelViewManagerCoreInternal mvm) {
        final MIReferrable referrable = asrPath.getAutosarObject(projectContext);
        if (referrable == null) {
            return Optional.absent();
        }
        if (isVisibleInAllMyVariants(mvm, referrable)) {
            return Optional.of(referrable);
        }
        return Optional.absent();
    }

    /**
     * Returns <code>true</code> if the set of variants, the specified object is visible in, is a superset of the variants specified in the link.
     *
     * @param mvm
     * @param obj
     * @return
     */
    private boolean isVisibleInAllMyVariants(IModelViewManagerCoreInternal mvm, MIObject obj) {
        if (mvm.isModelInvariant(obj)) {
            return true;
        }
        final ObjectLinkVarianceData variance = ObjectLinkVarianceData.valueOf(mvm, obj);
        final boolean isSuperset = variance.getVariantNames().containsAll(varianceData.getVariantNames());
        return isSuperset;
    }

    /**
     * Creates a string representation of the object link.
     * <p>
     * <b>Examples:</b>
     * <ul>
     * <li>For a container or module configuration object, the AUTOSAR path is returned - "/MICROSAR/A/B"</li>
     * <li>For a parameter, the parents AUTOSAR path, the last shortname of its definition and a positional index in the list of parameters with the same definition is used -
     * "/MICROSAR/A/B[2:SomeDefName]"</li>
     * </ul>
     * </p>
     *
     * <p>
     * For objects which are neither parameters nor referrables, the method returns the AUTOSAR path of the first referrable parent object on the root path plus some type
     * information of the object itself.
     * </p>
     *
     * <p>
     * If an object is not visible in all variants, the variant name is added to this link (sorted alphabetically).
     * </p>
     * <p>
     * <b>Examples:</b>
     * <ul>
     * <li>/ActiveEcuC/Can/CanConfigSet/CanHardwareObject[0:CanControllerRef]{VariantA}</li>
     * <li>/ActiveEcuC/Can/CanConfigSet/CanHardwareObject[0:CanControllerRef]{VariantA,VariantB}</li>
     * </ul>
     * </p>
     *
     * @return
     */
    @PublishedMethod
    public String getObjectLinkString() {
        return getObjectLinkStringInternal(true, true);
    }

    /**
     * Implements the same behavior like {@link #getObjectLinkString()} but omits the final variant part.
     *
     * @return
     */
    @PublishedMethod
    public String getObjectLinkStringWithoutVariant() {
        return getObjectLinkStringInternal(true, false);
    }

    /**
     * Implements the same behavior like {@link #getObjectLinkString()} but omits the parameter index if all of the following conditions apply.
     * <ul>
     * <li>The object is a parameter</li>
     * <li>This parameters upper-multiplicity is 1</li>
     * <li>There is actually exactly one parameter present</li>
     * </ul>
     *
     * The returned object link can still be used to retrieve the parameter by {@link #getAutosarObject(IProjectContext)} (index 0 is assumed).
     *
     * @return
     */
    @PublishedMethod
    public String getShortObjectLinkString() {
        return getObjectLinkStringInternal(false, true);
    }

    @KeepSecretFromPublishedApi
    public String getShortObjectLinkStringWithoutVariant() {
        return getObjectLinkStringInternal(false, false);
    }

    private String getObjectLinkStringInternal(boolean withOptional0Index, boolean withVariant) {
        if (!otherTypeData.isEmpty()) {
            return getObjectOtherLinkStringInternal(withOptional0Index, withVariant);
        }

        if (isRemoved()) {
            return bestEffortPath;
        }

        final StringBuilder s = new StringBuilder(bestEffortPath);
        if (isParameterValueLink) {
            parameterData.append(s, withOptional0Index);
        }

        if (withVariant) {
            varianceData.append(s);
        }

        return s.toString();
    }

    private String getObjectOtherLinkStringInternal(boolean withOptional0Index, boolean withVariant) {
        final StringBuilder s = new StringBuilder();
        otherTypeData.append(s, withOptional0Index, withVariant);
        return s.toString();
    }

    /**
     *
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return AsrObjectLink.class.getSimpleName() + ": " + getObjectLinkString();
    }

    private static final int prime1231 = 1231;

    private static final int prime1237 = 1237;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((asrPath == null) ? 0 : asrPath.hashCode());
        result = prime * result + ((bestEffortPath == null) ? 0 : bestEffortPath.hashCode());
        result = prime * result + (isParameterValueLink ? prime1231 : prime1237);
        result = prime * result + (isReferrableLink ? prime1231 : prime1237);
        result = prime * result + ((otherTypeData == null) ? 0 : otherTypeData.hashCode());
        result = prime * result + ((parameterData == null) ? 0 : parameterData.hashCode());
        result = prime * result + ((varianceData == null) ? 0 : varianceData.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof AsrObjectLink)) {
            return false;
        }
        final AsrObjectLink other = (AsrObjectLink) obj;
        if (asrPath == null) {
            if (other.asrPath != null) {
                return false;
            }
        } else if (!asrPath.equals(other.asrPath)) {
            return false;
        }
        if (bestEffortPath == null) {
            if (other.bestEffortPath != null) {
                return false;
            }
        } else if (!bestEffortPath.equals(other.bestEffortPath)) {
            return false;
        }
        if (isParameterValueLink != other.isParameterValueLink) {
            return false;
        }
        if (isReferrableLink != other.isReferrableLink) {
            return false;
        }
        if (otherTypeData == null) {
            if (other.otherTypeData != null) {
                return false;
            }
        } else if (!otherTypeData.equals(other.otherTypeData)) {
            return false;
        }
        if (parameterData == null) {
            if (other.parameterData != null) {
                return false;
            }
        } else if (!parameterData.equals(other.parameterData)) {
            return false;
        }
        if (varianceData == null) {
            if (other.varianceData != null) {
                return false;
            }
        } else if (!varianceData.equals(other.varianceData)) {
            return false;
        }
        return true;
    }

}
