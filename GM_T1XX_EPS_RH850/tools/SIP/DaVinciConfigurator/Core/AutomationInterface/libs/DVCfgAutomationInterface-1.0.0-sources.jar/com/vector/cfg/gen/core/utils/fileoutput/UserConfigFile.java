package com.vector.cfg.gen.core.utils.fileoutput;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.IGeneratorModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelException;
import com.vector.cfg.gen.core.bswmdmodel.param.GString;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultUtil;
import com.vector.cfg.util.IPathManager;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The UserConfigFile class abstracts the inclusion of userfiles into output file.
 *
 * <p>
 * The file encoding of the user files must be "ISO-8859-1".
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class UserConfigFile {
    private static final ILogger logger = Logger.INSTANCE.createLogger(UserConfigFile.class);

    private static final String START_TAG_USER_CONFIG_FILE = "/* User Config File Start */" + GenConstants.LINE_SEPARATOR;

    private static final String END_TAG_USER_CONFIG_FILE = "/* User Config File End */" + GenConstants.LINE_SEPARATOR;

    /**
     * <code>FILE_ENCODING</code> describes the used file encoding to read the UserConfigFile.
     */
    private static final String FILE_ENCODING = "ISO-8859-1";

    private String userFileContent;

    private final IGeneratorPackage genPackage;

    /**
     * Constructs a new UserConfigFile by by the filepath and a description.
     *
     * <p>
     * The fileDescription is used to report an error message to the user. Please pay attention to the description. MessageFormat : UserConfigFile
     * {fileDescription} with path {filePath} of module {YourModule} could not be found.
     * </p>
     *
     * <p>
     * If the filepath is != <code>null</code> && not empty && does not exists: A Error is reported into the {@link IGeneratorResultSink} of the passed
     * generatorPackage. Then the generated userFileContent is "".
     * </p>
     *
     *
     * @param genPackage The generator package
     * @param filePath The relative or absolute path to the userfile. Relative paths refer to the working folder the Cfg5 was started with. Use Cfg5 Path
     * variables to use the SipRootPath or the ProjectFolder.
     * @param fileDescription
     *
     * @exception IllegalArgumentException <ul>
     * <li>if genPackage is null</li>
     * <li>if fileDescription is null or empty</li>
     * </ul>
     */
    @PublishedMethod
    public UserConfigFile(IGeneratorPackage genPackage, String filePath, String fileDescription) {
        if (genPackage == null) {
            throw new IllegalArgumentException("genPackage is null");
        }
        if (fileDescription == null || fileDescription.isEmpty()) {
            throw new IllegalArgumentException("The fileDescription must not be null and must contain content about the file.");
        }

        this.genPackage = genPackage;

        if (filePath != null && !filePath.isEmpty()) {

            final String resolvedFilePath = resolvePathString(filePath, fileDescription);

            if (resolvedFilePath == null) {
                setUserFileContent("");
                return;
            }

            final File file = new File(resolvedFilePath);
            if (!file.exists()) {
                getResultSink().reportGeneratorResult(
                        GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getUserConfigFileNotFoundId(genPackage),
                                "UserConfigFile {0} with path {1} of module {2} could not be found", fileDescription, file.getAbsolutePath(), genPackage.getMSN()).buildResult());
                setUserFileContent("");
            } else {
                setUserFileContent(readFile(file, fileDescription, null));
            }
        } else {
            setUserFileContent("");
        }
    }

    /**
     * Constructs a new UserConfigFile by a bswmdModel parameter.
     *
     * <p>
     * If the filepath does not exists: A Error is reported into the {@link IGeneratorResultSink} of the passed generatorPackage. Then the generated
     * userFileContent is "".
     * </p>
     *
     * @param fileParameter The fileParameter of the BswmdModel
     *
     * @exception IllegalArgumentException <ul>
     * <li>if fileParameter is null</li>
     * </ul>
     *
     */
    @PublishedMethod
    public UserConfigFile(GString fileParameter) {
        if (fileParameter == null) {
            throw new IllegalArgumentException("fileParameter is null");
        }
        if (!(fileParameter.getGeneratorModelAccess() instanceof IGeneratorModelAccess)) {
            throw new IllegalArgumentException("The passed fileParameter, was not created in a GeneratorPackage context. You could only use a BswmdModel for Generators!");
        }

        this.genPackage = ((IGeneratorModelAccess) fileParameter.getGeneratorModelAccess()).getGeneratorPackage();

        if (!fileParameter.existsMDF()) {
            // The Parameter does not exist
            if (fileParameter.isRequiredParameter()) {
                /*
                 * Report that the parameter is required
                 */
                try {
                    fileParameter.getValue();
                } catch (final BswmdModelException ex) {
                    getResultSink().reportValidationResult(ex.getResults());
                }
            }
        }

        if (fileParameter.hasValueAndNotEmpty()) {

            final String fileString = resolvePathBswmd(fileParameter);

            if (fileString == null) {
                setUserFileContent("");
                return;
            }
            final File file = new File(fileString);

            if (!file.exists()) {

                getResultSink().reportGeneratorResult(
                        GeneratorResultBuilder
                                .newBuilder(CommonGeneratorResultIds.getUserConfigFileNotFoundId(genPackage), "UserConfigFile {0} configured by parameter {1} could not be found",
                                        file.getAbsolutePath(), fileParameter)
                                .addErrorObject(fileParameter).buildResult());
                setUserFileContent("");
            } else {
                setUserFileContent(readFile(file, "", fileParameter));
                return;

            }
        } else {
            setUserFileContent("");
        }

        // Error or Empty Path

    }

    /**
     * @param fileParameter
     * @return
     */
    private String resolvePathBswmd(GString fileParameter) {
        try {

            return resolvePathInternal(fileParameter.getValue());
        } catch (final IllegalArgumentException ex) {
            getResultSink().reportGeneratorResult(
                    GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasIllegalValue(genPackage),
                            "UserConfigFile configured by parameter {0} could not be resolved to a concrete file. {1}", fileParameter, ex.getMessage()).buildResult());
            return null;

        }
    }

    /**
     * @param fileParameter
     * @return
     */
    private String resolvePathString(String filePath, String fileDescription) {
        try {

            return resolvePathInternal(filePath);
        } catch (final IllegalArgumentException ex) {
            getResultSink().reportGeneratorResult(
                    GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getParameterHasIllegalValue(genPackage),
                            "UserConfigFile {0} with path {1} of module {2} could not be resolved to a concrete file. {3}", fileDescription, filePath, genPackage.getMSN(),
                            ex.getMessage()).buildResult());
            return null;

        }
    }

    /**
     * @param fileParameter
     * @return
     */
    private String resolvePathInternal(String pathValue) {

        final IPathManager pathManager = genPackage.getProjectContext().getService(IPathManager.class);
        final String fileString = pathManager.resolvePathWithoutQuotes(pathValue);
        return fileString;

    }

    /**
     * @return
     *
     */
    private IGeneratorResultSink getResultSink() {
        final IGeneratorResultSink sink = GeneratorResultUtil.getResultSink(genPackage);
        return sink;
    }

    /**
     * Returns the content of the UserConfigFile.
     *
     * @return Filecontent as string
     */
    @PublishedMethod
    public String generateFileContent() {
        return userFileContent;
    }

    /**
     * Reads the userConfigFile.
     *
     * @param file
     * @param fileDescription
     * @param fileParameter
     * @return
     */
    private String readFile(File file, String fileDescription, GString fileParameter) {
        try {
            final char[] buf = new char[1];
            final StringBuilder sb = new StringBuilder();
            final InputStreamReader sr = new InputStreamReader(new FileInputStream(file), FILE_ENCODING);
            try {
                while ((sr.read(buf)) > 0) {
                    sb.append(buf);
                }
                return sb.toString();
            } finally {
                sr.close();
            }

        } catch (final IOException e) {
            logger.error(e);

            final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getUserConfigFileNotFoundId(genPackage),
                    "UserConfigFile {0} with path {1} of module {1} could not be read: {2}", fileDescription, file.getAbsolutePath(), genPackage.getMSN(), e.getMessage());

            if (fileParameter != null) {
                builder.addErrorObject(fileParameter);
            }

            getResultSink().reportGeneratorResult(builder.buildResult());
            return "";
        }
    }

    private void setUserFileContent(String s) {
        if (s.endsWith(GenConstants.LINE_SEPARATOR)) {
            /*
             * Content of UserFile already ends with "\n" -> no modification needed.
             */
            userFileContent = String.format("%s%s%s", START_TAG_USER_CONFIG_FILE, s, END_TAG_USER_CONFIG_FILE);
        } else {
            /*
             * Content of UserFile does not end with "\n" -> add a new line
             */
            userFileContent = String.format("%s%s%s%s", START_TAG_USER_CONFIG_FILE, s, GenConstants.LINE_SEPARATOR, END_TAG_USER_CONFIG_FILE);
        }
    }
}
