package com.vector.cfg.gen.core.utils.query.selectors;

import java.text.MessageFormat;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.ElementSelector;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GenParamSelector<E extends GIParameter<?>> extends ElementSelector<GIContainer, E> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenParamSelector.class);

    private final DefRef paramName;

    @PublishedMethod
    public GenParamSelector(DefRef paramName) {
        this.paramName = paramName;

    }

    /**
     * {@inheritDoc}
     */

    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    public E getSelection(GIContainer parentElementSet) {

        final List<GIParameter<?>> paramList = parentElementSet.getParameters(paramName);
        if (paramList.size() > 1) {
            throw new IllegalArgumentException(MessageFormat.format(
                    "The parameter ({0}) has no 1:1 relation. Please you the GenParamManySelector for parameter with multiplicity *.", paramName));
        } else if (paramList.size() == 0) {
            return null;
        } else {

            return (E) paramList.get(0);
        }

    }

}