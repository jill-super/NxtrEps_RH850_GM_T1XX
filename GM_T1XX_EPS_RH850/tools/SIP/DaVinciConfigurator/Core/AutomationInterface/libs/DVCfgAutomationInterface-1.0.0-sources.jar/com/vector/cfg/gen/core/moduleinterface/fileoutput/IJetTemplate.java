package com.vector.cfg.gen.core.moduleinterface.fileoutput;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;

/**
 * Interface for all Jet templates. Every jet template must implement this interface.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients. Please use abstract class AbstractJetTemplate
 * @see IGenerationProcessor
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IJetTemplate extends IGeneratorPackageReferable {

    @PublishedField
    Class<? extends IJetTemplate> EMPTY_TEMPLATE = EmptyJetTemplate.class;

    /**
     * Gets the corresponding output file of the template.
     *
     * @return The output file
     */
    @PublishedMethod
    IOutputFile getOutputFile();

    /**
     * FRAMEWORK INTERNAL USE ONLY! Do not call this method!
     *
     * @param outputFile the new output file
     */
    @PublishedMethod
    void setOutputFile(IOutputFile outputFile);

    /**
     * Generate template content.
     *
     * <p>
     * Please use this method instead of {@link #generate(Object)}
     * </p>
     *
     * @return the generated content as string
     */
    @PublishedMethod
    String generateTemplate();

    /**
     * Generates the template content with the dataRepresentation.
     *
     * <p>
     * This method is the JET internal method. DO NOT USE THIS METHOD! Use {@link #generateTemplate()} instead.
     * </p>
     *
     * @param dataRepresentation the dataRep of the {@link IGenerationProcessor}.
     * @return The generated template content
     */
    @PublishedMethod
    String generate(final Object dataRepresentation);
}
