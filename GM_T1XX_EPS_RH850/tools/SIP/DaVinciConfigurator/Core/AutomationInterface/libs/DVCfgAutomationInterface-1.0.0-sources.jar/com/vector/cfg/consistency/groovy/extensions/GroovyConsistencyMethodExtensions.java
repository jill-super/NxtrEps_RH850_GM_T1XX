package com.vector.cfg.consistency.groovy.extensions;

import java.util.Collection;
import java.util.stream.Collectors;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.services.ActiveProjectContextHolder;
import com.vector.cfg.consistency.groovy.api.IValidationApi;
import com.vector.cfg.consistency.ui.IValidationResultUI;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * This class contains consistency-related groovy-extension-methods, e.g. for getting validation-results of an {@link MIObject} or {@link DefRef}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class GroovyConsistencyMethodExtensions {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GroovyConsistencyMethodExtensions.class);

    private GroovyConsistencyMethodExtensions() {
    }

    /**
     * <div class="extdoc" id="getValidationResultsExtDefRef"><code>DefRef.getValidationResults()</code> returns the validation-results for which
     * {@link IValidationResultUI#matchErroneousCE(MIHasDefinition, DefRef)} returns true. <br/>
     * The context project for this call is the active project, see <code>ScriptApi.getActiveProject()</code>. </div>
     *
     * @param defRef the def ref
     * @return the validation results
     */
    // DefRef
    @PublishedMethod
    public static Collection<IValidationResultUI> getValidationResults(final DefRef defRef) {
        final IValidationApi validationApi = ActiveProjectContextHolder.INSTANCE.getCurrentActiveProjectOfThisThreadChecked().getService(IValidationApi.class);
        return validationApi.getValidationResults().stream().filter(vr -> vr.matchErroneousCE(null, defRef)).collect(Collectors.toList());
    }

    /**
     * Returns the {@link IValidationResultUI}s for the model object.
     *
     * <div class="extdoc" id="getValidationResultsExtMiObject"><code>MIObject.getValidationResults()</code> returns the validation-results of an {@link MIObject}. These are
     * those results for which {@link IValidationResultUI#matchErroneousCE(MIObject)} returns true. </div>
     *
     * @param self the model object
     * @return the validation results
     */
    @PublishedMethod
    public static Collection<IValidationResultUI> getValidationResults(final MIObject self) {
        final IValidationApi validationApi = ModelUtil.getService(self, IValidationApi.class);
        return validationApi.getValidationResults().stream().filter(vr -> vr.matchErroneousCE(self)).collect(Collectors.toList());
    }

    /**
     * Returns the {@link IValidationResultUI}s for the model object.
     *
     * <div class="extdoc" id="getValidationResultsExtViewedModelObject"><code>IViewedModelObject.getValidationResults()</code> returns the validation-results for which the
     * following condition is true:<br/>
     * <code>IValidationResultUI.matchErroneousCE(theObject) && (IValidationResultUI.isGeneralVariantContext() ||
     * IValidationResultUI.getPredefinedVariantContexts().contains(theView)</code>. </div>
     *
     * @param self the model object
     * @return the validation results
     */
    @PublishedMethod
    public static Collection<IValidationResultUI> getValidationResults(final IViewedModelObject self) {
        final MIObject mdfObject = self.getMdfObject();
        final IModelView modelView = self.getCreationModelView();
        final IValidationApi validationApi = ModelUtil.getService(mdfObject, IValidationApi.class);
        return validationApi.getValidationResults()
                .stream()
                .filter(vr -> vr.matchErroneousCE(mdfObject) && (vr.isGeneralVariantContext() || vr.getPredefinedVariantContexts().contains(modelView)))
                .collect(Collectors.toList());
    }
}
