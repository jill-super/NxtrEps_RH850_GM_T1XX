package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelReferenceTargetException;
import com.vector.cfg.gen.core.bswmdmodel.param.GInstanceReference;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucAbstractRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;

/**
 * Base interface of bswmd model references.
 *
 * <div class="extdoc" id="Common"> All references in the BswmdModel are subtypes of {@link GIReference}. The generated model contains generated DefintionTyped classes for
 * references to container, for the other references their are only Untyped classes like {@link GInstanceReference}.
 *
 * <p>
 * A {@link GIReference} has the method <code>getRefTargetMdf()</code>, this will always return the target in the MDF model as {@link MIReferrable}. For non
 * {@link GIReferenceToContainer} this is the normal way to resolve references, but for reference to container you should always try to use the method
 * <code>getRefTarget()</code>, which will not leave the BswmdModel.
 * </p>
 * <p>
 * <b>Note:</b> Try to use <code>getRefTarget()</code> as much as possible.
 *
 * </p>
 *
 * </div>
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIReference<REF_TARGET extends MIReferrable> extends GIParamOrRef {
    // CHECKSTYLE:ON
    /**
     * Returns <code>true</code> if the reference has an AUTOSAR reference path.
     *
     * @return
     */
    @PublishedMethod
    boolean hasPath();

    /**
     * Returns <code>true</code> if the reference could be resolved and points to a target object.
     *
     * @return
     */
    @PublishedMethod
    boolean hasRefTarget();

    /**
     * Returns the AUTOSAR reference path.
     *
     * @return
     */
    @PublishedMethod
    String getPath();

    /**
     * Returns the resolved target object.
     *
     * @return
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the reference does not exist</li>
     * </ul>
     * @exception BswmdModelReferenceTargetException
     * <ul>
     * <li>if the target of the reference is null or has an invalid value</li>
     * </ul>
     */
    @PublishedMethod
    REF_TARGET getRefTargetMdf();

    /**
     * Sets the specified target object as reference target of the specified reference parameter.
     *
     * If the referenceTarget is <code>null</code>, the complete reference parameter is being removed from the model.
     *
     *
     * @param referenceTarget
     *
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    void setRefTargetMdf(REF_TARGET referenceTarget);

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucAbstractRef getEcucDefinition();
}
