package com.vector.cfg.gen.core.moduleinterface.fileoutput;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * <div class="extdoc" id="IArgumentedJetTemplateKey">
 * <h4>Including registered argumented templates</h4> With the interface {@link IArgumentedJetTemplateKey} a registered sub template key can be specified as an argumented
 * template. The template registration enum has to implement this interface.
 *
 * <p>
 * Example:
 * </p>
 *
 * <pre>
 * <code class="Java" id="Example for a Template Enumeration with argumented templates">
 * public enum ESubTemplates implements IArgumentedJetTemplateKey {
 *
 *  CONTENT1(true),
 *  CONTENT2(false);
 *
 *  private boolean isArgumentedTemplate;
 *
 *  ESubTemplates(final boolean isArgumentedTemplate) {
 *      this.isArgumentedTemplate = isArgumentedTemplate;
 *  }
 *
 *  public boolean isArgumentedTemplate() {
 *      return isArgumentedTemplate;
 *  }
 *</code>
 * </pre>
 *
 * </div>
 *
 * @see {@link IArgumentedJetTemplate}
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IArgumentedJetTemplateKey {

    @PublishedMethod
    boolean isArgumentedTemplate();
}
