package com.vector.cfg.automation.api.project;

import java.nio.file.Path;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.api.Converters;

/**
 * {@link IOpenProjectApi} provides means for parameterizing the process of opening a project.
 * <div class="extdoc" id="IOpenProjectApi"><!--Label:IOpenProjectApi-->{@link IOpenProjectApi} provides means for parameterizing the process of opening a project.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IOpenProjectApi {

    /**
     * Alias for {@link #setDpaFile(Object)}.
     */
    @PublishedMethod
    void dpaFile(Object dpaFile);

    /**
     * Using {@link #setDpaFile(Object)} the .dpa file of the project to be opened can be specified. <div class="extdoc" id="setDpaFile"><!--Label:IOpenProjectApi.setDpaFile-->
     * <h5>DPA File</h5> Using {@link #setDpaFile(Object)} the .dpa file of the project to be opened can be specified. The value given here is converted to {@link Path} using
     * {@link Converters#TO_SCRIPT_PATH} <!--Ref:Converters.TO_SCRIPT_PATH-->.</div>
     *
     * @param dpaFile the .dpa file of the project to be opened
     */
    @PublishedMethod
    void setDpaFile(Object dpaFile);

    /**
     * Alias for {@link #setLoadGenerators(boolean)}.
     */
    @PublishedMethod
    void loadGenerators(boolean generators);

    /**
     * Using {@link #setLoadGenerators(boolean)} is can be specified whether or not to activate generators (including their validations) for the opened project.
     * <div class="extdoc" id="setLoadGenerators"><!--Label:IOpenProjectApi.setLoadGenerators-->
     * <h5>Generators</h5> Using {@link #setLoadGenerators(boolean)} is can be specified whether or not to activate generators (including their validations) for the opened
     * project.</div>
     *
     * @param generators whether or not to activate generators (including their validations) for the project
     */
    @PublishedMethod
    void setLoadGenerators(boolean generators);

    /**
     * Alias for {@link #setEnableValidation(boolean)}.
     */
    @PublishedMethod
    void enableValidation(boolean validation);

    /**
     * Using {@link #setEnableValidation(boolean)} is can be specified whether or not to activate validation for the opened project.
     * <div class="extdoc" id="setEnableValidation"><!--Label:IOpenProjectApi.setEnableValidation-->
     * <h5>Validation</h5> Using {@link #setEnableValidation(boolean)} is can be specified whether or not to activate validation for the opened project.</div>
     *
     * @param validation
     */
    @PublishedMethod
    void setEnableValidation(boolean validation);

}
