/**
 * The base API of interfaces to implement and call Automation scripts.
 *
 * Every script and script task loaded from the Automation service, will be instances of the types defined in this package.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.scripting.base;