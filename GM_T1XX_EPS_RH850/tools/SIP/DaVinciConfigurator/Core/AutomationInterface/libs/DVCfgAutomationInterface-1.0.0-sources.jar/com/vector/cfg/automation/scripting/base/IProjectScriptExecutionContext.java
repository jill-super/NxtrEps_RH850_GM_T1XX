package com.vector.cfg.automation.scripting.base;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.cfg.util.scripting.dynamic.DynamicTarget;

/**
 * {@link IProjectScriptExecutionContext} is the sub type of an {@link IScriptExecutionContext}, which provides access to the current active project.
 * <p>
 * The active project is passed by the script task caller to the {@link IScriptTask#call(com.vector.cfg.util.servicecontext.IServiceContext, Object...)} method.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IScriptExecutionContext
 */
@DynamicTarget({
        "com.vector.cfg.automation.scripting.api.project.IProject"
})
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProjectScriptExecutionContext extends IScriptExecutionContext {

}
