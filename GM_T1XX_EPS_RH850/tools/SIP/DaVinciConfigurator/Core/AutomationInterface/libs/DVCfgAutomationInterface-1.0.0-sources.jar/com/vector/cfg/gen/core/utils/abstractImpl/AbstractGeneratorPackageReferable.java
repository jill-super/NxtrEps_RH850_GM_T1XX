package com.vector.cfg.gen.core.utils.abstractImpl;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;

/**
 * This class provides a skeletal implementation of the <tt>{@link IGeneratorPackageReferable IGeneratorPackageReferable}</tt> interface, to minimize the effort
 * required to implement this interface.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 * @see IGeneratorPackageReferable
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractGeneratorPackageReferable implements IGeneratorPackageReferable {

    @PublishedField
    protected final IGeneratorPackage generatorPackage;

    /**
     * Instantiates a new abstract generator package referable.
     *
     * @param generatorPackageRef another {@link IGeneratorPackageReferable} for the current generator.
     */
    @PublishedMethod
    public AbstractGeneratorPackageReferable(IGeneratorPackageReferable generatorPackageRef) {
        if (generatorPackageRef == null) {
            throw new IllegalArgumentException("generatorPackageRefereable is null");
        }
        if (generatorPackageRef.getGeneratorPackage() == null) {
            throw new IllegalArgumentException("generatorPackageRefereable reference to generatorPackage is null");
        }
        this.generatorPackage = generatorPackageRef.getGeneratorPackage();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IGeneratorPackage getGeneratorPackage() {
        if (generatorPackage == null) {
            throw new IllegalStateException("The Generator package was not yet set. It is null");
        }

        return generatorPackage;
    }

}
