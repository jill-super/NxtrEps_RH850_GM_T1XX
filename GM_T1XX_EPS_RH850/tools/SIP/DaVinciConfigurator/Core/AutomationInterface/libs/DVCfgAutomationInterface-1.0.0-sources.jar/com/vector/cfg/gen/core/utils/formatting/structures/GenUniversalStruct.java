package com.vector.cfg.gen.core.utils.formatting.structures;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The generic Format class for structured elements. You can choose the used separators of blocks and elements.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GenUniversalStruct extends AbstractGenStructure<GenUniversalStruct> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenUniversalStruct.class);

    @PublishedMethod
    protected GenUniversalStruct(String blockOpenTag, String blockCloseTag, String elementSeperationTag) {
        super(blockOpenTag, blockCloseTag, elementSeperationTag);

    }

    /**
     * Creates a new GenUniversalStruct and returns the new instance.
     *
     * @param blockOpenTag The text used to open a block
     * @param blockCloseTag The text used to close the block.
     * @param elementSeperationTag The element separation text.
     * @return The new GenArray
     */

    @PublishedMethod
    public static GenUniversalStruct create(String blockOpenTag, String blockCloseTag, String elementSeperationTag) {
        final GenUniversalStruct genArray = new GenUniversalStruct(blockOpenTag, blockCloseTag, elementSeperationTag);

        return genArray;

    }

    /**
     * {@inheritDoc}
     */

    @PublishedMethod
    @Override
    public GenUniversalStruct createInner() {
        ensureObjectIsMutable();
        final GenUniversalStruct inner = new GenUniversalStruct(blockOpenTag, blockCloseTag, elementSeperationTag);
        this.append(inner);

        return inner;
    }

}
