package com.vector.cfg.core.derivative;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Data structure containing (display-)value and uuid of a single implementation property.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public final class ImplementationProperty {
    private static final int HALF_INTEGER_BIT_SIZE = Integer.SIZE >> 1;

    private static final int LOWER_HALF_BIT_MASK = Integer.MAX_VALUE >> (HALF_INTEGER_BIT_SIZE - 1);

    private final String implValue;

    private final String implUUID;

    @PublishedMethod
    public ImplementationProperty(final String implValue, final String implUUID) {
        // Safety, internal values should always contain at least an empty string
        if (implValue != null) {
            this.implValue = implValue;
        } else {
            this.implValue = "";
        }
        if (implUUID != null) {
            this.implUUID = implUUID.toUpperCase();
        } else {
            this.implUUID = "";
        }
    }

    /**
     * Get (display-)value of implementation property.
     */
    @PublishedMethod
    public String getValue() {
        return implValue;
    }

    /**
     * Get uuid of implementation property.
     */
    @PublishedMethod
    public String getUUID() {
        return implUUID;
    }

    /**
     * Get value and uuid in the notation 'value[uuid]'.
     */
    @KeepSecretFromPublishedApi
    public String toFormattedString() {
        return String.format("%s[%s]", getValue(), getUUID());
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof ImplementationProperty) {

            final ImplementationProperty other = (ImplementationProperty) obj;
            // Check only whether UUID is the same as (Display-)Value may change
            if (!implUUID.isEmpty()) {
                return implUUID.equals(other.getUUID());
            } else {
                return implValue.toLowerCase().equals(other.getValue().toLowerCase());
            }

        } else if (obj instanceof String) {

            final String other = (String) obj;
            final boolean nameCheck = implValue.toLowerCase().equals(other.toLowerCase());
            return nameCheck || (!implUUID.isEmpty() && implUUID.equals(other));

        }

        return false;
    }

    @Override
    public int hashCode() {
        int result = 0;
        if (implValue != null) {
            result = implValue.hashCode() << HALF_INTEGER_BIT_SIZE;
        }
        if (implUUID != null) {
            result ^= implUUID.hashCode() ^ LOWER_HALF_BIT_MASK;
        }
        return result;
    }

    @Override
    public String toString() {
        return String.format("(%s,%s)", getValue(), getUUID());
    }
}
