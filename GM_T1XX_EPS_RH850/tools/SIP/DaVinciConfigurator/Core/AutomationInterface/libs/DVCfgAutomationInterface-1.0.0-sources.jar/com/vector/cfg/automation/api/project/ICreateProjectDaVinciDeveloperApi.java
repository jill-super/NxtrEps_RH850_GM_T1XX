package com.vector.cfg.automation.api.project;

import java.nio.file.Path;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.api.Converters;
import com.vector.cfg.business.Constraints;

/**
 * {@link ICreateProjectDaVinciDeveloperApi} provides means for specifying the new project's DaVinci Developer settings.
 * <div class="extdoc" id="ICreateProjectDaVinciDeveloperApi"><!--Label:ICreateProjectDaVinciDeveloperApi-->{@link ICreateProjectDaVinciDeveloperApi} provides means for
 * specifying the new project's DaVinci Developer settings.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectDaVinciDeveloperApi {

    /**
     * Alias for {@link #setCreateDaVinciDeveloperWorkspace(boolean)}.
     */
    @PublishedMethod
    void createDaVinciDeveloperWorkspace(boolean createDaVinciDeveloperWorkspace);

    /**
     * Using {@link #setCreateDaVinciDeveloperWorkspace(boolean)} it can be specified whether or not to create a DaVinci Developer workspace for the new project.
     * <div class="extdoc" id="setCreateDaVinciDeveloperWorkspace"><!--Label:ICreateProjectDaVinciDeveloperApi.setCreateDaVinciDeveloperWorkspace-->
     * <h5>Create DEV Workspace</h5> Using {@link #setCreateDaVinciDeveloperWorkspace(boolean)} it can be specified whether or not to create a DaVinci Developer workspace for
     * the new project. This is an optional parameter defaulting to {@code true} if and only if a compatible DaVinci Developer installation can be detected and the parameter is
     * not provided explicitly.</div>
     *
     * @param createDaVinciDeveloperWorkspace whether or not to create a DaVinci Developer workspace for the new project
     */
    @PublishedMethod
    void setCreateDaVinciDeveloperWorkspace(boolean createDaVinciDeveloperWorkspace);

    /**
     * Alias for {@link #setDaVinciDeveloperExecutable(Object)}.
     */
    @PublishedMethod
    void daVinciDeveloperExecutable(@Nonnull Object daVinciDeveloperExecutable);

    /**
     * Using {@link #setDaVinciDeveloperExecutable(Object)} the DaVinci Developer executable for the new project can be specified.
     * <div class="extdoc" id="setDaVinciDeveloperExecutable"><!--Label:ICreateProjectDaVinciDeveloperApi.setDaVinciDeveloperExecutable-->
     * <h5>DEV Executable</h5> Using {@link #setDaVinciDeveloperExecutable(Object)} the DaVinci Developer executable for the new project can be specified. This is an optional
     * parameter defaulting to the location of a compatible DaVinci Developer installation (if there is any) if the parameter is not provided explicitly. The value given here is
     * converted to {@link Path} using {@link Converters#TO_SCRIPT_PATH} <!--Ref:Converters.TO_SCRIPT_PATH-->. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_COMPATIBLE_DA_VINCI_DEV_EXECUTABLE} <!--Ref:Constraints.IS_COMPATIBLE_DA_VINCI_DEV_EXECUTABLE--></li>
     * </ul>
     * </div>
     *
     * @param daVinciDeveloperExecutable the DaVinci Developer executable for the new project
     */
    @PublishedMethod
    void setDaVinciDeveloperExecutable(@Nonnull Object daVinciDeveloperExecutable);

    /**
     * Alias for {@link #setDaVinciDeveloperWorkspace(Object)}.
     */
    @PublishedMethod
    void daVinciDeveloperWorkspace(@Nonnull Object daVinciDeveloperWorkspace);

    /**
     * Using {@link #setDaVinciDeveloperWorkspace(Object)} the DaVinci Developer workspace for the new project can be specified.
     * <div class="extdoc" id="setDaVinciDeveloperWorkspace"><!--Label:ICreateProjectDaVinciDeveloperApi.setDaVinciDeveloperWorkspace-->
     * <h5>DEV Workspace</h5> Using {@link #setDaVinciDeveloperWorkspace(Object)} the DaVinci Developer workspace for the new project can be specified. This is an optional
     * parameter defaulting to ".\Config\Developer\&lt;ProjectName&gt;.dcf" if the parameter is not provided explicitly. The value given here is converted to {@link Path} using
     * {@link Converters#TO_PATH} <!--Ref:Converters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project folder) should be given here. The following
     * constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_DCF_FILE} <!--Ref:Constraints.IS_DCF_FILE--></li>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--> (applies to the parent {@link Path} of the given {@link Path} to the DaVinci
     * Developer executable)</li>
     * </ul>
     * </div>
     *
     * @param daVinciDeveloperWorkspace the DaVinci Developer workspace for the new project
     */
    @PublishedMethod
    void setDaVinciDeveloperWorkspace(@Nonnull Object daVinciDeveloperWorkspace);

    /**
     * Alias for {@link #setUseImportModePreset(boolean)}.
     */
    @PublishedMethod
    void useImportModePreset(boolean useImportModePreset);

    /**
     * Using {@link #setUseImportModePreset(boolean)} it can be specified whether or not to use the import mode preset for the new project.
     * <div class="extdoc" id="setUseImportModePreset"><!--Label:ICreateProjectDaVinciDeveloperApi.setUseImportModePreset-->
     * <h5>Import Mode Preset</h5> Using {@link #setUseImportModePreset(boolean)} it can be specified whether or not to use the import mode preset for the new project. This is
     * an optional parameter defaulting to {@code true} if the parameter is not provided explicitly.</div>
     *
     * @param useImportModePreset whether or not to use the import mode preset for the new project
     */
    @PublishedMethod
    void setUseImportModePreset(boolean useImportModePreset);

    /**
     * Alias for {@link #setLockCreatedObjects(boolean)}.
     */
    @PublishedMethod
    void lockCreatedObjects(boolean lockCreatedObjects);

    /**
     * Using {@link #setLockCreatedObjects(boolean)} it can be specified whether or not to lock created objects for the new project.
     * <div class="extdoc" id="setLockCreatedObjects"><!--Label:ICreateProjectDaVinciDeveloperApi.setLockCreatedObjects-->
     * <h5>Object Locking</h5> Using {@link #setLockCreatedObjects(boolean)} it can be specified whether or not to lock created objects for the new project. This is an optional
     * parameter defaulting to {@code true} if the parameter is not provided explicitly.</div>
     *
     * @param lockCreatedObjects whether or not to lock created objects for the new project
     */
    @PublishedMethod
    void setLockCreatedObjects(boolean lockCreatedObjects);

    /**
     * Alias for {@link #setSelectiveImport(ESelectiveImport)}.
     */
    @PublishedMethod
    void selectiveImport(@Nonnull ESelectiveImport selectiveImport);

    /**
     * Using {@link #setSelectiveImport(ESelectiveImport)} the selective import mode for the new project can be specified.
     * <div class="extdoc" id="setSelectiveImport"><!--Label:ICreateProjectDaVinciDeveloperApi.setSelectiveImport--> Using {@link #setSelectiveImport(ESelectiveImport)} the
     * selective import mode for the new project can be specified. This is an optional parameter defaulting to {@link ESelectiveImport#ALL} if the parameter is not provided
     * explicitly.</div>
     *
     * @param selectiveImport the selective import mode for the new project
     */
    @PublishedMethod
    void setSelectiveImport(@Nonnull ESelectiveImport selectiveImport);

}
