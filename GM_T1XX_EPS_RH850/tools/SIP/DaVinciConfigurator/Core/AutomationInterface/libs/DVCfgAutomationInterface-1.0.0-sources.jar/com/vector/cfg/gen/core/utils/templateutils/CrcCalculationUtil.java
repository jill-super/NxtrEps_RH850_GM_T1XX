package com.vector.cfg.gen.core.utils.templateutils;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class CrcCalculationUtil {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(CrcCalculationUtil.class);

    @PublishedField
    public static final String CRC_INCLUDE_TAG_START = "/* START of Checksum include for - ";

    @PublishedField
    public static final String CRC_INCLUDE_TAG_START_END = " */\r\n";

    @PublishedField
    public static final String CRC_INCLUDE_TAG_STOP = "/* END of Checksum include for - ";

    @PublishedField
    public static final String CRC_INCLUDE_TAG_STOP_END = " */\r\n";

    @PublishedField
    public static final String CRC_EXCLUDE_TAG_START = "/* START of Checksum exclude for - ";

    @PublishedField
    public static final String CRC_EXCLUDE_TAG_START_END = " */\r\n";

    @PublishedField
    public static final String CRC_EXCLUDE_TAG_STOP = "/* END of Checksum exclude for - ";

    /**
     * <code>CRC_INCLUDE_TAG</code> describes the CRC tag to include CRC information.
     */
    @PublishedField
    public static final String CRC_EXCLUDE_TAG_STOP_END = " */\r\n";

    @PublishedField
    public static final String CRC_VALUE_TAG = "<CRC_VALUE_TAG_1524df2c-f551-4a9a-99aa-c88d409caa80>";

    @PublishedField
    public static final String CRC_VALUE_TAG_END = "<CRC_VALUE_TAG_END_1524df2c-f551-4a9a-99aa-c88d409caa80>";

    /**
     * Returns a tag which marks the beginning of a CRC section.
     *
     * @param crcName Name of CRC
     * @return Tag
     */
    @PublishedMethod
    public static String getCrcStartTag(final String crcName) {
        return CrcCalculationUtil.CRC_INCLUDE_TAG_START + crcName + CrcCalculationUtil.CRC_INCLUDE_TAG_START_END;
    }

    /**
     * Returns a tag which marks the end of a CRC section.
     *
     * @param crcName Name of CRC
     * @return Tag
     */
    @PublishedMethod
    public static String getCrcStopTag(final String crcName) {
        return CrcCalculationUtil.CRC_INCLUDE_TAG_STOP + crcName + CrcCalculationUtil.CRC_INCLUDE_TAG_STOP_END;
    }

    /**
     * Returns a tag which marks the beginning of an exclude section.
     *
     * @param crcName Name of CRC
     * @return Tag
     */
    @PublishedMethod
    public static String getCrcExcludeStartTag(final String crcName) {
        return CrcCalculationUtil.CRC_EXCLUDE_TAG_START + crcName + CrcCalculationUtil.CRC_EXCLUDE_TAG_START_END;
    }

    /**
     * Returns a tag which marks the end of an exclude section.
     *
     * @param crcName Name of CRC
     * @return Tag
     */
    @PublishedMethod
    public static String getCrcExcludeStopTag(final String crcName) {
        return CrcCalculationUtil.CRC_EXCLUDE_TAG_STOP + crcName + CrcCalculationUtil.CRC_EXCLUDE_TAG_STOP_END;
    }

    /**
     * Returns the calculated CRC value for the passed tag.
     *
     * @param crcName Name of CRC
     * @return CRC value
     */
    @PublishedMethod
    public static String getCrcValueTag(final String crcName) {
        return CrcCalculationUtil.CRC_VALUE_TAG + crcName + CrcCalculationUtil.CRC_VALUE_TAG_END;
    }

    private CrcCalculationUtil() {

    }
}
