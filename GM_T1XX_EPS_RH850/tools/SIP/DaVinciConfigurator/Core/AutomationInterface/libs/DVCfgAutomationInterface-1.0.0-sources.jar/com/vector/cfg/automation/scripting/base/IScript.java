package com.vector.cfg.automation.scripting.base;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;

/**
 * {@link IScript} represents a loaded client side script.
 *
 * The script can be used to query the loaded {@link IScriptTask}s, and execute them.
 *
 * <p>
 * A Script is hold by an {@link IScriptContainer}, see {@link IScriptContainer} for more details.
 * </p>
 *
 * <h5>Load behavior</h5> The script instance will not change, when a script is reloaded due to changes. So the user code, can hold a reference to the {@link IScript} when the
 * script is changed.
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IScriptTask
 * @see IScriptContainer
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IScript extends IScriptIdentifier {

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    String getScriptName();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IScriptPath getScriptPath();

    /**
     * Gets the script logger of this script, which is created for each script separately.
     *
     * <p>
     * The name of the logger is: <code>com.vector.cfg.automation.script.&lt;ScriptName&gt;</code>. E.g. com.vector.cfg.automation.script.MyScript
     * </p>
     *
     * <p>
     * The log level could be changed in the logging configuration, see {@link ILogger} documentation.
     * </p>
     *
     * @return the script logger
     * @see ILogger
     */
    @PublishedMethod
    ILogger getScriptLogger();

    /**
     * Gets the description of the {@link IScript}, if the script has provided a description, otherwise an empty string.
     *
     * <p>
     * The script can set this description by call the method <code>scriptDescription("Description")</code> during the initial script execution.
     * </p>
     *
     * @return the description of this script
     */
    @PublishedMethod
    String getDescription();

    /**
     * Returns the {@link IScriptTask}s of this script.
     *
     * <p>
     * <b>CAUTION:</b> This method will block until the {@link IScript} is fully loaded, which could be an expensive operation.
     * </p>
     *
     * @return the tasks of this {@link IScript}.
     */
    @PublishedMethod
    List<IScriptTask> getTasks();

}
