package com.vector.cfg.gen.core.utils.fileoutput;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IArgumentedJetTemplate;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The abstract implementation class for jet templates with a second argument.
 * <p>
 * The second argument can be passed via the {@link #includeTemplate(Class, Object)} method to specified to template behavior.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractArgumentedJetTemplate<T> extends AbstractJetTemplate implements IArgumentedJetTemplate<T> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractArgumentedJetTemplate.class);

    private T argument;

    /**
     * Instantiates a new jet template.
     */
    @PublishedMethod
    protected AbstractArgumentedJetTemplate() {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final T getSecondArgument() {
        return argument;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void setSecondArgument(T secondArgument) {
        this.argument = secondArgument;

    }

}
