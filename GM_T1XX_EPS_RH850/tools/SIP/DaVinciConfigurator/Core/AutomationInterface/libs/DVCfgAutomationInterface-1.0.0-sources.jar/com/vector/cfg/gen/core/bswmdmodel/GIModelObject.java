package com.vector.cfg.gen.core.bswmdmodel;

import java.util.function.Supplier;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucDefinition;
import com.vector.cfg.model.access.ecuconfiguration.IEcuConfigurationAccess;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucHasDefinition;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.state.CeStatePublishedFactory;
import com.vector.cfg.model.state.ICeStatePublished;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;

/**
 * Base interface of all bswmd model objects.
 *
 * <div class="extdoc" id="BswmdModelTypes">
 *
 * <h4>DefinitionModel</h4> The DefinitionModel is the base implementation of every BswmdModel. Every BswmdModel class is a subclass of the DefinitionModel where the classes
 * begin with <code>GI</code>, like {@link GIContainer}.
 *
 * <h3>Types of DefinitionModels</h3> There are two types of DefinitionModels:
 * <ol>
 * <li><b>BswmdModel</b> (formally known as DefinitionTyped BswmdModel)</li>
 * <li><b>DefRef API</b> (formally known as Untyped BswmdModel)</li>
 * </ol>
 *
 * <p>
 * The <b>BswmdModel</b> consists of generated classes for the module definition elements like <code>ModuleDefinitions, Containers, Parameters</code> in bswmd files. The
 * generated class contains getter methods for each child element. So you can access every child by the corresponding getter method with compile time safety of the sub type.
 * </p>
 * <p>
 * The <b>BswmdModel</b> derives from the <b>DefinitionModel DefRef API</b>, so the <b>BswmdModel</b> contains all functionalities of the <b>DefRef API</b>.
 * </p>
 * <p>
 * The <b>DefRef API</b> of the DefinitionModel provides an generic access to the Ecu configuration structure via {@link DefRef DefRefs}. There are <b>NO</b> generated classes
 * for the Definition structure. The <b>DefRef API</b> uses the base classes of the DefinitionModel to provide this {@link DefRef} based access. Every interface in the
 * DefinitionModel starts with an <code>GI</code>. The Ecu Configuration elements have corresponding base interfaces for each element:
 *
 * <ul>
 * <li>ModuleConfiguration - {@link GIModuleConfiguration}</li>
 * <li>Container - {@link GIContainer}</li>
 * <li>ChoiceContainer - {@link GIChoiceContainer}</li>
 * <li>Parameter - {@link GIParameter}&lt;?&gt;</li>
 * <ul>
 * <li>Integer Parameter - {@link GIParameter}&lt;BigInteger&gt;</li>
 * <li>Boolean Parameter - {@link GIParameter}&lt;Boolean&gt;</li>
 * <li>Float Parameter - {@link GIParameter}&lt;BigDecimal&gt;</li>
 * <li>String Parameter - {@link GIParameter}&lt;String&gt;</li>
 * </ul>
 * <li>Reference - {@link GIReference}&lt;?&gt;</li>
 * <ul>
 * <li>Container Reference - {@link GIReferenceToContainer}</li>
 * <li>Foreign Reference- {@link GIReference}&lt;Class&gt;</li>
 * </ul>
 * </ul>
 *
 * </p>
 * </div>
 *
 * <div class="extdoc" id="DefRefGetterMethods"> The DefRef API classes have no getter methods for the specific child types, but the children could be retrieve via the generic
 * getter methods like:
 * <ul>
 * <li>{@link GIContainer#getSubContainers()}</li>
 * <li>{@link GIContainer#getParameters()}</li>
 * <li>{@link GIContainer#getParameters(TypedDefRef)}</li>
 * <li>{@link GIContainer#getParameter(TypedDefRef)}</li>
 * <li>{@link GIContainer#getReferencesToContainer(TypedDefRef)}</li>
 * <li>{@link GIModuleConfiguration#getSubContainer(TypedDefRef)}</li>
 * <li>{@link GIParameter#getValueMdf()}</li>
 * </ul>
 *
 * Additionally there are methods to retrieve other referenced elements, like parent of reference reverse lookup:
 * <ul>
 * <li>{@link GIContainer#getParent()}</li>
 * <li>{@link GIContainer#getParent(DefRef)}</li>
 * <li>{@link GIContainer#getReferencesPointingToMe()}</li>
 * <li>{@link GIContainer#getReferencesPointingToMe(DefRef)}</li>
 * </ul>
 *
 *
 * </div>
 *
 *
 * <div class="extdoc" id="PBSelectable">
 *
 * The BswmdModel supports the Post-build selectable use case, in respect that you do not have to switch nor cache the corresponding {@link IModelView}. The BswmdModel objects
 * cache the so called Creation ModelView and switch transparently to that view when accessing the Model. So you don't have to switch to the correct view on access. See figure
 * <!--LaTeX:\vref{fig:BswmdModelCreatePBSelectable}-->. You only have to ensure, that the requested {@link IModelView} is active or passed as parameter, when you create an
 * instance at the {@link GIModelFactory}. Note: A lazy created object will inherit the view of the existing element.
 *
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAkoAAAGKCAYAAADzI26wAAAAAXNSR0ICQMB9xQAAAAlwSFlzAAAV1wAAFdcBBCy7GQAAABl0RVh0U29mdHdhcmUATWljcm9zb2Z0IE9mZmljZX/tNXEAAEsjSURBVHja7Z0LWFRl/vhneH7//dWuaf22m7fylmhekqtczKyUyKy0IkW8IOVo5lJmLZopbJqSkWIuuabmNVEx75CIl7Z7u2m7aaZgltZupeb9kpl8/+c9MwfOwAwgAjMDH57n8zAczjlz5pz38pnve7P85S9/sQAAAABAabgJAAAAAIgSAAAAAKIEAAAAgCgBAAAAIEoAAAAAiBIAAAAAogQAAACAKAEAAAAgSgAAAACIEgAAAACiBAAAAIAoAQAAAACiBAAAAIAoARgkJSVd3bVr10ndunVLAQCAuoNW9k+02WwhiBJAGXTv3v3ZG2644XMKDQCAuoW/v/+aVq1a5VgsFiuiBOCGPn36xHfq1Gm+yigAAFB3MJf/iBJABUSJ+wEAQPmPKAEgSgAAlP+IEgCiBAAAiBIAogQAAIgSAKIEAACIEgCiBFVIcmJ0QFOL5ZD2nAsNgmKT7y/vuLggi5Y2mh6OGhl7X4AlYNPApKRGbt8jeWDDQEtgrrFPXHT0Y7bU1Holt18Oxjmr4x4NCGrySnRickB5961p1Mhna+KZGddjXIP2vqPN/0+JC+qlPZtD3UeMC7ycz1jWMwTKf0QJyCiIUp0RpcZB/V/VnrOfetZJSQMbBViaflpWJasqTSVHMUlJjfUCsQJpxNhHHRvcJHq2LSnpqooeW+5nKHHOqiYuoHGaS1FqGr08xmarb79vtqvuadx4WVmyUdXXY7+GwJzgxsHLzAKj/t+kSZMPL0WUXH1GV88cUaL8R5QAEKW6KkpFz3lkVNPRRpTCHjlyjpg4tonFErAvZlxMoBFp0M/VuPH7TS2Ww/oxTaPylLyYoxFFxwbFLlBS5hRpMr2X+r+6JnfndKrkTeeMDbIsCIpL6VX02QLi0vTfgYGZARbLPvO53X0+5+0B+4KDSwuQIUrGtaSm2upFBUWNV1Ete0THclEdHxI7Mja6SfBs/f7o96HpJ0pgdLm7KfpviYndbzdfm7oG9RlKflZX12NcQ1x002TzZw6JjhsV3bTpcuOaXd3Xsj6jq3uCKFH+I0oAiBKi5NimKnolSnqFH9R/oRFtUgKlKmR71MkeUTJXoOYoiznCYt5HHauiP2of8/aS72UIj7tzmj+D0zlNn8e4XnsTVcCn6nrN53b3+czb3UXYHM1eh81NbxZLp6/VZ+kf1PhVtb8654gRI1qZz6siPcZrdY/N12Z/L8s+1fTp7jrN12PcG122HJ85MSro8e6JibcbouTuvro7p7t7gihR/iNKAIgSomSKKKnKUf12FgF7hMFJjkqIkvlcRU1EJfY3msnM2433LClr7s7p9BlM51SRHRXBiU2ODXB3Xca53X2+ktdSkaa3UnLn6L+k3y/H+yuJiY6Lfky9VjJlRIWMazOu3ZAR43zurqcoqpVsa2j/zIm3qKhWYkrijYZQuruv7s5ZkWdOvqH8R5QAEKU6K0olozyqkjQvbVByn6oSJVMkw2qWhEsVJUP0goODZxvNh0bUpqSAuPt85mtR8uIqilWy6c18Xr2S0I4dN6J7oCEy6hw3Bd3zhi41QUGvBAVFv6J3aK+AKLm7HvM16OITFTU+KCrxcfM+7u6ru3NW5JmTbyj/ESUARKlOiVLJJiTzqLei/jKm/12uKOn9cZpG5Y0YF9PaXPk6vZejEq+oKBnnLBaw4uYy/RzBwcuK+yg5i4Orz168velhVx2jXTa9Oc5r7uNjnE+P1Dj+r85tlrjyRMnd9ZhFSb2+yXLTHrW9pNy5uq9lfcbynjn5hvIfUQJAlOoUJRfErMj/Lve18ber7RV9L1fX6SraU3JkX0Xf0909cbeP+TO5u5euPsOl3LPKPodL+YwVeS+g/EeUgIyCKIEPYu9j0/SwOQLkqh8WACBKAIgS1ElcpVnSMQCiBIAoAQAAogSAKAEAAKIEgCgBAACiBIAoAQAAogSAKAEAAKIEQEYBAABECYCMAgAAlP+IEpBRAACA8h9RAkCUAAAo/xElAEQJAAAQJQBECQAAECUARAkAABAlAEQJAAAQJQBECQAAECUARAkAABAlAEQJAAAQJQBECQAAECUAMgoAAFD+I0pARgEAAMp/RAnIKIgSAADlP6IEgCgBAACiBIAoAQAAogSAKAEAAKIEgCgBAACiBIAoAQAAogSAKAEAAKIEgCgBAACiBIAoQc2SmJjYJj4+vptBVFTU0926dUsxMP/PZrOFcc8AAFECQJRqDZrcdFLPJyIiIqNNm9Y7Gt5ww/facyo0uPmmJsc7hwYdNRhhiz83Yewo0RkzSjoHBx416ND+1mPmYxvUv+q4v3/rz0NDQ1YowVIyxT0HoPxHlAAQJa9ERYdiYmL63XFH5FQlRUpm/Fu3Ohb7aO+Tr6Ymy+YNy2XnP7fKhRMHy+S3k9/Z0V7/evxb+fXYNzrnj+7X+FrO/7xPftE4sPsjyV27RObMfFmGPxZ3LjQ44Kh6zyZNGn8dFha2oFevXsOJQgFQ/iNKQEZBlDyGEqPAwMANv/vd//tVRYd697rnxEspY3Qpcik/l4J+7AG5oMnShSJh2i+/KlkyCdMvRwrk7KG9dn7aIx9vWSWvTU2W+LiHz7S/1R6F8m/d4nMlTklJSVfz3AAo/xElIKNAtaGiNOFhYQv+8Iffn1FitOTNDDn1U8HlSdFlitK5w/l2dGHaownTV3Lmx91y+ocvNXbJO2+/KYNiHz5d7w+/PxcY2GGDEjyeJQDlP6IEZBSoEkaPHt3srrvumnjtH/94qFP7W49mTJ8shw/uqloxqmJRMmTpzI9fauySU//dqfGFzJ81Ve7r2f3kH37/+zOqiY7mOQBECYCMApWib9++vW9u0nhfo4Y3nnz+ucQLBTs/ql45qkZRUpGl0z/s1IXp5H/+LQd3vy/TU1+Q9rf6H/2jJoDR0dHPpaamXsFzh5qG0Z+IEgCi5GOowtjf33/7PT26Hfvne+/Ym9VqQo5qSJRUZEnJkuLEd5/LFx9tEFt837PXXXfdkQceeGAIaQCqOD8x+hNRAkCUagOqiU27l+tV81re+mU1Fz3yoCid/P5fuiwdP7hD9n62Sfr26flL0yZN9sfFxd1LmoDKRIcY/YkoASBKtQw1Gqxr1y5/a9a08dHF8zI8K0geEqUT3+2QE5osHTvwmbyX85bcERlypk3rljsSEhICSCNQFoz+RJQAEKVajOqbc/311x995aVxF9ToNY8LkodF6fjB7XJck6Vj3/5D1mXOktatWpxSI+USExOvIb2AAaM/ESUARKn2R5FuVP2Qnhg6+PShA7u8R5C8RJSOH/inLktHv/lU5r42SZo2uvHnhISEcNJO3YXRn4gSAKJURxg4cGD0zU2bHPJ4PyQfECVDlr76dIN06tD2fFRU1GuktboFoz8RJQBEqQ4RHR017fbIiGOHDuz0TkHyUlE6+s0ncuTrj+TZkQmFHTp02JWUlHQl6al2o0aQtWzZ4ktGfyJKAIhSHUB9S4zoHLz6z888cezX414aRfJyUfp5/8c6y96cJm38bzmqyVJD0lbtQ41c69ix42Y1VP/9vNWM/kSUABCl2o4a5RIc0PGD12dMPXPhhJcLkg+I0s9ffyTb1i2Qju3b/KIqVdJYrcknN0ZEdF6kRq5lLZnD6E8fGP2JKAEgSlUSSerYvt2na5bPP+8TguQjonRk34eyfVuWhAR2PD969OhQ0ppv06PH3ZMb3XjD8ddenXTBq/rtMfoTUQJAlKpXklQkyeckyUdEyZAl/9atLowbN64jac73UBFB1Q9pzOjEc141PYYXj/70puY4RAkAUbosVJ8k1dzmc5LkQ6J0pOAD2bp2vgQGdDyPLPlc2TG0Xds2P9j7IZEPKjr6847I0F/vvvuO2d4woAFRAkCUKk1UVPepfx79p1M+0yfJh0XpsMbCjMkSGRF2Ljk5+RrSn/fT7Y475vR9+H5Gf1Zy9Oe4Z5+Q2zq02+vppjhECQBRqhRq8riQ4NsOnfTGpoRaKkqH898X26AYGT586CFkyXtRzdFaebFt8l/GnfXaOcR8JB+sXfpXadfW/7gnBzQgSgCIUqUqgkaNGv0n/4sPfVeSfFSUvt+5WW5tc4vMnDnzU9Kj96FGf7Zt6//vZYtn/Uo+qJp88NHGt6Rje//zI0aM6IooASBKPoFa3Fat2+bTkuSjonQ4/z3Zsnqe6tx9cd68ec+THr3rC8QtLVvuUf2RyAdVmw++/GitdGx364VRo0Z1R5QAECWvRoXAtcrgiFeO3qkjonRo79/lwZ53ywvPjzudkpLSljzqHZLE6M/qHv25QtprspScnNwDUQJAlLwWNZtw1pK5vi9JPi5KOz9cLY0bNZQ1q9fsFxEinR4mJDAgZ9GcdN9pbvPl0Z+dOlzQviCE+lL5TyYBRKmOYLPZOvm3bnXMJzqo1nJRUtgGPSLDhw07m5GRMYh86jkY/emZ0Z+aLDX0lfKfjAKIUh2ha9eI2WX2Tfo8RSL9gmXajsqJ1PrHQmTa55d5bAWvwb7/gYpVEP8YJxF+VrFaA2XqJ3vsFcQnY4u2vfzxrgpWEK9Jgp+fDFnwmb58g8sKYtvT0tmvo7y05cNyRWnL6rnSpnUryduU93NqaioL6Hrmy0NYp/a3HvWJtQ0Z/YkoASBK1Yfqg6FW/P4uf7uUJUoR1qDKidLKgeKnHftqFRxbbsSraP+Ki1K4NUAeGxQgYRNz5YxWQeycGCjhAx+VMEuATL0EURpitUp8OaIUau1QIVH6ac+7+gi4WbNmnZszZ85z5NWaRY1wa9682UFGf3pm9GdYiJb3pk7dXt3lMqIEgChViIEDB0bfHhlRdrObWZSUjPgNEFuCirooBsg6/dj3ZVqYnyYqju0JC7VCWtvWWXttsWjbgjWBWSQ2Pz/HcRqdU+SrE9+5OWeJY7O0ayiKKC2SYaXO47x/2o5vZf2Q4uuJeGmrvXJwIUqvTOwr1kFz5MxPe2TNIKskTBwrYdZiUVo1yPS5BmbIie9VBbFeUkMc24M7Sqj2voYoZQ0o3j90wkr5uRKiNO6ZoTKgf3/Jzs6mr1KNR1gZ/enR0Z9ramb0J6IEgChViIiIiIxXU5PLLnCdRGmAJgCOqM0Otd0qQ7O0Atmxz6vb1faFsu5zI8pj3z9N225EhXSyjPOUcU7zsSWiWmWdJ237t/LVlBBNVvrL2qP7tUrhTRmqidXQ5Vql4EqUPpkrj1n7ypqf3pAE66Oy5mOTKC19VDtPjKz8j6oYMrT/+0nnlHWyIyVQ2/6IrDigVQzvPSudrXZR2pHcSfwsD8my/apiSJd4bf/4Nz+WI5coSltWz7E3v+XmHU9LSwsgv9YMtaq/ng/31VNNcE888cTp1NTUcEQJAFHyKDc3afz1Z++/c4miFOeIIi0SmyE1qn9QgrU48mJEmlaaREbvQ2REWyxisZgFx8U5zceWECX357EL1/p4I7pkvx7tGUv4S1vciNImeSUkUKZmPi9hwWPlC02Uwh2i9MWLAWINTpJ//9deQawaqJ1vwF81Ueok1qDnZMdB56a3rP6l3zdkQtYli9JPe7ZJ/fpXyerVqy8sWbRkOiMzawZGf3qHKO1yjP5ct2ZdtUVUESUARKlcVP+kevX+cLbcuZMqKEq/GVGeEwtdys76BE1uQlNk93FXkaCKi1LZ57GL0ldTgsUaOkG+PPqNVinsL252cylKe/Umt7DgALEMfEPOfFIsSiqiZLXGyNt65fC6JKjmND2ipAmU9RHJUqL0vjmidJsmUM/IZ3pE6VOtUvikUk1vSpTCQwIkfXo6zW81F03SO3Az+tN7Rn8++eST56urnx6iBIAolYuaZPLmm5ocL7diqJAoOfdRsoQ6+h99bm9K0/sZTYkr7lcUGiThFotJiFyc03xsVoomL+ZrcHEe0/5pO7ZJWmdThCt0vHz5s3tROpfZT49OJSzd7SxKWgXx9sDi81gG/FWO632U1smUYKuLPkqrZXKw6X2DRmnSVDlRGtTvfnlm1DOydcvWX1JSUq4hz1Yv4WFhCzKmT64dklQLROmDnEXSvNnNsil309HqGP2JKAEgSuUSHx/frXNoUIW+QRfvc9Bp9JkeQXIqmA2cj7UfY/7/QdOx7s9ZfGzpayh9Hsf+xx2j3vSKwYgoua4gzmoVg72C2CNnVMXgqCBO//BlcQVRVDEYOCoIrXI4XlQxbJdjRgVRVDGoiFJxBaFWTq9IBWGI0rNPDpb4wfGqojg2Y8aMO8mz7hk9enSzXr16DU9KSrqxstHVBg3qnzx8cBei5CWipPJB4G3t5LUZr1XL6E9ECQBRKpe+ffv2vqdHt9oz0WQtqiCUKL049kl5NCZGNm/afHbWrFlPkGfdo4b0h4SEvF6vXr3/NmvWbOulSlOtzAu1IB9MVHngkUckNzf3+6pufkaUABClCn3+2Ed7n0SUvFOUZkz+s9zXs6e8u+1dmT9/fgodusuptLT7o1CR0uDg4FmXIk0VGv1JPqjxfGCM/szdmHssLS0t3NvKfzIeIEq1nArNoUQF4TFRUnMpxcXF6aK0ePHi1xGl6pOmCo3+JB94JB+o0Z/r162v8jyAKAEgSuVyKX2UqCBqvoIw+igpUcpanpWFKFWPNKlmu3r1/nCOfOCd+SD67ttl0sRJVT76E1ECQJTKRXWAbdTwRprevLSCeLRPtDwx/AldliZOnLjQSKfquXXr1i3FHWrSRPMzZt/S+3bs2HFBo0aN/vm73/3u5FVXXfXd9Q3+93zRSMqSM8df8lqH9pnjbVmmgQ7ljCq9nLUULycfrB0SLGn/yC+VD9YMDpKpn+y+/Hzw92f0NQ4nb/uk0vmgukZ/Ikp1gMLCwouF/Dj9XOq3DeZRquA8Sp6ishVIFYjSar2i2OVRUVLzKE2ZPEUXpalTp6Yb6VRFQMoSBCUFxjNm39L7RkREpPr7+6+59tprv/qf//mfc9dcc03BrY0bnLNY4mStPmKyxFxgFVlnsIQoOc0vVoF0Xum1FC8nHyzvL37WQHnl0xKilBmrbQ+Qlz/eXSVfGIwRoJcbWd2ct/l4RkZGH0TJxTfeqKiop82Jv3v37mPU/C+Iki4G/Dj/IEqXSJs2rXds3rDca0WpUhXI5YpSZj9HReE5UTr471y9b0buxlzJ25R3atasWUNcNSe5wl3TU13eV4mSyu+aIK3+3//932Mq38fExPRR+6nfUQGNTitRWmcI0efOy/MUCXtF1jrsbJrbq0TaLJ5R3ioRU96z/9/trPPF++xJDdHeN1giOhtrKabIq52N93NEvkoeO/nv8qvKB1kDtGPjZOgQ45r7y5qft0paqDGLfKD2pcCYJmOTTA0p3v7yx1/K6hJrHZ78j3M+WDlQ/f9hyTroyAfvjZYwP6t0Tl4lR0tElJbHmdZBfGGZHN63XCYFadtiX9HSvpYP5t6vXatVBr/xrvyo5YPMWD+xNu4i91bD6E+fFyUlQlqC3q6aBUbY4s9NGDtKFOPHPCXP/OnxX29q2vh4kyaNv05ISAhHlPhBlCrPXXfdNfH55xIvXPCwFFVPBTJBdh+zi9K6hOJjwydtlnNKlJZp36j9+snjg40KpJ+s/jHXVFEoWdrpEVFavWi6BAV0km1btzGPUiVR/Y9UHm/Tps0qTY6OqryupgEoKVJqn35dmp21mJae0ScXHbJAE42KrXWop0OrIyJlXq/QlMad9lERK6N5znR+d/vsSQ22v+/2A47Z6NX5D8iv7q7BcezQLC39Z8Xp0pO2XfuSsH28tr9FHlfrHi6PdZakoohSPz3tp370pZxZ2ldf69CYmf4xfa3DDXLSnA8+eE6fmT40ZY0+r9iOlNu04x+SFd/am97URKtKlLZPuE38LL0lc5/KA2kyWDvX4Lla+p/7gLb/A5KpidKyflYZ1Pd+sfSdKj9+9bIM0j5b8/uGVsvoT58WpejoqJRbWrY8krd+mdNkc4pfj38j547s01f5/ihvpXTqcOuJO+/sOkPLEFfWtUKgSJQK0qWLaSX1yOn5UhUGlZOeLgWIUq3HG0a+VX0F8q2c35FsrxBWfCO7Jwdrx8bKmiMF8svPc/UFch9fViDnlsXqFcLUT/bI2U+el3BjZu7Mvo6KYqfHIkp6c0O8vSP35rzN56p6ZuLa0HTvKr8rOVKdtFVnbdVp250clcoDba8/5dz09p4u3BGp7zmlQ3cz0+vp0JiN3k3Tm1oLsdT6g1Ocz79+iOt9vtLTeVzp9RNNkS+Xx05+VxOl/noUSS0Q/euxN2Wo9j+zKJVueuvn+JKwW754MVCswWPk3z/Y84F9rcMM54lXtXywcoCahf5Z2XFgrT5jfWjyKjl2wFmUVsS6WAdRRZUKlDRpgjQnUyYFtJeJuVNlUOCf5JONIyXE2kv6VdPoT58UJRUabdmyxZdPjbCdPvmj6z4TSpRUyFzNpqvaTdVDmvDnkYXNbmr6Q2JiYvO6J0o5MtwvQtL3XhT1Z2FhvqRH+smwnMLLlKUcGRapiZLvxawQpUpw7R//eKhg50eeiyZVeQWiVXafF4vSOhcL5IapqNIyVSH0ldVqdu5Dc7Rvy1YnUfJk01uTxg0lc2mmXjmsXbv2c6niyfZqSUTaau6mof1sUXKkRrapEW5lyZEZffRnq/875dT0pprSOlsl/FJEydj+ubuIkl2m9DUKzTPKO30hcL3PngqIUqljNemzN73FVVqUVERJrXW4Ss8Ds/Q8EloyoqTywfsqqtRRpqQ8rH0pUdGk4s7cxRGljmINfFr+sc+eB/S078gHyzSJCun7gIQEaIK0Z6lMDGwvA/u2E0vf1Gob/emTotS+fdsP1arNZX2zLSlKqtBShdTfsxdLy+bNTiQnJ19Tl0SpID1SIqfvdZaiQrskFaR3kS6RkVoiHybZ2rac4cVND+aok3m7dVi26PqlbbNanP8udWzOcL0tWW0bll1azFyd1+lHRcK6aNdv7BM5XfILSx9rf78CSe8yTHL0kyg5jJT0fMfrLk5ChyhVvvnt4gWPRZSqugJxFqXdk4PEGjJedh0x9U3Sm95ivVKUVi9KL2p227J5y4UFCxZMquo0WttESQ1MUF0xKipHZpRk3djg96Wa3qwWs/iUt9ahikBZy+mjZNqnxKi64iZm1/tURJQuuDh29/EyROmzF/QoqnMfJU2UPn2+aLvqo7SqxFqHJ/7jOh+oqJKf3gS3Wo4dKC1KR79ZKZOCzOsgPiWfFjjyweZEbT+L3uT2056/y6fPd9C/3AycvVViekfLmKQx9ojSwsWv1FlR0i54aN+H7y83/O9OlFSB9MKzT0hsbN+TKSkpdSKyZIiSzU30SP3PasuRixcL7VJjy9Zfq/IxX5MoPeqkyUpk0fZ8mR7pEJDCbBmmxOWiuD02xxYp0/PtkayCgoJSEuTyvCX3iUyXvSX3cfN+RZ81Z5hERkQUv04vMH9+RKkSeH6agKquQJxF6fyxbXrH1eIFcl+wS5M7UdIXxfVcH6W+fYorBtWRW5OA5tVRfpQVUR7uZ3wxufyfAqO88XAE2R3G6M+TP+aXWkOw8msduhnxVsZ6iGXvc/DSr+G4MajhG8eABvugBn0wg2NQwznzgAbToAb7aDcHTum/jHxQcs1DV6PeVPr/2ogoOeeDQ3vfc6Dywbvy41fb5EfH6M/06el1u4+SKqRvadnsx0MHdpZboJYlSqoQCrytvcyYPuPH1KTUWt9nSS/oSouCVirlSE6BXZQi0/Md0aVI529KWiUQ4YgM5Wv/MyJDVkuEJj+FTk1vbo9VouPoG+WqX5Tr85aUqZyiSFPOME2UCgrLfj9t//x0m6TnpEuE9jrHFqEfQ9Pb5RMW1nnxzFdfuujZuY+qqAJxjHrTKwZj1JvTaDfjd75pUdy9pRbFVYJU0xGlrWvmSccOt+qj3aqr2a0iEaWqDDiV9YXOG0RJ4dWjP+vwfGLljf6sM6KkXej6xW9mVOjBlydKOVmzpUP7toVvLXlrRm2v/Iw+SsP8zNEa1UTlJxGaIOWbREkXKk02LhYWOvoymZrn0vc6tpsjP6Y+Sm6ONQrTwvzpemTI7EHuz1u+KLl/P+2zaeeJtKn30l4Ps4nNVqofFaJUSZKSkho2vPGGk147p1IdqSCiu3fVZyE2oklVWTFUKqLkpok8Z3iX4i8p+j7pju2lm9wNUVLlgt+wnEo351enKHnL6E/yQc2N/vQZUbrUCe/KEyV1s1UnyCWLFp3Qzl2rpw4wCrrC/OLIjj5seromKOIcUdL20vzDVIAZBVGB+VitMLM5mrSUKFn9HIWi62PN22wlCzW3562AKLm7VlNzol7QDrPqQlgoiFJVoUacPps4/DdzRIcKouYqiGVzX5HwzqF6paBEKSc7J7+qR7uVFiWjz5/5S5fK/7YiUXLdRD5M/Bx5sbhZ3LnZPHuYX3Gzebo9v1+8lOZ8fUSvJmx6GeeyKbDK8m2tXM6nFohSdY7+9BlRutTEWRFRMtr3c3JydldHyNrbRKkoslMi2qOEo1Qnb3dRIbfbyzjW5Xs6h+4Ly93HzR9ujy1xTZf5DRNRKv3FpW3btrs/2LyGCqKGK4h9n+XIrW1ukWWZmUalcHzmzJkPVW/5oSLQmvjs3ev4fbEoouQkSi6/0Bj75IjNz75vqSY2R9cAFd22+lnFYiuOMFW0OV//IthFE7W99t/5hdUjSgpPj/4kH9Ts6E+fESV1obGP9j5ZlaL07Mh4fShhdXWC9EZR4gdRqirUNBv+/q1PHz64iwqiBiuIe3t0lUmT7E1uinVr1n1cnV/09PJDiYk1QtKz0yVC/S6ykIqIkvav6ZoYDbNpklNQ1MRvddrX6mhy0/bLvijZtvKa110057u9xqoXJU+P/iQf1OzoT58RJTUx2JCBsaerS5Sqq30fUUKUajMPP9znybi+D/3ms80QPlZBvDj2T9I35pEiSdqUu+mQJk0taqTpvlA1uam52FRkyE3TmxtRKpKYInmxN7cVNZvbNshFc9NcgREVqmBzvt70pl3HXk2S1O+LF6ut6U2hz8XUtPHRWtFPrxaIUnT3253661V14MNnRCkmJqZf7173nKhKUfrT0P5iG2ordyihWllaTVCmZnD1RbzBk5o3b77Nm7jUe6gWxaxXr94PvpoGqgI1K7Gr/HHffT3njnvuqUKf/HbtQxXEwtenyB1dby/ql6RVCEdnzpzZt6ab7s2/S792117uYnScU7N56W4Al9qc7+raqkuUFF27RsxOm/zCRUTJs6KkRn+2ad2qKF9Ux+hPnxElTVbCOrW/tUr7KD3Y826ZMH5CuaKkZgJXfaR8FW+IKCUkJNzpy/dQrSLeqlWrd3z5M1wuaskHlwWAlm969Ljj09defYkKopoqiI1ZsyU4sFPRVACaJJ1dunTpmzUR4axtE05WFYz+9L7Rn6q/XkZGRp/q6PrjM9MDNKhf//h3+durRJS+37VVrrv2j7J+3Xplor/NmzdvLE1vvlVQ1SQ0vZVTCGj35fbbI795469pVBBVXEG8u36BhAYFyIZ164zK4Ne1q9e+u2LFCj+a7j1b/qjRn6NG2i4w+tM7Rn9mZ2fvr45n7VOipEKdr0x+4UJViJIexr69i36D8/LyTs6cOTO2VouSY0HcUhM+6vORRJae5LGMH6d5UVzv4Wq2XkSplqMWnO7Ro8d34557SnymGc7LK4jl816Vjh3aaV/o1hX1S8rekL1zdurs39fUc1V519eprnvD6E/vGf3pmDupp7eW/zVaEN98U5Nvd/5z62WJ0v5/5UnL5jfL2yvf1m/wls1bTqekpFxT20UpMtImtgibk8CoDpcRERGlJ3ksS4PMnTTdiFJRB09Eqc5FluJiY7+J6/dwoU80SXhxBfHKi89JeFiobHxnY7EkZWd/pVXO/0da8x7U6M/Wt7Q6xehPz47+XLVq1dbqqmd8bq03tZhhUMBtv1zOWm+xD98nY8aMqZEb7F2ilC456aYJHbVtw9JzJN0kSu4WqC3ePkyfFNIQJdcL6CJKdT2ylDhy5BeR4aGFFflSQwXhXEGoL3KqjOrT+8GiJoWtW7eed0wqiSR5Z/lgY/Sn50Z/5ubm/qDljUbeXP7XeKK8++47M/404jEpK1G6E6VXJ41xGjmSuzH3SHXeYG8Tpfz84iG8BenDNOGxL/fhapFZY7Zc51l0lQRFlLkobSGiRGRJu08pKSmZbdv4X5z7+qtUEBWsIDatmivt2rZ2+iKnOm6vXr36H7Nn11xzG1w6jP70zOhP1eQ2c+bMu7y9/PdIIRwdfc+K4MBObr+xlhSlff/aKnd3i5T7et6rbmxRD/lZs2YNq+0Z2EmU1NpnkUpi1Bpoav2zYlEqa7Zc8/ZyF6VFlMCRT7UC7Kl774n6pftdd4hXRpe8pIL49ostMnxIP70/ktHnwiijli9fnllTHbfh8tJ7r169tr44/s+IUjWJ0vK5r0o3TZKMOrymRn/6pCiZvrEu176xFo5Pelr27frYpSh9s+tDSX0xSVq2aCZTX55aXABt3nxBjRypzU1urkVJitZTsqWrWXLNESXXs+UWOm133t/1rLmIEhSj1lKc+OLEn1o0by5DhwyQ7wt2UEE4Kogf8z+U8X8eIU0aN5KRI0cWfUs2JpNUX+RIc74lS93v6rbP56bK8AFR2rjyDQkJVKM/19f46E+fFSUjUc6fPz8jfuDAc00aN5YO7W+VLpFhdiI66/OOXHfdtdL30Rh9GgBTAXQsa3nWKq0ArxOh7JKiZF+I1uiXZBIfN7PlOm83d/52tygtogTOqH5LK1esfDsxMfFskyaNRX25OfLdl3W6gng9LVkXpAFxcU7lkxpcojptp6WltSDt+KYs3XvvPfnPPj1cfGbaAC8XJdXcZpekdUV99tasWfNRTY3+9GlRMhKl+saavSH7wN9m/e18+vR0ee7Z53Rez3jd6RuaiiKpb2kZGRk961KFV7wEgXlSXOeFZc2vS8+WW3p2XHfbC12dH1ECR16dNm3avRvWbfh+yOD4861atpC0Kcl1roJ4e9FfpX1bf7nv3nuLRt7qzQh5eefUl7g5c+Y8Vxci3bU9rQ8aNGgvoz+rZvSn6pNkTLbqidGfPi9KpvD+lQsXLkzduHHj4QEDBvwyIG6AXugYqLb+pUuXvpGSklLnRo0w4SSi5E2otDB79uzE5cuWH3304Yd/u6lpE8mYPtkzEaYarCDezEiViLBgCQ/rLHPnzC0q9PUoUt6WE0sWLXmtLpZPtVmWRo4c+RGjP6tu9Kdqblu3bt0/a3r0Z60RJSNhqkK4R48es6KjoxfMmDHjTkVaWlq42l5XKzlECVHyRowvN0sWLznW+8EHCxvUry8xDz0gb72ZUWsqiC3rF0vCwEdEfbYe3e8WFfF2inJrX+CylmdlqZG3pK3aKUvjxo3LYPTn5Y/+3LRp06lVWave8USXmVolSgbdunVLUVDwFH+Dr60z4yJKvl+RaAVfw8zMzNmbcjedUmsv9ujRXRo0qC9DEwbIh1vW+lwF8eU/cmXMM09I0yaN9FFsz4x6xqkPktFPct2adR9rnz2QNFX70/i0adPiet5773lGf1Zu9KdaAHrx4sWva/fSz1fLf0QJaj2IUo0IU3NNmBaoIb9rVq85pQTjto4dRDXNjR8zSrZkr5DTh/Z5ZQWxLXupzHh5ggQFdNQ7aA+Jj5fMpZnO0aNNm89u3bL1l6ysrA0q0k0/pLpFSkpK24kvTvy+RfNmhYz+rPjoTzXX4cyZM/t6suz1WlFKTExs06xZsy0aWy+Vq6+++htFZY5VqJXSydiAKHlGmJRAqLUXlVBs2bzll7eWvHVOiUdIcKBcccUV+ujWgf1j5NXUZF2earqC+HTrGpn92hQZaRskwYG36aM91Tfg3r0fLDWARLv+C5r4nVKdT2fNmvWEWiqJNFR3UaM/tfQ8g9GfFR/9qX2p8PiE0F4rSmqxQSUslUF9IEVlj9cS89VkakCUPC9NSiyUYKgCM2/TplOb8zZfUB2hxySNkUdjYnR5UqISEhSgN9WpTuFKngxKzq9WkQri0Lf/krx1Sx28JYvmpMtzTw2TyPBQ/b3a+PvrE9eOfHJkkRiZ5choWlMDSxYsWDBJRcqIHoE5Xaelpd25bt26/fGDBzP60wdGf9L0BoAoeT2qwFTCocRj7dq1n6tIjeoIreRJSYoSFtVU16d3b12eDNT8aubZ453mWtPnW7PPuWbeR3W8DgkKLKJH9+5iG2or6ohdUopUc5oq2I1hy6r5sK4PIIGKpWkVOdVHf8bEXGD0p/eO/kSUABAln/o2bgwQ0GQkYNasWUNUJ08lT0YkJy8376whNCVRBbMSHpvNJj179tRfmwXIFeaCXPv7N5MU7Vcj1mbPnj3KECPkCC4VNfpz/vz5KUuWLDnB6E/vHP2JKAEgSrVJnsJVU52K6ih5MlDNYGbhadu27W+/+93vCnM35h4zz7dm3kd1KjefQ/WZmjdv3lijIzZSBFWZhlUzM6M/a2/5jygBogReK08lSU5ObnjllVcebdCgweGEhIQXjPnWzALkCp491ES6ZfQnooQoAaIEHiUqKurpFi1a5KpRtf7+/qt5puCtos/oT0QJUQJECWqca6+9dvddd901Vj3PevXq/ZCUlNSQ+wLeLE2M/kSUECVAlKBGUNN/NGvWbJvxPCkrwJdg9CeihCgBogTVSocOHZbGxMT0M56niibVq1fvvzxX8CWqavRnSRj9iSgBIEp1GE2Kbrz66qv3q9mR1fMMDg6epZ5nmzZtVvXt27c39whqkTxVaPSnikaZR30y+hNRAkCU6jCqE3fnzp2nO0YWXZGYmHiN2q4kiU7dUNvlyRUqGmUe9cnoT0QJAFGqw6hO3CNGjGjr6n+q+Y1O3QCAKAEgSnUSoxO3u+dHmQEAiBIAolRnMTpxG38nJia2GThwYLTxt+q/RKduAECUABClOoe5E3dZz5NO3QBQp0SpS5cuU6jUAFECcyfusp4nnboBoM6I0o033rhD+wb5jfkbJACiVDdx1Ynb3fOkUzcA1HpRMr49qt9hYWHTqNgAUaq7qE7crVq1eqfkc3P3PFU0unv37mO4dwBQK0VJ+yZ4tfr2qL4RqnlS1OvExMTmPGhAlOom5vmSKvI81f6qHOHeAUCtFCUVQVKRJOPvmJiYPqqDJpUbIErA8wSAOi1Kariv6ptUsl9Ss2bNtqrwOw8bqFjB/DyNJUy4HwBQJ0SpdevWb7sa2puQkBBw/fXXb6dABEQJDNw1yQEA1EpRUhPHueqwaRASEvJ6r169hvPAAVECAIA6J0oqYpSQkBDo7v+uJpwDQJQAAKDWi5KryeTc7cd0AYAogUL1aTQvaQIAUCtFyTwdQHn7Ml0AIErA8wSAOiVKJacDKA+mCwAqVuB5AkCdECWbzdapSZMmH11qv6NWrVrlmFcNB6Bi5XkCANQ6UarsSt9MFwBUrMDzBIBaLUqXu8r3pTbZAVCx8jwBgPLCJ0RJdcpWTW4qMlTZc6jpAhwdu6+pyP42my2sWbNmW9Qs3+AZGjZs+El4ePgrnqrYqFgp+ACA8sInRKmi0wFU5XmUnKllUMBzREREpLZr1+4tRAmqAjU1AEuYAECtEyUVCXKs59bwcs+l5Eeda8SIEW1JCEQAEKW6B0uYAECtE6Wq7luk+joxXQCihCgBAIDPi1JlpwMoD6YLQJQQJQAA8HlRqux0AOXBdAGIEqJU92AJEwCoVaKkIj7t27fPrK5KSjXpqRtBgkCUECXSEwCAz4mS6nhd1U1uZtS51XuQIKjYqFhJTwAAPidKAIgS8DwBAFECQJSA5wkAiJKd5OSBDQMtlgLtzQvtND3cfcS4QE/djAFBTV6JTkwOIGFQsVGxkp4AADwqSoYkNY0aOVq9uWJkVFPtdcC+gUlJjWr6RqTEBfXytKgBogQ8TwBAlHTsUtTp65JSZL6QuCDLfCPapAnVs8VCE1gQEGDZZP9fsVi5399y0dg3ZlxMoFMUq2lUni3Z1jCqqSVP+1sMWYoNsiwo2icoVr22ljyXJ4SOhIooweXDEiYA4Bui1OSezbakpKtSU2317mlsiI+lMCg2+X5DpGKSkhonJQ1sFGCx7FPbTZGfoHEjugc2tVgOl7+/pTAgdvwDxoc0IljJsUH3G2JkPq/9tSZVpnOpyJercwGiBNVDYWHhxcLq/ZHCGvgREdIMAKJ06QcZMmJEZdQFmAWnf5BloT3CY/RfsoiKEpmPU813FdvfuUnNHHnS/nekhCgFmiVO7a9Hl4L6L6R5DlFClGpUlJRk1IYf0gwAonTpBxmSYzRrFUWZzBElTVZibLb6RgSopGCZRans/YvlRpckx35uIkqBrt6jOKKEKCFKPA9ECVECoP6pZlFSJCXZrnL0DSos7g/UX0WGrKo5zul/qi9RUtJV7kSp7P2L5cZoPtO56aY9TS2WI+r45MToANWMZ+zriFA5XROihCghSt4iSjky3G+Y5FyyS136cTnDu0h6QSGiBED9U/OipB/siP6Ycfc/83Z3r8vbv7z9SvZjKu9cgCiBZyJKlQs45cgwq+3SRGlYJKIEQP3DhJOAKCFKPhpRKkiXLl0iJdJqFasicrrkO44sSO8ifn7m7TliM0RJHTcsR4x3MUeOcob7iZ9+vmFis0W42G6VyOn5UogoAVD/IEqAKCFKnhUlJUWRkp6fI8P034XOkSFNeCIj02XvRTWKLV+mRzr2USJUtL1Q8tMjpUt6upMoRdpMomREjnKGi58tWy7qx6n3ibCfz2m7Ol8XGZajvVbvo6QtXzuf62Y90gwAosSNBEQJqkOUCiS9iyYwe/c6fl8s3YTmVniGSWR6gSnqo0lNBY4r0ITKpgRISm+3GlErHYtEOKJKhUqSumhSttf+O78QUQKg/kGUAFGC6hYlJTMqopOdLhFGZKeiouSINBUfMlz8htnEZnGORNn/b44cDRNr0fk0UTMiVEq8NDG6aJ9/yY6hQm6vE1ECoP5BlABRguoSJb3Ttmpy0+Rjb47Y3DW9uRIl7Uc1txX1UdL233DR1EdJlyCjz5HN1BepULKHGdsjJSLCEJ9C7dzFfZQUw7KNpjftnHs1SVK/L16k6Q2A+gdRAkQJakaUzCPczP27nV87DYcz/1Ec/XFxDiks/f9L2V5YxvUhSgDUP4gSIEpQI6LEhJMAgCgBIEqAKAEAogSAKEH5KMGoDfAsAah/uJGAKIFPYbPZwmJiYvpxLwAAUQISKqIEPE8AQJSAhErFCjxPAECUgIRKxQo8TwBAlAAQJeB5AgCiBIAoAc8TABAlAEQJSE8AgCgBIErgtaipATp37jyd5wkAiBKQUBElcEFSUtKV3AcAQJSAhIooAQAAogQkVEQJAAAQJSChIkpwWbCECQAgSkBCRZSA5wkAiBKQUKlYgecJAIgSkFARJeB5AgCiBIAoAc8TABAlAEQJeJ4AgCgBIEpAegIARAkAUQKPkZiY2CY+Pr6bQj2zbt26pRh06NBhS5s2rXcomjRqtP+aa64+ZPytMO8bFRX1tHEeNZUA9xaA+gdRAkQJUfIpRo8e3UzNhXTHHZFTlej87nf/79ebb2pyvHNo0FFF7KO9T04YO0oMVr41VzZvWF6CZZKnWJ8p48c8LeOTntJ54vEB5zoHBx7tHBxwtGO7tke1517YsmXz3WFhYQt69eo1XJOnTjwDAOofRAkQJUTJK0hKSrq6b9++vVW0R0nRH/7w+zONGt54sneve068lDJGl55TPxXIhRMHnfjt5Hdlo+93QC4c/1bn12PfaOyX8z/vk18URwrknOJwvrybs1xee+UvMjg25rT/LS2PKXnyb93i84iIiAyVPpS48awAqH8QJUCUeB41Qmpq6hUqYhQYGLihXr0/nLunR7djKjKkpOjwwV0Vl6FKiNKvR7+W8wqzMGmypDj70x4589NXcubH3fLOqgXy8otjpG+fnicb3njDSRV1UhEnJXY8QwDqH0QJECWoclS/oNDQoKwGDerrEaMlb2ZUjRRVkSidO7RXzh7aownTVzpKmE7/sEtjp2xZv0QGxfY5W+8Pvz+n+kQp0VPCx3MFQJQAECWoNKoT9p133DHt2j/+8ZDqXzRv1rSiqFGVy1E1iNKZH7/U2KUL06n/fiEn//OFLH0zXXrdc/eJBvWvOhkaGrJCCSDPGgBRAkCU4JIEqWPHjptVJ+yJLzx7oWDnR9UvR9UsSiqydOq/O3VhOvH9v+Tg7vdl1rQXJSSgw7EmjRt/HRcXdy/PHgBRAkCUwC1JSUk3du3a5W9KkLKWzKlZOapBUTr5n3/b0YTp+MEd8v47S+X2iNBTbVq33JGQkBBAWgBAlAAQJShC9deJjo5Kualpk8OvvDTugscEyQOidOK7zzV2yPED22X9sjfEv3WL04GBHTYkJiY2J20AIEoAiBLPMP666647/NQI2+lDB3d5VpA8KEonDmqydHC7HPv2nzJv5kuiSeOJiIiI2ZowXUM6AUCUABClOobqh9SyZYsv1QSQB/d+Jh6PInmJKB0/8JnGP+WHPe/LS+OeunjD9dedePjhhweTZgAQJQBEqe48t6G3tGx5+P281d4lSF4kSse+/YfO/n/lyf333vlLaGjIuqSkpCtJPwCIEgCiVEtREy5q92tb34fvP3byx3zvEyQvFKWj33wqP+//WGZOfUGaN7/58IgRI9qSlgAQJQBEqZahlvJo17btl8sWz/rVK6NIXixKR7/5RJeljzdlym0dbj03ePDgKNIUAKIEgCjVEtRisR06tN//z/dyvFuQvFyUFF/vyJVuXcJ+i4uLHUPaAkCUABAlH0fNPB3U6bb/5H/xoW9IkpeL0s9ffyTf79oqD95398XBA2Onk/YAECUARMmHI0lKkg4d2Ok7kuQDonRk34dyuOADebTPvYVDhgxZQPoDQJQAECUfQw3/b9e2zQ8+J0k+Ikq6LOV/IN26dC58+umnXycNAiBKAIiSj6CWIvH3b/2tTzW3+aAoHSn4QL7buUXCQgIKtXv+MukQAFECQJR8AH9//+1565f5piT5mCipJrjtW7OkTetbCidPnhxL+gNAlAAQJS9GrdmmliPx+ikAapEoHc5/XxZmvCS3d4k4n5qaGk46BECUABAlL0R13u7Y/tbDJ38s8F1J8lFROpz/ngzq96AkJiYeS05Ovob0CIAoASBKXoZau00tS+LTkuTDolTwz2xp0fxmmT9//oekSQBECQBR8iL69u3b+54e3Y75dJObj4vSob1/l4ljR8rDffr8Onv27ETKCABECUioiJIXkJqaekWjRo18a1LJWipK332RJwG3tZO/vf63Y9pzaUg5AYAoAQkVUfIw/bq2nKjdAxmapQmGEo2VA8XPb4Csq2x06fMUifQLlmk7Knf8+sdCZNrnBy99f/26g+XVHQeqVpTeitHOGyCpH3xRSpRWDuwkU97fXkqUVgy4TSb/XZOk+X20YzvKpK0fVUiUFC+qqNJDD13MzMycTbQTAFECEiqi5GFuu/n//qVEyRKaIl+dUKI0QKzWuMqLkkalm/CU7FiDNNk5eOn769cdVC2iZLV2Ki1Kix/R3rujTH6vhCgteEjb3kFeetcuSlbt9aWI0s4PVknjRg1lw/oNR9LS0gIoKwAQJSChIkoeQk0ueUODK89YLP0kbUqQDF15UC44idIiGebnp/1ttdPZLlPrH/PTZMAUddKjSH4SMeU9ueAUUXpfpoWpfdWxwRKh/bbpkStX59X27ay91qTNag3W5Wd9guNYDf3cTqJUYv8pcboohXd2nFN9BiVJK+LEz8/Y1l/WaIK0dkjxea2D52hypEQpV6aGOraHBEq49vuxt3bKKYcohYYY53hEsr5fL6nBxnur6NF2hyitlilF2zvKSxM0UbJ0kJAg49jekllgF6Vl/YuvIXTcUvnJIUo/7XlXorvfLsnJyb8tXbr0DaJKAIgSkFARJQ/Rq1ev4UPuanHOYlFitEiGasKyZ2WcU0Tpgt7nRyPLiNgc1MVISU+4Q172pAYXH6P/L0gXpT2pIZoMxMna4wfkwg77MUYTn8vzOqJCadsPOB97YqHYNLGyGc2DRRGl4v3tr1UT4rdy/vh8Gaq91+MrvpHzK/rr2x9fViDnft4n55f3187bT1brUaQ58rjVT8JfzJUvJgZp2x+VVT98Kac/HquJkkUSikTJIkMW/1tO/CdDErTzDln0Lzmx+BG7DP39s1IRJT2KtO0TR0TJIoPnfSiHv35V4rVjB839QP7xQkfxszwgS/e+r8nRVBmsXcPgN97VZUmJ0owpSdLz3mjJ25R3NDU19UrKCwBECUioiJIHCA0Nypo3MlysFrvk7EkdINNSnUXJHj2y6hW+xVLcLLY+QdsWWhwJMqTJWZSCHft8p0enbCZRcnnelcXStH6IEZmxR11U82B4yajSytKSZW96W1BClAIl7bN9etPb7peCxBryguw6bG96WzNYO/+gNzRRChBr8Fj54kfV9DZbHtOOTzBFlOxNb6+XEiVXTW9Wl01v04pEaVm/0p8t+Pm3ikTpsy2ZevNbXm7e8YyMjD6UFwCIEtRBoqKiRmmJtNDDiBdcg8e4ql69kwWv93ZqarP5qYrb/rcuM5ro7D5eIvJjFqIpcXrkx9wM5yRKTpEmuyjpTWquzmsSH0Oy9H2M6FOpPkqXLkrnl8dqf/eTNXr/pLnyuLZfmB5RCtS2PyqrVf+kT0pGlKpWlP7xQgexBiTKx3pEyd4/ydz09tOebdKkcUPJXJopWcuzsmh+A0CUoI6iEqmneOCBB4Y4MoqfJ6/DUyQlJTW85uoGZy5klYggqUiRQ5Ts8uHoXxMaJOHm0XGOff00oQifbIr0mETpt5PvyaudrfbI0ZA4GWoc7+68Dpmy91H6e/Gxpv5RJUfYFe3v6KNUrij9XCBr4ovPaxn0hpzR+yhtlJdDHNsHPioJlnJE6YPnpLO1ZB8lTZT+/oyEWp37KJUUpcP7lsvEQNNnC/yTfLLHWZQe7HmXTBg/QTZu3HhYRBAlAEQJwPcyii+jlizxb93qmD5CzDxKzRG9sf9tiua4iuq4ifS4Ot+FE+amN/fnvWB+f6d93I+ws+/v+O2YR0kf7aaPetuvC5LTqDfHiLezej8l06g3fbTbbjn9g6np7Ydd+mg3Yx6lE2r+JMf0AMcdkaSS0wPY50+yUzSHkobqxH3YGPWW/74cyjciSsWj3gxRsg16WEY+OVL1UzqVmpranDwLgCgBIEo1SHx8fLfOoUFHq3U2bsdouKK+OKEuokLeMuHkp89LRNHoOO1ag8fIv3+o2QknzaL07JODJX5wvOTl5Z2cOXNmLHkWAFECQJRqkJiYmH69e91zorqXLblQgaiQt8zMfaYoovSlTk3PzG0WpZeTR0mf3r1l65atv8yePXsUeRYAUQJAlGr488c+2vtkrVjfrZYsYWIWpRmT/yz39ewp7257Vy2Um0KHbgBECQBRqkFqpOkNUbrspjclSpmZmQsQJQBECQBRqkFsNltYp/a3IkpeKkp/GhortqE2XZSYIgAAUQJAlGoYtXyJPj2At4lSUQfwYKc5m0ptK1eU5uuzeQ9dvl/OuxOlT8dJhF+gvPLJHq8TJWN6AJreABAlAETJQzSoX//4d/nbvU6U1DxMQ4cESXhq8RIpEUPiJNxizM9UMVHS51IqR5TCrQFeKUotm98sixYslG1bt/02b968seRZAEQJAFGqYTp06LBl5VtzvVKU1Izf1iGL9JFyamLLoakpmtQUi1LxEigaCQsdI+rMi/AG6hNZGqK0zrQQbvikzXLOi0Up/x/rpX79q5QkMT0AAKIEgCh5iqioqKdH2OLPeVXzW9HM3otkqDVO1p9w/N5hEqWVA50XzLX6ScSU9+QrYyFd1S9p+wTtPHZR2j05WNseK6s1OfrlyFx53M9PHs/Ml7NeKkoL/jpR7ri9S5EopaamtiXPAiBKAIhSDTN69OhmjRre6F1TBBSJ0nsyrXOwTFupCZKaqHKHu8V2HcuuDFmoiVKQY30456a3dfGlF6ENm5jntaLUt0+0jEkao/dPytuUd5YlTAAQJQBEyUO0adN6x+YNy71QlA7K+iFWTZKCxKKa4MxryOlrxZkW8lXNaXpEybEIrxrxtsMcUdIEKmS87Dri6Jtk4IWidPDfm/Rmt9yNuboorVq1aiuiBIAoASBKHrwPsY8+dNprokqlhMi8YK7RR+mgrEswLWw7ZIH8qkeXTIvwOvVR2ippoaZFaENfkF2HvVOUZkwZIz3vjTaiSadmzZo1hPwKgCgBIEoeIjU19YrrrrvuiDeNfiu1KG+Zi+2WWBrl+AHHYrjf6Jw35lEyj3Y74rwwrjfNo3Rrm1tk7py5uihtztt8Tns+V5JfARAlAETJg0RHRz83wjbkl1ox+aQPTzg5+9UJ0qP7XbokMdEkAKIEgCh5Ec2aNtn/2fvvIEoeEqXvvsiTJo0bytsr3zaiScfT0tICSJsAiBIAouQFDB48+M6IzsHeN1N3HRGl0U/GS0J8vCFJv67KWvUOaRMAUQJAlLyIbl27zn154oRCRKlmRemdFbOkY7tb9XmTlChtydtyIjU1tRFpEgBRAkCUvIikpKQr/f1bH/TpJjgfE6V9n70j7dreIssyM4tGui1atCiNdAmAKAEgSl7IiBEj2nbs0O7M4YO7EKUaEKV7e3SVSZMmFXXgXrt27ecrVqzwIy0CIEoAiJKX8vjjj3cLCw2+cOqnAkSpGkWp78P3yvNjxhRJUm5u7g8zZsygyQ0AUQJAlLydhISEodFRd//mc7LkI6I0emSCJAyJL5KkjRs3Hp45c+ZdpD0ARAkAUfIRBg8ePF6TpYs+1QznA6L0J9sAecwkSZs3bf551qxZT5LmABAlAETJxxg5cuSLEWGhFwt2foQoXaYo/Xf3u9KnVw8ZPsxWLEl5m48vXLjwJdIhAKIEgCj5IOr+jB07dnxIcOBvH2xeiyhVUpS++nSD3Nk1TCZMmFBSktK1e0znbQBECQBR8mWSk5OHtm/X7sLE5CRE6RJFacX86XJrm9aSPj29SJI2bdx0zBFJQpIAECUARKk2MGnSpIB+/fqd6BIZJt60iK43i9JTwwdJeFjnoqVJjI7bGRkZg0l7AIgSAKJUy0hJSWk+ZcqUb5s0biTjk56W04f2IUouRGnJG6/ILS2ayTCbrWjGbT2SlLvpEKPbABAlAESpFqPu2fz58zPiBw4817RpE/nrtMmIkkOU8ta8KZGdg+SOrrfLooULiwRJLUuybs26j1NTU/+PNASAKAEgSnVAltLS0u5clrns6IP333/xllYtZcPbi+qsKH3x0XrpeU836dihnd4XyRxFUpKkieVYESGtASBKAIhSXSI1NfXKhQsXps6dM/dYeFhYoeq/5NG14mpYlPJ35MkTj/WXxo0byaSJk5wESY1qy1qelcUCtwCIEgCiVMejS5oMNMzMzJz9ytRXzrZt4y/394ySebOm1XwfphoSpVVLMiQ25gFRfbX+NHJkyX5IxxzNbIGkLwBECQBRgiJhUp29V69evSU5Ofn0fT17SoMG9WVg/xjJXrXY50Vp+3trZcTQOLn+umv1kWxjksZI7sbcIkHKy8s7mZ2dvX/atGl30cwGgCgBIErgEiUJqamp4evXrd+RvSH7mBKKiPAwuf766yRxxOOy67NtPiNKX//7XXn5xT9Lq5bNpUXzZjLyyZH6UH9zBEkJkhryP2PGjP4IEgCiBEBGgQoLU1paWnhmZuaCvE15Z1csX3FCiUaLFs1Fdf5OemaEvPVmRtWK02WK0jc735c1S9+Q558dIZHhIXLdtdfKozEx+gg2JznalHdq65atv2RlZW2YOXNmLIIEgCgBkFGgcgWKdo+VSMyYMaOPEovNeZtPz39z/hnbUJv06NFdF6crrrhCVEfwCWNHydtL58q+XR9Xuyj9uO8zyV2zWMY9N1Lui+6uN6ldpxERFibxg+NLjV5TYqQEae3atZ/PmjVrSEpKyjWkHwBECYCMAlUqTUowlGgo4VDisSl30ynV10eJiRKUbnd0lSaNG+v9m5Q8xTz0gC5QBioKtSV7RRFHvvvSSZQ2Zy+XzRuW6axfuUDGJz2lkSgvaAyN7y9dIkKlaVPt/PXrS0hQoP6easSa0aRWUo7U6LXc3Nzv58+f/0JqampzokcAlP/cSCCjQLXj6MvUXEnT4sWLX8/Ozv7KGDWWl5t3dv269bo8TRg/QZcZAxWFCgkOLEIJj9VqLcL8P9U3ynzsM6Oe0c+ZuTSzlBRpr39T771l85YLSozU0P7Zs2ePSktLC0COACj/ESUgo4DHMJrnjH5Nmjw9ofo2qVFkhjzpArUp75RDaiqMIULmKJFxPvVadcRWTYLz5s0bO2PGjDvV3FDqOkgbAJT/iBKQUagMfUKelMAoVPRp/vz5KQZKcFQTnoGKBikZUtEpY5ua08h8jIoSGedTzYBIEQDlP6IEgCjVKoEyY8hUWZj35x4CUP4jSgCIEgAAIEoAiBIAACBKAIgSAAAgSgCIEgAAIEoAiBIAACBKAIgSAAAgSgCIEgAAIEoAZBQAAECUAMgoAABA+Y8oARkFAAAo/xElAEQJAIDyH1ECQJQAAABRAkCUAAAAUQJAlAAAAFECQJQAAABRAkCUAAAAUQJAlAAAAFECQJQAAABRAkCUAAAAUQIgowAAAOU/ogRkFAAAoPxHlICMgigBAFD+I0oAiBIAACBKAIgSAAAgSgCIEgAAIEoAiBIAACBKAIgSAAAgSgCIEgAAIEoAiBIAACBKAIgSAAAgSgBkFAAAoPxHlICMAgAAlP+IEpBRECUAAMp/RAkAUQIAAEQJAFECAABECQBRAgAARAkAUQIAAEQJAFECAABECQBRAgAARAkAUQIAAEQJAFECAABECYCMAgAAiBI3EsgoAABA+Y8oARmF+wEAQPmPKAEgSgAAlP+IEgCiBAAAiBIAogQAAIgSAKIEAACIEgCiBAAAiBIAogQAAIgSAKIEAACIEgCiBAAAiBIAGQUAABAlADIKAABQ/iNKQEYBAADKf0QJAFECAKD8R5QAECUAAECUABAlAABAlAAQJQAAQJQAECUAAECUABAlAABAlAAQJQAAQJQAECUAAECUAMgoAACAKAGQUQAAgPIfUQIyCgAAUP4jSgCIEgAA5T+iBIAoAQAAogSAKAEAAKIEgCgBAACiBIAoAQAAogSAKAEAAKIEgCgBAACiBIAoAQAAogSAKAEAAKIEQEYBAADKf0QJyCgAAED5jygBGQVRAgCg/EeUABAlAABAlAAQJQAAQJQAECUAAECUABAlAABAlAAQJQAAQJQAECUAAECUABAlAABAlAAQJQAAQJQAyCgAAED5jygBGQUAACj/ESUgoyBKAACU/4gSAKIEAACIEgCiBAAAiBIAogQAAIgSQDVllFatWr0THx/fDQAA6g4RERGp7dq1ewtRAiiDwYMH333ttdfuatas2TYAAKg7NGzY8NOwsLA0RAmgvISuZRIAAKibXFb9QSUKAAAAgCgBAAAAIEoAAAAAiBIAAAAAogQAAACAKAEAAAAgSgAAAACIEgAAAACiBAAAAIAoAQAAACBKAAAAAIgSAAAAACBKAAAAAIgSAAAAAKIEAAAAgCgBAAAAIEoAAAAAiBIAAAAAogQAAACAKAEAAAAgSgAAAACIEgAAAACiBAAAAACIEgAAAEAF+P+GF4HIhBGqsgAAAABJRU5ErkJggg==" alt="Creating a BswmdModel in the Post-build selectable use case" id="fig:BswmdModelCreatePBSelectable "
 * data-latex-style="scale=1.0" />
 *
 * </div>
 *
 * <div class="extdoc" id="CreationModelView">
 *
 * Every {@link GIModelObject} (BswmdModel object) has a creation {@link IModelView}. This is the {@link IModelView}, which was active or passed during creation of the
 * BswmdModel. At every method call to the BswmdModel, the model will switch to this view.
 *
 * </div>
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 * @see TypedDefRef
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIModelObject extends IViewedModelObject {
    // CHECKSTYLE:ON

    /**
     * Returns the generator model access service of this object.
     *
     * @return
     */
    @PublishedMethod
    GIModelAccess getGeneratorModelAccess();

    /**
     * Returns the EcucDefinition of this object.
     *
     * @return the ecuc definition
     */
    @PublishedMethod
    IEcucDefinition getEcucDefinition();

    /**
     * Returns the EcucConfiguration object of this object as provided by {@link IEcuConfigurationAccess}. The returned object provides convenient access to the related MDF
     * model object.
     *
     * @return the ecuc configuration
     */
    @PublishedMethod
    IEcucHasDefinition getEcuConfiguration();

    /**
     * Returns the related configuration object in the MDF model.
     *
     * <p>
     * Attention: The returned {@link MIObject} could be invisible in the current active {@link IModelView}! You have to check the visibility in the client side code!
     * </p>
     *
     * @return
     */
    @Override
    @PublishedMethod
    MIHasDefinition getMdfObject();

    /**
     * Returns the root object (ModuleConfiguration) of this model object. If it is the moduleConfig it will return itself.
     *
     * @return
     */
    @PublishedMethod
    GIModuleConfiguration getModuleConfiguration();

    /**
     * Returns the related definition object in the MDF model.
     *
     * @return The MDF definition object of the {@link GIModelObject}.
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the element does not exist in the MDF model</li>
     * </ul>
     *
     */
    @PublishedMethod
    MIParamConfMultiplicity getDefinition();

    /**
     * Returns the object link as provided by the MDF model (see {@link IModelAccess#getObjectLink(MIHasDefinition)}).
     *
     * @return
     */
    @PublishedMethod
    String getObjectLink();

    /**
     * Returns the immediate parent of this model object or <code>null</code> if this object has no parent (module configurations).
     *
     * @return
     */
    @PublishedMethod
    GIHasContainer getParent();

    /**
     * Returns the parent of this model object or throws an {@link IllegalArgumentException}, if the passed {@link DefRef} could not be the parent of the element.
     *
     * <p>
     * Note: this method search the parent recursively for the requested parent.
     * </p>
     *
     * @return The parent with the passed DefRef.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the passed DefRef could never be the parent of this element</li>
     * </ul>
     */
    @PublishedMethod
    GIHasContainer getParent(DefRef parentDefRef);

    /**
     * Returns the parent of this model object or throws an {@link IllegalArgumentException}, if the passed {@link DefRef} could not be the parent of the element.
     *
     * <p>
     * Note: this method search the parent recursively for the requested parent.
     * </p>
     *
     * @return The parent with the passed DefRef.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the passed DefRef could never be the parent of this element</li>
     * </ul>
     */
    @PublishedMethod
    <DEF extends MIParamConfMultiplicity, CFG extends MIHasDefinition, VAL, WRAPPER extends GIHasContainer> WRAPPER getParent(
            WrappedTypedDefRef<DEF, CFG, VAL, WRAPPER> parentDefRef);

    /**
     * Returns the DefRef Object of the configuration element.
     *
     * @return The {@link DefRef}
     */
    @PublishedMethod
    DefRef getDefRef();

    /**
     * Checks if <code>this</code> object is an instance of the passed {@link DefRef}.
     *
     * <p>
     * Note: This method tests also refinements. So, if the {@link GIModelObject} is refined of the passed {@link DefRef}, it will also yield to true.
     * </p>
     *
     * <p>
     * See also method {@link DefRef#isDefinitionOf(MIObject)}.
     * </p>
     *
     * @param defRef The defRef to check.
     * @return <code>true</code>, if this is an instance of the defRef.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the passed DefRef is null</li>
     * </ul>
     */
    @PublishedMethod
    boolean isInstanceOfDefRef(DefRef defRef);

    /**
     * Returns the {@link ICeStatePublished} of the corresponding model object (see {@link #getMdfObject()}.
     *
     * <p>
     * <b>Note:</b> The returned {@link ICeStatePublished} is from the {@link CeStatePublishedFactory}.
     * </p>
     *
     * <p>
     * The method will never return <code>null</code>.
     * </p>
     *
     * @return the CeState.
     */
    @PublishedMethod
    ICeStatePublished getCeState();

    /**
     * <div class="extdoc" id="Using_getCreationModelView"> The method {@link #getCreationModelView()} returns the {@link IModelView} of this {@link GIModelObject}, which was
     * active during the creation of this BswmdModel.
     *
     * </div>
     *
     * @return the creation model view of the BswmdModel
     *
     * <p>
     * The method will never return <code>null</code>.
     * </p>
     */
    @Override
    @PublishedMethod
    IModelView getCreationModelView();

    /**
     * <div class="extdoc" id="Using_executeWithCreationModelView"> The method {@link #executeWithCreationModelView()} executes the code under visibility of the
     * {@link #getCreationModelView()} of this {@link GIModelObject}.
     * <p>
     * <b>The returned {@link IModelViewExecutionContext} must be used within a Java "try-with-resources" feature.</b> It makes sure, that the old view is restored when the try
     * is completed.
     * </p>
     *
     * <pre>
     * <code class="Java" id="Java: Execute code with creation IModelView of BswmdModel object">
     * GIModelObject myModelObject = ...;
     *
     * try (final IModelViewExecutionContext context = myModelObject.executeWithCreationModelView()) {
     *         // do some operations
     *         ...
     * }
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return The execution context
     * @see IModelViewManager#executeWithModelView(IModelView)
     */
    @PublishedMethod
    IModelViewExecutionContext executeWithCreationModelView();

    /**
     * <div class="extdoc" id="Using_executeWithCreationModelView_Supplier"> The method {@link #executeWithCreationModelView()} executes the {@link Supplier} code under
     * visibility of the {@link #getCreationModelView()} of this {@link GIModelObject}. You could use this method, if you want to return an object from this operation.
     * <p>
     *
     *
     * <pre>
     * <code class="Java" id="Java: Execute code with creation IModelView of BswmdModel object">
     * GIModelObject myModelObject = ...;
     *
     * ReturnType returnVal = myModelObject.executeWithCreationModelView(()->{
     *   // do some operations
     *   return theValue;
     *  });
     *
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return The execution context
     * @see IModelViewManager#executeWithModelView(IModelView)
     */
    @PublishedMethod
    <T> T executeWithCreationModelView(Supplier<T> code);

    /**
     * <div class="extdoc" id="Using_executeWithCreationModelView_Runnable"> The method {@link #executeWithCreationModelView(Runnable)} executes the {@link Runnable} code under
     * visibility of the {@link #getCreationModelView()} of this {@link GIModelObject}.
     * <p>
     *
     * <pre>
     * <code class="Java" id="Java: Execute code with creation IModelView of BswmdModel object via runnable">
     *  GIModelObject myModelObject = ...;
     *
     *  myModelObject.executeWithCreationModelView(()->{
     *   // do some operations
     *  });
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return The execution context
     * @see IModelViewManager#executeWithModelView(IModelView)
     */
    @PublishedMethod
    void executeWithCreationModelView(Runnable code);

    /**
     * Returns a bswmd model instance for the passed {@link MIHasDefinition} (mdfCfgElement). The element will be casted to type giModelClazz.
     *
     * <p>
     * Note: The used {@link IModelView} is the creation {@link IModelView}, from the {@link GIModelObject#getCreationModelView()}!
     * </p>
     *
     * @param <T> the generic type
     * @param giModelClazz the class of the bswmd model element.
     * @param mdfCfgElement the MDF configuration element.
     * @return single instance for the passed {@link MIHasDefinition}.
     */
    @PublishedMethod
    <T extends GIModelObject> T getInstanceInContextOfCreationModelView(Class<T> giModelClazz, MIHasDefinition mdfCfgElement);

}
