package com.vector.cfg.gen.core.utils.abstractImpl;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;

/**
 * {@link AbstractCalculator} provides an abstract implementation for customized model creators.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractCreator extends AbstractGeneratorPackageReferableWithModel {

    /**
     * Instantiates a new abstract creator.
     *
     * @param generatorPackageRef the generator package ref
     */
    @PublishedMethod
    protected AbstractCreator(IGeneratorPackageReferable generatorPackageRef) {
        super(generatorPackageRef);

    }
}
