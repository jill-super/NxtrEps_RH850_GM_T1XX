package com.vector.cfg.consistency.contribution;

import java.util.Collection;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.helper.validationresults.ValidationResultBuilder;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * An {@link IValidationResult} describes an inconsistency within the data model. Please use the {@link ValidationResultBuilder} API to construct instances of
 * {@link IValidationResult}s.
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * <p>
 * This interface is not intended to be implemented by clients.<br/>
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 * @see com.vector.cfg.consistency.contribution.helper.ValidationTupleResult ValidationTupleResult
 * @see com.vector.cfg.consistency.contribution.helper.ValidationTupleResultWithStorages ValidationTupleResultWithStorages
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IValidationResult {
    /**
     * This method returns an AutoSolvingAction or null, which is used for executing during the validation phase of the uow.
     *
     * @return
     */
    @PublishedMethod
    ISolvingAction getAutoSolvingAction();

    /**
     * This method returns the preferred SolvingAction or null, which is used for the "solve all" mechanism of the validation view. Either this method or
     * {@link #getPreferredUISolvingAction()} may return a solving action, but not both.
     *
     * @return
     */
    @PublishedMethod
    ISolvingAction getPreferredSolvingAction();

    /**
     * This method returns the ValidationResultId.
     *
     * @return
     */
    @PublishedMethod
    IValidationResultId getId();

    /**
     * This method returns a descriptive text of the inconsistency which can name the concrete CEs and concrete inconsistent values.
     *
     * @return
     */
    @PublishedMethod
    IMixedText getDescription();

    /**
     * This method returns the severity of the inconsistency.
     *
     * @return
     */
    @PublishedMethod
    EValidationSeverityType getSeverity();

    /**
     * This method returns the SolvingAction collection. <BR>
     * see {@link http://wiki.vi.vector.int/wiki-psc/Cfg5Development/Consistency}
     *
     * @return
     */
    @PublishedMethod
    Collection<ISolvingAction> getSolvingActions();

    /**
     * This method returns the UI-SolvingAction collection. <BR>
     *
     * @return
     */
    @PublishedMethod
    Collection<IUISolvingAction> getUISolvingActions();

    /**
     * Gets the preferred UI solving action or null. Either this method or {@link #getPreferredSolvingAction()} may return a solving action, but not both.
     *
     * @return the preferred ui solving action
     */
    @PublishedMethod
    @Nullable
    IUISolvingAction getPreferredUISolvingAction();

    /**
     * This method returns the tuple that describes the CEs belonging to the validation context.
     *
     * @return
     */
    @PublishedMethod
    Collection<IDescriptor> getDependentCEs();

    /**
     * This method returns the erroneous CEs which are a subset of ITuple.getCEs().
     *
     * @return
     */
    @PublishedMethod
    Collection<IDescriptor> getErroneousCEs();
}
