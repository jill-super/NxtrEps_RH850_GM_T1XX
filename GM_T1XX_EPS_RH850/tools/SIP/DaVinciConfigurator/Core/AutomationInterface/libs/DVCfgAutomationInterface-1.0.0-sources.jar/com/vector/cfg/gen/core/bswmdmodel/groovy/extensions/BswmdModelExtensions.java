package com.vector.cfg.gen.core.bswmdmodel.groovy.extensions;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.List;
import java.util.Optional;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.services.ActiveProjectContextHolder;
import com.vector.cfg.gen.core.bswmdmodel.GIModelFactory;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIOptional;
import com.vector.cfg.gen.core.bswmdmodel.groovy.api.IBswmdModelApiEntryPoint;
import com.vector.cfg.gen.core.bswmdmodel.groovy.api.IBswmdModelFactoryHolder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.scripting.groovy.ClosureCalls;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * This class provides extension methods for BswmdModel object like {@link GIModelObject} and other helper classes like optionals. The bswmdModel methods are the same as in the
 * API interface {@link IBswmdModelApiEntryPoint}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class BswmdModelExtensions {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BswmdModelExtensions.class);

    private BswmdModelExtensions() {
    }

    /**
     * Returns the bswmd objects found with the specified DefRef, or empty if no elements were found.
     *
     * @param <WRAPPER_TYPE> the bswmd model instance type
     * @param defRef an definition to search for
     * @return The found object list
     */
    @PublishedMethod
    public static <WRAPPER_TYPE extends GIModelObject> List<WRAPPER_TYPE> bswmdModelRead(WrappedTypedDefRef<?, ?, ?, WRAPPER_TYPE> defRef) {

        final IProjectContext projectContext = ActiveProjectContextHolder.INSTANCE.getCurrentActiveProjectOfThisThreadChecked();
        return projectContext.getInstance(IBswmdModelApiEntryPoint.class).bswmdModelRead(defRef);
    }

    /**
     * Calls the closure for each single bswmd object found with the specified {@link DefRef}.
     *
     *
     * @param <WRAPPER_TYPE> the bswmd model instance type
     * @param defRef an definition to search for
     * @return The found object list
     */
    @PublishedMethod
    public static <WRAPPER_TYPE extends GIModelObject> List<WRAPPER_TYPE> bswmdModelRead(@DelegatesTo.Target WrappedTypedDefRef<?, ?, ?, WRAPPER_TYPE> defRef,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "T") Closure<?> code) {

        final IProjectContext projectContext = ActiveProjectContextHolder.INSTANCE.getCurrentActiveProjectOfThisThreadChecked();
        return projectContext.getInstance(IBswmdModelApiEntryPoint.class).bswmdModelRead(defRef, code);
    }

    /**
     * Returns the found bswmd object from the passed MDF model object.
     *
     *
     * @param <CONFIG_TYPE> the MDF model type
     * @param <WRAPPER_TYPE> the bswmd model instance type
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    public static <CONFIG_TYPE extends MIHasDefinition, WRAPPER_TYPE extends GIModelObject> WRAPPER_TYPE bswmdModelRead(
            CONFIG_TYPE obj,
            WrappedTypedDefRef<?, CONFIG_TYPE, ?, WRAPPER_TYPE> defRef) {
        return getBswmdModelInstance(defRef.getModelWrapperClass(), obj);
    }

    /**
     * Calls the closure on the found single bswmd object from the passed MDF model object.
     *
     *
     * @param <CONFIG_TYPE> the MDF model type
     * @param <WRAPPER_TYPE> the bswmd model instance type
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    public static <CONFIG_TYPE extends MIHasDefinition, WRAPPER_TYPE extends GIModelObject> WRAPPER_TYPE bswmdModelRead(
            CONFIG_TYPE obj,
            @DelegatesTo.Target WrappedTypedDefRef<?, CONFIG_TYPE, ?, WRAPPER_TYPE> defRef,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "WRAPPER_TYPE") Closure<?> code) {

        final WRAPPER_TYPE instance = getBswmdModelInstance(defRef.getModelWrapperClass(), obj);
        ClosureCalls.callWithDelegateFirst(instance, code);
        return instance;
    }

    private static <T extends GIModelObject> T getBswmdModelInstance(Class<T> clazz, MIHasDefinition obj) {
        checkNotNull(obj, "Model object was null");
        checkNotNull(clazz, "BswmdModel class was null");

        final IProjectContext projectContext = ModelAccessUtil.getProjectContext(obj);
        final GIModelFactory modelFactory = projectContext.getInstance(IBswmdModelFactoryHolder.class).getCurrentModelFactory();
        final T instance = modelFactory.getInstance(clazz, obj);
        return instance;
    }

    /**
     * The method <code>executeWithCreationModelView(Closure)}</code> executes the {@link Closure} code under visibility of the {@link GIModelObject#getCreationModelView()} of
     * this {@link GIModelObject}. You could use this method, if you want to return an object from this operation.
     * <p>
     *
     *
     * <pre>
     * <code class="Groovy" id="Execute code with creation IModelView of BswmdModel object">
     * GIModelObject myModelObject = ...;
     *
     * ReturnType returnVal = myModelObject.executeWithCreationModelView {
     *   // do some operations
     *  }
     *
     * </code>
     * </pre>
     *
     * @param <T> the generic type of the BswmdModelObject
     * @param bswmdModelObject the bswmd model object
     * @param code the code to execute
     * @return The execution context
     * @see IModelViewManager#executeWithModelView(IModelView)
     */
    @PublishedMethod
    public static <T extends GIModelObject> void executeWithCreationModelView(@DelegatesTo.Target T bswmdModelObject,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST) @ClosureParams(value = FromString.class, options = "T") Closure<?> code) {

        try (IModelViewExecutionContext ctx = bswmdModelObject.executeWithCreationModelView()) {
            ClosureCalls.callWithDelegateFirst(bswmdModelObject, code);
        }
    }

    /**
     * Converts the {@link GIOptional} to a boolean value <code>true</code>, if the element exists, otherwise <code>false</code>.
     *
     * @param optional the optional to check
     * @return true, if {@link GIOptional#exists()} returns <code>true</code>
     */
    @PublishedMethod
    public static boolean asBoolean(GIOptional<?> optional) {
        if (optional == null) {
            return false;
        }
        return optional.exists();
    }

    /**
     * If a value is present, invoke the specified {@link Closure} with the value, otherwise do nothing.
     *
     * @param <T> the optional reference type
     * @param <R> the return type of the called closure code
     * @param optional to optional to check
     * @param code block to be executed if a value is present
     * @return the return value of the closure, or <code>null</code>, if nothing was executed.
     * @throws NullPointerException if value is present and {@code code} is null
     */
    @Nullable
    @PublishedMethod
    public static <T extends GIModelObject, R> R ifPresent(@DelegatesTo.Target GIOptional<T> optional,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "T") Closure<R> code) {
        if (optional.exists()) {
            return ClosureCalls.callWithDelegateFirst(optional.get(), code);
        }
        return null;
    }

    /**
     * Converts the {@link Optional} to a boolean value <code>true</code>, if the element is present, otherwise <code>false</code>.
     *
     * @param optional the optional to check
     * @return true, if {@link Optional#isPresent()} returns <code>true</code>
     */
    @PublishedMethod
    public static boolean asBoolean(Optional<?> optional) {
        if (optional == null) {
            return false;
        }
        return optional.isPresent();
    }

    /**
     * If a value is present, invoke the specified {@link Closure} with the value, otherwise do nothing.
     *
     * @param <T> the optional reference type
     * @param <R> the return type of the called closure code
     * @param optional to optional to check
     * @param code block to be executed if a value is present
     * @return the return value of the closure, or <code>null</code>, if nothing was executed.
     * @throws NullPointerException if value is present and {@code code} is null
     */
    @Nullable
    @PublishedMethod
    public static <T, R> R ifPresent(@DelegatesTo.Target Optional<T> optional,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "T") Closure<R> code) {
        if (optional.isPresent()) {
            return ClosureCalls.callWithDelegateFirst(optional.get(), code);
        }
        return null;
    }

    /**
     * Converts the {@link com.google.common.base.Optional} to a boolean value <code>true</code>, if the element is present, otherwise <code>false</code>.
     *
     * @param optional the optional to check
     * @return true, if {@link com.google.common.base.Optional#isPresent()} returns <code>true</code>
     */
    @PublishedMethod
    public static boolean asBoolean(com.google.common.base.Optional<?> optional) {
        if (optional == null) {
            return false;
        }
        return optional.isPresent();
    }

    /**
     * If a value is present, invoke the specified {@link Closure} with the value, otherwise do nothing.
     *
     * @param <T> the optional reference type
     * @param <R> the return type of the called closure code
     * @param optional to optional to check
     * @param code block to be executed if a value is present
     * @return the return value of the closure, or <code>null</code>, if nothing was executed.
     * @throws NullPointerException if value is present and {@code code} is null
     */
    @Nullable
    @PublishedMethod
    public static <T, R> R ifPresent(@DelegatesTo.Target com.google.common.base.Optional<T> optional,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "T") Closure<R> code) {
        if (optional.isPresent()) {
            return ClosureCalls.callWithDelegateFirst(optional.get(), code);
        }
        return null;
    }
}
