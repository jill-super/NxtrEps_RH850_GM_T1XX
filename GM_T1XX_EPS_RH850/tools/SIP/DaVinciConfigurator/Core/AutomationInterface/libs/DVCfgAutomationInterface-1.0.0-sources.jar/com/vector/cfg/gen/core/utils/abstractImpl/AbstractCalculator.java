package com.vector.cfg.gen.core.utils.abstractImpl;

import static com.google.common.base.Preconditions.checkNotNull;

import java.text.MessageFormat;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.calculation.ECalculationSubPhase;
import com.vector.cfg.gen.core.moduleinterface.calculation.ICalculator;

/**
 * {@link AbstractCalculator} provides an abstract implementation of {@link ICalculator}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractCalculator extends AbstractGeneratorPackageReferableWithModel implements ICalculator {
    //    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractCalculator.class);

    private volatile IGeneratorResultSink resultSink;

    private final ECalculationSubPhase associatedSubPhase;

    /**
     * Constructor for AbstractCalculator.
     *
     * @param generatorPackageRef the generator package ref
     * @param associatedSubPhase the associated sub phase
     */
    @PublishedMethod
    protected AbstractCalculator(IGeneratorPackageReferable generatorPackageRef, ECalculationSubPhase associatedSubPhase) {
        super(generatorPackageRef);
        this.associatedSubPhase = checkNotNull(associatedSubPhase);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public final ECalculationSubPhase getAssociatedSubPhase() {
        return associatedSubPhase;
    }

    /**
     * Gets the current resultSink.
     *
     * <p>
     * Attention:<br/>
     * A {@link IGeneratorResultSink} is only available during a {@link #calculate(IGeneratorResultSink)}!
     * </p>
     *
     * @return The current active resultSink
     *
     * @throws IllegalStateException<ul>
     * <li>if no resultSink is currently available.</li>
     * </ul>
     */
    @Override
    @PublishedMethod
    public IGeneratorResultSink getResultSink() {
        if (resultSink == null) {
            throw new IllegalStateException("The resultSink is currently not available. The resultSink is only available in the calculate() method.");
        }
        return resultSink;
    }

    /**
     * Set the current ResultSink.
     * <p>
     * Attention: Do not use this method. It is for internal purpose.
     * </p>
     *
     * @param resultSink Sets the current ResultSink
     */
    @Override
    @PublishedMethod
    public void setResultSink(IGeneratorResultSink resultSink) {
        if (this.resultSink != null && resultSink != null) {
            throw new IllegalAccessError("You can't change the currently assigned ResultSink");
        }
        this.resultSink = resultSink;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        return MessageFormat.format("Calculator for phase \"{1}\" in ({0})", getGeneratorPackage(), getAssociatedSubPhase().getName());
    }

}
