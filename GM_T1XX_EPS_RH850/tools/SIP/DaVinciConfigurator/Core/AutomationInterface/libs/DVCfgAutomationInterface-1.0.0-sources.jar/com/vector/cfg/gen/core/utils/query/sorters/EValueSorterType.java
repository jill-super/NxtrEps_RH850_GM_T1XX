package com.vector.cfg.gen.core.utils.query.sorters;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;

/**
 * The {@link EValueSorterType} could be used to choose the behavior of some sorters, if duplicate values are allowed or forbidden. For example see
 * {@link GenIntParameterSorter}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EValueSorterType {

    VALUE_EQUAL_ALLOWED,
    VALUE_EQUAL_FORBIDDEN;
}
