package com.vector.cfg.dom.com.model.groovy;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.com.model.groovy.can.ECanAcceptanceFilterType;
import com.vector.cfg.dom.com.model.groovy.can.ICanController;

/**
 * {@link ICommunicationApi} provides high convenience support for communication related use cases.
 * <div class="extdoc" id="IDomainApi"><!--Label:IDomainApi-->{@link ICommunicationApi} provides high convenience support for communication related use cases.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICommunicationApi {

    /**
     * See {@link ECanAcceptanceFilterType#STANDARD}.
     */
    @PublishedField
    ECanAcceptanceFilterType STANDARD = ECanAcceptanceFilterType.STANDARD;

    /**
     * See {@link ECanAcceptanceFilterType#EXTENDED}.
     */
    @PublishedField
    ECanAcceptanceFilterType EXTENDED = ECanAcceptanceFilterType.EXTENDED;

    /**
     * See {@link ECanAcceptanceFilterType#MIXED}.
     */
    @PublishedField
    ECanAcceptanceFilterType MIXED = ECanAcceptanceFilterType.MIXED;

    /**
     * {@link #getCanControllers()} returns a list of all {@link ICanController}s in the configuration.
     * <div class="extdoc" id="getCanControllers"><!--Label:ICommunicationApi.getCanControllers-->
     * <h5>Accessing Can Controllers</h5>{@link #getCanControllers()} returns a list of all {@link ICanController}s in the configuration <!--Ref:ICanController-->.</div>
     *
     * @return a list of all {@link ICanController}s in the configuration (never {@code null}, may be empty)
     */
    @PublishedMethod
    List<ICanController> getCanControllers();

}
