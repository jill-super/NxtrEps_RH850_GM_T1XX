package com.vector.cfg.gen.core.bswmdmodel;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaDefinitionUndefinedException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaWrongTypeException;

/**
 * Base interface of bswmd model objects that has container.
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see MIHasContainer
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIHasContainer extends GIModelObject, GIHasParameterAccessFunctions {
    // CHECKSTYLE:ON

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    MIHasContainer getMdfObject();

    /**
     * Returns the objects shortname.
     *
     * @return
     */
    @PublishedMethod
    String getShortname();

    /**
     * Convenience method to set the shortname of the {@link GIHasContainer}.
     *
     * @param newShortname
     *
     */
    @PublishedMethod
    void setShortname(String newShortname);

    /*----------------------------------------------------------------
     * existsSubContainer() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns <code>true</code> if the specified sub-container exists.
     *
     * @param defRef The {@link DefRef} of the subcontainer.
     * @return
     */
    @PublishedMethod
    boolean existsSubContainer(DefRef defRef);

    /**
     * Returns <code>true</code> if the specified sub-container exists.
     *
     * @param defName the The DefRef of the subcontainer.
     * @return
     *
     * @deprecated Please use {@link #existsSubContainer(DefRef)}.
     */
    @Deprecated
    @PublishedMethod
    boolean existsSubContainer(String defName);

    /*----------------------------------------------------------------
     * getSubContainer() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns one sub-container with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the subcontainer.
     * @return the requested container
     */
    @PublishedMethod
    GIContainer getSubContainer(DefRef defRef);

    /**
     * Returns one sub-container with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the subcontainer.
     * @return the requested container
     */
    @PublishedMethod
    <DEF extends MIContainerDef, CFG extends MIContainer, VALUE> GIContainer getSubContainer(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns one sub-container with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the subcontainer.
     * @return the requested container
     */
    @PublishedMethod
    <DEF extends MIContainerDef, CFG extends MIContainer, VALUE, WRAPPER extends GIContainer> WRAPPER getSubContainer(WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * getSubContainers() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns the list of sub-containers.
     *
     * @return A unmodifiable List of containers for the request.
     */
    @PublishedMethod
    List<GIContainer> getSubContainers();

    /**
     * Returns all sub-containers with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * <p>
     * If no container was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if
     * no or one element was found.
     * </p>
     *
     * @param defName The DefRef of the subcontainer.
     * @return A unmodifiable List of containers for the request.
     *
     * @exception McaDefinitionUndefinedException <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaWrongTypeException <ul>
     * <li>if the retrieved elements has the wrong type</li>
     * </ul>
     *
     * @deprecated Please use {@link #getSubContainers(DefRef)}.
     */
    @Deprecated
    @PublishedMethod
    List<GIContainer> getSubContainers(String defName);

    /**
     * Returns all sub-containers with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * <p>
     * If no container was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if
     * no or one element was found.
     * </p>
     *
     * @param defRef The {@link DefRef} of the subcontainer.
     * @return A unmodifiable List of containers for the request.
     *
     * @exception McaDefinitionUndefinedException <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaWrongTypeException <ul>
     * <li>if the retrieved elements has the wrong type</li>
     * </ul>
     */
    @PublishedMethod
    List<GIContainer> getSubContainers(DefRef defRef);

    /**
     * Returns all sub-containers with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * <p>
     * If no container was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if
     * no or one element was found.
     * </p>
     *
     * @param defRef The {@link DefRef} of the subcontainer.
     * @return A unmodifiable List of containers for the request.
     *
     * @exception McaDefinitionUndefinedException <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaWrongTypeException <ul>
     * <li>if the retrieved elements has the wrong type</li>
     * </ul>
     */
    @PublishedMethod
    <DEF extends MIContainerDef, CFG extends MIContainer, VALUE> List<GIContainer> getSubContainers(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns all sub-containers with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * <p>
     * If no container was found, the collection is EMPTY and not <code>null</code>, so you must not check against <code>null</code>. No exception is thrown, if
     * no or one element was found.
     * </p>
     *
     * @param defRef The {@link DefRef} of the subcontainer.
     * @return A unmodifiable List of containers for the request.
     *
     * @exception McaDefinitionUndefinedException <ul>
     * <li>if the DefinitionRef is invalid</li>
     * </ul>
     *
     * @exception McaWrongTypeException <ul>
     * <li>if the retrieved elements has the wrong type</li>
     * </ul>
     */
    @PublishedMethod
    <DEF extends MIContainerDef, CFG extends MIContainer, VALUE, WRAPPER extends GIContainer, T extends WRAPPER> List<T> getSubContainers(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

}
