package com.vector.cfg.consistency.contribution;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.event.IRuleEventCollection;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasOnModelEvent {

    /**
     * On model event.
     *
     * <p>
     * The passed events parameter could have the actual type {@link IRuleEventCollection}. You could check and cast to the type {@link IRuleEventCollection} to
     * get details information about the events. See {@link IRuleEventCollection} for more details.
     * </p>
     *
     * @param results the results
     * @param events the events
     */
    @PublishedMethod
    void onModelEvent(IValidationResultSink results, IValidationEvents validationEvents);
}
