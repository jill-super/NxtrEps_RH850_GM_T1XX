package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasValidationOrigin;

/**
 * This interface defines the available model access services for the bswmd model.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGeneratorModelAccess extends GIModelAccess, IGeneratorPackageReferable {

    @PublishedMethod
    IHasValidationOrigin getValidationResultOrigin();

    /**
     * Gets the corresponding GeneratorPackage, if the Model was created with an {@link IGeneratorPackage}.
     *
     * @return The GeneratorPackage
     */
    @Override
    @PublishedMethod
    IGeneratorPackage getGeneratorPackage();

}
