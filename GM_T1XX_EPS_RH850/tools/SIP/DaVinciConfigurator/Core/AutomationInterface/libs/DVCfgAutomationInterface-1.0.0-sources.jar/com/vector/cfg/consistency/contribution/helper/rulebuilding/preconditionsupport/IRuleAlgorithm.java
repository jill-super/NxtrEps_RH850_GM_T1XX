package com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IRuleFilterContribution;
import com.vector.cfg.consistency.contribution.IValidationEvents;
import com.vector.cfg.consistency.contribution.IValidator;

/**
 *
 * This interface defines the necessary methods for a validation-rule in order to be usable as a validation-precondition for another validation-rule.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IRuleAlgorithm<CONTEXTTYPE> {

    /**
     * Gets the {@link IRuleFilterContribution} used by this algorithm.
     *
     * <p>
     * This method could also be implemented by the same method of {@link IValidator#getFilter()}!
     * </p>
     *
     * @return the filter of the algorithm/validation.
     */
    @PublishedMethod
    IRuleFilterContribution getFilter();

    /**
     * If the event is an input for this algorithm, this method returns the affected contexts, otherwise an empty list.
     *
     * @param validationEvents the validation events
     * @return the affected contexts
     */
    @PublishedMethod
    Collection<CONTEXTTYPE> getAffectedContexts(IValidationEvents validationEvents);

    /**
     * Please document in your RuleAlgorithm what the context object has to be and specify the concrete AlgorithmResult type.
     *
     * @param context
     * @return
     */
    @PublishedMethod
    IRuleAlgorithmResult perform(CONTEXTTYPE context, IValidationEvents validationEvents);
}
