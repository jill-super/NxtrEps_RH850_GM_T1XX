package com.vector.cfg.gen.core.utils.frameworkinternal;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.vector.cfg.consistency.EValidationSeverityType.ERROR;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiVersionCheck;
import com.vector.annotations.publishedapi.PublishedApiVersionInfo;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationSeverityResultId;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageException;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageInitializationException;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.gen.core.utils.generatorresult.ValidationSeverityResultId;
import com.vector.cfg.model.query.definitionverify.AbstractPublishedApiVersionVerifier;

/**
 * GenPublishedApiVersionVerifier verifies an {@link PublishedApiVersionCheck} annotation against the current Range in the System.
 *
 * <p>
 * In Error cases {@link GeneratorPackageException} are thrown.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenPublishedApiVersionVerifier extends AbstractPublishedApiVersionVerifier {

    private IValidationSeverityResultId resultId;

    private GenPublishedApiVersionVerifier() {
        super();
    }

    /**
     * Creates a new {@link GenPublishedApiVersionVerifier} instance.
     *
     * @return the new {@link GenPublishedApiVersionVerifier}
     */
    @PublishedMethod
    public static GenPublishedApiVersionVerifier create() {
        return new GenPublishedApiVersionVerifier();
    }

    /**
     * {@inheritDoc}
     */
    @KeepSecretFromPublishedApi
    @Override
    protected DomainType getDomainTypeToVerify() {
        return DomainType.GENERATORS;
    }

    /**
     * {@inheritDoc}
     */
    @KeepSecretFromPublishedApi
    @Override
    protected RuntimeException reportFailedVersionCheck(Class<?> clazz, String expectedVersion, String actualVersionRange, String description) {
        final IGeneratorResult result = GeneratorResultBuilder.newBuilder(resultId,
                "CfgCoreFeature VersionCheck failed. The class {2} requires the version: {0}. But the current CfgCore version is: {1}. {3}", expectedVersion, actualVersionRange,
                clazz.getName(), description).buildResult();
        throw new GeneratorPackageInitializationException(result);
    }

    /**
     * Verify class against the {@link PublishedApiVersionInfo} of the {@link DomainType#GENERATORS}.
     *
     * <p>
     * Attention: Please use {@link #verifyClass(IGeneratorPackageReferable, Class)}, if it is possible!
     * </p>
     *
     * @param generatorName the generator name
     * @param clazz the Class to verify
     */
    @PublishedMethod
    public void verifyClass(String generatorName, Class<?> clazz) {
        checkNotNull(generatorName);
        checkNotNull(clazz);

        synchronized (this) {

            final IGeneratorPackage currentGeneratorPackage = GeneratorUtilFrameworkHelper.getCurrentGeneratorPackage();
            if (currentGeneratorPackage != null) {
                resultId = CommonGeneratorResultIds.getVersionCheckFailedErrorId(currentGeneratorPackage);
            } else {
                resultId = new ValidationSeverityResultId(generatorName, CommonGeneratorResultIds.getVersionCheckFailedErrorIdIntegerValue(), ERROR, "Version check failed");
            }
            try {
                verifyClassInternal(clazz);
            } finally {
                resultId = null;
            }

        }
    }

    /**
     * Verify class against the {@link PublishedApiVersionInfo} of the {@link DomainType#GENERATORS}.
     *
     * @param genPack the {@link IGeneratorPackage} where the class belongs to.
     * @param clazz the Class to verify
     */
    @PublishedMethod
    public void verifyClass(IGeneratorPackageReferable genPack, Class<?> clazz) {
        checkNotNull(genPack);
        checkNotNull(clazz);
        synchronized (this) {
            resultId = CommonGeneratorResultIds.getVersionCheckFailedErrorId(genPack.getGeneratorPackage());
            try {
                verifyClassInternal(clazz);
            } finally {
                resultId = null;
            }
        }
    }

}
