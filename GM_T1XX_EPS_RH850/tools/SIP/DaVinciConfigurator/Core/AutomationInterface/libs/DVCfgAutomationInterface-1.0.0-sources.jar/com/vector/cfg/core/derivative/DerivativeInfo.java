package com.vector.cfg.core.derivative;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * Data structure containing name and uuid of a single derivative.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public final class DerivativeInfo {
    private static final int HALF_INTEGER_BIT_SIZE = Integer.SIZE >> 1;

    private static final int LOWER_HALF_BIT_MASK = Integer.MAX_VALUE >> (HALF_INTEGER_BIT_SIZE - 1);

    private final String derName;

    private final String derUUID;

    @PublishedMethod
    public DerivativeInfo(final String derName, final String derUUID) {
        // Safety, internal values should always contain at least an empty string
        if (derName != null) {
            this.derName = derName;
        } else {
            this.derName = "";
        }
        if (derUUID != null) {
            this.derUUID = derUUID.toUpperCase();
        } else {
            this.derUUID = "";
        }
    }

    /**
     * Get name of derivative.
     */
    @PublishedMethod
    public String getName() {
        return derName;
    }

    /**
     * Get uuid of derivative.
     */
    @PublishedMethod
    public String getUUID() {
        return derUUID;
    }

    @Override
    public boolean equals(final Object obj) {
        if (!(obj instanceof DerivativeInfo)) {
            return false;
        }
        final DerivativeInfo other = (DerivativeInfo) obj;
        // Check only whether UUID is the same as Name may change
        return derUUID.equals(other.getUUID());
    }

    @Override
    public int hashCode() {
        int result = 0;
        if (derName != null) {
            result = derName.hashCode() << HALF_INTEGER_BIT_SIZE;
        }
        if (derUUID != null) {
            result ^= derUUID.hashCode() ^ LOWER_HALF_BIT_MASK;
        }
        return result;
    }

    @Override
    public String toString() {
        return String.format("(%s,%s)", getName(), getUUID());
    }
}
