package com.vector.cfg.gen.core.moduleinterface.fileoutput;

import java.io.File;
import java.util.regex.Pattern;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenFolders;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The {@link CFileTypeSpecification} indicates that the {@link IOutputFile} is a C programming language file. <br/>
 * The {@link CFileTypeSpecification} generates the files into the "CodeOutputFolder". E.g. &lt;ProjectFolder&gt;\\Appl\\GenData<br/>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class CFileTypeSpecification extends FileTypeSpecification {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(CFileTypeSpecification.class);

    /**
     * <code>DATE_START_TAG</code> describes the starting string of the date tag in the header section.
     */
    @PublishedField
    public static final String DATE_START_TAG = " *   Generation Time: ";

    /**
     * <code>LINE_SEPARATOR</code> The LINE_SEPARATOR of the current system.
     */
    @PublishedField
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");

    /**
     * Constructor for CFileTypeSpecification.
     *
     * @param file the file
     */
    @PublishedMethod
    public CFileTypeSpecification(IOutputFile file) {
        super(file);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final String getIllegalFilePatternToMarkFileAsErronous() {
        return "\r\n#error Generated code may be invalid\r\n\r\n";
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final String formatStringToComment(String content) {

        final String escapedContent = content.trim().replace("*/", "*");

        final String newLineAsterix = escapedContent.replaceAll("[\\r]?[\\n]", "\r\n * ");

        final StringBuilder builder = new StringBuilder();

        builder.append("/**********************************************************************************************************************\r\n");
        builder.append(" * ");
        builder.append(newLineAsterix);
        builder.append("\r\n");
        builder.append(" *********************************************************************************************************************/\r\n");
        return builder.toString();

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final boolean supportsConditionalFileWriting() {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final String stripContentForConditionalFileWriting(String fileContent) {
        return fileContent.replaceFirst(Pattern.quote(DATE_START_TAG) + ".*?" + Pattern.quote(LINE_SEPARATOR), "");

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public File getOutputFolder(IGenFolders genFolders) {
        return genFolders.getCodeOutputFolder();
    }
}
