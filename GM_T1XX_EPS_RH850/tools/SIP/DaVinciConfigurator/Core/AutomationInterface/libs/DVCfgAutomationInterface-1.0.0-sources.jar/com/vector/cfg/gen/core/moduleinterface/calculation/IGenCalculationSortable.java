package com.vector.cfg.gen.core.moduleinterface.calculation;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.EDefRefWildcard;

/**
 * <div class="extdoc" id="GenCalculationSortable"> The {@link IGenCalculationSortable} interface provides the functionality to specify the execution order of
 * an {@link ICalculator} instance.
 *
 * <p>
 * To support the sorting of the GeneratorPackages during the CalculationPhase, the {@link ICalculator} just needs to implement the interface
 * {@link IGenCalculationSortable}. The following conditions can be specified:
 * <ul>
 * <li>Execute this generator before "DefRef"</li>
 * <li>Execute this generator after "DefRef"</li>
 * </ul>
 * The DefRef means, any generator({@link IGeneratorPackage#getModuleDefinitionRef() getModuleDefinitionRef()}) which matches to the specified {@link DefRef}
 * above.
 *
 * You should use the wildcard {@link EDefRefWildcard#MICROSAR MICROSAR}, instead of {@link EDefRefWildcard#ANY ANY} in the SortingRules, if possible.
 * </p>
 *
 * <p>
 * Use the GenCalculationSorterBuilder class to create instances of {@link IGenCalculationSortingCriteria}.
 * </p>
 *
 * </div>
 *
 * <p>
 * This interface can only be implemented by an {@link ICalculator}.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IGenerationProcessor
 * @see ICalculator
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGenCalculationSortable extends ICalculator {

    /**
     * Returns the {@link IGenCalculationSortingCriteria} of the {@link ICalculator}.
     * <p>
     * The {@link IGenCalculationSortingCriteria} could be build with the class GenCalculationSorterBuilder.
     *
     * @return the calculation sorting criteria
     */
    @PublishedMethod
    IGenCalculationSortingCriteria getCalculationSortingCriteria();
}
