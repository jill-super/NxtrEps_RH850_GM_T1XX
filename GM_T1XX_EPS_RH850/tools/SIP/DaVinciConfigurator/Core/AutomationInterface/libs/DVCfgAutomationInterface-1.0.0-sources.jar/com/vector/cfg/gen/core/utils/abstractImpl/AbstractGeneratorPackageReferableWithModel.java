package com.vector.cfg.gen.core.utils.abstractImpl;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.IModelSimpleAccess;

/**
 * This class provides a skeletal implementation of the <tt>{@link IGeneratorPackageReferable IGeneratorPackageReferable}</tt> interface, to minimize the effort
 * required to implement this interface.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 * @see IGeneratorPackageReferable
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractGeneratorPackageReferableWithModel implements IGeneratorPackageReferable {

    @PublishedField
    protected final IGeneratorPackage generatorPackage;

    @PublishedField
    protected final IModelCheckedAccess mca;

    @PublishedField
    protected final IModelSimpleAccess msa;

    @PublishedField
    protected final IModelAccess ma;

    /**
     * Instantiates a new abstract generator package referable with model.
     *
     * @param generatorPackageRef another {@link IGeneratorPackageReferable} for the current generator.
     */
    @PublishedMethod
    public AbstractGeneratorPackageReferableWithModel(IGeneratorPackageReferable generatorPackageRef) {
        if (generatorPackageRef == null) {
            throw new IllegalArgumentException("generatorPackageRefereable is null");
        }
        if (generatorPackageRef.getGeneratorPackage() == null) {
            throw new IllegalArgumentException("generatorPackageRefereable reference to generatorPackage is null");
        }
        this.generatorPackage = generatorPackageRef.getGeneratorPackage();

        /*
         * Get CFG5 MDF Model services
         */
        ma = generatorPackage.getProjectContext().getService(IModelAccess.class);
        mca = generatorPackage.getProjectContext().getService(IModelCheckedAccess.class);
        msa = mca.simple();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IGeneratorPackage getGeneratorPackage() {
        if (generatorPackage == null) {
            throw new IllegalStateException("The Generator package was not yet set. It is null");
        }

        return generatorPackage;
    }

}
