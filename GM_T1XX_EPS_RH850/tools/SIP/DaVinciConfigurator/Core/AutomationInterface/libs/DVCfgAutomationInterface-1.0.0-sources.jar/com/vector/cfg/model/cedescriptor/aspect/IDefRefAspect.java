package com.vector.cfg.model.cedescriptor.aspect;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.cedescriptor.IDescriptorAspect;
import com.vector.cfg.model.cedescriptor.validator.AspectValidator;
import com.vector.cfg.model.internal.cedescriptor.validator.DefRefAspectValidator;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@AspectValidator(DefRefAspectValidator.class)
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IDefRefAspect extends IDescriptorAspect {
    @PublishedMethod
    DefRef getDefRef();
}
