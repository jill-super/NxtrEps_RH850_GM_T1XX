package com.vector.cfg.gen.core.bswmdmodel.exceptions;

import java.util.List;

import javax.annotation.Nullable;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultUtil;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.exceptions.ExceptionUtil;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Thrown to indicate that a bswmd model access has failed.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see ModelException
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class BswmdModelException extends ModelException implements IDebugable {

    private static final long serialVersionUID = 5626524297219471034L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BswmdModelException.class);

    @Nullable
    private final GIModelObject parent;

    private final List<IValidationResult> resultList;

    /**
     * Constructor for BswmdModelException.
     *
     * @param result the result
     * @param parent the parent
     */
    @PublishedMethod
    public BswmdModelException(IValidationResult result, @Nullable GIModelObject parent) {
        this(ImmutableList.of(result), parent);
    }

    /**
     * Constructor for BswmdModelException.
     *
     * @param results the results
     * @param parent the parent
     */
    @PublishedMethod
    public BswmdModelException(List<? extends IValidationResult> results, @Nullable GIModelObject parent) {
        this(results, parent, null);

    }

    /**
     * Constructor for BswmdModelException.
     *
     * @param results the results
     * @param parent the parent
     */
    @PublishedMethod
    public BswmdModelException(List<? extends IValidationResult> results, @Nullable GIModelObject parent, Throwable cause) {
        super("", cause);

        this.resultList = ImmutableList.copyOf(results);
        this.parent = parent;

    }

    /**
     * Return the list of {@link IValidationResult} of the {@link BswmdModelException}.
     *
     * @return
     */
    @PublishedMethod
    public List<IValidationResult> getResults() {
        return resultList;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getMessage() {
        final StringBuilder builder = new StringBuilder();
        boolean first = true;

        if (resultList.size() > 1) {
            builder.append("Results: \n");
        }
        for (final IValidationResult result : resultList) {
            if (!first) {
                builder.append(" \n");

            } else {
                first = false;
            }
            builder.append(buildResultMsg(result));

        }
        return builder.toString();
    }

    static String buildResultMsg(IValidationResult result) {

        if (result == null) {
            throw new IllegalArgumentException("result is null");
        }

        if (result instanceof IGeneratorResult) {

            return ((IGeneratorResult) result).toString("short");
        } else {
            return GeneratorResultUtil.buildSpecConformStringOfValidationResult(result);
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append(getClass().getName());
        builder.append(":");
        for (final IValidationResult result : resultList) {
            builder.append("\n  ");
            builder.append(result.toString());

        }
        return builder.toString();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toDebugString() {

        final StringBuilder builder = new StringBuilder();
        builder.append(getClass().getName());
        builder.append(":");
        for (final IValidationResult result : resultList) {
            builder.append("\n  ");
            builder.append(result.toString());

        }
        builder.append("\n");
        ExceptionUtil.printStacktrace(this, builder);

        if (getCause() != null) {
            Throwable inner = this.getCause();

            while (inner != null) {

                builder.append("\r\nCause: ");
                builder.append(inner.toString().trim());
                builder.append("\r\n");
                ExceptionUtil.printStacktrace(inner, builder);
                inner = inner.getCause();
            }

        }

        builder.append("\n");

        return builder.toString();

    }

}
