package com.vector.cfg.gen.core.moduleinterface.automation;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.vector.cfg.automation.scripting.base.services.ScriptTaskTypeSignature.signatureOf;

import java.util.EnumSet;
import java.util.List;

import com.google.common.base.Strings;
import com.google.inject.util.Types;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IScriptTaskType.IProjectScriptTaskType;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.gen.core.moduleinterface.EGenerationPhaseType;
import com.vector.cfg.gen.core.moduleinterface.EGenerationProcessResult;
import com.vector.cfg.gen.core.moduleinterface.EGenerationProcessType;
import com.vector.cfg.gen.core.moduleinterface.IGenerator;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum EGenerationAutomationScriptTaskType implements IProjectScriptTaskType {
    DV_GENERATION_STEP(
            "Generation Step",
            signatureOf(/*EnumSet.of(EScriptTaskTypeFeature.NEEDS_MD_OPTION),*/ Void.class, EGenerationPhaseType.class, EGenerationProcessType.class, IValidationResultSink.class)),
    DV_GENERATION_ON_START(
            "Generation Process Start",
            signatureOf(EnumSet.of(EScriptTaskTypeFeature.AUTOMATIC_EXECUTION), Void.class, Types.newParameterizedType(List.class, EGenerationPhaseType.class),
                    Types.newParameterizedType(List.class, IGenerator.class))),
    DV_GENERATION_ON_END(
            "Generation Process End",
            signatureOf(EnumSet.of(EScriptTaskTypeFeature.AUTOMATIC_EXECUTION), Void.class, EGenerationProcessResult.class,
                    Types.newParameterizedType(List.class, IGenerator.class))),

    ;

    private final String name;

    private final IScriptTaskTypeSignature sig;

    EGenerationAutomationScriptTaskType(String name, IScriptTaskTypeSignature sig) {
        checkArgument(!Strings.isNullOrEmpty(name));
        this.name = name;
        this.sig = checkNotNull(sig);
    }

    @Override
    @PublishedMethod
    public String getUserReadableName() {
        return name;
    }

    @Override
    @PublishedMethod
    public IScriptTaskTypeSignature getSignature() {
        return sig;
    }

}
