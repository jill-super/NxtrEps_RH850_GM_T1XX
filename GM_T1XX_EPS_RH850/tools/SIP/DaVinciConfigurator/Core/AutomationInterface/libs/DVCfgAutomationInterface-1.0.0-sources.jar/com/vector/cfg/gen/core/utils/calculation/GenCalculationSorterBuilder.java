package com.vector.cfg.gen.core.utils.calculation;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.calculation.IGenCalculationSortingCriteria;
import com.vector.cfg.gen.core.moduleinterface.calculation.ISortRule;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.util.collections.ObjectsPrinter;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The GenCalculationSorterBuilder provides an interface to build {@link IGenCalculationSortingCriteria} object.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenCalculationSorterBuilder {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenCalculationSorterBuilder.class);

    private final IGeneratorPackage generatorPackage;

    private final Map<DefRef, DefRef> map = Maps.newLinkedHashMap();

    private final DefRef genDefRef;

    /**
     * Create a new builder for {@link IGenCalculationSortingCriteria}.
     *
     * @param generatorPackage the generator package or a referable.
     * @return the created builder
     */
    @PublishedMethod
    public static GenCalculationSorterBuilder newBuilder(final IGeneratorPackageReferable generatorPackage) {

        checkNotNull(generatorPackage);
        return new GenCalculationSorterBuilder(generatorPackage.getGeneratorPackage());
    }

    /**
     * Instantiates a new gen calculation sorter builder.
     *
     * @param generatorPackage the generator package
     */
    @PublishedMethod
    private GenCalculationSorterBuilder(final IGeneratorPackage generatorPackage) {
        this.generatorPackage = generatorPackage;
        this.genDefRef = generatorPackage.getModuleDefinitionRef();

    }

    /**
     * Execute this generator before the generator with the corresponding ModuleDefRef.
     *
     * <p>
     * Adds a new Rule for the Calculation sorting
     * </p>
     *
     * @param defRef the defRef of the other module
     * @return this builder
     */
    @PublishedMethod
    public GenCalculationSorterBuilder executeThisBeforeGeneratorWithDefRef(final DefRef defRef) {
        checkNotNull(generatorPackage);

        map.put(genDefRef, defRef);
        return this;
    }

    /**
     * Execute this generator after the generator with the corresponding ModuleDefRef.
     *
     * <p>
     * Adds a new Rule for the Calculation sorting
     * </p>
     *
     * @param defRef the defRef of the other module
     * @return this builder
     */
    @PublishedMethod
    public GenCalculationSorterBuilder executeThisAfterGeneratorWithDefRef(final DefRef defRef) {
        checkNotNull(generatorPackage);

        map.put(defRef, genDefRef);
        return this;
    }

    /**
     * Builds the {@link IGenCalculationSortingCriteria} object.
     * <p>
     * Do not use the builder after a call to this method
     * </p>
     *
     * @return the criteria object
     */
    @PublishedMethod
    public IGenCalculationSortingCriteria build() {

        final List<ISortRule> ruleList = Lists.newArrayList();

        for (final Map.Entry<DefRef, DefRef> entry : map.entrySet()) {
            ruleList.add(new ISortRule() {

                @Override
                public DefRef getBefore() {
                    return entry.getKey();
                }

                @Override
                public DefRef getAfter() {
                    return entry.getValue();
                }

                @Override
                public String toString() {
                    return getBefore().getDefRefString() + " -> " + getAfter().getDefRefString();
                }
            });
        }

        return new IGenCalculationSortingCriteria() {

            @Override
            public List<ISortRule> getSortRules() {
                return ruleList;
            }

            @Override
            public IGeneratorPackage getGeneratorPackage() {
                return generatorPackage;
            }

            @Override
            public String toString() {
                return "SortRules: " + ObjectsPrinter.toStringCollection(ruleList);
            }

        };
    }
}
