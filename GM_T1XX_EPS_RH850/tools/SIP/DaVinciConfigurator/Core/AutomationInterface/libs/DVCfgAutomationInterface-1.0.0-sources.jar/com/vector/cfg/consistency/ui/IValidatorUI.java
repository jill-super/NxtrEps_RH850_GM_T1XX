package com.vector.cfg.consistency.ui;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * An IValidatorUI represents a validator that can create live-validation-results.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved. <BR>
 * <BR>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
public interface IValidatorUI {
    /**
     * See interface doc.
     */
    @PublishedMethod
    String getName();

    /**
     * See interface doc.
     */
    @PublishedMethod
    String getDescription();
}
