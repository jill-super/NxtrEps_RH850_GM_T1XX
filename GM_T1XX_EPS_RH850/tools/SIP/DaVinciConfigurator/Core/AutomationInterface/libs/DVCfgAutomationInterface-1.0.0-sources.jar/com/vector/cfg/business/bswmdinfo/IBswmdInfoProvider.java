package com.vector.cfg.business.bswmdinfo;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IBswmdInfoProvider {
    @PublishedMethod
    IBswmdInfo getBswmdInfo(MIModuleDef moduleDef);

    @PublishedMethod
    IBswmdInfo getBswmdInfo(String moduleDefPath);
}
