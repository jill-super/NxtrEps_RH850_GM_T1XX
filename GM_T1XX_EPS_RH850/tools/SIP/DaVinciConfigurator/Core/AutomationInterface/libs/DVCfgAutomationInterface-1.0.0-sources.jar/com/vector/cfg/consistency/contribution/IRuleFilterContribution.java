package com.vector.cfg.consistency.contribution;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MICoreArtefact;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IRuleFilterContribution {
    /**
     * Provide a list of DefRefs for filtering the rule events.
     *
     * @return
     */
    @PublishedMethod
    Collection<? extends DefRef> getDefRefList();

    /**
     * Provide a list of Class objects for filtering the rule events with an instanceof check of the source.
     *
     * @return
     */
    @PublishedMethod
    Collection<Class<? extends MICoreArtefact>> getInstanceOfClassList();
}
