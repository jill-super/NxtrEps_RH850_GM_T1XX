package com.vector.cfg.business;

import static com.google.common.base.Preconditions.checkArgument;
import static com.vector.cfg.util.string.StringUtil.concat;
import static com.vector.cfg.util.text.format.VMessageFormatter.format;
import static java.lang.String.valueOf;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.function.Consumer;
import java.util.function.Function;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import org.eclipse.core.runtime.IStatus;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.util.autosar.AutosarUtil;
import com.vector.cfg.util.davincideveloper.DaVinciDevUtil;

/**
 * {@link Constraints} provides general purpose constraints for checking given parameter values throughout the automation interface.
 * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="Constraints"><!--Label:Constraints-->{@link Constraints} provides general purpose constraints for
 * checking given parameter values throughout the automation interface. These constraints are referenced from the AutomationInterface documentation wherever they apply. The
 * AutomationInterface takes a fail fast approach verifying provided parameter values as early as possible and throwing appropriate exceptions if values violate the
 * corresponding constraints.
 *
 * <p>
 * The following constraints are provided:
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class Constraints {

    static final int MAX_PROJECT_NAME_LENGTH = 128;

    private static final String STRING_CONTAINS_ILLEGAL_CHARACTER = "\"{0}\" contains the illegal character '{1}' at index {2}.";

    private static final String NO_VALID_ARGUMENTS_AVAILABLE = "There are no valid arguments available.";

    private static final String ARGUMENT_MUST_NOT_BE_EMPTY = "Argument must not be empty.";

    private static final String OUT_OF_RANGE_ARGUMENT = "\"{0}\" is no valid argument. Valid arguments are: {1}.";

    private static final String ARGUMENT_MUST_NOT_BE_NULL = "Argument must not be null.";

    private static final String ELEMENT_CAN_NOT_BE_WRITTEN_TO = "\"{0}\" can not be written to.";

    private static final String ELEMENT_CAN_NOT_BE_READ = "\"{0}\" can not be read.";

    private static final String ELEMENT_DOES_NOT_EXIST = "\"{0}\" does not exist.";

    private static final String PATH_IS_NOT_A_FOLDER = "\"{0}\" is not a folder.";

    private static final String PATH_IS_NOT_A_FILE = "\"{0}\" is not a file.";

    private static final String ILLEGAL_FILE_EXTENSION = "Illegal file extension in \"{0}\". Legal file extensions are: {1}.";

    private static final String PROJECT_NAME_MUST_START_WITH_LETTER = "\"{0}\" is not a valid project name. A valid project name must start with a letter [a-zA-Z].";

    private static final String STRING_EXCEEDS_MAX_LENGTH = "\"{0}\" exceeds maximum length of {1} characters.";

    private static final String PROJECT_NAME_CONTAINS_INVALID_CHARS = "\"{0}\" contains invalid characters. Valid characters are: [a-zA-Z0-9_].";

    @PublishedField
    public static final String DCF_FILE_EXTENSION = ".dcf"; // $NON-NLS-1$

    @PublishedField
    public static final String DPA_FILE_EXTENSION = ".dpa"; // $NON-NLS-1$

    @PublishedField
    public static final String ARXML_FILE_EXTENSION = ".arxml"; // $NON-NLS-1$

    @PublishedField
    public static final String DBC_FILE_EXTENSION = ".dbc"; // $NON-NLS-1$

    @PublishedField
    public static final String LDF_FILE_EXTENSION = ".ldf"; // $NON-NLS-1$

    @PublishedField
    public static final String XML_FILE_EXTENSION = ".xml"; // $NON-NLS-1$

    @PublishedField
    public static final String VSDE_FILE_EXTENSION = ".vsde"; // $NON-NLS-1$

    @PublishedMethod
    private Constraints() {
    }

    /**
     * Ensures that the given {@link Object} is not {@code null}. <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_NOT_NULL">
     * <h5>IS_NOT_NULL</h5><!--Label:Constraints.IS_NOT_NULL-->Ensures that the given {@link Object} is not {@code null}.</div>
     */
    @PublishedField
    public static final Consumer<Object> IS_NOT_NULL = object -> {

        if (object == null) {
            throw new NullPointerException(ARGUMENT_MUST_NOT_BE_NULL);
        }

    };

    /**
     * Ensures that the given {@link String} is not empty. <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_NON_EMPTY_STRING">
     * <h5>IS_NON_EMPTY_STRING</h5><!--Label:Constraints.IS_NON_EMPTY_STRING-->Ensures that the given {@link String} is not empty.</div>
     */
    @PublishedField
    public static final Consumer<String> IS_NON_EMPTY_STRING = string -> {

        IS_NOT_NULL.accept(string);
        if (string.isEmpty()) {
            throw new IllegalArgumentException(ARGUMENT_MUST_NOT_BE_EMPTY);
        }

    };

    /**
     * Ensures that the given {@link Iterable} is not empty. <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_NON_EMPTY_ITERABLE">
     * <h5>IS_NON_EMPTY_ITERABLE</h5><!--Label:Constraints.IS_NON_EMPTY_ITERABLE-->Ensures that the given {@link Iterable} is not empty.</div>
     */
    @PublishedField
    public static final Consumer<Iterable<?>> IS_NON_EMPTY_ITERABLE = iterable -> {

        IS_NOT_NULL.accept(iterable);
        if (!iterable.iterator().hasNext()) {
            throw new IllegalArgumentException(ARGUMENT_MUST_NOT_BE_EMPTY);
        }

    };

    /**
     * Ensures that the given {@link String} can be used as a file name. <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_VALID_FILE_NAME">
     * <h5>IS_VALID_FILE_NAME</h5><!--Label:Constraints.IS_VALID_FILE_NAME-->Ensures that the given {@link String} can be used as a file name.</div>
     */
    @PublishedField
    public static final Consumer<String> IS_VALID_FILE_NAME = string -> {

        Paths.get(ensureCharsAreNotUsed(string, '/', '\\'));

    };

    /**
     * Ensures that the given {@link String} can be used as a name for a project.
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_VALID_PROJECT_NAME">
     * <h5>IS_VALID_PROJECT_NAME</h5><!--Label:Constraints.IS_VALID_PROJECT_NAME-->Ensures that the given {@link String} can be used as a name for a project. A valid project
     * name starts with a letter [a-zA-Z] contains otherwise only characters matching [a-zA-Z0-9_] and is at most 128 characters long.</div>
     */
    @PublishedField
    public static final Consumer<String> IS_VALID_PROJECT_NAME = string -> {

        IS_NON_EMPTY_STRING.accept(string);

        if (string.length() > MAX_PROJECT_NAME_LENGTH) {
            throw new IllegalArgumentException(format(STRING_EXCEEDS_MAX_LENGTH, string, MAX_PROJECT_NAME_LENGTH));
        }

        char c = string.charAt(0);
        if ((c < 'a' || c > 'z')
                && (c < 'A' || c > 'Z')) {
            throw new IllegalArgumentException(format(PROJECT_NAME_MUST_START_WITH_LETTER, string));
        }

        for (int i = string.length() - 1; i > 0; --i) {
            c = string.charAt(i);
            if (c != '_'
                    && (c < 'a' || c > 'z')
                    && (c < 'A' || c > 'Z')
                    && (c < '0' || c > '9')) {
                throw new IllegalArgumentException(format(PROJECT_NAME_CONTAINS_INVALID_CHARS, string));
            }
        }

    };

    /**
     * Ensures that the given {@link String} conforms to the syntactical requirements for AUTOSAR short names.
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_VALID_AUTOSAR_SHORT_NAME">
     * <h5>IS_VALID_AUTOSAR_SHORT_NAME</h5><!--Label:Constraints.IS_VALID_AUTOSAR_SHORT_NAME-->Ensures that the given {@link String} conforms to the syntactical requirements for
     * AUTOSAR short names.</div>
     */
    @PublishedField
    public static final Consumer<String> IS_VALID_AUTOSAR_SHORT_NAME = string -> {

        final IStatus status = AutosarUtil.isValidShortname(string);
        if (!status.isOK()) {
            throw new IllegalArgumentException(status.getMessage());
        }

    };

    /**
     * Ensures that the given {@link String} conforms to the syntactical requirements for AUTOSAR short name paths.
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_VALID_AUTOSAR_SHORT_NAME_PATH">
     * <h5>IS_VALID_AUTOSAR_SHORT_NAME_PATH</h5><!--Label:Constraints.IS_VALID_AUTOSAR_SHORT_NAME_PATH-->Ensures that the given {@link String} conforms to the syntactical
     * requirements for AUTOSAR short name paths.</div>
     */
    @PublishedField
    public static final Consumer<String> IS_VALID_AUTOSAR_SHORT_NAME_PATH = string -> {

        AsrPath.create(string);

    };

    /**
     * Ensures that the file or folder represented by the given {@link Path} exists and can be written to.
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_WRITABLE">
     * <h5>IS_WRITABLE</h5><!--Label:Constraints.IS_WRITABLE-->Ensures that the file or folder represented by the given {@link Path} exists and can be written to.</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_WRITABLE = path -> {

        path = path.toAbsolutePath();
        if (!path.toFile().canWrite()) {
            throw new IllegalArgumentException(format(ELEMENT_CAN_NOT_BE_WRITTEN_TO, path));
        }

    };

    /**
     * Ensures that the file or folder represented by the given {@link Path} exists and can be read.
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_READABLE">
     * <h5>IS_READABLE</h5><!--Label:Constraints.IS_READABLE-->Ensures that the file or folder represented by the given {@link Path} exists and can be read.</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_READABLE = path -> {

        path = path.toAbsolutePath();
        if (!path.toFile().canRead()) {
            throw new IllegalArgumentException(format(ELEMENT_CAN_NOT_BE_READ, path));
        }

    };

    /**
     * Ensures that the given {@link Path} points to an existing folder. <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_EXISTING_FOLDER">
     * <h5>IS_EXISTING_FOLDER</h5><!--Label:Constraints.IS_EXISTING_FOLDER-->Ensures that the given {@link Path} points to an existing folder.</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_EXISTING_FOLDER = path -> {

        path = path.toAbsolutePath();
        final File file = path.toFile();
        if (!file.exists()) {
            throw new IllegalArgumentException(format(ELEMENT_DOES_NOT_EXIST, path));
        }

        if (!file.isDirectory()) {
            throw new IllegalArgumentException(format(PATH_IS_NOT_A_FOLDER, path));
        }

    };

    /**
     * Ensures that the given {@link Path} points to an existing file. <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_EXISTING_FILE">
     * <h5>IS_EXISTING_FILE</h5><!--Label:Constraints.IS_EXISTING_FILE-->Ensures that the given {@link Path} points to an existing file.</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_EXISTING_FILE = path -> {

        path = path.toAbsolutePath();
        final File file = path.toFile();
        if (!file.exists()) {
            throw new IllegalArgumentException(format(ELEMENT_DOES_NOT_EXIST, path));
        }

        if (!file.isFile()) {
            throw new IllegalArgumentException(format(PATH_IS_NOT_A_FILE, path));
        }

    };

    /**
     * Ensures that the given {@link Path} either points to an existing folder which can be written to or points to a location at which a corresponding folder could be created.
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_CREATABLE_FOLDER">
     * <h5>IS_CREATABLE_FOLDER</h5><!--Label:Constraints.IS_CREATABLE_FOLDER-->Ensures that the given {@link Path} either points to an existing folder which can be written to or
     * points to a location at which a corresponding folder could be created.</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_CREATABLE_FOLDER = path -> {

        path = path.toAbsolutePath();
        File file = path.toFile();
        while (!file.exists()) {
            file = file.getParentFile();
        }
        path = file.toPath();
        IS_EXISTING_FOLDER.accept(path);
        IS_WRITABLE.accept(path);

    };

    /**
     * Ensures that the given {@link Path} points to a DaVinci Developer workspace file (.dcf file).
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_DCF_FILE">
     * <h5>IS_DCF_FILE</h5><!--Label:Constraints.IS_DCF_FILE-->Ensures that the given {@link Path} points to a DaVinci Developer workspace file (.dcf file).</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_DCF_FILE = path -> {

        ensureLegalFileExtension(path, DCF_FILE_EXTENSION);

        path = path.toAbsolutePath();
        final File file = path.toFile();
        if (file.exists() && !file.isFile()) {
            throw new IllegalArgumentException(format(PATH_IS_NOT_A_FILE, path));
        }

    };

    /**
     * Ensures that the given {@link Path} points to a DaVinci project file (.dpa file). <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_DPA_FILE">
     * <h5>IS_DPA_FILE</h5><!--Label:Constraints.IS_DPA_FILE-->Ensures that the given {@link Path} points to a DaVinci project file (.dpa file).</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_DPA_FILE = path -> {

        ensureLegalFileExtension(path, DPA_FILE_EXTENSION);

        path = path.toAbsolutePath();
        final File file = path.toFile();
        if (file.exists() && !file.isFile()) {
            throw new IllegalArgumentException(format(PATH_IS_NOT_A_FILE, path));
        }

    };

    /**
     * Ensures that the given {@link Path} points to an .arxml file. <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_ARXML_FILE">
     * <h5>IS_ARXML_FILE</h5><!--Label:Constraints.IS_ARXML_FILE-->Ensures that the given {@link Path} points to an .arxml file.</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_ARXML_FILE = path -> {

        ensureLegalFileExtension(path, ARXML_FILE_EXTENSION);

        path = path.toAbsolutePath();
        final File file = path.toFile();
        if (file.exists() && !file.isFile()) {
            throw new IllegalArgumentException(format(PATH_IS_NOT_A_FILE, path));
        }

    };

    /**
     * Ensures that the given {@link Path} points to a system description input file (.arxml, .dbc, .ldf, .xml or .vsde file).
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_SYSTEM_DESCRIPTION_FILE">
     * <h5>IS_SYSTEM_DESCRIPTION_FILE</h5><!--Label:Constraints.IS_SYSTEM_DESCRIPTION_FILE-->Ensures that the given {@link Path} points to a system description input file
     * (.arxml, .dbc, .ldf, .xml or .vsde file).</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_SYSTEM_DESCRIPTION_FILE = path -> {

        ensureLegalFileExtension(path, ARXML_FILE_EXTENSION, DBC_FILE_EXTENSION, LDF_FILE_EXTENSION, XML_FILE_EXTENSION, VSDE_FILE_EXTENSION);

        path = path.toAbsolutePath();
        final File file = path.toFile();
        if (file.exists() && !file.isFile()) {
            throw new IllegalArgumentException(format(PATH_IS_NOT_A_FILE, path));
        }

    };

    /**
     * Ensures that the given {@link Path} points to a compatible DaVinci Developer executable (DaVinciDEV.exe).
     * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="IS_COMPATIBLE_DA_VINCI_DEV_EXECUTABLE">
     * <h5>IS_COMPATIBLE_DA_VINCI_DEV_EXECUTABLE</h5><!--Label:Constraints.IS_COMPATIBLE_DA_VINCI_DEV_EXECUTABLE-->Ensures that the given {@link Path} points to a compatible
     * DaVinci Developer executable (DaVinciDEV.exe).</div>
     */
    @PublishedField
    public static final Consumer<Path> IS_COMPATIBLE_DA_VINCI_DEV_EXECUTABLE = path -> {

        path = path.toAbsolutePath();
        IS_EXISTING_FILE.accept(path);
        final IStatus status = DaVinciDevUtil.doesDaVinciDeveloperMatchCfgVersion(path.toString());
        if (!status.isOK()) {
            throw new IllegalArgumentException(status.getMessage());
        }

    };

    /**
     * @param path the {@link Path} to be validated
     * @param legalFileExtensions the legal file extensions
     * @throws IllegalArgumentException if the given {@link Path} contains does not end in any of the given file extensions
     */
    static void ensureLegalFileExtension(@Nonnull final Path path, @Nonnull final String... legalFileExtensions) {
        if (legalFileExtensions.length == 0) {
            return;
        }
        final String normalizedFileName = path.getFileName().toString().toLowerCase();
        for (final String legalFileExtension : legalFileExtensions) {
            if (normalizedFileName.endsWith(legalFileExtension.toLowerCase())) {
                return;
            }
        }
        throw new IllegalArgumentException(format(ILLEGAL_FILE_EXTENSION, path, concat(", ", legalFileExtensions))); // $NON-NLS-1$
    }

    /**
     * @param string the {@link String} to be validated
     * @param forbiddenChars the forbidden {@code char}s
     * @return the given {@link String}
     * @throws IllegalArgumentException if the given {@link String} contains any of the given {@code char}s
     */
    @KeepSecretFromPublishedApi
    public static String ensureCharsAreNotUsed(@Nullable final String string, @Nullable final char... forbiddenChars) {
        if (string == null || forbiddenChars == null || string.length() == 0) {
            return string;
        }
        for (final char forbiddenChar : forbiddenChars) {
            final int i = string.indexOf(forbiddenChar);
            if (i != -1) {
                throw new IllegalArgumentException(format(STRING_CONTAINS_ILLEGAL_CHARACTER, string, forbiddenChar, i));
            }
        }
        return string;
    }

    /**
     * @param forbiddenChars
     * @return a {@link Consumer} implementing {@link #ensureCharsAreNotUsed(String, char...)}
     */
    @KeepSecretFromPublishedApi
    public static Consumer<String> ensureCharsAreNotUsedConstraint(@Nullable final char... forbiddenChars) {
        return string -> ensureCharsAreNotUsed(string, forbiddenChars);
    }

    /**
     * @param selection the elements which have been selected
     * @param range the range from which the elements are supposed to be selected
     * @param allowEmptySelection {@code true} if {@code null} or an empty collection is a valid selection
     * @param allowEmptyRange {@code true} if {@code null} or an empty collection is a valid range
     * @param formatter {@link Function} yielding a description for a selected element (used for creating error messages)
     * @return the given selection
     */
    @KeepSecretFromPublishedApi
    public static <E, C extends Collection<E>> C ensureSelectedFrom(@Nullable final C selection,
            @Nullable final Collection<?> range,
            final boolean allowEmptySelection,
            final boolean allowEmptyRange,
            @Nonnull final Function<? super E, String> formatter) {
        checkArgument(allowEmptySelection || !allowEmptyRange);
        if (range == null || range.isEmpty()) {
            if (!allowEmptyRange) {
                throw new IllegalArgumentException(NO_VALID_ARGUMENTS_AVAILABLE);
            }
            if (selection != null && !selection.isEmpty()) {
                throw new IllegalArgumentException(NO_VALID_ARGUMENTS_AVAILABLE);
            }
        }
        if (selection == null || selection.isEmpty()) {
            if (allowEmptySelection) {
                return selection;
            }
            throw new IllegalArgumentException(ARGUMENT_MUST_NOT_BE_EMPTY);
        }
        for (final E element : selection) {
            if (!range.contains(element)) {
                throw new IllegalArgumentException(format(OUT_OF_RANGE_ARGUMENT,
                        formatter.apply(element),
                        '"' + selection.stream().map(e -> e == null ? valueOf(e) : formatter.apply(e)).reduce((str1, str2) -> str1 + "\", \"" + str2).get() + '"'));
            }
        }
        return selection;
    }

    /**
     * @param range
     * @param allowEmptySelection
     * @param allowEmptyRange
     * @param formatter
     * @return a {@link Consumer} implementing {@link #ensureSelectedFrom(Collection, Collection, boolean, boolean, Function)}
     */
    @KeepSecretFromPublishedApi
    public static <E, C extends Collection<E>> Consumer<C> multiSelectionFromConstraint(@Nullable final Collection<?> range,
            final boolean allowEmptySelection,
            final boolean allowEmptyRange,
            @Nonnull final Function<? super E, String> formatter) {
        return selection -> ensureSelectedFrom(selection, range, allowEmptySelection, allowEmptyRange, formatter);
    }

    /**
     * @param range
     * @param allowEmptySelection
     * @param allowEmptyRange
     * @param formatter
     * @return a {@link Consumer} implementing {@link #ensureSelectedFrom(Collection, Collection, boolean, boolean, Function)}
     */
    @KeepSecretFromPublishedApi
    public static <T> Consumer<T> singleSelectionFromConstraint(@Nullable final Collection<?> range,
            final boolean allowEmptySelection,
            final boolean allowEmptyRange,
            @Nonnull final Function<? super T, String> formatter) {
        return selection -> ensureSelectedFrom(selection == null ? emptyList() : singletonList(selection), range, allowEmptySelection, allowEmptyRange, formatter);
    }

}
