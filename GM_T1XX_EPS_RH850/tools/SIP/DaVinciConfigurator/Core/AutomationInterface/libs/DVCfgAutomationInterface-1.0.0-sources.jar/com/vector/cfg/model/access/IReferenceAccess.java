package com.vector.cfg.model.access;

import java.util.Collection;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIARRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDefARRef;

/**
 * <div class="extdoc" id="Common">
 * <h2>IReferenceAccess</h2> <!--LaTeX:\label{sec:IReferenceAccess}-->
 *
 * The {@link IReferenceAccess} is a basic model service which provides methods to simplify reference handling.
 *
 * <ul>
 * <li>{@link #getRefTarget(MIARRef)}: Returns the target object, an AUTOSAR reference points to. This method works for all reference types and therefore returns an object of
 * type MIReferrable. This is the base type all reference target types must implement
 * <li>{@link #getReferenceTarget(MIReferenceValue)}: Returns the target object of a reference-value (ECUC parameter of type MIReferenceValue)
 * <li>{@link #sortReferences(Collection)}: Sorts a collection of AUTOSAR references to guarantee deterministic order for example during code generation (the sort criteria are
 * described in the JavaDoc documentation in the code).
 * <li>{@link #getAllReferencesPointingTo(MIReferrable)}: This is the reverse operation of {@link #getRefTarget(MIARRef)}
 * <li>{@link #getReferenceParametersPointingTo(MIReferrable)}: This is the reverse operation of {@link #getReferenceTarget(MIReferenceValue)}
 * </ul>
 *
 * </div>
 *
 * <div class="extdoc" id="AutosarReferences" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation"> All AUTOSAR reference objects in the MDF model have the base
 * interface {@link MIARRef}.
 *
 * Figure <!--LaTeX:\vref{fig:AutosarContainerDefRef}--> shows this type hierarchy for the definition reference of an ECUC container. <br/>
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAP8AAAFwCAYAAAB3ma1zAAAABmJLR0QA/wD/AP+gvaeTAAAgAElEQVR4nO3dd1QUV/8/8Lc5zzcmwiJKMSrYNRawITaaBQULohQV7DVGTWwx0cRoNBpNjCUxogIKgqJUEQWxU0SIihrB3ntolgVjnud3jvv7Y91hZ2d22aUt7P28zuGwM3Pnzt1l3zt3Zme4dWQymQyEEOZ8oO8GEEL0g8JPCKMo/IQwisJPCKMo/IQw6j/6bkBVKCwsRGpqKt69e6fvppBa7oMPPoCLiwvMzc313ZTKJzNAM2fOlAGgH/qplJ+ZM2fq+y1dJQxyz19SUgIA2Ld7m9JcGe+X0gPew9JJlZlK66sukc9XU15sjky4XFbm5Raq7ZWpmxSUFzwf8SegMl8mXkxpgzLVmZpX4NcsVpb3Jyrj9RR5vvzXQcPrr5iSiSxVWW3GgpXc+8nQGGT4FXxGDlOakqn8KiNMGt4com9OmepcDWHSKvw6tlfD+uLh17K9aj8sNYdfxmu/NuGXqTzlMtor8nwrr71KDxaottNw0Ak/QhhF4SeEURR+QhhF4SfVJvf6bfhP/wpmLXvDrFVvfTeHeRR+Papn2Z77kUqLecuk0mIYNeoIo0/kP8qMG3eCcWMb0TrPZ1+BpIktJE0643z2FcFyk6ZdYGLVBSZWXWFi1RX1rbpid0ScoFx96+4wte4O02aKHzvsjjhQgWcL/LRhB5JPpuP+lRMoupdVobpIxRn02f7a5OipdPiOHMqbLo+90QeVHifAvntn0XLSJ5cBAKkZ5+AxZiakxSX4YuYEQblXjy4CANLOnsOIsbNQXPIGc2eML1fbkk/Kn5OJxFjD14KkutCevwbYvWMDomIP8+ZFxSYidMevOtXz+Olz7AyLQsi2XxCy7RfsDIvC46fPNa7j7NATALDsx42ay/W1l5dbvUmwLO3seSz8bh0atLCH3/SFSDt7XlCmYcte3GPq9tcMFP4awG2gM5KOnUbqGXlXOPVMFpKOnYbbACed6jmZkgEA6NWjK3r16PJ+3tnKbayKtLPn4en3ORx7dcfLB+exaM4UePrPRtrZC7xyL+7/yT0uup9F3f4agMJfA5iYSBC6YwP+2BEGqbQYf+wIQ+iOX2FiItG6Dqm0BF8sXolpE0fDumljWDdtjGkTR+OLr1dCWqz+CrW0jHMAgF1b12msX7E33/nHT7z58YknAACu/fsCAHp0swUAHHw/n9RcdMxfQ7gNcMLkzxbh+9UbuWldXLpyFQAwbeJobt60ib7YGRaFS1euwcXBnlfexKor93jqBF94e7qJHoebNuteWm68D7xH8MuF7IkFADS36c9bL2RvHDasWaLTcyDVi8JfQyj2/pM/W4Sk2BCd9voAsDVoDwCgr6uPYFlAULgg/IoTfjEHkzF1zhJMm+ADmw7tBOsqTvjFJiRj2txvMXW8N6/clPHeCNkTi5cPz4tfLktqLOr21yC+I4fiTd51uDjqdjIs5+pNHDmegjXLv0Lxs5z3P1dQ/OwK1ixfhCPHU5Fz7about6e7hgyyAWr1wdo3Ib3CDe4uzpj9a/bePNHDnMFAMQlHOPm3bn/CFuD9ur0HEj1o/AbgPjD8uD1dxZ+aPR3ks87eFj9Mfjs6eNw5Hiq6Pf9/HL+SD6Rht37Sr/vd+5rj+PxIbh+6x4atLBHgxb2yMi6CM9hA8vzVEg1qiMr+17SWmfcuHGIiIjA/3v9SGku3dUntj7d1SfW3tIHn3QYAH9/f+zda3g9GdrzE8IoCj8hjKLwE8IoCj8hjKLwE8IoCj8hjKLwE8IoCj8hjKLwE8IoCj8hjKLwE8Iog76l9//qN9N3EwipsQw6/PzhuviEdzOJ3N+k8ZYn8YVi9wJpUZn6mlTvN9GxPepXFL09ScP6urVfeKOM1hvSuEj19ivtq9ZcXt374VByqvbbqWUMOvyaBuqku/rorj6t7upLHqDaUINBx/yEMIrCTwijKPyEMIrCTwijKPy1kHHjTlVSb1rGOd7/8dsdESc6+g4xDBR+wgnYGYFRHoO56VEegxEQrJ//XWfeuq9etssSCn8V+di89H/bv5YWw2f85xrL+06YLRiptzrlXrsF35FD5INovmciMcYQV2fkXrtV5vpxCce48foatLBH2L54PHn2N6+M8nh9ZSm8W7XDjBEKf7WobyLBGO/hyLl6Q3R5SnoWRnsP13mgjsqUfTkXXWzaC+bbdbVB9uVcjev+8X7AkB+WzMXLB+fx8sF5OPTujoOJJ6ukraRyUPjViIo7hLoNW8HLfwZS0jJRt2Fr3vLE5FPwHjcTH5m1wa6wSN6yj83byn9btMPHFvIeQD+n3ggK3S+6rbiEZG54Lqm0GCF7omHUqCOMGnXE79tCNLbTuLGNYJ6kia1g3pHjqRgz+UuYNO2C0IhYwfLLOddhaWEmmN/Mugn+yuV/aJk2t+NNf796M7xGDOb1Glq3bIY5M8Zx04q9fsOWvWDWsnR8AbNWvZGeeQHjZiyGWes+3HzVbr95GwdcuHwVi5evh0UbByxe/isKi14K2nsg8SQs2zlhwqylSM+6KFhOSlH4RSQmy/dY/31xD3ERQcgvLOQtT0nPRF5+AWL3BuLfojswNjZC1IHSIbbfFt6W/y64hbcF8i6zhbkZWrdsJtj751y9Aae+9txe//vVG+Ha3xFv8q7hTd41dLHtiOj4pAo9n9SMc8jLL0Rk6O+QPv0LxkZGiDmYzCuzKzyGF14FE4kxdu2J0Vj/j8vmY7dIN1+ZYpTeF/f/RNF9/gi9BYUvsTdoPYruZmrczuMnz7F+1WIU3MnAiCH9ERTGb9fRU/JRivNvpSN8+1rRDwdSisIvYufufXBz7cdNKz8GgNiDSfAeOZSbHu01HJExh8qs12uEO06l8o9lg0L3o7d96WCYv/2yAtZNG3PTLo69EBWXqOMz4Is/dAxeI9y4aR9Pd0THHyl3fa8eZvOm584Yj0YWZti9Lx4NWthj4XfrEHfomJq1hbw8BmlVbtRwV+6xUx87bAzYzVu+J/IQBiqNWjRQZAQjUsqgr+0vr8Tkk6hvIuGu866vciweFBKBoJAIneu1tmoCAHj85BmsrRrj8ZPnaN2yOaytGnPX9hcUFmFb8F78vGmbpqp0sjM8CjvDozSWmTrBB9LiEsHeX1pcgqnjhYN/qnJ3dYL7QCd8t2gWpMUlOJ6Sga1BezFn+rgy160sR09lwERixE0rPyZCtOcXMcx9IF4rnXl/rXIWfsYUf/xbdIf/876rX5ahbgMQlyDvcsclJMNrhDtv+ewF38PPdwTX7X/z97UKPhtg2oTRkD79q/TnyV/cKL0KXW074NHjZ4J1Hz1+JnoiUBMTiTG8PAbj+zW/VajdunIb4ABp8RtuWvkxEaLwi5g2yQ9HT6Rw08qPAcDbcyh2hUVyHwqvpcXYFc4/6TfMTfxusLatW+Du/Ue4ffcB7t5/CGurxoIyH31UF4D85F9Zx/vfzP8MqWf+5KZjDgq78yM9BiN0byykxSXyeotLEKoyKKe6s/rZl3Nh15V/UlH1hN8fQXtw594j3rzkE+n48bt5vHnuA500PpeKGj/GAyfTSs8nKD8mQhR+EcPc5SPMKs72W5qb85b3c+qDVi2bYdmq9fjIrA2WrVoPp749eWXmzprMO9uvbMbksejSxx0zJo8VLPvph6/x62+BMGrUEd+v3ghLc+EZeGWzpo1DWsY5SJrYYv6SH9HcqqmgjItDT7RsYY0VazbDpGkXrPhpMxx78wNs07EdjpxI4z4gAPmHxJETabDpKHwOykYOc0XGnxe57/j9pi/EP2/f8s72A8CsqWMFZ/srk9sABwDgzvabmzWoku0YChqll5un/n7+19JiLFv5M7Zs+NGg7+dPO3MO9x8+wSR/LwAyhEbEoWVzazj3tRddv6bfzy8tfiM/7q/I/fw0Si97FF/3AUBMfCKcHLS/Oq22cnbo+T74cpP8vd4Hv/ZQfN0HAAePnNJjS2o+Cr8a5uYN4eU/A3UbtoLE2AijvYbru0lEC+YNTTFh1hJYtnOGsVE9fTenRqOv+tTo1aMb4iKClOYY3NGRQbLr2gnh29eB/l5loz0/IYyi8BPCKAo/IYyi8BPCKAo/IYyi8BPCKIP+qs9vkvp/nSX8IkjkqyGN3xaJL5RpN6EF1Sv8tCyv5Ww11ylqWF+39hvKcF2GzKDDHxNfsfvgCTFkBh3+yrq2X3V9Q722X7S9Ynv+WnJtf/nbW/rgkw40Vh8hxMBQ+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZR+AlhFIWfEEYZ9Ig9/OG6xEdkUX1YOlnWCDiqi9WUF5uj1Yg9atdWM2KP+vLiI+CIlFc3wpBo1ZpHwFHXFm5NsbLqRuwRmxZ5vmpH7FHTCnUjMrHCIMNvbGwMQPNAnYRoS/F+MjR1ZGXvcmqdwsJCpKam4t27d/puSo2VmZmJTZs2YcGCBejTp4++m1NjffDBB3BxcYG5ubm+m1LpDDL8pGze3t6Ii4uDl5cXYmNj9d0cogd0wo9BUqkUSUlJ2LJlC5KSkiCVSvXdJKIHFH4GxcXFwcrKCnPnzoWVlRXi4uL03SSiBxR+BkVERMDf3x8A4O/vj4iICD23iOgDHfMzJi8vD02bNkVubi7at2+PGzduwMbGBk+fPkWjRo303TxSjWjPz5jo6GjY2tqiffv2AID27dvD1tYW0dHRem4ZqW4UfsYod/kVqOvPJur2M+TevXto164d7t+/D2tra27+48eP0bJlS9y6dQutWrXSYwtJdaI9P0MiIyPRt29fXvABwNraGn379kVkZKSeWkb0gcLPkH379sHPz090mZ+fH/bt21fNLSL6RN1+RuTk5MDOzg7Pnj0TvVS1sLAQTZo0QXZ2NmxtbfXQQlLdaM/PiIiICAwePFjtNerm5uYYPHgwnfhjCIWfATKZDJGRkRg7dqzGcmPHjkVkZKQWtxcTQ0DhZ0BWVhby8vLg6empsZynpyfy8vKQlZVVTS0j+kThZ0BERAQ8PDwgkUg0lpNIJPDw8KCuPyPohB8D6tSpo/M69LYwfAb5n3wIX0FBgeC23eLiYnTt2hWXL18W9AhMTEyqs3lET2jPz6jXr1/D1NQUr169Qv369fXdHKIHdMxPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKPqyGQymerMd+/eYcGCBXj+/Lk+2kSqwbt373Dr1i20a9cOH3xA+wBD1bhxY2zatEn0bywa/qtXr8LGxqZaGkcIqVq5ubno1KmTYP5/xAq/e/cOAPDNwjlYveIbkRIyDQ8FnyVKs2TisyETXU1sAzKx+YLimkqp25ZK62XCZeJVqWu4THRV0fJqXh9eq7R8ffhz1G1L3d9B07bK9/qof4XEXx/RNTS8Plx5HV6f0oeV+fqo1KrD6yNeQv3rI3iF1ExsCdqHNRuDuDyrov4eIYyi8BPCKAo/IYyi8BPCKAp/LSRpYgtJE1t9N6NS5V6/Db/pC9GghT0atuip7+bo5OqNOxj/2TewaOsEi7ZO+m6O1kTP9tdUdc1ac4/z7l9CfRMJN/1aWoxGLbtx0/8W3gYAfGzeFgDw9v20spT0LKSeycK6jQEAgGFuA+DY1x7zZk+tkvYrGH8i/9ql5O+rVbqdqmBq3Z037e7qDMfedujn2BM2HduVu941G7Yh+UQ6HuachkRiJFh+4VIuBnvJ/y7H4naiRzf+V9FmrXoL1tn001JMHDuCX651H2G5NUswQaWcLtZuCsLRUxm4ezEZJhIj9V8G1DC1KvzKjp5IxWiv4bxpXaxcuxk5V29g+dL5WLF0PgAZCgqLcOjIyUpuaeUrfpaj7ybg1aOLAABpcQku51yDo7sfFn85Hd999Xm56ks+kQ4AMJEYi345uC/2sNLjREH4FYruZQEA0jMvYOS4uSguKcGc6f6CcoV3MwHIkJ6ZjVHjv0BxyRvMnu5XrrYfPZXxvu3CD62arFZ2+8OCfkNkbAJvXmRsAsKCNmu1fvSBRKzbGICv589C507tufkW5maYMmG06Dop6Vn4cvEPqGfZHl8u/gEp6VmCMkaNOsCoUQfkXL2BeV+vhFGjjpj3zUo8flp6paRir694rDwNAOey/4JxYxsYN7bB6ElzERN/RLAdsW6/pElnSJp2Rs61m1iwZDVMmnbGgiWr8eSp8CrN1IxzWLB0DUysumLMlHlIyzgnKFPfuhvqW3fD+Ys5GDt1Puqr7PEVTCTGcO5rj4T927H+92CknT3PW5529jwWfrcWDZr3gN+0hYLlANCghT3vsWq3/8mzvxGyNw7Bv69G8O+rEbI3Dk+e/S3aHgWnPj0AAMt/2lJGOTt5ubXCcumZ2fhq+XpYtHHA+JlfIz0zW1DGoq2j0uPa1e2vleF3c3VBYvIppKRnAgBS0jORmHwKbq4uWq0fGXsIANCzR1etyqekZ2Go92S4u7rgn/wbcHd1wVDvyUg5I/wAAIAbt+/ht19W4PLZJATvjsSvvwdyy5S7+iV/XxV0/d++/RfPbmah5HkuflrxFaZ8vlj0A0Cdm7fvY9O6ZbiYfgg7w6OxYctO3vLUjHPwGDMTDr3tIH1yGV99MQ0eY2aKfgAAwKMnz7B/12a8fnxR43a72nYAAAQER3Dz0s6exwi/z+HYyw4vH17AorlT4On3ueAD4OWD87zHLx7w23IqTf4697SzRU87W968qpKemY1RE76EQ89uKLiTgfmzJ8FrwpeCD4CC22eUHqej4HZ6lbarMtXK8Nc3kSAsaDO2bA/Ba2kxtmwPQVjQZt45AE0Sj57SaXtxCckAgKFu/Xm/FfNV+Y4cCgBo27oFACB4d6TW23Jx7AUTE2MAQJtW8vWjDiRpvb6Pp/v7dZsDAHaGR/OWxx8+BgAYPEC+x7Lv3hkAcODwcdH6vEe4abVdE4m8zckn0kq3lXgCAODavy8AoEc3W958bUiLSzB/6U+YMs4LVk0+gVWTTzBlnBfmL10LaXGJ2vXSMy8AAIJ+W6WxfkWYVcsdPCJ/jwx0kZ9L6NFV3kNLOHJa67bXdLUy/EDp3n/ZqvXctLaGuQ3QaVvBu/frNL+8Cgpf4PftoVy337ix/Lj2yLGUStuG4sPAqoMjTKy6wsRK3vvZpfIhoStFEN1dnbl5u/bEAACa2/RDg+Y90KC5vCsesidW63ov59wAAEwZ583NmzLOi7dMmVmr3jBr1Rsjx83FlHFe8PIYJFqvees+MG/dF6PGf4HJ/qMwargrb3loRDwAoFU3N1i0cYBFGwfefENQa0/4Kfb+E2fMR3J8uNZ7fQAY4+2BxKOncO7CZa26/kPd+iPpqPATf/qksTq1uSxzFi1H0rEUXL9wHNZNGwMA9wFQWaZN8MXO8GhIn1zm5lXG2enLOdcBALOVTq5NHe+DXXti8PLhBZE1tNvq9l37AADOQ8eJLNsP5749ePMUJ/ziDh3HjHnfY7L/SNh0aCtYV3HC78DhE5gxbzmm+I9Cpw5tuOWT/UciNCIehXcydLi2v3aptXt+ABjtNRz/Ft1BPyfh1zea+I4ahiULZ+OXzdtx5Wrp3qOgsAgh4VGC8nNnTgIA7gNA8dtrhHt5m67RR3XrAoBOx/raGjl8sLzug6WHLHfuPcSWHWHlqk9aXCI/th87C4u/nA7nvqUn70YOk+9N4xKOKW3rEf4I2qNV3bnXbyP5RDp+/HYeXtw/hxf3/+R+fvz2SySfTEfudeFXuADg5TEI7gMdsXZjoOhyhVHDXeE20BE/beKX8xwi7x0eOFx6iHL3/mME7Kzc3p4+1erwV8SKpfMx97PJOJCQjI8t2uFji0/x+fxloseR/Zx6IyZ8G3btiUI9y/ZIPpGKpNhQ9HMUfresjcSYXRg6uJ/gbP9PK77C9Imj0dLWGfO/WYVm1k3K/fzUcXHoiZMJYbhx6y7X7c/Iysao9x8K2jJt1h2mzbpj5rxluJJ7E2eS9wm+5nPua4/j8SG4fusu1+3P+DOb+1AoS0KS/GtXF0fhRT+KeQlJ6s/fzJo6FsknzyBs/0GN25k1ZQyOnjyD8P2l3yA59bFDckwgbty+z3X7z567hBFD+mvV9tpA9H7+nJwcdO7cmW7p1WJbdEuvmu0obYtu6dXvLb1XrlyBra3wilBm9/yEsI7CTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijNN7Vd+PWHcTEJ4osEb9kUs0MzVc3aiogsq0yb6gSuTxTq8aoLq3w5b06bL/My3vVN0HjOjr8LXgFtLm8VxvlvLy3jApF5mp5p502l/dq06jKurxXYwnNl/dq057rt+5p3KbG8B88fBQHDx/VWAEhpHbSGH7P4W4Y6ztSZAnt+UvbQ3t+TVXRnl+L+kRLVHzPf+TkGcQdVv8PaTWGv327NvAZOUzzxrW+U0q4jPcm1ebNLVNZR21xTaW0fHNXOPzifzy6q09lHdEmqntzlyf85Xmvluf1UalVh9dHvITm8KuvvnTiweNnANSHn074EcIoCj8hjKLwE8IoCj8hjGIy/I+fPIPP+Fn42KL8Y8vVJKlnziF0b+m/ww7dG4tUNYNwkNrh6bM8TPj8WzRq36/KtsFk+HeFR2HTuuV4W3BL302pFFuDwuHlUTq4htcINwQEheuxRTWHWSvd/rNzTREefRjrvp+HvBspVbaNGh3+ug1bCeZ9ZNb6/U8bfGTWBrvCIlFQWKRTves2BsDaqvQ/4yr+e+/HFp+inuLHUv5Tk4gNy51z7SZGew3jRvkB5KPnDBnUDznXbmqsz8SqKxYsXSO6bMG3a1Dfuhtvnup4fQVFL7A7Ig6mzexg2swOa37dhjv3Hmr7dHTSsGX5hu0uupdZyS1RTzFWn2VbJ1i2c8K6zcE4eioD0uI3Ote1KSAcTZs0qoJWlqrR4Vfn36K7+LfoDv4tugObjp9i1brfKlTf24JbeFtwE28L5GH5p+Am/smX/9R02ZdyuXHylNl1s0H2pdwy12/VwhpPnvIHvXzy9G+0atFM43rS4hKs3bAddl1t8OpRNl49ysbMKWOQkaV5TD9DV3A7Hfm305F/Kx3TJ3ijXr2PMWfx6nJ9AFS1Kgt/VOwhfGjaAqPGTsfptLP4sEELQZnE5JPw8puOug1aYWcYfzAExV6/bsPWqNuwtdrt9OzRFUEhEbx5iUdPwXvcZ/jIvC12hfPHyfvYXH6cL9/b63bML5UWIyRc/r/761m2x2/bQgRljBp1QOqZLPhOmAOjRh15y6Ljk2D8SSeMnjgHqWf+FIzQCwBJx1IwetJcGDe2QcjeGG6+Yq+vOkLv5ZzrsDQ3E9TT3Lop/no/io6CSdMugnL9nHrjwOFjvHkHEo+jv2MvsZeAc/x0Bvx8PGDTsfQ1tDBriEn+owRl4xKOcf+3X3kAD4UGLexx4VIOFn63Dg1a2GPRd+tQUPSSW67Y6zds2QsNW5a2S1pcgrD98TBrKR+ia2twhKBu5W6/Wes+uHApF199/wvMW/fBV9+vR6HSdhSOnsrAuJlfw7yNA8IjEwTLLdo6Ij0zG+M/+4Y3Sq8qc7MGcOrdHTMn+3Jj/ylvY8LnS2H5qQvCow7zljX61OX9736175g/MVk+ysn/Xj3Agf3Bot3y02ln8XdeAeL2BeO/L+9BYmyEqLhD3PL/vrj3/vdd/PfFXbXbSknPxNJFc3jTefkFiN27A/8W3obE2AjRB0pf3LeF8uN8+d5et2P+ZT9ugGt/J/yTfwP/5N9AF9sOiI4XDqKZX/gC0eFb8SbvGjcv6dhpAPKReaPCtoq+Jqln/kReQSGidv+Bkue5kBgZcaP2FD/L4X4rHgPAzrAoXpdfwURiLBikU4xtx3a49+Axt/d/8vRv3HvwiBdqMdHxR2DfXXgYoir5RBqK37zBy4cX8PLhBRS/ecMbzFPh0ZPn2LhmCV4+OA/PYa4ICi390H5x/9z73/LRehRW/rwVA5x7o+h+ForuZaFzp3aIOyQ+4Ci3nafP8euPX6PwbiY8hw5A0G7+a5SemY38giLsDfwFhXcyYGxUjzdqj0Jh0Uvs2fEzb5RedZx6d8exU2dLt5F1EfmFLxC+bS3yb6bC2OhjxCeWXomXdzP1/e+U2nfMHxy6H26D+nHTbq79BGVi45PgM6r00uHRXh7YHyP8lBWjfMy/ZXsIZs+cWFrvwSPw9hzKTfuOGo7ImENi1ejs9/U/wNqqMTfdz7E3omIPC8opRulVFrInBm4DSsduHzxAOI77gUNH4e1ROgSYz8ghiDogdldl+Uif/iU6f9oEX5xMlb85Dxw+jmnjfcusSyzAYkL3xWPU8NLBMkcNH4Td+4SDXXp5lI4Y5Ny3B37dsqvMujes/gZWTT7hpp369EBsguYb0byU2uLUxw4btobylh88cgqeQ0sHch013BWxIr0V1YE9y3L0VAb3OOHIaW44MAAYNWwgYkU+YKpalQzUmZh8gjdwptggmoEhexEYsrdc9f9bdBeADK+lxdj8RzBevZbC4n3XNyg0AkGhwu5fZSgoLMK24D1Yt3GbzusmHTsNExMJd1W2ichrEhwWheAw4ViBmkybOBpSaYlg7y8tLsG0CWWHGABsOrbDzvBoONx7iHsPHuGLmRPKXEd5NF5Nkk+kccN3A/IeibYfHGUpKHqJoNAo/PpH2R8U2gqNOIDQiAOVVp+C26RbvdkAABBTSURBVAAH7vHufQexe5/mIcSqQ5Xs+Ye5u+K1tJibVn6sMHPKOPz35f33P/fw3xf3uK6+tuqbSDB/7nQsWb6Wmzdjsj/+LbzN/bx9/1MZPl+wDH6+nly3/5884RDR6gwd3B9SpddBKvKaTJ84GiXPc3k/xc81n7TratsBD588Fcx/+PgpuoicCFRn1PBBsHP25O2lNfEdOQTnL+aUWc7d1Zk3/qG0uETrD46yzPtmDcZ4DeG6/YoReitisv8oFN7J4P0U3Mkoe0UN0rMuwsujtKcwyc8T+bfSkH8zDfk3U5F/M5Xr6lenKgn/9MljcfR4Cjd99ESKoIz3yKHYuXs/98HwWlosOOk3zH1gmduqbyLBGO8RuJIrP7nl7TkEu8IjefWqnvSrCMUIulJpMaJF/9GJuCnjfXD0VDo3fUzpscIoDzeE7I2BVFryfhslCFU66TdE6VBKQd1Z/exLubDrxh/eW+yEn4KzQ0+8fnIZzg7afaU2qL8D9sUcQu610vMm8q/++HvNyX4jceBw6XH4gcPHMclP7DZxzdwHCg+TAKBu3Q8ByD9Uyjre14bnkAEIj0zgPrCkxSWiJ/20UVj0EulZFxEYGo2BzqWDuo4Y0h/hUYe4bwCkxW+wJ0p4+FjVqmzPD4A7228hcja6v3NftG7ZDMt++Bl1G7TCspW/wNmBf4b5y1lTyzzbDwDdunTCgQT5kNP9nPqgVYtmWLZqPT4yb4vvV62HU9/yfUesau0P32D9bztQz7I9lv24QfR5qTN0sHx0V8XZfrF1XRx7oVVzayxfsxHGjW2wfM1GOPYpHX9+zozxgrP9th0/RdKxFO4DA5C/YY8cT4Ftx6q7TsFEYoyli2Yh+3Iu9z1/YEgkHHrzrwVwd3WGxMiIO9svMTIq155/1lQ/wdn+H7/7EpsCdsOsZW+s+iUAFuYNKvy8nPrYoUWzpli1fhvM2zhg1fpt6NuzW9krvqf8PX9weCz++ectwrevhYnEqHQbvbujRbOm+HHDdlh+6oIfN+xAn57qP5irSrWM0vv6dTG++2Ed/ti4Wk0t7N3PL5UWY/maTdj88/IK38+feuYc7j98jMn+3gCAkL2xaNnCGi4O9mqaRffzs3A/v95G6VV83QcAMQcOw7mcY9kbEsXXfQAQm3CUt1evCBfHnpg8zpubnjzOGy5adt8Ju6os/OZmZhg1djo+NG0BicQYo708qmpTtYa5WUOMnjgHxp90gsS4HnxEvhIkpLpUyVd9ANDLvhsO7A+WT6jtJrGlp10XRIVt1XczCAFQS6/tJ4RUHIWfEEZR+AlhFIWfEEZR+AlhFIWfEEZpvMKPEFL7qbvCr8zhumx0uD687K/zNZTQ+VoA7VbQcKVqRRug3ZbVXalanroqqZjmy1fLU0XlvnbqL+8tX20VLV4Jr5aGbVX2O6J0yZ17jzWO1FvmQJ2VcW2/umuzWb62X6xoea/tV7/Jyrx2na7t56Zq1bX96sNPx/yEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMIrCTwijKPyEMErjiD0/b9yKu/ceaF0ZDdclUl8NHq7r5avXaGBan4brKqN4bR2u61ByqsY6RAfqfP36NSwtLfG///2vXA0jhNQMH374IfLz81G/fn3BMtHwE8P26NEj2NjYYOjQoUhKSkJubi6aNWum72aRakbhZ4xMJsOgQYPQoEEDREdHw9fXFy9fvsTx48dRp04dfTePVCM64ceYwMBA5OTkYNu2bQCAbdu2IScnB4GBgXpuGalutOdniKK7v2vXLvj4+HDzY2JiMHXqVOr+M4bCzwhFd79hw4aIiooSLB89ejRevHhB3X+GULefEYrufkBAgOjygIAA6v4zhvb8DHj48CFsbW0F3X1Viu5/Tk4OmjdvXo0tJPpAe34DJ5PJMG3aNLi7u2sMPgD4+PjA3d0d06ZNQ1n7hPz8fAQFBaFOnTqoU6cOgoKCkJ+fX+525ufnY//+/RgxYgQddlQTCr+BW7lyJS5duqS2u68qICAAly5dKrP7P336dNja2kImk0Emk8HW1hbTp08vdztXrFgBIyMjBAcHl7sOohvq9hu4sWPHIjExEVKpVKs9qkwmg4mJCXr06IHTp0+Lljl06BAAwMPDQ6v5uqpTp06ZPQ9ScbTnN3BbtmxBvXr1tD6RFxgYiHr16ol+I6Bw7tw59OrVSzC/V69eOHfuXLnbSqoX7fkZoO33+OquA1Clac9cGXtt2vNXDwo/I3x9ffHq1SscO3ZMtPsvk8kwePBgmJqaIjo6WmNdFH7DQN1+RgQEBODKlStqu/+BgYG4cuWK1icGSe1H4WeEhYUFtm7disWLF+PRo0e8ZY8ePcLixYuxdetWWFhYlFnXsmXLRL/Wy8/Px7JlyyqtzaRqUbefMardf126+wp0tt9AyAhTCgoKZJaWlrLt27fLZDKZbPv27TJLS0tZQUGBTvV4eHjIMjMzuenMzEyZh4eHoJzYW6ystx29LasHvcoMio6OlkkkEll6erpMIpHIoqOjda4jLy9PFhgYKIP8/0bJAgMDZXl5eYJyuoRfUZfyD6k61O1nlK+vL2JiYuDj46N1d58YFgo/ox4+fIhu3brh0qVLdBMPo+hsP6NMTU3x8uVLmJqa6rspRE8o/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwqo5MJpPpuxGVoWPHjrh+/bq+m0EMXIcOHXDt2jV9N6NSGEz469SpAwDwGTlMbRnhExV56mW+GuIFZBqL6PoSy3irlL22mhIaV5RpWbeikO5vE5liHa1XLaOg6GuiY7u0eLure58cSk59X4VBRAb/0XcDKpOf70iEBf+uNEem8kv13SPyFhL8YWUqs1WWy1RDJBN598hUNsdvh0ywgmr41bebWy726SMTfYa8OtS3W6bSXNXnrUO71bx2whBp+HvJV1AtWa6/l+qrp1pMXbtn/2cN4g6fhKGgY35CGEXhJ4RRFH5CGEXhJ4RRFH7CqW/dDfWtu+m7GZXu6o07mDBrKSzbOcPyUxd9N6fGMKiz/eX1YYOW3OP8B3+hvomEm34tLYZli67c9L9Fd7jHH5m1kc8rvC2oMyU9C6lnsrBuYwAAYKjbADj1sce82VMrvf0Kkia2AIDiZ1eqbBtVyaxVH96020BHOPTsBhcHe3Tq0Kbc9a7bvBNHT2XgTvYRmBjXK8eXloaJ9vwqjp5IUZlO1bmOlWs3448doRg1wh1vC27hbcFNbNu8GiYS40pqZdV4/fgSXj++pO9moOhuJoruZmLbhuWw7dQOLsMnYu3GwHLXd/RUBgDARGJUWU00CBR+JeE7f8f+mATevP0xCQgP/k3rOqIPJGLdxgB8PX8WOndqz823MDfDlAmjBeVTzmRh3tcrYdSoA+Z9vRKpZ7IEZYw/6QTjTzoh5+pNzP9mFYwb22D+N6vw+Olzroxiry9/3BmSJp15dZy/eAUmTbvApGkXjJnyJWIOJgu2I9btN7XuDtNm3ZF77RYWfrsWps3ssPDbtXjy7G/B+mlnz2Phd+vQoIU9/KYvRNrZC4IyDVv2QsOWvXDhUi7GzfgKZq16C8oomEiM4dTHDgf2bMGGraFIz8zmLU/PzMbi5b/Coq0jxn/2jWA5AFi2c+Y9pm5/KQq/EjfXfkhMPomUtEwAQEpaJhKTT8LNVfs3TGTMIQBAzx5dyygpPzQY6j0Zbq7OeJN3HW6uzhjqPQWpZ/4ULX/z9l1s/nk5LmccRnBYFDb8HsQtK36Wo/T4iqDr/8/bf/HkRgakT//Cmu8XYeqcJaIfAOrcvHMfG39aigspcdi1JwYbt4bwlqedPQ9Pv9lw7N0dLx+cx6I5UzDSf7boBwAAPHryHHuDfkXRPeGHnaouNp8CALaHRHLz0jOz4TXhS/Tt2RUFt89g/ucT4TVxHtIzL/LWzb+Vxnucf1P3npyhovArqW8iQXjwb/h9+y68lhbj9+27EB78G+8cQFkSj57Sumxcgjx8Qwf35/1WzFflM3IoAKBNqxYAgOCwKK235eLQkzvsaNOqOQAgOv6I1ut7j3DjrbtrTwxveXziCQCAa7++AIAe3eQ9kYPv56vy8hik9bYV7VZ03wEg4Yj8dR7oIu859Oja6f3801rXyzoKvwrF3n/Zyl/eT+vWTRzmNkDrssG796uZHyk6v7wKCl9gy44wrttvYtUFAHDkeOXtBUP2xAIAmtv2R4MW9mjQwl4+f29cheuWFpcAANwGOHDzQiPiAQCtu7vDoq0jLNo6yufvi6/w9lhB4Veh2PsHhuzFl7Om6rTXB4AxPh4AgHMXLpdZdqhbf9H50yeN0WmbZZn71Qp8t2oDrp1LhvTpX5A++atS6weAKeO9AQAvH5znfl48OIcXD85VuO6/cm8CAGZNKX1dJvuPBAAU3D6j8pNe4e2xgsIvYrSXB/774h76Ofcpu7AK31HDsGThbPyyeTuuXL3BzS8oLEJIOL+bPnfmJABA0rHTvN9eI9zL23SN6tatCwA6Hetra+QwVwBA3KFj3Ly79x9ha9DectcpLS5BemY2Ro3/AovmTIZTHztu2Ygh8h7WgcOlhxV37z9GwE7x3hQRovBXgRVL52PuZ5NxICEZH1u0w8cWn+Lz+cu47qtCP6feiAnfhpDwaBg16oCjJ9KQFBsCF8de5dru4ahgDBnUT3C2f83yrzBtgi9ad+mPBUtWo7l1kwo9PzHOfe1xPH4Xrt+6x3X7M7IuwnPYQJ3rMmvdB2at++DzRauQc/UWUg+HYenCmbwyTn3scCQmEDdu3+e6/WfPXcKIIeK9KSJkUPfz0y29KvXTLb0i7a7ALb2L5bf0GkhkaM9PCKso/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwisJPCKMo/IQwyqBu7CGkOhhIZAzrX3c3s2qq8X/nCf9kIn/EMv+u4gXEbqrToVJhedWb8MrRJs0rqt7VV1ZR3d/whjZK78W/ruPp83zdtleDGVT4HfrY0y29yvXTLb0i7a74Lb2Ggo75CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUhZ8QRlH4CWEUjdJLiI4MJDKGM1Dn2rVrcfHiRX03gxi47t2767sJlcZg9vyEEN3QMT8hjKLwE8IoCj8hjKLwE8IoCj8hjPr/VVF1QHMwmSQAAAAASUVORK5CYII=" alt="The ECUC container definition reference" id="fig:AutosarContainerDefRef " data-latex-style
 * ="scale=0.7" />
 *
 * <p>
 * In ARXML, such a reference can be specified as:
 *
 * <pre>
 * &lt;DEFINITION-REF DEST="ECUC-PARAM-CONF-CONTAINER-DEF"&gt;
 *     /MIRCOSAR/Com/ComGeneral
 * &lt;/DEFINITION-REF&gt;
 * </pre>
 *
 * <pre>
 * <!--UML: ClassDiag AutosarContainerDefRef{
 * [MIARRef:{@link MIARRef}|getValue():String],
 * [MIContainerDefARRef:{@link MIContainerDefARRef}|getRefTarget():MIContainerDef],
 * [MIContainerDef:{@link MIContainerDef}],
 * [MIContainerDefARRef]-^[MIARRef],
 * [MIContainerDef]-"    0..1"<>[MIContainerDefARRef],
 * }
 * -->
 * </pre>
 *
 * <ul>
 * <li>{@link MIARRef#getValue()} returns the AUTOSAR path of the object, the reference points to (as specified in the ARXML file). In the example above
 * <code>"/MIRCOSAR/Com/ComGeneral"</code> would be this value</li>
 * <li>{@link MIContainerDefARRef#getRefTarget()} on the other hand returns the referenced MDF object if it exists. This method is located in a specific, typesafe (according to
 * the type it points to) reference interface which extends {@link MIARRef}. So, if an object with the AUTOSAR path <code>"/MIRCOSAR/Com/ComGeneral"</code> exists in the model,
 * this method will return it
 * </ul>
 *
 * </p>
 * </div>
 *
 * <p>
 * This ProjectService is threadsafe
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IReferenceAccess {

    /**
     * This method returns the target object of the specified reference. It returns <code>null</code> in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>The specified reference is <code>null</code>
     * <li>The specified reference is removed or invisible
     * </ul>
     *
     * @param ref
     * @return
     * @throws MultipleVariantObjectsException if more than one reference target exists which can never happen in the following cases:
     * <ul>
     * <li>In non-variant projects
     * <li>If the client code is being executed in a predefined variant view
     * </ul>
     */
    @PublishedMethod
    MIReferrable getRefTarget(final MIARRef ref);

    /**
     * This method returns all target objects of the specified reference. It returns an empty collection in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>The specified reference is <code>null</code>
     * <li>The specified reference is removed or invisible
     * </ul>
     * This method never returns <code>null</code>.
     *
     * @param ref
     * @return
     */
    @PublishedMethod
    Collection<MIReferrable> getRefTargets(final MIARRef ref);

    /**
     * This method returns the target object of the specified reference parameter. It returns <code>null</code> in the following cases:
     * <ul>
     * <li>No such target exists
     * <li>If the parameter is <code>null</code>
     * <li>If the parameter is removed or invisible
     * </ul>
     *
     * @param parameter
     * @return
     * @throws MultipleVariantObjectsException if more than one reference target exists which can never happen in the following cases:
     * <ul>
     * <li>In non-variant projects
     * <li>If the client code is being executed in a predefined variant view
     * </ul>
     */
    @PublishedMethod
    MIReferrable getReferenceTarget(final MIReferenceValue parameter);

    /**
     * This method returns all target objects of the specified reference parameter. It returns an empty collection in the following cases:
     * <ul>
     * <li>If the reference parameter has no reference value
     * <li>If the parameters reference value has no target
     * <li>If the parameter is <code>null</code>
     * <li>If the parameter is removed or invisible
     * </ul>
     * This method never returns <code>null</code>.
     *
     * @param parameter
     * @return
     */
    @PublishedMethod
    Collection<MIReferrable> getReferenceTargets(final MIReferenceValue parameter);

    /**
     * This method sorts the specified collection of reference objects to guarantee deterministic order.
     * <p>
     * The criterion to be sorted by is the object link of the reference objects. If this link is equal, the reference values (AUTOSAR path) will be compared.
     * </p>
     *
     * @param references
     * @return
     * @throws NullPointerException if the specified collection is <code>null</code>
     */
    @PublishedMethod
    <T extends MIARRef> List<T> sortReferences(final Collection<T> references);

    /**
     * Returns all reference objects pointing to the specified object. It returns an empty collection if the object is invisible, removed or <code>null</code>.
     * <p>
     * <b>Remark:</b> Be aware that this method also returns objects located in the DerivedEcuC!
     * </p>
     *
     * @param referrable is the object, the searched references point to
     * @return
     */
    @PublishedMethod
    Collection<MIARRef> getAllReferencesPointingTo(final MIReferrable referrable);

    /**
     * Returns all reference objects pointing to the specified object. It returns an empty collection if the object is invisible, removed or <code>null</code>. The returned
     * references are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> Be aware that this method also returns objects located in the DerivedEcuC!
     * </p>
     *
     * @param referrable is the object, the searched references point to
     * @return
     */
    @PublishedMethod
    List<MIARRef> getAllReferencesPointingToSorted(final MIReferrable referrable);

    /**
     * Returns all reference parameters pointing to the specified target object. It returns an empty collection if the object is invisible, removed or <code>null</code>. The
     * returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(final MIReferrable target);

    /**
     * Returns all reference parameters with the specified definition pointing to the specified target object. It returns an empty collection if the object is invisible, removed
     * or <code>null</code> or the specified definition is <code>null</code>. The returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @param definition is a parameter definition (absolute definition path or its last shortname)
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(final MIReferrable target, final String definition);

    /**
     * Returns all reference parameters with the specified definition pointing to the specified target object. It returns an empty collection if the object is invisible, removed
     * or <code>null</code> or the specified definition is <code>null</code>. The returned parameters are sorted by means of {@link #sortReferences(Collection)}.
     * <p>
     * <b>Remark:</b> This method doesn't return objects contained in the DerivedEcuC!
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @param defRef is a parameter {@link DefRef}
     * @return
     */
    @PublishedMethod
    List<MIReferenceValue> getReferenceParametersPointingTo(final MIReferrable target, final DefRef defRef);

    /**
     * This method returns all model objects which are parent objects of references pointing to the specified target. It returns an empty collection if the object is invisible,
     * removed or <code>null</code>.
     * <p>
     * The returned list may also contain derived objects (located in the InitialEcuC).
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIObject> getObjectsPointingTo(final MIReferrable target);

    /**
     * This method returns all parameter objects located in the ActiveEcuC which are parent objects or references pointing to the specified target. It returns an empty
     * collection if the object is invisible, removed or <code>null</code>.
     * <p>
     * The returned objects can be of type {@link MIReferenceValue} and {@link MIInstanceReferenceValue}.
     * </p>
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIParameterValue> getActiveEcucParametersPointingTo(final MIReferrable target);

    /**
     * This method returns all objects located in the system description which are parent objects of references pointing to the specified target. It returns an empty collection
     * if the object is invisible, removed or <code>null</code>.
     *
     * @param target is the object, the searched reference parameters point to
     * @return
     */
    @PublishedMethod
    List<MIObject> getSystemDescriptionObjectsPointingTo(final MIReferrable target);

}
