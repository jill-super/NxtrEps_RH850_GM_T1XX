package com.vector.cfg.consistency;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved. <BR>
 * <BR>
 * An IValidationResultId represents the unique identifier of a validation result. getId() + getOrigin() together must be unique.
 *
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IValidationResultId {

    /**
     * Describes the Max_Value of the {@link #getId()} method.
     */
    @PublishedField
    int MAX_ID_VALUE = 99999;

    /**
     * The integer Id that must be unique within the origin. The id must be in the range [1..{@link #MAX_ID_VALUE}]
     *
     * @return
     */
    @PublishedMethod
    int getId();

    /**
     * This method returns a short static string representation of the Id.
     *
     * @return
     */
    @PublishedMethod
    String getMessage();

    /**
     * The origin describes the "namespace" of the Id which can be the MSN or "Cfg" for general validation messages.<BR>
     *
     * @return
     */
    @PublishedMethod
    String getOrigin(); // MSN or "Cfg"
}
