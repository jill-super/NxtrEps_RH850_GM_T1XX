package com.vector.cfg.gen.core.utils.query.sorters;

import java.math.BigInteger;
import java.text.MessageFormat;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.gen.core.bswmdmodel.IGeneratorModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.param.GReference;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.access.AsrObjectLink;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.CompareResult;
import com.vector.cfg.util.query.ElementSorter;

/**
 *
 * The {@link GenReferenceToIntegerInContainerSorter} is a {@link ElementSorter} for two {@link GIContainer} objects.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenReferenceToIntegerInContainerSorter extends ElementSorter<GIContainer> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenSymbolicNameRefToIntegerInContainerSorter.class);

    private final EValueSorterType sorterType;

    private final DefRef referenceName;

    private final DefRef intParameterNameInTargetContainer;

    /**
     * Constructor for GenIntValueSorter.
     *
     * @param referenceName the reference name
     * @param intParameterNameInTargetContainer the int parameter name in target container
     * @param sorterType the sorter type
     */
    @PublishedMethod
    public GenReferenceToIntegerInContainerSorter(DefRef referenceName, DefRef intParameterNameInTargetContainer, final EValueSorterType sorterType) {
        this.intParameterNameInTargetContainer = intParameterNameInTargetContainer;
        this.sorterType = sorterType;
        this.referenceName = referenceName;
    }

    /**
     * Constructor for GenIntValueSorter.
     *
     * @param referenceName the reference name
     * @param intParameterNameInTargetContainer the int parameter name in target container
     */
    @PublishedMethod
    public GenReferenceToIntegerInContainerSorter(DefRef referenceName, DefRef intParameterNameInTargetContainer) {
        this(referenceName, intParameterNameInTargetContainer, EValueSorterType.VALUE_EQUAL_ALLOWED);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected CompareResult compareElements(GIContainer container1, GIContainer container2) {

        final IGeneratorModelAccess genMa = (IGeneratorModelAccess) container1.getGeneratorModelAccess();

        final BigInteger value1 = getValueOfContainer(container1);
        final BigInteger value2 = getValueOfContainer(container2);

        if (value1.compareTo(value2) < 0) {
            return CompareResult.ELEMENT_1_BEFORE_ELEMENT_2;
        } else if (value1.equals(value2)) {
            if (sorterType.equals(EValueSorterType.VALUE_EQUAL_ALLOWED)) {
                return CompareResult.ELEMENTS_EQUAL;
            } else if (sorterType.equals(EValueSorterType.VALUE_EQUAL_FORBIDDEN)) {

                final IGeneratorResult result = GeneratorResultBuilder
                        .newBuilder(CommonGeneratorResultIds.getElementNotUniqueErrorId(genMa.getValidationResultOrigin()),
                                "The two Integer values {0} and {1} of the containers {2} and {3} via the SymbolicReferences are the same. These values should be unique.",
                                getParameterOfContainer(container1), getParameterOfContainer(container2), container1.getObjectLink(), container2.getObjectLink())
                        .addErrorObject(container1).addErrorObject(container2).addDependentObject(container1.getParent()).addDependentObject(container2.getParent()).buildResult();

                throw new ValidationFailedException(result);

            } else {
                throw new IllegalArgumentException("The sorterType has an unknown value.");
            }

        } else {
            return CompareResult.ELEMENT_1_AFTER_ELEMENT_2;
        }
    }

    /**
     * Gets the value of container.
     *
     * @param container the container
     * @return the value of container
     */
    private BigInteger getValueOfContainer(GIContainer container) {
        try (IModelViewExecutionContext context = container.executeWithCreationModelView()) {
            final MINumericalValue paramValue = getParameterOfContainer(container);

            final IModelCheckedAccess mca = container.getGeneratorModelAccess().getMdfModelCheckedAccess();

            return mca.parameter(paramValue).asInt().getValue();
        }

    }

    /**
     * Gets the parameter of container.
     *
     * @param container the container
     * @return the parameter of container
     */
    private MINumericalValue getParameterOfContainer(GIContainer container) {

        final GReference bsmwdRef = getRefOfContainer(container);

        final MIReferrable targetRef = bsmwdRef.getRefTargetMdf();

        if (!(targetRef instanceof MIContainer)) {

            try (IModelViewExecutionContext context = container.executeWithCreationModelView()) {
                String objLink;
                if (targetRef instanceof MIHasDefinition) {
                    objLink = AsrObjectLink.create(targetRef).getObjectLinkString();
                } else {
                    objLink = targetRef.getName();
                }

                throw new IllegalArgumentException(MessageFormat.format("The reference {0} does not point to a MIContainer. Target object location: {1}", referenceName, objLink));
            }
        }
        final MIContainer targetContainer = (MIContainer) targetRef;

        final MINumericalValue targetParam = getTargetParameterInTargetContainer(container, targetContainer);

        return targetParam;
    }

    /**
     * Gets the target parameter in target container.
     *
     * @param container the container
     * @param targetContainer the target container
     * @return the target parameter in target container
     */
    private MINumericalValue getTargetParameterInTargetContainer(GIContainer container, MIContainer targetContainer) {
        try (IModelViewExecutionContext context = container.executeWithCreationModelView()) {

            final IModelCheckedAccess mca = container.getGeneratorModelAccess().getMdfModelCheckedAccess();

            final MINumericalValue param = mca.parameter(targetContainer, intParameterNameInTargetContainer).asInt().getParam();

            return param;
        }
    }

    /**
     * Gets the ref of container.
     *
     * @param container the container
     * @return the ref of container
     */
    private GReference getRefOfContainer(GIContainer container) {
        final List<GIReference<?>> paramList = container.getReferences(referenceName);

        if (paramList.size() != 1) {
            throw new IllegalArgumentException(MessageFormat.format("The Parameter {0} with multiplicity != 1 is not permitted. Parameter location: {1}", referenceName,
                    container.getObjectLink()));
        }
        final GIReference<?> param = paramList.get(0);

        if (!(param instanceof GReference)) {
            throw new IllegalArgumentException(MessageFormat.format("The Parameter {0} is no GReference. Parameter location: {1}", referenceName, container.getObjectLink()));
        }
        final GReference symRef = (GReference) param;
        return symRef;
    }
}
