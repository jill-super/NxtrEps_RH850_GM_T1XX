package com.vector.cfg.consistency;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.ui.ISolvingActionUI;
import com.vector.cfg.util.activity.execresult.IExecutionResult;

/**
 * <div class="extdoc" id="Common">An {@link ISolvingActionExecutionResult} represents the result of one solving action execution. Use {@link #isOk()} to find out if it was
 * successful. Call {@link #getUserMessage()} to get the failure reason.</div>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISolvingActionExecutionResult extends IExecutionResult {

    /**
     * Get the solving action.
     *
     * @return the solving action
     */
    @PublishedMethod
    ISolvingActionUI getSolvingAction();
}
