/**
 * The communication domain API is specifically designed to support communication related use cases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.dom.com.model.groovy;