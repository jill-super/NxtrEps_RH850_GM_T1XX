package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import java.math.BigDecimal;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * This class is an {@link ISolvingAction} that sets a float parameter when executed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SASetFloat extends SASetNumTextRef<MINumericalValue> {

    private final BigDecimal targetValue;

    /**
     * Constructor for SASetFloat.
     *
     * @param numerical the parameter to be adjusted
     * @param targetValue the target value as BigDecimal
     */
    @PublishedMethod
    public SASetFloat(MINumericalValue numerical, BigDecimal targetValue) {
        super(numerical, MixedText.newBuilder().append(targetValue.toString()).flushResult());
        this.targetValue = targetValue;
    }

    /**
     * Constructor for SASetFloat.
     *
     * @param numerical the parameter to be adjusted
     * @param targetValue the target value as double
     */
    @PublishedMethod
    public SASetFloat(MINumericalValue numerical, double targetValue) {
        super(numerical, MixedText.newBuilder().append(BigDecimal.valueOf(targetValue).toString()).flushResult());
        this.targetValue = BigDecimal.valueOf(targetValue);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {
        ModelUtil.getModelAccess(getParam()).setAsFloat(getParam(), targetValue);
    }
}
