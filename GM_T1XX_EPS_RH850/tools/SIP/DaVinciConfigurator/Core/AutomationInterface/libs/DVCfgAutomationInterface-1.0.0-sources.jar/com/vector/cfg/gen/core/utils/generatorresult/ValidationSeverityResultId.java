package com.vector.cfg.gen.core.utils.generatorresult;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.IValidationSeverityResultId;

/**
 * Internal implementation class for ValidationResultIds.
 *
 *
 * <p>
 * This is a basic implementation of the IValidationSeverityResultId. This class is @deprecated, because you should use an enum to define ValidationResultIds.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class ValidationSeverityResultId implements IValidationSeverityResultId {

    private final String message;

    private final int id;

    private final String origin;

    private final EValidationSeverityType severity;

    /**
     * Constructor for ValidationSeverityResultId.
     *
     * @param origin
     * @param id
     * @param message
     */
    @PublishedMethod
    public ValidationSeverityResultId(String origin, int id, EValidationSeverityType severity, String message) {

        if (origin == null) {
            throw new IllegalArgumentException("origin is null");
        }
        if (message == null) {
            throw new IllegalArgumentException("message is null");
        }
        if (severity == null) {
            throw new IllegalArgumentException("severity is null");
        }

        this.origin = origin;
        this.id = id;
        this.message = message;
        this.severity = severity;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getOrigin() {
        return origin;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int getId() {
        return this.id;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getMessage() {
        return this.message;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public EValidationSeverityType getSeverity() {
        return severity;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        result = prime * result + ((message == null) ? 0 : message.hashCode());
        result = prime * result + ((origin == null) ? 0 : origin.hashCode());
        return result;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof IValidationResultId)) {
            return false;
        }
        final IValidationResultId other = (IValidationResultId) obj;
        if (id != other.getId()) {
            return false;
        }
        if (message == null) {
            if (other.getMessage() != null) {
                return false;
            }
        } else if (!message.equals(other.getMessage())) {
            return false;
        }
        if (origin == null) {
            if (other.getOrigin() != null) {
                return false;
            }
        } else if (!origin.equals(other.getOrigin())) {
            return false;
        }
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        return "ValidationSeverityResultId [" + getOrigin() + getId() + ", " + severity + ", " + getMessage() + "]";
    }

}
