package com.vector.cfg.gen.core.utils.abstractImpl;

import java.text.MessageFormat;

import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenOptions;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;

/**
 * This class provides a skeletal implementation of the <tt>{@link IGenerationProcessor IGenerationProcessor}</tt> interface, to minimize the effort required to
 * implement this interface.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 * @see IGenerationProcessor
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractGenerationProcessor extends AbstractGeneratorPackageReferableWithModel implements IGenerationProcessor {

    private volatile IGeneratorResultSink resultSink;

    private volatile IGenOptions currentActiveOptions;

    /**
     * Constructor for AbstractGenerationProcessor.
     *
     * @param generatorPackage the generator package
     */
    @PublishedMethod
    public AbstractGenerationProcessor(IGeneratorPackage generatorPackage) {
        super(generatorPackage);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final IGeneratorResultSink getResultSink() {
        if (resultSink == null) {
            throw new IllegalStateException("The resultSink is currently not available. The resultSink is only available in the buildDataStructures() or generate() method.");
        }
        return resultSink;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void setResultSink(IGeneratorResultSink resultSink) {
        if (this.resultSink != null && resultSink != null) {
            throw new IllegalStateException("You can't change the currently assigned ResultSink");
        }
        this.resultSink = resultSink;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final ImmutableList<MIModuleConfiguration> getModuleConfigList() {
        if (getGenOptions() == null || getGenOptions().getModuleConfigList() == null) {
            throw new IllegalStateException(
                    "The moduleConfigList is currently not available. The moduleConfigList is only available in the buildDataStructures() or generate() method.");
        }
        return getGenOptions().getModuleConfigList();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void setGenOptions(IGenOptions options) {
        this.currentActiveOptions = options;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IGenOptions getGenOptions() {
        if (currentActiveOptions == null) {
            throw new IllegalStateException(
                    "The GenOptions are currently not available. The GenOptions are only available in the calculate(),  buildDataStructures() or generate() method.");
        }
        return currentActiveOptions;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        return MessageFormat.format("GenerationProcessor in ({0})", getGeneratorPackage());
    }

}
