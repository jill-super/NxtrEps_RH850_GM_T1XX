package com.vector.cfg.consistency.contribution;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved. <BR>
 * <BR>
 * The type of an IRuleEvent
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public enum ERuleEventType {
    /**
     * An MDF feature was set at the source object. Check getSource() + getFeatureName().
     */
    PROPERTY_SET,
    /**
     * An MIObject was added to the source object. Check getSource() + getFeatureName() + getAdded*().
     */
    ITEM_ADDED,
    /**
     * An MIObject was removed from the source object. Check getSource() + getFeatureName() + getRemoved*().
     */
    ITEM_REMOVED,
    /**
     * TODO document the ITEM_SET_AT EventType.
     */
    ITEM_SET_AT,
    /**
     *
     */
    USER_DEFINED_CLEARED,
    /**
     * the source element was removed from the model. In that case getSource() return null. In that case, you can cast the rule event to
     * {@link IRuleEvent} to get further information.
     */
    ELEMENT_REMOVED;
}
