package com.vector.cfg.consistency.contribution.exceptions;

import java.util.concurrent.Callable;
import java.util.function.Consumer;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.ui.IValidationResultUI;
import com.vector.cfg.model.exceptions.ModelException;

/**
 * The {@link IErrorHandlingContext} class abstract the execution of which which can cause {@link ModelException}s or other exceptions like
 * GeneratorPackageExceptions and the corresponding catch blocks.
 *
 * <p>
 * The {@link IErrorHandlingContext} will normally report the {@link IValidationResultUI}s to the {@link IValidationResultSink}. If you want a exception thrown
 * after the process you can call {@link #testForErrorAndThrowException()}.
 * </p>
 *
 * <p>
 * You can construct {@link IErrorHandlingContext} object by the ConsistencyErrorHandlingContext class,. If you have an {@link IGeneratorPackage}, you call use
 * the ErrorHandlingContext of the GenCore See com.vector.cfg.gen.core.utils.exceptions.ErrorHandlingContext.
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients. Please use class {@link ErrorHandlingContext}.
 * @see ModelException
 * @see IGeneratorResultSink
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IErrorHandlingContext {

    /**
     * Execute a {@link Callable} object and catches all {@link GeneratorPackageException}s and some {@link ModelException}s when the executed code in the
     * callable will throw such a exception.
     * <p>
     * All caught exceptions are reported to the {@link IGeneratorResultSink}.
     * </p>
     *
     * <p>
     * If you want a {@link GeneratorPackageWrapperException} you can call {@link #testForErrorAndThrowException()} after all execute calls.
     * </p>
     *
     * @param <T> the generic return type of the callable.
     * @param callable The callable to executed to inner code.
     * @return the returned object of the callable, or null if an exception occurred.
     *
     * @exception RuntimeException
     * <ul>
     * <li>if the callable has thrown a checked {@link Exception}.</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the callable is null</li>
     * </ul>
     *
     * @exception ModelException
     * <ul>
     * <li>if the {@link ModelException} can not be transformed into a {@link IGeneratorResult}. See {@link ModelExceptionProcessor} for more detail.</li>
     * </ul>
     */
    @PublishedMethod
    <T> T execute(Callable<T> callable);

    /**
     * Execute a {@link Runnable} object and catches all {@link GeneratorPackageException}s and some {@link ModelException}s when the executed code in the
     * runnable will throw such a exception.
     *
     * <p>
     * All caught exceptions are reported to the {@link IGeneratorResultSink}.
     * </p>
     *
     * <p>
     * If you want a {@link GeneratorPackageWrapperException} you can call {@link #testForErrorAndThrowException()} after all execute calls.
     * </p>
     *
     * @param runnable the runnable to executed to inner code.
     *
     * @exception ModelException
     * <ul>
     * <li>if the {@link ModelException} can not be transformed into a {@link IGeneratorResult}. See {@link ModelExceptionProcessor} for more detail.</li>
     * </ul>
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the callable is null</li>
     * </ul>
     */
    @PublishedMethod
    void execute(Runnable runnable);

    /**
     * Adds the custom exception handler, which is called when any runnable/callable raises an Exception.
     *
     * <p>
     * <b>Attention: You have to add your {@link ICustomExceptionHandler} before you call any execute method.</b>
     * </p>
     *
     * @param custom Your custom exception handler
     * @return This error handling context (fluent interface)
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the custom is null</li>
     * </ul>
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if there is already a customException handler</li>
     * </ul>
     */
    @PublishedMethod
    IErrorHandlingContext addCustomExceptionHandler(ICustomExceptionHandler custom);

    /**
     * Test if previous {@link #execute(Callable)} or {@link #execute(Runnable)} calls have thrown an exception. If there was an exception the method will throw
     * a new {@link GeneratorPackageWrapperException} with all thrown inner exceptions.
     *
     * <p>
     * A call to this method is OPTIONAL. When no call is performed all caught exception are reported to the {@link IGeneratorResultSink}
     * </p>
     *
     * @exception GeneratorPackageWrapperException
     * <ul>
     * <li>if the were thrown exception during the execute calls.</li>
     * </ul>
     */
    @PublishedMethod
    void testForErrorAndThrowException();

    /**
     * The method {@link #checking(Consumer)} will return a {@link Consumer}, which wraps the passed {@link Consumer}, with the {@link IErrorHandlingContext}
     * logic. It add try/catch blocks for the supported exceptions.
     *
     * <p>
     * The usage would be
     *
     * <pre>
     * <code class="Java" id="Usage sample">
     *   final List&lt;String&gt; chlList = ...;
     *   final ErrorHandlingContext context = ErrorHandlingContext.create(generatorPackage);
     *
     *   chlList.forEach(context.checking((x) -> {
     *       // Do some stuff with x
     *       // The ErrorHandlingContext will catch all GeneratorPackageExceptions or ModelExceptions
     *   }));
     * </code>
     * </pre>
     * </p>
     *
     * @param consumer the consumer to wrap
     * @return the new consumer which contains the catch blocks.
     */
    @PublishedMethod
    <T> Consumer<T> checking(Consumer<T> consumer);

}
