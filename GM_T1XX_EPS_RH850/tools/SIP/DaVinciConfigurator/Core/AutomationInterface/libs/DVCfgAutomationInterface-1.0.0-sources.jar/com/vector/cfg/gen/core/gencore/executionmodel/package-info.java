/**
 * Generation Process execution model defines, what to call druing generation.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.gencore.executionmodel;