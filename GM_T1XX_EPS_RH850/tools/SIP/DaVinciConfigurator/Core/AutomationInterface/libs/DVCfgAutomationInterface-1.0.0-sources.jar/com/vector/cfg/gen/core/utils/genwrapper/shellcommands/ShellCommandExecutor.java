package com.vector.cfg.gen.core.utils.genwrapper.shellcommands;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.charset.DefaultCharsets;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.util.exceptions.InterruptedRuntimeException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The class {@link ShellCommandExecutor} provides an API to call external processes, within a generator. Usage of following class can go as ...
 * <p>
 *
 * <pre>
 * <code class="Java" id="The usage of the ShellCommandExecutor class">
 *      Charset commandlineEncoding =  ...; // the encoding of the exe to call
 *      ShellCommandExecutor cmdExecutor = new ShellCommandExecutor();
 *      int exitStatus = cmdExecutor.runCommand(commandLine);
 *
 *      String cmdError = cmdExecutor.getCommandError();
 *      String cmdOutput = cmdExecutor.getCommandOutput();
 * </code>
 * </pre>
 *
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@NotThreadSafe
public class ShellCommandExecutor {
    private static final ILogger logger = Logger.INSTANCE.createLogger(ShellCommandExecutor.class);

    private static final String NEW_LINE = GenConstants.LINE_SEPARATOR;

    private final Charset commandlineEncoding;

    private File workingDirectory = null;

    private List<EnvironmentVar> environmentVarList = null;

    private StringBuffer cmdOutputBuffer = null;

    private StringBuffer cmdErrorBuffer = null;

    private StringBuffer cmdUnifiedBuffer = null;

    private AsyncStreamReader cmdOutputThread = null;

    private AsyncStreamReader cmdErrorThread = null;

    /**
     * Instantiates a new shell command executor.
     *
     * <p>
     * Uses the Os default {@link Charset} encoding from {@link DefaultCharsets} for the output stream of the process.
     * </p>
     *
     */
    @PublishedMethod
    public ShellCommandExecutor() {
        this(DefaultCharsets.INSTANCE.getOsDefaultCharset());
    }

    /**
     * Instantiates a new shell command executor.
     *
     * <p>
     * The parameter commandlineEncoding specifies the used {@link Character} for the output stream of the process.
     * </p>
     *
     * @param commandlineEncoding the {@link Charset} to use for the output stream of the process.
     */
    @PublishedMethod
    public ShellCommandExecutor(Charset commandlineEncoding) {

        this.commandlineEncoding = commandlineEncoding;
    }

    /**
     * Sets the working directory for the new process.
     *
     * @param workingDirectory the new working directory
     */
    @PublishedMethod
    public void setWorkingDirectory(File workingDirectory) {
        this.workingDirectory = workingDirectory;
    }

    /**
     * Clones all currently available environment variables for the new process.
     */
    @PublishedMethod
    public void cloneCurrentEnvironmentVariables() {
        /* clone current environment */
        final Map<String, String> variables = System.getenv();

        for (final Map.Entry<String, String> entry : variables.entrySet()) {
            final String name = entry.getKey();
            final String value = entry.getValue();

            setEnvironmentVar(name, value);
        }
    }

    /**
     * Sets a the environment variable for the new process.
     *
     * <p>
     * Attention: Java will remove all currently available variables at the first call to this method. If you need theses you can make a call to
     * {@link #cloneCurrentEnvironmentVariables()}.
     * </p>
     *
     * @param name the name
     * @param value the value
     */
    @PublishedMethod
    public void setEnvironmentVar(String name, String value) {
        if (environmentVarList == null) {
            environmentVarList = new ArrayList<>();
        }

        environmentVarList.add(new EnvironmentVar(name, value));
    }

    /**
     * Gets the commandline output.
     *
     * @return The Commandline output as String
     */
    @PublishedMethod
    public String getCommandOutput() {
        return cmdOutputBuffer.toString();
    }

    /**
     * Gets the commandline error output.
     *
     * @return The Commandline error output as String
     */
    @PublishedMethod
    public String getCommandError() {
        return cmdErrorBuffer.toString();
    }

    /**
     * Gets the commandline error output.
     *
     * @return The Commandline error output as String
     */
    @PublishedMethod
    public String getCommandUnifiedOutput() {
        return cmdUnifiedBuffer.toString();
    }

    /**
     * Runs a command with the specified parameters.
     *
     * @param command The Command
     * @param parameters List of parameters
     * @return exitCode of the called command
     * @throws InvocationTargetException
     * @throws IOException, InvocationTargetException
     */
    @PublishedMethod
    public int runCommand(String command, List<CmdParameter> parameters) throws InvocationTargetException, IOException {
        if (command == null) {
            throw new IllegalArgumentException("command is null");
        }
        if (parameters == null) {
            throw new IllegalArgumentException("parameters is null");
        }
        final String[] commandLineStringArray = new String[parameters.size() * 2 + 1];
        // Assign command and parameters
        commandLineStringArray[0] = command;
        for (int i = 0; i < parameters.size(); i++) {
            commandLineStringArray[i * 2 + 1] = parameters.get(i).getParameter();
            commandLineStringArray[i * 2 + 2] = parameters.get(i).getValue();
        }

        /* run command */
        final Process process = runCommandHelper(commandLineStringArray);

        /* start output and error read threads */
        startOutputAndErrorReadThreads(process.getInputStream(), process.getErrorStream(), commandlineEncoding);

        /* wait for command execution to terminate */
        int exitStatus = -1;
        try {
            exitStatus = process.waitFor();

            // Wait for read Threads to complete reading
            waitForStreamThreads();

        } catch (final InterruptedException ex) {
            // Notify reading threads to stop
            notifyOutputAndErrorReadThreadsToStopReading();

            /*
             * Try to terminate the process
             */
            if (process != null) {
                process.destroy();
                try {

                    process.waitFor();
                } catch (final InterruptedException exInner) {
                    // we could ignore this, because we are already interrupted.
                    logger.trace(exInner);
                }
            }

            Thread.currentThread().interrupt();
            // Propagate interruption
            throw new InterruptedRuntimeException(ex);

        } catch (final Throwable ex) {
            if (process != null) {
                process.destroy();
            }
            throw new InvocationTargetException(ex);

        } finally {

            /* notify output and error read threads to stop reading */
            notifyOutputAndErrorReadThreadsToStopReading();
        }

        return exitStatus;
    }

    /**
     * @throws InterruptedException
     *
     */
    private void waitForStreamThreads() throws InterruptedException {

        if (null != cmdOutputThread) {
            cmdOutputThread.join();

        }
        if (null != cmdErrorThread) {
            cmdErrorThread.join();
        }

    }

    private Process runCommandHelper(String[] commandLine) throws IOException {
        Process process = null;
        if (workingDirectory == null) {
            process = Runtime.getRuntime().exec(commandLine, getEnvTokens());
        } else {
            process = Runtime.getRuntime().exec(commandLine, getEnvTokens(), workingDirectory);
        }

        return process;
    }

    private void startOutputAndErrorReadThreads(InputStream processOut, InputStream processErr, Charset encoding) {

        cmdUnifiedBuffer = new StringBuffer();

        cmdOutputBuffer = new StringBuffer();
        cmdOutputThread = new AsyncStreamReader(processOut, cmdOutputBuffer, cmdUnifiedBuffer, "GenShellCommandExecutor-OUTPUT", encoding);
        cmdOutputThread.start();

        cmdErrorBuffer = new StringBuffer();
        cmdErrorThread = new AsyncStreamReader(processErr, cmdErrorBuffer, cmdUnifiedBuffer, "GenShellCommandExecutor-ERROR", encoding);
        cmdErrorThread.start();
    }

    private void notifyOutputAndErrorReadThreadsToStopReading() {
        cmdOutputThread.stopReading();
        cmdErrorThread.stopReading();
    }

    private String[] getEnvTokens() {
        if (environmentVarList == null) {
            return null;
        }

        final String[] envTokenArray = new String[environmentVarList.size()];
        final Iterator<EnvironmentVar> envVarIter = environmentVarList.iterator();
        int nEnvVarIndex = 0;
        while (envVarIter.hasNext()) {
            final EnvironmentVar envVar = (envVarIter.next());
            final String envVarToken = envVar.getName() + "=" + envVar.getValue();
            envTokenArray[nEnvVarIndex++] = envVarToken;
        }

        return envTokenArray;
    }

    private class EnvironmentVar {
        private String name = null;

        private String value = null;

        EnvironmentVar(String name, String value) {
            this.name = name;
            this.value = value;
        }

        public String getName() {
            return name;
        }

        public String getValue() {
            return value;
        }
    }

    private static class AsyncStreamReader extends Thread {
        private StringBuffer buffer = null;

        private InputStream inputStream = null;

        private String threadId = null;

        private final StringBuffer buffer2;

        private volatile boolean stopRead = false;

        private final Charset encoding;

        AsyncStreamReader(InputStream inputStream, StringBuffer buffer, StringBuffer buffer2, String threadId, Charset encoding) {
            super(threadId);
            this.inputStream = inputStream;
            this.buffer = buffer;
            this.buffer2 = buffer2;
            this.threadId = threadId;
            this.encoding = encoding;

        }

        @SuppressWarnings("unused")
        public String getBuffer() {
            return buffer.toString();
        }

        @Override
        public void run() {
            try {
                readCommandOutput();
            } catch (final Exception ex) {

                logger.error(ex);
            }
        }

        private void readCommandOutput() throws IOException {
            BufferedReader bufOut = null;
            try {
                bufOut = new BufferedReader(new InputStreamReader(inputStream, encoding));

                String line = null;
                // CHECKSTYLE:OFF
                while ((stopRead == false) && ((line = bufOut.readLine()) != null)) {
                    // CHECKSTYLE:ON
                    buffer.append(line + NEW_LINE);
                    buffer2.append(line + NEW_LINE);
                }
            } finally {

                if (bufOut != null) {
                    bufOut.close();
                }
                if (logger.isTraceEnabled()) {
                    logger.trace("END OF: " + threadId);
                }
            }
        }

        public void stopReading() {
            stopRead = true;
        }

    }

}
