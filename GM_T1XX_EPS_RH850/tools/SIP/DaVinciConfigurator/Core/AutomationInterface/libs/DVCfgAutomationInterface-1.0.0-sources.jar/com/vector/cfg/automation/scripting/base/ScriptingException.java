package com.vector.cfg.automation.scripting.base;

import static com.google.common.base.Preconditions.checkNotNull;
import static java.util.stream.Collectors.toList;

import java.lang.reflect.UndeclaredThrowableException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.services.IScriptExecutionPathProvider;
import com.vector.cfg.automation.scripting.base.services.ScriptStackframes;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.collections.MultimapCollector;
import com.vector.cfg.util.exceptions.IHasCreationStackframe;
import com.vector.cfg.util.exceptions.StackframeProvider;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.exception.ExceptionMessageUtil;
import com.vector.cfg.util.text.exception.IExceptionAggregatesCauseChainInUserMessage;
import com.vector.cfg.util.text.log.IUserMessage;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * {@link ScriptingException} is the base type of all exceptions thrown by an {@link IScriptTask} execution. The
 * {@link IScriptTask#call(com.vector.cfg.util.servicecontext.IServiceContext, Object...)} method will throw a subclass of {@link ScriptingException} to indicate failure of the
 * execution.
 *
 * <p>
 * Every thrown exception from the script task client code is wrapped into an instance of {@link ScriptingException}, before handed to the caller.
 * </p>
 *
 * <p>
 * The exception provides information of the:
 * <ul>
 * <li>Where</li>
 * <li>Stackframe</li>
 * <li>What went wrong</li>
 * <li>Which script</li>
 * <li>What script file</li>
 * </ul>
 * </p>
 *
 * <p>
 * A client code should use subtypes of <code>ScriptClientExecutionException</code> to implement own exception types with the same behavior, instead of subclassing the class
 * directly.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public abstract class ScriptingException extends RuntimeException implements IDebugable, IExceptionAggregatesCauseChainInUserMessage {
    private static final long serialVersionUID = -3650747009786491426L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ScriptingException.class);

    private static final String WHERE = "* Where:";

    private static final Object STACKFRAMES = "* Stackframes:";

    private static final Object TASK_CREATION_STACKFRAMES = "* Task creation stackframe:";

    private static final String NL = System.lineSeparator();

    private static final String TAB = "  ";

    private final IScriptExecutionContext scriptExecutionContext;

    private final boolean stacktraceContainsClientScriptFrames;

    private String message;

    private static IScriptExecutionContext getCurrentExecutingScript() {
        return ScriptExecutionContexts.getCurrentContextOfThisThreadChecked();
    }

    /**
     * Marker interface that the exception is a {@link ScriptingException}, which was issued by the client code.
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    @PublishedApiDomain(DomainType.AUTOMATION_IF)
    public interface IScriptingClientExecutionException {
        @PublishedMethod
        Optional<Integer> getConsoleReturnCode();
    }

    /**
     * Returns the newline used in the message.
     *
     * @return the newline
     */
    @PublishedMethod
    protected static String nlStr() {
        return NL;
    }

    /**
     * Returns the tab space used in the message.
     *
     * @return the tag
     */
    @PublishedMethod
    protected static String tabStr() {
        return TAB;
    }

    /**
     * Returns the where string used in the message.
     *
     * @return the where string
     */
    @PublishedMethod
    protected static String whereStr() {
        return WHERE;
    }

    /**
     * Instantiates a new scripting exception.
     *
     * @param message the message
     * @param cause the cause
     */
    @PublishedMethod
    protected ScriptingException(String message, Throwable cause) {
        this(getCurrentExecutingScript(), false, message, cause);

    }

    /**
     * Instantiates a new scripting exception.
     *
     * @param message the message
     */
    @PublishedMethod
    protected ScriptingException(String message) {
        this(getCurrentExecutingScript(), false, message, null);
    }

    /**
     * Instantiates a new scripting exception.
     *
     * @param scriptExecutionContext the script execution context
     * @param message the message
     */
    @PublishedMethod
    protected ScriptingException(IScriptExecutionContext scriptExecutionContext, String message) {
        this(scriptExecutionContext, true, message, null);
    }

    /**
     * Instantiates a new scripting exception.
     *
     * @param scriptExecutionContext the script execution context
     * @param message the message
     * @param cause the cause
     */
    @PublishedMethod
    protected ScriptingException(IScriptExecutionContext scriptExecutionContext, String message, Throwable cause) {
        this(scriptExecutionContext, true, message, cause);

    }

    private ScriptingException(IScriptExecutionContext scriptExecutionContext, boolean ctxPassedFromClient, String message, Throwable cause) {
        super(message, cause);
        this.scriptExecutionContext = checkNotNull(scriptExecutionContext);

        this.stacktraceContainsClientScriptFrames = calcIfStacktraceContainsClientCode(ctxPassedFromClient);
    }

    private boolean calcIfStacktraceContainsClientCode(boolean ctxPassedFromClient) {
        if (!ctxPassedFromClient) {
            return true;
        }
        boolean stacktraceContainsScriptFramesLoc = true;
        if (ctxPassedFromClient) {
            final Optional<IScriptExecutionContext> currentContextOfThisThread = ScriptExecutionContexts.getCurrentContextOfThisThread();
            if (!currentContextOfThisThread.isPresent() || currentContextOfThisThread.get() != this.scriptExecutionContext) {
                stacktraceContainsScriptFramesLoc = false;
            }
        }
        return stacktraceContainsScriptFramesLoc;
    }

    /**
     * Returns the {@link IScriptExecutionContext}, which was active when the {@link ScriptingException} happend.
     *
     * @return the executed script context
     */
    @PublishedMethod
    public IScriptExecutionContext getExecutedScriptContext() {
        return scriptExecutionContext;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getMessage() {
        if (message != null) {
            return message;
        }
        final StringBuilder builder = new StringBuilder();
        buildMessage(builder);
        message = builder.toString();
        return message;
    }

    /**
     * Returns the content of the What went wrong message without the surronding text.
     *
     * @return the what went wrong
     */
    @PublishedMethod
    public String getWhatWentWrong() {
        return buildWhatWentWrongContent().toString();
    }

    String getOriginalMessage() {
        return super.getMessage();
    }

    /**
     * Builds the message, when the {@link #getMessage()} was called.
     *
     * @param builder the builder
     */
    @PublishedMethod
    protected void buildMessage(StringBuilder builder) {
        buildMessageHeader(builder);
        buildWhereClause(builder);
        buildWhatWentWrong(builder);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IMixedText getUserMessage() {
        return MixedText.fromConstantString(getMessage());
    }

    /**
     * Builds the message header.
     *
     * @param builder the builder
     */
    @PublishedMethod
    protected void buildMessageHeader(StringBuilder builder) {
        builder.append("Execution of script task \"");
        builder.append(scriptExecutionContext.getScriptTask().getQualifiedName());
        builder.append("\" failed with exception.");
        builder.append(NL);
    }

    void buildWhereClause(StringBuilder builder) {
        final int entrySize = builder.length();
        final Set<StackTraceElement> foundStackFrames = Sets.newHashSet();
        buildWhereByStackFrames(builder, this, foundStackFrames, true, false);

        final boolean hadAlreadyFileInformation = !foundStackFrames.isEmpty();
        foundStackFrames.clear();
        buildWhereByStackFrames(builder, this, foundStackFrames, false, hadAlreadyFileInformation);

        if (foundStackFrames.isEmpty()) {
            if (!buildWhereFromCompileException(builder)) {

                buildWhereFromTaskCreationStackframe(builder);
            }
        }

        final List<Path> scriptFiles = buildScriptFilesInWhereClause(builder, foundStackFrames);
        buildRootScriptFileInWhereClause(builder, scriptFiles);

        if (entrySize < builder.length()) {
            builder.append(NL);
            builder.append(NL);
        }
    }

    private void buildWhereFromTaskCreationStackframe(StringBuilder builder) {

        final IScriptTask scriptTask = getExecutedScriptContext().getScriptTask();
        if (scriptTask instanceof IHasCreationStackframe) {
            final IHasCreationStackframe stackFrameProvider = (IHasCreationStackframe) scriptTask;
            final Optional<String> stackframe = stackFrameProvider.getCreationStackframe();
            if (stackframe.isPresent()) {
                builder.append(NL);
                builder.append(WHERE);
                builder.append(NL);
                builder.append(TASK_CREATION_STACKFRAMES);
                builder.append(NL);
                builder.append(TAB);
                builder.append(stackframe.get());
            }

        }
    }

    private List<Path> buildScriptFilesInWhereClause(StringBuilder builder, Set<StackTraceElement> foundStackFrames) {
        if (!(scriptExecutionContext instanceof IScriptExecutionPathProvider)) {
            return ImmutableList.of();
        }
        final List<Path> scriptPathsUsedDuringExecution = ((IScriptExecutionPathProvider) scriptExecutionContext).getScriptPathsUsedDuringExecution();

        //Collect all Files  by FileName
        final Multimap<String, Path> existingPaths = scriptPathsUsedDuringExecution
                .stream()
                .filter(x -> Files.isRegularFile(x))
                .collect(MultimapCollector.toMultimap(x -> x.getFileName().toString(), Function.identity()));

        //Find Files matching filename and add found elements to the list
        final List<Path> foundFilesInTrace = foundStackFrames
                .stream()
                .filter(x -> x.getFileName() != null)
                .map(x -> existingPaths.get(x.getFileName()))
                .filter(x -> x != null)
                .flatMap(t -> t.stream())
                .map(Path::toAbsolutePath)
                .distinct()
                .sorted()
                .collect(toList());

        if (!foundFilesInTrace.isEmpty()) {
            builder.append(NL);
            builder.append("* File");
            if (foundFilesInTrace.size() > 1) {
                builder.append("s");
            }
            builder.append(":");
            foundFilesInTrace.forEach(x -> {
                builder.append(NL);
                builder.append(TAB);
                builder.append(x.toString());
            });
        }
        return foundFilesInTrace;
    }

    private void buildRootScriptFileInWhereClause(StringBuilder builder, List<Path> scriptFiles) {
        final IScript script = scriptExecutionContext.getScript();
        final Path path = script.getScriptPath().toPath().toAbsolutePath();
        if (scriptFiles.size() == 1 && scriptFiles.contains(path)) {
            // If the only script is already the root script, do not print the root.
            return;
        }
        builder.append(NL);
        if (Files.isDirectory(path)) {
            builder.append("* Script project folder:");
        } else if (path.toString().endsWith(".jar")) {
            builder.append("* Script project file:");
        } else {
            builder.append("* Task script file:");
        }
        builder.append(NL);
        builder.append(TAB);
        builder.append(path.toString());
    }

    private void buildWhereByStackFrames(StringBuilder builder, Throwable ex, Set<StackTraceElement> alreadyAddedFrames, boolean onlyDisplayFileInformation,
            boolean hadAlreadyFileInformation) {
        if (ex == null) {
            return;
        }
        buildWhereByStackFrames(builder, ex.getCause(), alreadyAddedFrames, onlyDisplayFileInformation, hadAlreadyFileInformation);

        if (ex instanceof ScriptingException) {
            final ScriptingException scriptingEx = (ScriptingException) ex;
            if (scriptingEx.getExecutedScriptContext() == this.getExecutedScriptContext()) {
                if (!scriptingEx.stacktraceContainsClientScriptFrames) {
                    return;
                }
            }
        }

        final StackTraceElement s = ScriptStackframes.DEFAULT.get(ex);
        if (s != null && s != StackframeProvider.NO_STACKFRAME) {
            if (!alreadyAddedFrames.contains(s)) {

                if (onlyDisplayFileInformation) {
                    if (s.getFileName() == null || s.getLineNumber() <= 0) {
                        //No File information so skip frame, because we shall only print line information
                        return;
                    }
                }

                if (alreadyAddedFrames.isEmpty()) {
                    if (!hadAlreadyFileInformation) {
                        builder.append(NL);
                        builder.append(WHERE);
                    } else {
                        builder.append(NL);
                        builder.append(STACKFRAMES);
                    }
                }
                builder.append(NL);
                builder.append(TAB);
                if (onlyDisplayFileInformation) {
                    builder.append(s.getFileName());
                    builder.append(":");
                    builder.append(s.getLineNumber());
                } else {
                    builder.append(s);
                }

                alreadyAddedFrames.add(s);
            }
        }
    }

    /**
     * Builds the where part from compile errors, if present. Otherwise empty.
     *
     * @param builder the builder
     * @return <code>true</code>, if a compile error was present and inserted
     */
    @PublishedMethod
    protected boolean buildWhereFromCompileException(StringBuilder builder) {
        return false;
    }

    /**
     * Builds the what went wrong part.
     *
     * @param builder the builder
     */
    @PublishedMethod
    protected final void buildWhatWentWrong(StringBuilder builder) {
        final StringBuilder builderInner = buildWhatWentWrongContent();
        builder.append("* What went wrong:");
        builder.append(NL);
        builder.append("> ");
        builder.append(builderInner.toString().trim().replaceAll("[\r]?\n", "\r\n> "));
    }

  
    private StringBuilder buildWhatWentWrongContent() {
        final StringBuilder builderInner = new StringBuilder();
        final String msg = getMessageOrClassName();
        builderInner.append(msg.trim());
        buildWhatWentWrongInternal(builderInner, getCause());
        return builderInner;
    }

    private void buildWhatWentWrongInternal(StringBuilder builder, Throwable cause) {
        if (cause == null) {
            return;
        }
        final String causeName = cause.getClass().getName();
        String causeMsg = ExceptionMessageUtil.getMessageOrUserMessageOfException(cause);

        if (cause instanceof UndeclaredThrowableException) {
            //Ignore the UndeclaredThrowableException It is only a wrapper
            causeMsg = null;
        }

        if (causeMsg != null) {
            final String msg = builder.toString();
            if (msg.contains(causeMsg)) {
                //Already text appended to stop the cause evaluation
                return;
            }

            //Append the cause to the msg
            builder.append(NL);
            if (!causeMsg.equals(causeName) && !isKnownException(cause)) {
                builder.append(cause.getClass().getName());
                builder.append(": ");
            }
            builder.append(causeMsg);

        }
        if (!(cause instanceof IExceptionAggregatesCauseChainInUserMessage)) {
            buildWhatWentWrongInternal(builder, cause.getCause());
        }
    }

    /**
     * Returns <code>true</code>, if the passed {@link Throwable} is of a known type, with a meaningful message. Then the message without the exception type is appended.
     * Otherwise the exception type is also appended.
     *
     * @param cause the cause
     * @return true, if is known exception
     */
    @PublishedMethod
    protected boolean isKnownException(Throwable cause) {
        if (cause instanceof ScriptingException) {
            return true;
        }
        if (cause instanceof IUserMessage) {
            return true;
        }
        return false;
    }

    private String getMessageOrClassName() {
        final String fullname = getClass().getName();
        final String messageLoc = getOriginalMessage();
        return (messageLoc != null) ? messageLoc : fullname;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        return getMessage();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toDebugString() {
        return ExceptionMessageUtil.toDebugStringForException(this);
    }

}
