package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelException;
import com.vector.cfg.model.exceptions.ModelException;

/**
 * Interface for optional model objects.
 *
 * <p>
 * You can test a request before it will throw an exception, if the modelObject exists.
 * </p>
 * <p>
 * This mechanism shall provide a compile time check for optional objects. The user must explicitly write an additional {@link GIOptional#get()} to see that this is optional.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
//CHECKSTYLE:OFF Class Naming problem
public interface GIOptional<T extends GIModelObject> extends Iterable<T> {
    // CHECKSTYLE:ON
    /**
     * Returns true, if the optional object exists, otherwise false.
     *
     * @return true, if the element exists.
     */
    @PublishedMethod
    boolean exists();

    /**
     * Returns true, if the optional object exists, otherwise false.
     *
     * @return true, if the element exists.
     */
    @PublishedMethod
    boolean isPresent();

    /**
     * Gets the the optional object.
     *
     * @return the optional object.
     *
     * @exception BswmdModelException
     * <ul>
     * <li>If the exists() method returns false.</li>
     * </ul>
     * @exception ModelException
     * <ul>
     * <li>If the exists() method returns false, and the request was a Mca request instead of a BswmdModel request.</li>
     * </ul>
     */
    @PublishedMethod
    T get();

    /**
     * Returns the contained instance if it is present; {@code defaultValue} otherwise.
     *
     * <p>
     * If no default value should be required because the instance is known to be present, use {@link #get()} instead. <br>
     * For a default value of {@code null}, use {@link #orNull}.
     * </p>
     */
    @PublishedMethod
    T or(T defaultValue);

    /**
     * Returns this {@code GIOptional} if it has a value present; {@code secondChoice} otherwise.
     */
    @PublishedMethod
    GIOptional<T> or(GIOptional<? extends T> secondChoice);

    /**
     * Returns this {@code Optional} if it has a value present; {@code secondChoice} otherwise.
     */
    @PublishedMethod
    Optional<T> or(Optional<? extends T> secondChoice);

    /**
     * Returns the contained instance if it is present; {@code null} otherwise. If the instance is known to be present, use {@link #get()} instead.
     */
    @PublishedMethod
    @Nullable
    T orNull();

}
