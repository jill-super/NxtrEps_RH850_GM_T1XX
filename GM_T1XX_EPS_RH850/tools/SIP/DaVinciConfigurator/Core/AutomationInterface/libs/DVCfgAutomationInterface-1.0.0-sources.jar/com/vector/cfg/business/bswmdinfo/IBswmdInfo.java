package com.vector.cfg.business.bswmdinfo;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBswImplementation;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.util.version.IVersion;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * This interface gives information on exactly one module definition
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IBswmdInfo {
    /**
     * This method returns an IVersion of the Vector BSWMD version if the version is available, otherwise null.
     * */
    @PublishedMethod
    IVersion getBswmdVersion();

    /**
     * This method returns an IVersion if the version is available, otherwise null.
     * */
    @PublishedMethod
    IVersion getBswImplementationArVersion();

    /**
     * This method returns an IVersion if the version is available, otherwise null.
     * */
    @PublishedMethod
    IVersion getSchemaVersion();

    /**
     * This method returns the module definition.
     * */
    @PublishedMethod
    MIModuleDef getModuleDef();

    /**
     * This method returns the associated BswImplementation, otherwise null.
     * */
    @PublishedMethod
    MIBswImplementation getBswImplementation();
}
