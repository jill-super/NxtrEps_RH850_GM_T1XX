package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.eclipse.osgi.service.resolver.VersionRange;
import org.osgi.framework.Version;

/**
 * PublishedApiVersionInfo is used to verify a consistent version numbering of the {@link PublishedApi} classes.
 * 
 * <p>
 * To you the Version Info you have to annotate two fields in one class which shall specify the {@link Version} and the {@link VersionRange}. The class with the annotated field
 * shall be a {@link PublishedApi} (If the class should not be exported choose {@link ChangePolicy#CLASS_DEPENDENCY}).
 * </p>
 * 
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.CLASS)
@Target(ElementType.FIELD)
public @interface PublishedApiVersionInfo {

    /**
     * Domain type specifies the version of the specific {@link DomainType} like {@link DomainType#GENERATORS}.
     * 
     * There can be one VersionInfo for each {@link DomainType} in the system.
     * 
     * @return the domain type
     */
    @PublishedMethod
    DomainType domainType();

    /**
     * Version type specified if the annotated field is a {@link VersionType#VERSION} or a {@link VersionType#VERSION_RANGE}.
     * 
     * <p>
     * Attention: You always need both fields in the same class!
     * </p>
     * 
     * @return the version type
     */
    @PublishedMethod
    VersionType versionType();
}
