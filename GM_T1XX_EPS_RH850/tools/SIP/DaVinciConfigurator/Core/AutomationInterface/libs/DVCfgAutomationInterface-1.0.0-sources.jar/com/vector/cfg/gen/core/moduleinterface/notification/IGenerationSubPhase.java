package com.vector.cfg.gen.core.moduleinterface.notification;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.gen.core.moduleinterface.calculation.ICalculator;

/**
 * {@link IGenerationSubPhase} is a interface for {@link ICalculator} subphases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public interface IGenerationSubPhase {

    /**
     * Gets the name.
     *
     * @return the name
     */
    String getName();

}
