package com.vector.cfg.gen.core.moduleinterface.auxiliary;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.model.access.DefRef;

/**
 * The interface is a marker that disables the ModuleDefinition check of the {@link IGeneratorPackage} in the GenCore. This means for a generator implementing
 * this interface, the GenCore will not perform any ModuleDefinition checks.
 *
 * <p>
 * So the generator may not have a ModuleDefintion for the {@link DefRef}, but the generator should be called although it has no valid definition.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IRequiresNoModuleDefinitionGeneratorPackage extends IGeneratorPackage {

}
