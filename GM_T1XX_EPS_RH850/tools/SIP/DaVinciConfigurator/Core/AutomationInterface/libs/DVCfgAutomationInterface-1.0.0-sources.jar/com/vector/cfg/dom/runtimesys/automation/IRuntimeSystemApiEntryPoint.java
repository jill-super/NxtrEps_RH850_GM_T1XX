package com.vector.cfg.dom.runtimesys.automation;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IRuntimeSystemApiEntryPoint {

    @PublishedMethod
    IRuntimeSystemApi getRuntimeSystemApi();

    @PublishedMethod
    <T> T runtimeSystem(@Nonnull @VDelegatesToWithClosureParam(IRuntimeSystemApi.class) Closure<T> code);

}
