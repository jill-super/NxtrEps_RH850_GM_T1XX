package com.vector.cfg.consistency.contribution.helper.validationresults;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SolvingActions;

/**
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Common">
 *
 * An {@link ISolvingActionGroup} is a token for solving actions of the same kind within different validation-results. E.g. if there are multiple filters and for each invalid
 * filter you have a validation-result with "open filter" and "delete filter" as SA. The "open filter" SAs of all filter problems can belong to one group and the "delete filter"
 * SAs to another. At most one solving-action of one result may be assigned to a particular group.
 * <p/>
 * The solving-action-group information is used to allow applying one solution to several results. It may also be used to identify a SA programmatically (automation client),
 * because assigned to a group, a SA has an ID in addition to the plain description text. It is also used by the Consistency to identify a solving action again after a
 * validation-result was replaced by a newer instance due to deduplication.
 * <p/>
 * The {@link ISolvingActionGroup} interface is typically implemented as an enum, otherwise it requires an appropriate equals/hashcode implementation or any other singleton
 * behavior. It is important to understand that a solving action group is just a token to which SAs can be assigned, it is not a collection data structure.
 * <p/>
 * </div>
 *
 * Example:
 *
 * <pre>
 * <code class="Java" id="Sample of a ISolvingActionGroup enum">
 * public enum ESolvingActionBaseValidators implements ISolvingActionGroup {
 *     RESET_TO_BASE_VALUE(1, "Reset to base value"),
 *     SOLVE_LOWER_MULTIPLICITY(2, "Solve lower multiplicity violation by creating elements"),
 *     DELETE_OBJECT_WITH_ERRONEOUS_DEFINITION(3, "Delete object with erroneous definition"),
 *     REMOVE_INVALID_PARAMETER_IF_LOWER_MULTIPLICITY_IS_ZERO(4, "Remove invalid parameter if lower multiplicity is zero"),
 *     SET_INVALID_PARAMETER_TO_DEFAULT_VALUE(5, "Set the invalid parameter to its default value"),
 *     SET_INVALID_PARAMETER_TO_MINIMUM_VALUE(6, "Set the invalid parameter to its minimum value"),
 *     SET_INVALID_PARAMETER_TO_MAXIMUM_VALUE(7, "Set the invalid parameter to its maximum value");
 *
 *     private final int id;
 *
 *     private final String description;
 *
 *     ESolvingActionGroupBaseValidators(int id, String description) {
 *         this.id = id;
 *         this.description = description;
 *     }
 *
 *     &#064;Override
 *     public String getSolvingActionDescription() {
 *         return description;
 *     }
 *
 *     &#064;Override
 *     public int getId() {
 *         return id;
 *     }
 * }
 * </code>
 * </pre>
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Common2"> A result builder has methods to assign a SA to a solving action group, or you can pass the
 * solving action group directly when adding the SA to the result builder.
 * <p/>
 * The solving action group assignment is not mandatory but recommended, due to the mentioned advantages for the user experience.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface ISolvingActionGroup {
    /**
     * @return a text that describes what these solving actions of the same kind do
     */
    @PublishedMethod
    String getSolvingActionDescription();

    /**
     * Return a positive integer that identifies this solving action group among other solving action groups of the same {@link IValidationResultId}. The maximal allowed value
     * for solving action groups from contributions is {@link SolvingActions#MAX_GROUP_ID}, higher values are reserved for core validators. Changing this Id will break
     * compatibility to automation clients.
     *
     * @return
     */
    @PublishedMethod
    int getId();
}
