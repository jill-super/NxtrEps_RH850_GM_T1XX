package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.annotation.concurrent.Immutable;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIOptional;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Optional BswmdModel object representation implementation.
 *
 * <p>
 * Attention: Please use {@link GIOptional} interface in client code.
 * </p>
 *
 * <p>
 * Note: the {@link GOptional} implements {@link Collection}, to provide Groovy GPath functionality for {@link GIOptional}s. So Groovy can call getProperty() on the Collection
 * and the navigation is transparent.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@Immutable
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GOptional<T extends GIModelObject> extends AbstractCollection<T> implements GIOptional<T> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GOptional.class);

    private final boolean exists;

    private final T result;

    private final Runnable executionToGenerateEx;

    /**
     * Instantiates a new {@link GOptional} object.
     *
     * @param exists the exists
     * @param result the result
     * @param executionToGenerateEx The passed runnable will throw the correct exception, when executed.
     */
    @PublishedMethod
    public GOptional(boolean exists, T result, Runnable executionToGenerateEx) {
        this.exists = exists;
        if (exists) {
            this.result = checkNotNull(result);
            this.executionToGenerateEx = null;
        } else {
            this.result = null;
            this.executionToGenerateEx = checkNotNull(executionToGenerateEx);
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean exists() {
        return exists;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean isPresent() {
        return exists();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public T get() {
        if (exists) {
            return result;
        } else {

            executionToGenerateEx.run();
            //Fail-Safe
            throw new IllegalStateException("Internal Class error. The call to executionToGenerateEx( ) must generate a BswmdModelException()");

        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public T or(T defaultValue) {
        if (exists()) {
            return get();
        }
        return defaultValue;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    public GIOptional<T> or(GIOptional<? extends T> secondChoice) {
        if (exists()) {
            return this;
        }
        return (GIOptional<T>) secondChoice;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    public Optional<T> or(Optional<? extends T> secondChoice) {
        if (exists()) {
            return Optional.of(get());
        }
        return (Optional<T>) secondChoice;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public T orNull() {
        if (exists()) {
            return get();
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Iterator<T> iterator() {
        List<T> l;
        if (exists()) {
            l = ImmutableList.of(get());
        } else {
            l = ImmutableList.of();
        }
        return l.iterator();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int size() {
        if (exists()) {
            return 1;
        }
        return 0;
    }

    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("GOptional [exists=");
        builder.append(exists);
        builder.append(", ");
        if (result != null) {
            builder.append("result=");
            builder.append(result);
        }
        builder.append("]");
        return builder.toString();
    }

}
