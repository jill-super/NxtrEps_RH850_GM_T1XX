/**
 * DaVinci Configurator application types like {@link com.vector.cfg.core.app.IApplicationContext}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.core.app;