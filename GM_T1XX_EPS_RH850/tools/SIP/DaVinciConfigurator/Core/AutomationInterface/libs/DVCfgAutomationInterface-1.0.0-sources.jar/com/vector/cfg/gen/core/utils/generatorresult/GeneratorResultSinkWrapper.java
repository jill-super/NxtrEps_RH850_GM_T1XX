package com.vector.cfg.gen.core.utils.generatorresult;

import static com.google.common.base.Preconditions.checkNotNull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.utils.frameworkinternal.AbstractGeneratorResultSink;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * This class is not intended to be used by the client!
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GeneratorResultSinkWrapper extends AbstractGeneratorResultSink {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GeneratorResultSinkWrapper.class);

    private final IValidationResultSink resultSink;

    /**
     * Constructor for GeneratorResultSinkWrapper.
     *
     * @param generatorPackage
     *
     * @param resultSink2
     */
    private GeneratorResultSinkWrapper(IGeneratorPackage generatorPackage, IValidationResultSink resultSink) {
        super(generatorPackage);
        this.resultSink = checkNotNull(resultSink);

    }

    private GeneratorResultSinkWrapper(IValidationResultSink resultSink) {
        super();
        this.resultSink = checkNotNull(resultSink);

    }

    @PublishedMethod
    public static IGeneratorResultSink wrap(IGeneratorPackage generatorPackage, IValidationResultSink resultSink) {
        if (resultSink instanceof IGeneratorResultSink) {
            return (IGeneratorResultSink) resultSink;
        }
        return new GeneratorResultSinkWrapper(generatorPackage, resultSink);

    }

    @PublishedMethod
    public static IGeneratorResultSink wrap(IValidationResultSink resultSink) {
        if (resultSink instanceof IGeneratorResultSink) {
            return (IGeneratorResultSink) resultSink;
        }
        return new GeneratorResultSinkWrapper(resultSink);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void reportValidationResultInternal(IValidationResult result) {
        resultSink.reportValidationResult(result);
    }

}
