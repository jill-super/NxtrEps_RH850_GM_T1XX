package com.vector.cfg.consistency.contribution.helper.solvingactions;

import static com.google.common.base.Preconditions.checkNotNull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.operations.IModelOperations;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * this class is an {@link ISolvingAction} that creates a parameter when executed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SACreateParameter implements ISolvingAction {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SACreateParameter.class);

    @PublishedField
    protected final MIContainer parent;

    @PublishedField
    protected final DefRef paramDef;

    private final IModelOperations modelOperations;

    private final String description;

    /**
     * Constructor for {@link SACreateParameter}.
     *
     * @param parent the parent container
     * @param paramDef the parameter DefRef
     */
    @PublishedMethod
    public SACreateParameter(MIContainer parent, DefRef paramDef) {
        this(parent, checkNotNull(paramDef), "Create Parameter " + paramDef.getLastShortname());

    }

    /**
     * Constructor for {@link SACreateParameter}.
     *
     * @param parent the parent container
     * @param paramDef the parameter DefRef
     * @param description override the description of the SA
     */
    @PublishedMethod
    public SACreateParameter(MIContainer parent, DefRef paramDef, String description) {

        this.parent = checkNotNull(parent);
        this.modelOperations = ModelUtil.getService(parent, IModelOperations.class);

        this.paramDef = checkNotNull(paramDef);

        this.description = checkNotNull(description);
        if (description.isEmpty()) {
            throw new IllegalArgumentException("The description is empty.");
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {

        modelOperations.createParameterByDefinition(parent, paramDef);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getDescription() {
        return description;
    }
}
