package com.vector.cfg.gen.core.utils.templateutils;

import static com.google.common.base.Preconditions.checkNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.gen.core.utils.formatting.primitives.StringGenElement;
import com.vector.cfg.gen.core.utils.generatorpackage.GeneratorPackageUtil;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.ModelCheckedAccessUtil;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaInvalidRequestException;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.references.McaReferenceWrongTypeException;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The SymbolicNameUtil class helps to generate SymbolicNameValues, according the the AUTOSAR Spec EcuConfiguration. <br/>
 * AS3: <ModuleDef>_<ContInstanceSN> <br/>
 * AS3: #define <ModuleDef>_<ContInstanceSN> (<Value>)<br/>
 *
 * AS4: <ModuleDef>Conf_<ContDefinitionSN>_<ContInstanceSN> <br/>
 * AS4: #define <ModuleDef>Conf_<ContDefinitionSN>_<ContInstanceSN> (<Value>) <br/>
 *
 * <p>
 * AUTOSAR-Requirement: [ecuc sws 2108]
 * </P>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class SymbolicNameUtil {
    private static final ILogger logger = Logger.INSTANCE.createLogger(SymbolicNameUtil.class);

    private SymbolicNameUtil() {

    }

    /**
     * The Version of the generated SymbolicNames.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    // @CHECKSTYLE:OFF Singleton and PublishedApi
    public static enum Version {
        // @CHECKSTYLE:ON
        AR3,
        AR4
    }

    /**
     * Returns a prefix containing the ModuleDefinition short name and an underscore. <MSN>_ E.g. Nvm_
     *
     * ecuc_sws_2108: The values of configuration parameters which are defined as symbolicNameValue = true shall be generated into the header file of the declaring module. The
     * symbol shall be the shortName of the container which holds the configuration parameter value prefixed with the module short name <MSN> of the declaring BSW Module
     * followed by an underscore.
     *
     * @param mdfObj MIObject which is used to locate the short name of the module definition.
     * @param genPackage GeneratorPackage to emit Validation Results
     * @return String
     *
     */
    @PublishedMethod
    public static String getSNVPrefix(MIObject mdfObj, IGeneratorPackage genPackage) {
        if (mdfObj == null) {
            throw new IllegalArgumentException("Argument MIObject must not be null.");
        }
        if (genPackage == null) {
            throw new IllegalArgumentException("Argument GeneratorPackage must not be null.");
        }
        final IModelAccess ma = genPackage.getProjectContext().getService(IModelAccess.class);

        final MIModuleDef moduleDefinition = ma.getModuleDefinition(mdfObj);
        if (moduleDefinition == null) {
            /*
             * Report ModuleDefinition of MDF Object not found
             */
            final GeneratorResultBuilder rb = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getDefinitionMissingForCEErrorId(genPackage),
                    "ModuleDefinition could not be resolved.");
            rb.addErrorObject(mdfObj);
            throw new ValidationFailedException(rb.buildResult());
        }
        return moduleDefinition.getName() + "_";
    }

    /**
     * Generates a SymbolicNameValue define of the passed reference value according to the passed AUTOSAR version.
     * <p>
     * Note: The value starts with #define<br />
     *
     * AUTOSAR3: &lt;ModuleDef>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : #define Com_PNC_02 (231)<br/>
     * <br/>
     * AUTOSAR4: &lt;ModuleDef>Conf_&lt;ContDefinitionSN>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : #define ComConf_ComSignal_PNC_02 (231)<br/>
     * </p>
     *
     * @param ref the SymbolicNameReference
     * @param version the SymbolicNameversion, which should be generated
     * @return The SymbolicNamedefine as {@link StringGenElement}.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if ref is null.</li>
     * <li>if version is null.</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if ref has no definition.</li>
     * </ul>
     * @exception McaInvalidRequestException
     * <ul>
     * <li>if there is no parameter which has the SymbolicNameValue flag set in its definition.</li>
     * </ul>
     * @exception McaParameterXXXException
     * <ul>
     * <li>if the request mca.parameter(xxx).asInt().getValue() has a failure.</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the passed ref is no SymbolicNameReference.</li>
     * </ul>
     */
    @PublishedMethod
    public static StringGenElement generateSymNameDefine(MIReferenceValue ref, Version version) {
        checkNotNull(ref, "ref is null");

        final MIContainer cont = ModelUtil.getService(ref, IModelCheckedAccess.class).reference(ref).asSymbolicNameRefToContainer().getRefTarget();

        return generateSymNameDefine(cont, version);
    }

    /**
     * Generates a SymbolicNameValue define of the passed {@link MIContainer} according to the passed AUTOSAR version.
     * <p>
     * Note: The value starts with #define<br />
     *
     * AUTOSAR3: &lt;ModuleDef>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : #define Com_PNC_02 (231)<br/>
     * <br/>
     * AUTOSAR4: &lt;ModuleDef>Conf_&lt;ContDefinitionSN>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : #define ComConf_ComSignal_PNC_02 (231)<br/>
     *
     * </p>
     *
     *
     * @param container the container
     * @param version AUTOSAR version according to which the SNV shall be constructed
     * @return The SymbolicNamedefine as {@link StringGenElement}.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if container is null.</li>
     * <li>if version is null.</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if container has no definition.</li>
     * </ul>
     * @exception McaInvalidRequestException
     * <ul>
     * <li>if there is no parameter which has the SymbolicNameValue flag set in its definition.</li>
     * </ul>
     * @exception McaParameterXXXException
     * <ul>
     * <li>if the request mca.parameter(xxx).asInt().getValue() has a failure.</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the passed ref is no SymbolicNameReference.</li>
     * </ul>
     */
    @PublishedMethod
    public static StringGenElement generateSymNameDefine(MIContainer container, Version version) {
        checkNotNull(container, "container is null");
        checkNotNull(version, "version is null");

        final StringBuilder builder = new StringBuilder();
        builder.append(GenConstants.C_DEFINE);
        builder.append(" ");

        generateSymName(builder, container, true, version);
        return F.formatString(builder.toString());

    }

    /**
     * Generates a SymbolicNameValue define for the passed {@link MIContainer}.Generates a SymbolicNameValue define for the passed {@link MIContainer}. <br/>
     * Returns Com_ComSignal_PNC_02 (231)
     *
     * @param builder
     * @param container
     * @param appendValue If true the value is appended "(231)"
     */
    private static void generateSymName(StringBuilder builder, MIContainer container, boolean appendValue, Version version) {
        final MIModuleConfiguration moduleConfig = getModuleConfig(container);
        final String moduleMsn = GeneratorPackageUtil.getMsn(moduleConfig);

        switch (version) {
        case AR3:
            generateSymNameManually(builder, container.getName(), null, moduleMsn, (appendValue) ? getSymbolicNameValue(container) : "",
                    version, appendValue);
            break;
        case AR4:
            final DefRef containerDefRef = DefRef.create(container);
            generateSymNameManually(builder, container.getName(), containerDefRef.getLastShortname(), moduleMsn, (appendValue) ? getSymbolicNameValue(container) : "", version,
                    appendValue);
            break;
        default:
            throw new IllegalArgumentException("The passed Version is not supported");
        }

    }

    /**
     * Returns the symbolic name value of the SymbolicNameParameter related to this container. <br/>
     * SymbolicNameParameter of type integer, enumeration or float are accepted.
     *
     * @param container
     * @return
     */
    private static String getSymbolicNameValue(MIContainer container) {
        final Object symbNameVal = ModelCheckedAccessUtil.getSymbolicNameValueGeneric(container);

        if (symbNameVal instanceof BigInteger) {
            return F.formatInt((BigInteger) symbNameVal).asDecimal().generate();
        } else if (symbNameVal instanceof String) {
            return (String) symbNameVal;
        } else if (symbNameVal instanceof BigDecimal) {
            return F.formatFloat((BigDecimal) symbNameVal).generate();
        }
        throw new IllegalArgumentException(
                "The method SymbolicNameUtil.getSymbolicNameValue(MIContainer) only supports SymbolicNameValues of type enum, int or float. The SymbolicNameValue of the passed container has an unsupported type");
    }

    private static MIModuleConfiguration getModuleConfig(MIContainer container) {
        return ModelUtil.getModelAccess(container).getModuleConfiguration(container);
    }

    /**
     * Generates a SymbolicNameValue of the passed {@link MIContainer} according to the passed AUTOSAR version.
     * <p>
     * AUTOSAR3: &lt;ModuleDef>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : Com_PNC_02 (231)<br/>
     * <br/>
     * AUTOSAR4: &lt;ModuleDef>Conf_&lt;ContDefinitionSN>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : ComConf_ComSignal_PNC_02 (231)<br/>
     * </p>
     *
     * @param container the container
     * @param version AUTOSAR version according to which the SNV shall be constructed
     * @return The SymbolicName as {@link StringGenElement}.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if container is null.</li>
     * <li>if version is null.</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if container has no definition.</li>
     * </ul>
     * @exception McaInvalidRequestException
     * <ul>
     * <li>if there is no parameter which has the SymbolicNameValue flag set in its definition.</li>
     * </ul>
     * @exception McaParameterXXXException
     * <ul>
     * <li>if the request mca.parameter(xxx).asInt().getValue() has a failure.</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the passed ref is no SymbolicNameReference.</li>
     * </ul>
     */
    @PublishedMethod
    public static StringGenElement generateSymName(MIContainer container, Version version) {
        checkNotNull(container, "container is null");
        checkNotNull(version, "version is null");

        final StringBuilder builder = new StringBuilder();
        generateSymName(builder, container, false, version);
        return F.formatString(builder.toString());

    }

    /**
     * Generates a SymbolicNameValue of the passed {@link GIContainer} according to the passed AUTOSAR version.
     * <p>
     * AUTOSAR3: &lt;ModuleDef>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : Com_PNC_02 (231)<br/>
     * <br/>
     * AUTOSAR4: &lt;ModuleDef>Conf_&lt;ContDefinitionSN>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : ComConf_ComSignal_PNC_02 (231)<br/>
     * </p>
     *
     * @param container the container
     * @param version the SymbolicNameversion, which should be generated
     * @return The SymbolicName as {@link StringGenElement}.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if container is null.</li>
     * <li>if version is null.</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if container has no definition.</li>
     * </ul>
     * @exception McaInvalidRequestException
     * <ul>
     * <li>if there is no parameter which has the SymbolicNameValue flag set in its definition.</li>
     * </ul>
     * @exception McaParameterXXXException
     * <ul>
     * <li>if the request mca.parameter(xxx).asInt().getValue() has a failure.</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the passed ref is no SymbolicNameReference.</li>
     * </ul>
     */
    @PublishedMethod
    public static StringGenElement generateSymName(GIContainer container, Version version) {
        checkNotNull(container, "container is null");
        checkNotNull(version, "version is null");
        try (IModelViewExecutionContext ctx = container.executeWithCreationModelView()) {
            final StringBuilder builder = new StringBuilder();
            generateSymName(builder, container.getMdfObject(), false, version);
            return F.formatString(builder.toString());
        }
    }

    /**
     * Generates a SymbolicNameValue of the passed reference value according to the passed AUTOSAR version.
     * <p>
     * AUTOSAR3: &lt;ModuleDef>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : Com_PNC_02 (231)<br/>
     * <br/>
     * AUTOSAR4: &lt;ModuleDef>Conf_&lt;ContDefinitionSN>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * Example : ComConf_ComSignal_PNC_02 (231)<br/>
     * </p>
     *
     * @param ref the SNV reference
     * @param version the SymbolicNameversion, which should be generated
     * @return The SymbolicName as {@link StringGenElement}.
     *
     * @exception NullPointerException
     * <ul>
     * <li>if container is null.</li>
     * <li>if version is null.</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if container has no definition.</li>
     * </ul>
     * @exception McaInvalidRequestException
     * <ul>
     * <li>if there is no parameter which has the SymbolicNameValue flag set in its definition.</li>
     * </ul>
     * @exception McaParameterXXXException
     * <ul>
     * <li>if the request mca.parameter(xxx).asInt().getValue() has a failure.</li>
     * </ul>
     * @exception McaReferenceWrongTypeException
     * <ul>
     * <li>if the passed ref is no SymbolicNameReference.</li>
     * </ul>
     */
    @PublishedMethod
    public static StringGenElement generateSymName(MIReferenceValue ref, Version version) {
        checkNotNull(ref, "ref is null");

        final MIContainer cont = ModelUtil.getService(ref, IModelCheckedAccess.class).reference(ref).asSymbolicNameRefToContainer().getRefTarget();

        return generateSymName(cont, version);
    }

    /**
     * It is strongly recommended <b>NOT</b> to use this method. Please use the other methods which does not take Strings directly. <br/>
     * This method does not check or correct case sensitive issues for the passed strings.<br/>
     * This method constructs a symbolic name value out of pure strings.<br/>
     * AS3: &lt;ModuleDef>_&lt;ContInstanceSN> <br/>
     * AS4: &lt;ModuleDef>Conf_&lt;ContDefinitionSN>_&lt;ContInstanceSN> <br/>
     *
     * @param containerInstanceShortName Instance name of the container which holds the symbolic name value.
     * @param containerDefinitionShortName Definition name of the container which holds the symbolic name value. In case of a CDD module make sure to pass the correct string!
     * (apiServicePrefix or module configuration shortname)
     * @param moduleDefinitionShortName Definition name of the Module which holds the symbolic name value.
     * @param version AUTOSAR version
     * @return
     */
    @PublishedMethod
    public static StringGenElement generateSymNameManually(String containerInstanceShortName, String containerDefinitionShortName, String moduleDefinitionShortName,
            Version version) {
        if ((containerDefinitionShortName == null)) {
            throw new IllegalArgumentException("generateSymNameManually(): passed shortname of containerDefinition must not be null or empty.");
        }
        if ((moduleDefinitionShortName == null) || (moduleDefinitionShortName.isEmpty())) {
            throw new IllegalArgumentException("generateSymNameManually(): passed shortname of module must not be null or empty.");
        }

        if ((version == null)) {
            throw new IllegalArgumentException("generateSymNameManually(): passed version must not be null.");
        }

        final StringBuilder builder = new StringBuilder();
        generateSymNameManually(builder, containerInstanceShortName, containerDefinitionShortName, moduleDefinitionShortName, null, version, false);
        return F.formatString(builder.toString());
    }

    /**
     * It is strongly recommended <b>NOT</b> to use this method. Please use the other methods which does not take Strings directly. <br/>
     * This method does not check or correct case sensitive issues for the passed strings.<br/>
     * This method constructs a define Tl428 statement for a symbolic name value out of pure strings.<br/>
     * AS3: #define &lt;ModuleDef>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * AS4: #define &lt;ModuleDef>Conf_&lt;ContDefinitionSN>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     *
     * @param containerInstanceShortName Instance name of the container which holds the symbolic name value.
     * @param containerDefinitionShortName Definition name of the container which holds the symbolic name value. In case of a CDD module make sure to pass the correct string!
     * (apiServicePrefix or moduleconfiguration shortname)
     * @param moduleShortName Definition name of the Module which holds the symbolic name value.
     * @param value Symbolic name value.
     * @param version AUTOSAR version
     * @return
     */
    @PublishedMethod
    public static StringGenElement generateSymNameDefineManually(String containerInstanceShortName, String containerDefinitionShortName, String moduleShortName, String value,
            Version version) {
        if ((containerDefinitionShortName == null) || (containerDefinitionShortName.isEmpty())) {
            throw new IllegalArgumentException("generateSymNameDefineManually(): passed shortname of containerDefinition must not be null or empty.");
        }
        if ((moduleShortName == null) || (moduleShortName.isEmpty())) {
            throw new IllegalArgumentException("generateSymNameDefineManually(): passed shortname of module must not be null or empty.");
        }

        if ((value == null)) {
            throw new IllegalArgumentException("generateSymNameDefineManually(): passed value must not be null.");
        }

        if ((version == null)) {
            throw new IllegalArgumentException("generateSymNameDefineManually(): passed version must not be null.");
        }

        final StringBuilder builder = new StringBuilder();
        builder.append(GenConstants.C_DEFINE);
        builder.append(" ");
        generateSymNameManually(builder, containerInstanceShortName, containerDefinitionShortName, moduleShortName, value, version, true);
        return F.formatString(builder.toString());
    }

    /**
     * Internal method to create the SNV with or without value from plain strings. The Result depends on the passed AS version.<br/>
     * AS3: &lt;ModuleDef>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     * AS4: &lt;ModuleDef>Conf_&lt;ContDefinitionSN>_&lt;ContInstanceSN> (&lt;Value>) <br/>
     *
     * @param builder Stringbuilder to append the result.
     * @param containerInstanceShortName Shortname of the container which contains the symbolic name parameter. (The concrete instance.)
     * @param containerDefinitionShortName Shortname of the container from the module definition which contains the symbolic name parameter. Is NULL for AS3. In case of a CDD
     * module make sure to pass the correct string! (apiServicePrefix or moduleconfiguration shortname)
     * @param moduleDefinitionShortName ModuleConfiguration which contains the symbolic name parameter.
     * @param value Value of the symbolic name param.
     * @param version AS Version.
     * @param appendValue Shall the value be appended?
     */
    private static void generateSymNameManually(StringBuilder builder, String containerInstanceShortName, String containerDefinitionShortName, String moduleDefinitionShortName,
            String value, Version version, boolean appendValue) {
        switch (version) {
        case AR3:
            builder.append(moduleDefinitionShortName);
            builder.append("_");

            builder.append(containerInstanceShortName);
            if (appendValue) {
                builder.append(" (");
                builder.append(value);
                builder.append(")");
            }
            break;
        case AR4:
            /*
             * Parameter is only relevant for AS4
             */
            if ((containerDefinitionShortName == null)) {
                throw new IllegalArgumentException("generateSymNameManually(): passed instance shortname of containerDefinition must not be null or empty in case of AUTOSAR 4.");
            }
            builder.append(moduleDefinitionShortName);
            builder.append("Conf_");
            builder.append(containerDefinitionShortName);
            builder.append("_");
            builder.append(containerInstanceShortName);
            if (appendValue) {
                builder.append(" (");
                builder.append(value);
                builder.append(")");
            }
            break;
        default:
            throw new IllegalArgumentException("The passed Version is not supported.");
        }

    }

}
