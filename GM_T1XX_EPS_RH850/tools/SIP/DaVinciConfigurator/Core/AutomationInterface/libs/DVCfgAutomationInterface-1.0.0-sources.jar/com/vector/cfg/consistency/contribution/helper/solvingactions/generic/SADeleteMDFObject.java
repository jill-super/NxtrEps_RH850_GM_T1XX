package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.operations.IModelOperations;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.FormatSpec;
import com.vector.cfg.util.text.mixedtext.IFormatSpec;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * SolvingAction for deleting an MIObject, e.g. a parameter or container.
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SADeleteMDFObject implements ISolvingAction {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SADeleteMDFObject.class);

    private final MIObject mdfObject;

    /**
     * Instantiates a new {@link SADeleteMDFObject}, which is an {@link ISolvingAction} that deletes the passed MDF object when excuteds.
     *
     * @param mdfObject the mdf object
     */
    @PublishedMethod
    public SADeleteMDFObject(MIObject mdfObject) {
        this.mdfObject = mdfObject;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {
        if (mdfObject != null && !ModelAccessUtil.isRemovedOrInvisible(mdfObject)) {
            final IModelOperations mo = ModelUtil.getService(mdfObject, IModelOperations.class);
            if (mdfObject instanceof MIModuleConfiguration) {
                mo.deleteModuleConfiguration((MIModuleConfiguration) mdfObject);
            } else {
                mo.deleteFromModel(mdfObject);
            }
        }
    }

    private static final IFormatSpec formatSpec = FormatSpec.getInternedFormatSpec(false, false);

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getDescription() {
        if (mdfObject != null && !ModelAccessUtil.isRemovedOrInvisible(mdfObject)) {
            String objectTypeName;
            if (mdfObject instanceof MIContainer) {
                objectTypeName = "container";
            } else if (mdfObject instanceof MIParameterValue) {
                objectTypeName = "parameter";
            } else if (mdfObject instanceof MIModuleConfiguration) {
                objectTypeName = "module";
            } else {
                objectTypeName = "object";
            }
            return MixedText.newBuilder().append("Delete").append(objectTypeName).append(mdfObject).flushResult().getFormattedText(formatSpec);
        } else {
            return "<Delete-solving-action for already deleted object>";
        }
    }
}
