package com.vector.cfg.gen.core.utils.formatting;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The base interface of listed GenElements (e.g. array, structs, lists), which support the generation of data with formating information.
 * <p>
 * Attention: This interface is not intended to be implemented by the user!
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IListGenElement {

    /**
     * Adds a header without a newline before the {@link IListGenElement} starts.<br />
     *
     * <p>
     * Subsequent calls to {@link #header(String)} are not permitted.
     * </p>
     *
     * @param header The comment
     * @return The GenElement
     *
     * @throws IllegalArgumentException
     * <ul>
     * <li>if header is null.</li>
     * </ul>
     *
     * @throws IllegalStateException
     * <ul>
     * <li>if the header was already set.</li>
     * </ul>
     *
     */
    @PublishedMethod
    IListGenElement header(String header);

    /**
     * Adds a footer without a newline after the {@link IListGenElement} ends.<br />
     *
     * <p>
     * Subsequent calls to {@link #footer(String)} are not permitted.
     * </p>
     *
     * @param footer The comment
     * @return The GenElement
     *
     * @throws IllegalArgumentException
     * <ul>
     * <li>if footer is null.</li>
     * </ul>
     *
     * @throws IllegalStateException
     * <ul>
     * <li>if the footer was already set.</li>
     * </ul>
     *
     */
    @PublishedMethod
    IListGenElement footer(String footer);
}
