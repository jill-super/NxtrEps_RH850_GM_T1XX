package com.vector.cfg.gen.core.moduleinterface.genservices;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IDeployablePackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageFactory;
import com.vector.cfg.gen.core.moduleinterface.genservices.exceptions.GenServiceContributionException;
import com.vector.cfg.gen.core.moduleinterface.pluginInterface.IPluginGeneratorPackageFactory;
import com.vector.cfg.util.IProjectContext;

/**
 * Every {@link IDeployablePackage} ( {@link IGeneratorPackage}, {@link IGeneratorPackageFactory}, or {@link IPluginGeneratorPackageFactory}) could implement
 * {@link IGenServiceContributor} to provide Generator specific services to the Configurator.
 *
 * <p>
 * The method {@link #createGenServicesForRegistry(IProjectContext, IGenServiceRegistry)} is called during the Load process of the {@link IGeneratorPackage}s.
 * </p>
 *
 * <p>
 * Attention: All registered Services must be <b>threadsafe</b>, because is it not guaranteed that the services are called from an certain thread!
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGenServiceContributor {

    /**
     * This method shall register the GenServices provided by the Generator.
     *
     * <p>
     * You can call {@link IGenServiceRegistry#addGenService(com.vector.cfg.model.access.DefRef, Object, Class, Class...)} to register a GenService.
     * </p>
     *
     * <p>
     * If the method throws a {@link GenServiceContributionException} the load of the corresponding generator is aborted.
     * </p>
     *
     * @param projectContext the current {@link IProjectContext}.
     * @param registry the registry to register GenServices.
     * @throws GenServiceContributionException If the any GenService could not be registered
     */
    @PublishedMethod
    void createGenServicesForRegistry(IProjectContext projectContext, IGenServiceRegistry registry) throws GenServiceContributionException;
}
