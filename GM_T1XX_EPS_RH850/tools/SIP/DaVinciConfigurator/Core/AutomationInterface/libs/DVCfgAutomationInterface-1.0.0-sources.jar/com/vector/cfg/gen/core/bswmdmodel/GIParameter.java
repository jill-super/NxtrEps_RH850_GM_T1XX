package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasIllegalValueException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelParameterHasNoValueException;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucParameterDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.state.IParameterStatePublished;

/**
 * Base interface of bswmd model parameter.
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see MIParameterValue
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
//CHECKSTYLE:OFF Class Naming problem
public interface GIParameter<VALUE> extends GIParamOrRef {
    // CHECKSTYLE:ON
    /**
     * Returns <code>true</code> if the parameter has a value.
     *
     * @return
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    boolean hasValue();

    /**
     * Returns the parameters value.
     *
     * @return The value object
     *
     * @exception BswmdModelParameterHasNoValueException
     * <ul>
     * <li>if the value of the parameter is null</li>
     * </ul>
     * @exception BswmdModelParameterHasIllegalValueException
     * <ul>
     * <li>if the value of the parameter is illegal</li>
     * </ul>
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    VALUE getValueMdf();

    /**
     * Returns the parameters value, or the parameter defaultValue, if the parameter does not exist or has no value.
     *
     * <p>
     * <code>null</code> as defaultValue is permitted!
     * </p>
     *
     * @return The value object, or the defaultValue.
     */
    @PublishedMethod
    VALUE getValueOrDefaultMdf(VALUE defaultValue);

    /**
     * Returns the value formatter object depending on the type.
     *
     * @return
     * @see F
     */
    @PublishedMethod
    IGenElement formatValue();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IParameterStatePublished getCeState();

    /**
     * Convenience method to set the value of the {@link GIParameter}.
     *
     * This method checks if the specified parameters definition object is available and sets the value only if its definition type is integer. If the parameter has no
     * definition the parameter is set in either case.
     *
     * @param newValue
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    void setValueMdf(VALUE newValue);

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucParameterDefinition getEcucDefinition();

}
