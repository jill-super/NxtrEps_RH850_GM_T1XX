package com.vector.cfg.gen.core.utils.generatorresult;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.helper.validationresults.ValidationResultSorter;
import com.vector.cfg.consistency.ui.IValidationResultUI;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GeneratorResultSorter {

    private GeneratorResultSorter() {

    }

    /**
     * Sort validation result list.
     *
     * @param list the list
     */
    @KeepSecretFromPublishedApi
    public static void sortValidationResultList(List<IValidationResultUI> list) {
        new ValidationResultSorter(null).sortValidationResultList(list);
    }

    /**
     * Sort validation result list.
     *
     * @param list the list
     */
    @PublishedMethod
    public static void sortValidationResultListContrib(List<IValidationResult> list) {
        new ValidationResultSorter(null).sortValidationResultListContrib(list);
    }
}
