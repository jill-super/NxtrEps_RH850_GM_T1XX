package com.vector.cfg.consistency.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.IValidationSeverityResultId;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.contribution.helper.validationresults.IValidationResultBuilder;
import com.vector.cfg.consistency.contribution.helper.validationresults.ValidationResultBuilder;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * The {@link IValidationResultCreationApi} provides methods to create new {@link IValidationResult} instances via the {@link IValidationResultBuilder} to add validation-results
 * e.g during generation.
 *
 * <div class="extdoc" id="Common"> The <code>resultCreation</code> API provides methods to create new {@link IValidationResult}s, which could then be reported to a
 * {@link IValidationResultSink}. This is can be used to report validation-results similar to a validator/generator, but from within a script task.
 *
 * <h5>ValidationResultSink</h5> The {@link IValidationResultSink} must be obtained by the context and is not provided by the creation API. E.g. some script tasks pass an
 * {@link IValidationResultSink} as argument (like DV_GENERATION_STEP). If you don't get a sink from the script task, you can not report any {@link IValidationResult}s.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IValidationResultCreationApi {

    /**
     * Creates an {@link IValidationResultId} with the passed id, severity and the script task name as origin.
     *
     *
     * @param id the id
     * @param message the summary message of the result id
     * @param severity severity
     * @return the result id
     */
    @PublishedMethod
    IValidationSeverityResultId createValidationResultIdForScriptTask(int id, String message, EValidationSeverityType severity);

    /**
     * Creates an {@link IValidationResultId} with the passed id and the script task name as origin.
     *
     * @param id the id
     * @param message the summary message of the result id
     * @return the result id
     */
    @PublishedMethod
    IValidationResultId createValidationResultIdForScriptTask(int id, String message);

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * <p>
     * The descriptionPattern parameter is a {@link MixedText} pattern.<br />
     * See {@link MixedText#format(String, Object...)} with the parameters descriptionPattern and patternArguments for more details.
     * </p>
     *
     * @param resultId The IValidationResultId of the {@link IValidationResult}
     * @param severityType The Severity of the result
     * @param formatPattern The description pattern for {@link IMixedTextBuilder#appendFormat(String, Object...)}
     * @param patternArguments The arguments for the descriptionPattern
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * <li>if formatPattern is null</li>
     * <li>if patternArguments is null</li>
     * </ul>
     */
    @PublishedMethod
    ValidationResultBuilder newResultBuilder(IValidationResultId resultId, EValidationSeverityType severityType, String formatPattern, Object... patternArguments);

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * <p>
     * The descriptionPattern parameter is a {@link MixedText} pattern.<br />
     * See {@link MixedText#format(String, Object...)} with the parameters descriptionPattern and patternArguments for more details.
     * </p>
     *
     * @param resultId The IValidationSeverityResultId of the {@link IValidationResult}
     * @param formatPattern The description pattern for {@link IMixedTextBuilder#appendFormat(String, Object...)}
     * @param patternArguments The arguments for the descriptionPattern
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     * @see IMixedTextBuilder
     * @see IMixedText
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if formatPattern is null</li>
     * <li>if patternArguments is null</li>
     * </ul>
     */
    @PublishedMethod
    ValidationResultBuilder newResultBuilder(IValidationSeverityResultId resultId, String formatPattern, Object... patternArguments);

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     * @param resultId The IValidationSeverityResultId of the {@link IValidationResult}
     * @param description The detailed description text of the result
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    ValidationResultBuilder newResultBuilder(IValidationSeverityResultId resultId, String description);

    /**
     * Creates a new {@link ValidationResultBuilder} object, which can be used to build an {@link IValidationResult}.
     *
     *
     * @param resultId The IValidationResultId of the {@link IValidationResult}
     * @param severityType The Severity of the result
     * @param description The description
     * @return A new builder
     *
     * @see ValidationResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    ValidationResultBuilder newResultBuilder(IValidationResultId resultId, EValidationSeverityType severityType, String description);
}
