package com.vector.cfg.model.access;

import static com.google.common.base.Preconditions.checkNotNull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class TypedAsrPath<METACLASS_TYPE extends MIReferrable> extends AsrPath implements IDebugable {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(TypedAsrPath.class);

    private final Class<METACLASS_TYPE> metaModelClass;

    TypedAsrPath(final AsrPath parentAsrPath, final String childPathString, final Class<METACLASS_TYPE> metaModelClass) {
        super(parentAsrPath, childPathString);

        if (metaModelClass == null) {
            throw new IllegalArgumentException("metaModelClass is null.");
        }

        this.metaModelClass = metaModelClass;

    }

    TypedAsrPath(final String pathString, final Class<METACLASS_TYPE> metaModelClass) {
        super(pathString);

        if (metaModelClass == null) {
            throw new IllegalArgumentException("metaModelClass is null.");
        }

        this.metaModelClass = metaModelClass;

    }

    TypedAsrPath(final AsrPath asrPath, final Class<METACLASS_TYPE> metaModelClass) {
        this(checkNotNull(asrPath).getAutosarPathString(), metaModelClass);
    }

    /**
     * Returns the MetaModelClass object of the AUTOSAR element.
     *
     * @return the MetaModel class object.
     */
    @PublishedMethod
    public Class<METACLASS_TYPE> getMetaModelClass() {
        return metaModelClass;
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject.
     *
     *
     * <p>
     * Note: This method is an implicit null and modelObjectClass class check. This means, if it returns true, the modelObject is an instance of modelObjectClass.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>true</code>, if this is the definition of the modelObject and it is instance of modelObjectClass.
     *
     */
    @PublishedMethod
    @Override
    public boolean isPathOf(final MIObject modelObject) {
        return super.isPathOfInternal(modelObject, metaModelClass);
    }

    /**
     * <p>
     * DO NOT use this method! Use {@link #isPathOf(MIObject)} instead, because a {@link TypedAsrPath} already provides the type information.
     * </p>
     *
     * {@inheritDoc}
     *
     */
    @PublishedMethod
    @Deprecated
    @Override
    public <R extends MIReferrable> boolean isPathOf(final MIObject modelObject, final Class<R> classToCheck) {
        return super.isPathOfInternal(modelObject, classToCheck);
    }

    /**
     * <p>
     * DO NOT use this method! Use {@link #asPathOf(MIObject)} instead, because a {@link TypedAsrPath} already provides the type information.
     * </p>
     * {@inheritDoc}
     */
    @PublishedMethod
    @Deprecated
    @Override
    public <R extends MIReferrable> R asPathOf(final MIObject modelObject, final Class<R> classToCheck) {
        return super.asPathOfInternal(modelObject, classToCheck);
    }

    /**
     * Checks if <code>this</code> object is the AUTOSAR path of the passed modelObject and an instance of modelObjectClass. If the check is true, the method returns the object
     * casted to modelObjectClass. Otherwise the method return <code>null</code>.
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>object</code>, if this is the AUTOSAR path of the modelObject and it is instance of modelObjectClass. Otherwise null.
     * @see #isDefinitionOf(MIObject)
     *
     */
    @PublishedMethod
    public METACLASS_TYPE asPathOf(final MIObject modelObject) {
        return super.asPathOfInternal(modelObject, metaModelClass);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toDebugString() {

        final StringBuilder builder = new StringBuilder();

        builder.append(super.toString());

        builder.append("(MetaClass: ");
        builder.append(metaModelClass.getSimpleName());
        builder.append(")");

        return builder.toString();
    }

}
