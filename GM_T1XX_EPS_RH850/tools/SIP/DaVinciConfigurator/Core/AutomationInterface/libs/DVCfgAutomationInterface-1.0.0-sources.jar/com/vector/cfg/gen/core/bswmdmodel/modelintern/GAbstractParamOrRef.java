package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import static com.google.common.base.Preconditions.checkNotNull;

import java.math.BigInteger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIParamOrRef;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.access.ecucdefinition.IEcucDefinitionAccess;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The abstract base class for bswmd model parameters or references.
 *
 * <p>
 * Attention: Do not use this class in Client Code! Use {@link GIParameter} of {@link GIReference} instead.
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSSTYLE:OFF
public abstract class GAbstractParamOrRef extends GAbstractModelObject implements GIParamOrRef {
    // CHECKSSTYLE:ON
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GAbstractParamOrRef.class);

    private final DefRef defRef;

    @Nullable
    private final MIParameterValue parameter;

    private final GIContainer parent;

    @Nullable
    private final MIConfigParameter definitionObj;

    private final boolean onlyOneElement;

    private boolean mdfObjectAlreadyChecked;

    private boolean valueAlreadyChecked;

    /**
     * Constructor.
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GAbstractParamOrRef(@Nonnull DefRef defRef, @Nullable MIParameterValue parameter, @Nonnull IInternalGeneratorModelAccess generatorModelAccess, GIContainer parent,
            boolean onlyOneElement) {
        super(generatorModelAccess, parameter);
        this.defRef = checkNotNull(defRef);
        this.parameter = parameter;
        this.parent = checkNotNull(parent);
        this.onlyOneElement = onlyOneElement;

        this.definitionObj = getDefObjInit(parameter, defRef, generatorModelAccess);
    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public GAbstractParamOrRef(@Nonnull IInternalGeneratorModelAccess generatorModelAccess, @Nonnull DefRef defRef, @Nullable MIParameterValue parameter, GIContainer parent,
            boolean onlyOneElement) {
        super(generatorModelAccess, defRef, parameter);
        this.defRef = checkNotNull(defRef);
        this.parameter = parameter;
        this.parent = checkNotNull(parent);
        this.onlyOneElement = onlyOneElement;

        this.definitionObj = getDefObjInit(parameter, defRef, generatorModelAccess);
    }

    private static MIConfigParameter getDefObjInit(MIParameterValue parameter, DefRef defRef, IInternalGeneratorModelAccess generatorModelAccess) {
        if (parameter != null) {
            final MIConfigParameter definition = ModelUtil.getDefinition(parameter);
            generatorModelAccess.getModelVerifier().assertMdfConfigElementHasCorrectDefinition(parameter, definition, defRef);
            return definition;
        }

        final MIParamConfMultiplicity definitionObjectByDefRef = defRef.getDefinitionObject(generatorModelAccess.getProjectContext());
        if (definitionObjectByDefRef != null && definitionObjectByDefRef instanceof MIConfigParameter) {
            // Do not verify Definition, because the parameter is null, so there is nothing to verify.
            return (MIConfigParameter) definitionObjectByDefRef;
        }

        /*
         * The parameter does not exist and has no unique DefRef (e.g. ANY wildcard), so we can't determine the correct definition, so we could only return null.
         * The getDefinition() must check for null!
         */
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean existsMDF() {
        if (parameter == null) {
            return false;
        }
        return true;
    }

    /**
     * Returns true, if the Definition in the MDF model has a Lower Multiplicity > 0.
     *
     * @return
     */
    @PublishedMethod
    public boolean isRequiredParameter() {

        final BigInteger lowerMultiplicity = getGeneratorModelAccess().getProjectContext().getService(IEcucDefinitionAccess.class).def(getDefinition()).getMultiplicity()
                .getLower();
        if (lowerMultiplicity.compareTo(BigInteger.ZERO) > 0) {
            return true;
        }

        return false;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public DefRef getDefRef() {
        return defRef;
    }

    @PublishedMethod
    @Override
    public GIContainer getParent() {
        return parent;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void invalidateCache() {
        super.invalidateCache();
        mdfObjectAlreadyChecked = false;
        valueAlreadyChecked = false;
    }

    @PublishedMethod
    protected void setValueChecked() {
        valueAlreadyChecked = true;
    }

    @PublishedMethod
    protected boolean isValueChecked() {
        getGenModelAccessInternal().checkCacheAndInvalidateIfNecessary();
        return valueAlreadyChecked;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIParameterValue getMdfObject() {
        if (mdfObjectAlreadyChecked) {
            return parameter;
        }
        try {
            switchView();

            getModelVerifier().assertParameterOrReferenceNotNull(getParent(), this);
            if (onlyOneElement) {
                getModelVerifier().assertElementIsTheOnlyElement(getParent(), this, parameter);
            }
            mdfObjectAlreadyChecked = true;
            return parameter;

        } finally {
            restoreView();
        }
    }

    @Override
    @PublishedMethod
    protected MIParameterValue getMdfObjectUnsafe() {
        return parameter;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIConfigParameter getDefinition() {
        if (definitionObj == null) {
            try {
                switchView();
                getModelVerifier().assertParameterOrReferenceNotNull(getParent(), this);
                throw new AssertionError("Shall not be reachable Code!");
            } finally {
                restoreView();
            }
        }
        return definitionObj;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append(getClass().getSimpleName());
        builder.append(": ");
        if (existsMDF()) {
            builder.append(getObjectLink());
        } else {
            builder.append("MIObject undefined");
        }
        return builder.toString();
    }

}
