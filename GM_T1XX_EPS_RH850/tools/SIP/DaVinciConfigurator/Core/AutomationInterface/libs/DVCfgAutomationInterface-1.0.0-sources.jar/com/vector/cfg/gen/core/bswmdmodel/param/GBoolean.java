package com.vector.cfg.gen.core.bswmdmodel.param;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIBoolParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractParam;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.BoolGenElement;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucBooleanDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucBooleanParameter;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.varianthandling.attributevaluevariationpoints.MINumericalValueVariationPoint;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBooleanParamDef;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Boolean parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GBoolean extends GAbstractParam<Boolean> implements GIBoolParameter {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GBoolean.class);

    private Boolean value;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GBoolean(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MINumericalValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MINumericalValue getMdfObject() {
        return (MINumericalValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MINumericalValue getMdfObjectUnsafe() {
        return (MINumericalValue) super.getMdfObjectUnsafe();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasValue() {
        if (isValueChecked()) {
            return true;
        }
        return getValueInternal() != null;
    }

    private MINumericalValueVariationPoint getValueVariationPoint() {
        try {
            switchView();

            if (getMdfObject() != null) {
                return getMdfObject().getValue();
            }
            return null;

        } finally {
            restoreView();
        }
    }

    private Boolean getValueInternal() {
        try {
            switchView();

            final MINumericalValue parameter = getMdfObjectUnsafe();
            if (parameter != null) {
                if (getGeneratorModelAccess().getMdfModelAccess().containsBoolean(parameter)) {
                    return getGeneratorModelAccess().getMdfModelAccess().getAsBoolean(parameter);
                }
            }
            return null;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public Boolean getValue() {
        return getValueMdf();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Boolean getValueOrDefault(Boolean defaultValue) {
        if (hasValue()) {
            return getValue();
        }

        return defaultValue;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Boolean getValueMdf() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            getModelVerifier().assertParameterOrReferenceNotNull(getParent(), this);
            getModelVerifier().assertParameterValueNotNull(this, getValueVariationPoint());
            getModelVerifier().assertParameterHasLegalValue(this, "Boolean");
            value = getValueInternal();
            setValueChecked();
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public BoolGenElement formatValue() {
        return F.formatBool(this);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(Boolean valueOf) {
        final IModelViewManager vm = getGeneratorModelAccess().getModelViewManager();
        try (IModelViewExecutionContext viewContext = vm.executeWithModelView(getCreationModelView())) {
            try (IModelViewExecutionContext modeContext = vm.executeWithVariantSpecificModelChanges()) {
                getGeneratorModelAccess().getMdfModelAccess().setAsBoolean(getMdfObject(), valueOf);
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIBooleanParamDef getDefinition() {
        return (MIBooleanParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucBooleanDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucBooleanParameter getEcuConfiguration() {

        final IEcucParameter cfg = super.getEcuConfiguration();
        return (IEcucBooleanParameter) cfg;
    }

}
