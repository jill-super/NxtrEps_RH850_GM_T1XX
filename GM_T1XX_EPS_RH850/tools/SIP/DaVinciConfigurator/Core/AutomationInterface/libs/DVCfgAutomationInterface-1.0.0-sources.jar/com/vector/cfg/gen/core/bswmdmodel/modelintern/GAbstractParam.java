package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucParameterDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.state.IParameterStatePublished;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The abstract base class for bswmd model parameters.
 *
 * <p>
 * Attention: Please use {@link GIParameter} interface in client code.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GAbstractParam<VALUE extends Object> extends GAbstractParamOrRef implements GIParameter<VALUE> {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GAbstractParam.class);

    /**
     * Constructor for GAbstractParam.
     *
     * @param typename
     * @param parameter
     * @param modelAccess
     * @param parent
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GAbstractParam(@Nonnull DefRef defRef, @Nullable MIParameterValue parameter, @Nonnull IInternalGeneratorModelAccess modelAccess, @Nonnull GIContainer parent,
            boolean onlyOneElement) {
        super(defRef, parameter, modelAccess, parent, onlyOneElement);
    }

    /**
     * Constructor for GAbstractParam.
     *
     * @param modelAccess the model access
     * @param defRef the def ref
     * @param parameter the parameter
     * @param parent the parent
     * @param onlyOneElement the only one element
     */
    @PublishedMethod
    public GAbstractParam(@Nonnull IInternalGeneratorModelAccess modelAccess, @Nonnull DefRef defRef, @Nullable MIParameterValue parameter, @Nonnull GIContainer parent,
            boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public boolean asBoolean() {
        if (existsMDF() && hasValue()) {
            return true;
        }
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IParameterStatePublished getCeState() {
        return (IParameterStatePublished) super.getCeState();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public VALUE getValueOrDefaultMdf(VALUE defaultValue) {
        if (hasValue()) {
            return getValueMdf();
        }

        return defaultValue;

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucParameterDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucParameter getEcuConfiguration() {

        return getGeneratorModelAccess().getEcuConfigurationAccess().cfg(getMdfObject());
    }

}
