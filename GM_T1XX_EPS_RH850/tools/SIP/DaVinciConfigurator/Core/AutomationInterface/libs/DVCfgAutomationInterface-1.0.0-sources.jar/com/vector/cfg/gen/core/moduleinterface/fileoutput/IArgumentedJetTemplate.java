package com.vector.cfg.gen.core.moduleinterface.fileoutput;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The interface for jet templates with a second argument.
 * <p>
 * The second argument can be passed via the parent jetTemplate to specified to template behavior.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients. Please use abstract class AbstractArgumentedJetTemplate
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IArgumentedJetTemplate<T> extends IJetTemplate {

    /**
     * Gets the second argument of the {@link IArgumentedJetTemplate}.
     *
     * @return the second argument
     */
    @PublishedMethod
    T getSecondArgument();

    /**
     * Sets the second argument.
     *
     * @param secondArgument the new second argument
     */
    @PublishedMethod
    void setSecondArgument(T secondArgument);
}
