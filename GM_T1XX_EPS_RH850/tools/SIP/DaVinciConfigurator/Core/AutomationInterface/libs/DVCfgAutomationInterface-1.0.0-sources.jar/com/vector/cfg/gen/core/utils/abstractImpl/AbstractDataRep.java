package com.vector.cfg.gen.core.utils.abstractImpl;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IDataRep;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Abstract class for all generator DataRepresentation implementations.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IDataRep
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractDataRep extends AbstractGeneratorPackageReferable implements IDataRep {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractDataRep.class);

    /**
     * Constructor for AbstractDataRep.
     *
     * @param generatorPackageRef A {@link IGeneratorPackageReferable} of the generator.
     */
    @PublishedMethod
    public AbstractDataRep(IGeneratorPackageReferable generatorPackageRef) {
        super(generatorPackageRef);

    }

}
