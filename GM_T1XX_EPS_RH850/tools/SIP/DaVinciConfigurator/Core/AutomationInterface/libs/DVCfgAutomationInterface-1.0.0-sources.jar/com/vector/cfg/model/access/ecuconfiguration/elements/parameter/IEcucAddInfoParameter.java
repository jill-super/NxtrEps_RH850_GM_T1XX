package com.vector.cfg.model.access.ecuconfiguration.elements.parameter;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIEcucAddInfoParamValue;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucAddInfoParameter extends IEcucParameter {

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    MIEcucAddInfoParamValue getEcucObject();

}
