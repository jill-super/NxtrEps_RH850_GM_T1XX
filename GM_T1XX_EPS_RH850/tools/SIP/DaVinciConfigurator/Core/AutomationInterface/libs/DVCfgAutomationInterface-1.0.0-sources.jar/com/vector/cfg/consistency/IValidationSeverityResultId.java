package com.vector.cfg.consistency;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The interface for {@link IValidationResultId}s that additionally hold the severity.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IValidationResultId
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IValidationSeverityResultId extends IValidationResultId {

    /**
     * Gets the severity of the result Id.
     *
     * @return The severity of the Result Id
     *
     * @see EValidationSeverityType
     */
    @PublishedMethod
    EValidationSeverityType getSeverity();
}
