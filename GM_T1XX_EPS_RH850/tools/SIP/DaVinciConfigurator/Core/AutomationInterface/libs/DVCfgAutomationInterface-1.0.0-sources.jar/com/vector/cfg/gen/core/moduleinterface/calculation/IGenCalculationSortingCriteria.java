package com.vector.cfg.gen.core.moduleinterface.calculation;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;

/**
 * IGenCalculationSortingCriteria provides the information for the CalculationSorting algorithm.
 * <p>
 * You can create instances of this Interface via the GenCalculationSorterBuilder class
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see GenCalculationSorterBuilder
 * @see IGenCalculationSortable
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenCalculationSortingCriteria extends IGeneratorPackageReferable {

    /**
     * Returns the list of {@link ISortRule}s which are used to sort the {@link ICalculator}s topologically.
     *
     * @return the sort rules
     */
    @PublishedMethod
    List<ISortRule> getSortRules();
}
