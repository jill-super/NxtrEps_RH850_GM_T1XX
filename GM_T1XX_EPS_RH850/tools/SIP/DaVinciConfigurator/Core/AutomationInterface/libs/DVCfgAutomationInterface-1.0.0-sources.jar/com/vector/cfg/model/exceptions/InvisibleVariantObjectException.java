package com.vector.cfg.model.exceptions;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.view.IModelVarianceState;
import com.vector.cfg.model.view.IModelViewManagerCoreInternal;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.variant.IInvariantEcucDefView;
import com.vector.cfg.util.IProjectContext;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public class InvisibleVariantObjectException extends ModelVariantException {

    private static final long serialVersionUID = -3115470943127134043L;

    private IModelVarianceState modelVarianceState;

    /**
     * Constructor.
     */
    public InvisibleVariantObjectException(String msg) {
        this(msg, null, null);
    }

    /**
     * Constructor.
     */
    public InvisibleVariantObjectException(MIObject source) {
        this("The model object is invisible in the current  model view.", source, null);
    }

    /**
     * Constructor.
     */
    public InvisibleVariantObjectException(String msg, MIObject source) {
        this(msg, source, null);
    }

    /**
     * Constructor.
     */
    public InvisibleVariantObjectException(String msg, MIObject source, Throwable cause) {
        super(msg, source, cause);
        storeVarianceState(source);
    }

    private void storeVarianceState(MIObject source) {
        final IProjectContext projectContext = ModelUtil.getProjectContext(source);
        if (projectContext == null) {
            return;
        }
        final IModelViewManagerCoreInternal modelViewManager = projectContext.getService(IModelViewManagerCoreInternal.class);
        modelVarianceState = modelViewManager.getModelVarianceState();
    }

    /**
     * Returns the model variance state which was active when the exception was created. The return value is only available if the related source object of this exception is not
     * <code>null</code>.
     *
     * @return
     */
    public Optional<IModelVarianceState> getModelVarianceState() {
        return Optional.fromNullable(modelVarianceState);
    }

    @Override
    public String getMessage() {
        String msg = super.getMessage();
        if (modelVarianceState != null) {
            final IModelView view = modelVarianceState.getModelView();
            msg += " View: " + view.getName();
            if (view instanceof IInvariantEcucDefView) {
                msg += " (object is probably invisible because it supports variance!)";
            }
        }
        return msg;
    }

}
