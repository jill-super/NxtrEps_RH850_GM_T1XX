package com.vector.cfg.automation.api.project;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * The literals of {@link EEcucFileStructure} define the alternative ECUC file structures supported for the of the new project.
 * <div class="extdoc" id="EEcucFileStructure"><!--Label:EEcucFileStructure-->The literals of {@link EEcucFileStructure} define the alternative ECUC file structures supported by
 * the new project. The following alternatives are supported:</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum EEcucFileStructure {

    /**
     * {@link #SINGLE_FILE} results in a single ECUC file containing all module configurations.
     * <div class="extdoc" id="SINGLE_FILE"><!--Label:EEcucFileStructure.SINGLE_FILE-->{@link #SINGLE_FILE} results in a single ECUC file containing all module
     * configurations.</div>
     */
    SINGLE_FILE,

    /**
     * {@link #ONE_FILE_PER_MODULE} results in a separate ECUC file for each module configuration all located in a common folder.
     * <div class="extdoc" id="ONE_FILE_PER_MODULE"><!--Label:EEcucFileStructure.ONE_FILE_PER_MODULE-->{@link #ONE_FILE_PER_MODULE} results in a separate ECUC file for each
     * module configuration all located in a common folder.</div>
     */
    ONE_FILE_PER_MODULE,

    /**
     * {@link #ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE} results in a separate ECUC file for each module configuration each located in its separate folder.
     * <div class="extdoc" id="ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE"><!--Label:EEcucFileStructure.ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE-->
     * {@link #ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE} results in a separate ECUC file for each module configuration each located in its separate folder.</div>
     */
    ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE

}
