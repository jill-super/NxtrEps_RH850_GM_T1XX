package com.vector.cfg.gen.core.moduleinterface.genservices;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.genservices.exceptions.GenServiceException;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * The {@link IGenServiceProvider} provides GenServices registered by Generators to the Configurator (e.g. GUI).
 *
 * <p>
 * Attention: All registered Services must be <b>threadsafe</b>, because is it not guaranteed that the services are called from an certain thread!
 * </p>
 *
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenServiceProvider {

    /**
     * Gets the requested GenService.
     *
     * @param <T> the generic type
     * @param clazz the interface class of the requested service.
     * @param mdfObj A ModelObejct under the ModuleConfiguration of the corresponding Generator.
     * @return the service implementation. Never returns <code>null</code>.
     *
     * @exception ModelCeHasNoDefinitionException <ul>
     * <li>if the mdfObj has no parent with a correct ModuleDefinition.</li>
     * </ul>
     * @exception GenServiceException <ul>
     * <li>if the requested services does not exist</li>
     * </ul>
     * @exception NullPointerException <ul>
     * <li>if clazz is null</li>
     * <li>if mdfObj is null</li>
     * </ul>
     * @exception IllegalArgumentException <ul>
     * <li>if clazz is in no interface</li>
     * </ul>
     */
    @PublishedMethod
    <T> T getService(Class<T> clazz, MIHasDefinition mdfObj);

    /**
     * Gets the requested GenService.
     *
     * @param <T> the generic type
     * @param clazz the interface class of the requested service.
     * @param moduleDefRef The ModuleDefinition {@link DefRef} of the corresponding Generator.
     * @return the service implementation. Never returns <code>null</code>.
     *
     * @exception ModelCeHasNoDefinitionException <ul>
     * <li>if the mdfObj has no parent with a correct ModuleDefinition.</li>
     * </ul>
     * @exception GenServiceException <ul>
     * <li>if the requested services does not exist</li>
     * </ul>
     * @exception NullPointerException <ul>
     * <li>if clazz is null</li>
     * <li>if moduleDefRef is null</li>
     * </ul>
     * @exception IllegalArgumentException <ul>
     * <li>if moduleDefRef is no moduleDefinition</li>
     * <li>if clazz is in no interface</li>
     * </ul>
     */
    @PublishedMethod
    <T> T getService(Class<T> clazz, DefRef moduleDefRef);

    /**
     * Tries to get the requested GenService.
     *
     * @param <T> the generic type
     * @param clazz the interface class of the requested service.
     * @param mdfObj A ModelObejct under the ModuleConfiguration of the corresponding Generator.
     * @return the service implementation, or <code>null</code> if the service does not exist.
     *
     * @exception NullPointerException <ul>
     * <li>if clazz is null</li>
     * <li>if mdfObj is null</li>
     * </ul>
     * @exception IllegalArgumentException <ul>
     * <li>if clazz is in no interface</li>
     * </ul>
     */
    @PublishedMethod
    <T> T tryGetService(Class<T> clazz, MIHasDefinition mdfObj);

    /**
     * Tries to get the requested GenService.
     *
     * @param <T> the generic type
     * @param clazz the interface class of the requested service.
     * @param moduleDefRef The ModuleDefinition {@link DefRef} of the corresponding Generator.
     * @return the service implementation, or <code>null</code> if the service does not exist.
     *
     * @exception NullPointerException <ul>
     * <li>if clazz is null</li>
     * <li>if moduleDefRef is null</li>
     * </ul>
     * @exception IllegalArgumentException <ul>
     * <li>if moduleDefRef is no moduleDefinition</li>
     * <li>if clazz is in no interface</li>
     * </ul>
     */
    @PublishedMethod
    <T> T tryGetService(Class<T> clazz, DefRef moduleDefRef);

    /**
     * Checks if is the requested service is available. Return true, if the service exists, otherwise false.
     *
     * @param <T> the generic type
     * @param clazz the interface class of the requested service.
     * @param moduleDefRef The ModuleDefinition {@link DefRef} of the corresponding Generator.
     * @return true, if the GenService is available.
     *
     * @exception NullPointerException <ul>
     * <li>if clazz is null</li>
     * <li>if moduleDefRef is null</li>
     * </ul>
     * @exception IllegalArgumentException <ul>
     * <li>if moduleDefRef is no moduleDefinition</li>
     * <li>if clazz is in no interface</li>
     * </ul>
     */
    @PublishedMethod
    <T> boolean isServiceAvailable(Class<T> clazz, DefRef moduleDefRef);

}
