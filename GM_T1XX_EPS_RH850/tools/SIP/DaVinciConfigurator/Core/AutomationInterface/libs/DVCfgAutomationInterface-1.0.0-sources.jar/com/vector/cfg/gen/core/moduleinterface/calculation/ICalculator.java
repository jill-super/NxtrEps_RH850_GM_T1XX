package com.vector.cfg.gen.core.moduleinterface.calculation;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasGetGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasSetGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.exceptions.CalculationFailedException;

/**
 * <div class="extdoc" id="ICalculator"> The {@link ICalculator} provides the ability to implement model change logic which is automatically called in the
 * calculation phase.
 * <ul>
 * <li>calculate - Will be called before {@link IGenerationProcessor#buildDataStructures(IGeneratorResultSink) buildDataStructures()} is called</li>
 * </ul>
 * An {@link ICalculator} must be registered by an {@link IGenCalculationAspect} at your {@link IGeneratorPackage}.
 *
 * <p>
 * You should use the AbstractCalculator as base class for your implementation.
 * </p>
 *
 * <p>
 * <b>Attention:</b> It is no longer permitted, that a {@link IGenerationProcessor} implements the {@link ICalculator} interface to support the calculation
 * phase.
 * </p>
 * </div>
 *
 * <p>
 * You can control the calculation order, if you implement the {@link IGenCalculationSortable} interface. See the doc of the interface for more details.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 * @noimplement This interface is not intended to be implemented by clients. Please use abstract class AbstractCalculator
 * @see IGeneratorPackage
 * @see IGenCalculationAspect
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public interface ICalculator extends IGeneratorPackageReferable, IHasSetGeneratorResultSink, IHasGetGeneratorResultSink {

    /**
     * Gets the associated sub phase of the calculation phase of the {@link ICalculator}. The Calculator must specify by this method in which
     * {@link ECalculationSubPhase} the {@link ICalculator#calculate(IGeneratorResultSink)} method is called, during the execution of the calculation phase.
     *
     * @return the associated step
     */
    @PublishedMethod
    ECalculationSubPhase getAssociatedSubPhase();

    /**
     * <code>calculate()</code> can change the Ecu Configuration before it is generated.
     *
     * <p>
     * Calling point:<br/>
     * This method is called during the Calculation Phase, before the Validation has started.
     * </p>
     *
     * @param resultSink The method will append it results to the resultSink. The caller must provide an appropriate resultSink.
     *
     * @throws CalculationFailedException<ul>
     * <li>if the calculation has failed. This will cancel the Validation and Generation.</li>
     * </ul>
     */
    @PublishedMethod
    void calculate(IGeneratorResultSink resultSink);
}
