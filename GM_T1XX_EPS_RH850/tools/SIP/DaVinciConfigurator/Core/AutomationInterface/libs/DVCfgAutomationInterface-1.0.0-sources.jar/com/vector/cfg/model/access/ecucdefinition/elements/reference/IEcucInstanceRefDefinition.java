package com.vector.cfg.model.access.ecucdefinition.elements.reference;

import javax.annotation.concurrent.NotThreadSafe;
import javax.jmi.reflect.RefClass;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIInstanceReferenceParamDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucInstanceRefDefinition extends IEcucAbstractRef {

    /**
     * returns an optional holding the target ref class. Never returns <code>null</code>.
     *
     * @return
     */
    @PublishedMethod
    Optional<? extends RefClass> getTargetRefClass();

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    MIInstanceReferenceParamDef getDef();
}
