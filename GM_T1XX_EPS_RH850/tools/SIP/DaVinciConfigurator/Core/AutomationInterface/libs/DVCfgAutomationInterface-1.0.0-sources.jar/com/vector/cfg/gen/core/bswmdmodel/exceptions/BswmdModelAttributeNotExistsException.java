package com.vector.cfg.gen.core.bswmdmodel.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Thrown to indicate that a requested attribute of a model object does not exist.
 *
 * Examples are The Software version or the BswImplementationVersion.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class BswmdModelAttributeNotExistsException extends BswmdModelException {

    private static final long serialVersionUID = 7646889542428545535L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BswmdModelAttributeNotExistsException.class);

    private final String attributeDescription;

    private final String methodName;

    /**
     * Constructor for BswmdModelNotExistsException.
     *
     * @param result the result
     * @param modelObject the model object
     * @param attributeDescription the attribute description
     * @param methodName the method name
     */
    @PublishedMethod
    public BswmdModelAttributeNotExistsException(IValidationResult result, GIModelObject modelObject, String attributeDescription, String methodName) {
        super(result, modelObject);
        this.attributeDescription = attributeDescription;
        this.methodName = methodName;
    }

    /**
     * Gets the attribute description.
     *
     * @return the attribute description
     */
    @PublishedMethod
    public String getAttributeDescription() {
        return attributeDescription;
    }

    /**
     * Gets the method name.
     *
     * @return the method name
     */
    @PublishedMethod
    public String getMethodName() {
        return methodName;
    }

}
