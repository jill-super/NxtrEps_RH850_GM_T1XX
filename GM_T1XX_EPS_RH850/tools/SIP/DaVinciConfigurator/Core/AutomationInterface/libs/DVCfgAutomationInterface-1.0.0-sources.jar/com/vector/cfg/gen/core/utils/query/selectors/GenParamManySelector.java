package com.vector.cfg.gen.core.utils.query.selectors;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.ElementManySelector;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenParamManySelector<E extends GIParameter<?>> extends ElementManySelector<GIContainer, E> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenParamManySelector.class);

    private final DefRef paramName;

    @PublishedMethod
    public GenParamManySelector(DefRef paramName) {
        this.paramName = paramName;

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<E> getManySelection(GIContainer parentElementSet) {

        @SuppressWarnings("unchecked")
        final List<E> paramList = (List<E>) parentElementSet.getParameters(paramName);

        return paramList;

    }

}