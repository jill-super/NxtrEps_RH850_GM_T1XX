package com.vector.cfg.gen.core.moduleinterface.fileoutput;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;

/**
 * {@link EmptyJetTemplate} is a convenience class which provides the {@link IJetTemplate} API without any content.
 * <p>
 * You could get the {@link EmptyJetTemplate} by calling {@link EmptyJetTemplate#EMPTY_TEMPLATE}.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class EmptyJetTemplate implements IJetTemplate {

    /**
     * The Constant EMPTY_TEMPLATE is the static instance of an {@link EmptyJetTemplate}.
     */
    @PublishedField
    public static final IJetTemplate EMPTY_TEMPLATE = new EmptyJetTemplate();

    /**
     * Constructor for EmptyJetTemplate.
     *
     * This must be public because JetTemplates are created via reflection
     */
    @PublishedMethod
    public EmptyJetTemplate() {
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String generate(Object dataRepresentation) {
        return "";
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IGeneratorPackage getGeneratorPackage() {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IOutputFile getOutputFile() {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setOutputFile(IOutputFile outputFile) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String generateTemplate() {
        return "";
    }

}
