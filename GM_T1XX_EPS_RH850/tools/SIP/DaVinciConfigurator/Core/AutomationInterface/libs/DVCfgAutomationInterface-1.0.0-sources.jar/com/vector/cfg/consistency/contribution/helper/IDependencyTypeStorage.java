package com.vector.cfg.consistency.contribution.helper;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EDependencyType;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.<BR>
 * <BR>
 * This interface contains a setter method for the EDependencyType of an IActionTuple implementation.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IDependencyTypeStorage<IMPLTYPE> {
    /**
     * With this method you can set the dependency type.
     *
     * @see com.vector.cfg.consistency.IHasDependencyType IHasDependencyType
     */
    @PublishedMethod
    IMPLTYPE setDependencyType(EDependencyType dependencyType);
}
