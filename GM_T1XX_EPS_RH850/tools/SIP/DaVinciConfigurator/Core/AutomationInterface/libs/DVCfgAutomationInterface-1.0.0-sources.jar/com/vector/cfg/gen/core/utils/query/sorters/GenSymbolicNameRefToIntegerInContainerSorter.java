package com.vector.cfg.gen.core.utils.query.sorters;

import java.math.BigInteger;
import java.text.MessageFormat;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.gen.core.bswmdmodel.IGeneratorModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.param.GSymbolicNameReference;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.CompareResult;
import com.vector.cfg.util.query.ElementSorter;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenSymbolicNameRefToIntegerInContainerSorter extends ElementSorter<GIContainer> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenSymbolicNameRefToIntegerInContainerSorter.class);

    private final EValueSorterType sorterType;

    private final DefRef symbolicNameReference;

    /**
     * Constructor for GenIntValueSorter.
     *
     * @param symbolicNameReference
     * @param sorterType
     */
    @PublishedMethod
    public GenSymbolicNameRefToIntegerInContainerSorter(DefRef symbolicNameReference, EValueSorterType sorterType) {
        this.sorterType = sorterType;
        this.symbolicNameReference = symbolicNameReference;
    }

    /**
     * Constructor for GenIntValueSorter.
     *
     */
    @PublishedMethod
    public GenSymbolicNameRefToIntegerInContainerSorter(DefRef symbolicNameReference) {
        this(symbolicNameReference, EValueSorterType.VALUE_EQUAL_ALLOWED);
    }

    @PublishedMethod
    @Override
    protected CompareResult compareElements(GIContainer container1, GIContainer container2) {

        final IGeneratorModelAccess genMa = (IGeneratorModelAccess) container1.getGeneratorModelAccess();

        final BigInteger value1 = getValueOfContainer(container1);
        final BigInteger value2 = getValueOfContainer(container2);

        if (value1.compareTo(value2) < 0) {
            return CompareResult.ELEMENT_1_BEFORE_ELEMENT_2;
        } else if (value1.equals(value2)) {
            if (sorterType.equals(EValueSorterType.VALUE_EQUAL_ALLOWED)) {
                return CompareResult.ELEMENTS_EQUAL;
            } else if (sorterType.equals(EValueSorterType.VALUE_EQUAL_FORBIDDEN)) {

                final IGeneratorResult result = GeneratorResultBuilder
                        .newBuilder(CommonGeneratorResultIds.getElementNotUniqueErrorId(genMa.getValidationResultOrigin()),
                                "The two Integer values {0} and {1} of the containers {2} and {3} via the SymbolicReferences are the same. These values should be unique.",
                                getParameterOfContainer(container1), getParameterOfContainer(container2), container1.getObjectLink(), container2.getObjectLink())
                        .addErrorObject(container1).addErrorObject(container2).addDependentObject(container1.getParent()).addDependentObject(container2.getParent()).buildResult();

                throw new ValidationFailedException(result);

            } else {
                throw new IllegalArgumentException("The sorterType has an unknown value.");
            }

        } else {
            return CompareResult.ELEMENT_1_AFTER_ELEMENT_2;
        }
    }

    /**
     * @param element1
     * @param paramList1
     * @return
     */
    private BigInteger getValueOfContainer(GIContainer container) {
        try (IModelViewExecutionContext context = container.executeWithCreationModelView()) {
            final MINumericalValue paramValue = getParameterOfContainer(container);

            final IModelCheckedAccess mca = ModelUtil.getProjectContext(paramValue).getService(IModelCheckedAccess.class);

            return mca.parameter(paramValue).asInt().getValue();
        }

    }

    private MINumericalValue getParameterOfContainer(GIContainer container) {

        final GSymbolicNameReference symRef = getSymRefOfContainer(container);

        final MIParameterValue targetParam = symRef.getRefTargetParameterMdf();

        if (!(targetParam instanceof MINumericalValue)) {
            throw new IllegalArgumentException(MessageFormat.format("The Parameter {0} is no SymblicNameReference. Parameter location: {1}", symbolicNameReference,
                    container.getObjectLink()));
        }
        return (MINumericalValue) targetParam;
    }

    private GSymbolicNameReference getSymRefOfContainer(GIContainer container) {
        final List<GIReference<?>> paramList = container.getReferences(symbolicNameReference);

        if (paramList.size() != 1) {
            throw new IllegalArgumentException(MessageFormat.format("The Parameter {0} with multiplicity != 1 is not permitted. Parameter location: {1}", symbolicNameReference,
                    container.getObjectLink()));
        }
        final GIReference<?> param = paramList.get(0);

        if (!(param instanceof GSymbolicNameReference)) {
            throw new IllegalArgumentException(MessageFormat.format("The Parameter {0} is no SymblicNameReference. Parameter location: {1}", symbolicNameReference,
                    container.getObjectLink()));
        }
        final GSymbolicNameReference symRef = (GSymbolicNameReference) param;
        return symRef;
    }
}
