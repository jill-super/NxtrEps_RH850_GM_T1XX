package com.vector.cfg.model.access;

import javax.annotation.concurrent.Immutable;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.internal.access.ObjectLinkOtherTypeData;
import com.vector.cfg.model.internal.access.ObjectLinkParameterData;
import com.vector.cfg.model.internal.access.ObjectLinkVarianceData;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@Immutable
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class TypedAsrObjectLink<METACLASS_TYPE extends MIObject> extends AsrObjectLink implements IDebugable {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(TypedAsrObjectLink.class);

    private final Class<METACLASS_TYPE> metaModelClass;

    TypedAsrObjectLink(String bestEffortPath, boolean isParameterValueLink, boolean isReferrableLink, final Class<METACLASS_TYPE> metaModelClass) {
        super(bestEffortPath, isParameterValueLink, isReferrableLink);
        if (metaModelClass == null) {
            throw new IllegalArgumentException("metaModelClass is null.");
        }
        this.metaModelClass = metaModelClass;
    }

    TypedAsrObjectLink(String bestEffortPath, ObjectLinkVarianceData variantData, final Class<METACLASS_TYPE> metaModelClass) {
        super(bestEffortPath, variantData);
        if (metaModelClass == null) {
            throw new IllegalArgumentException("metaModelClass is null.");
        }
        this.metaModelClass = metaModelClass;
    }

    TypedAsrObjectLink(String bestEffortPath, ObjectLinkParameterData parameterData, ObjectLinkVarianceData variantData, final Class<METACLASS_TYPE> metaModelClass) {
        super(bestEffortPath, parameterData, variantData);
        if (metaModelClass == null) {
            throw new IllegalArgumentException("metaModelClass is null.");
        }
        this.metaModelClass = metaModelClass;
    }

    TypedAsrObjectLink(ObjectLinkOtherTypeData otherTypeData, final Class<METACLASS_TYPE> metaModelClass) {
        super(otherTypeData);
        if (metaModelClass == null) {
            throw new IllegalArgumentException("metaModelClass is null.");
        }
        this.metaModelClass = metaModelClass;
    }

    /**
     * Returns the MetaModelClass object of the AUTOSAR element.
     *
     * @return the MetaModel class object.
     */
    @PublishedMethod
    public Class<METACLASS_TYPE> getMetaModelClass() {
        return metaModelClass;
    }

    /**
     * Returns an AUTOSAR object which matches this link. See {@link AsrObjectLink} for details about restrictions of retrieving objects by link.
     * <p>
     * <b>Remark:</b> This method will probably return an invisible MDF object!
     * </p>
     *
     * @param projectContext
     * @return
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    public Optional<METACLASS_TYPE> getTypedAutosarObject(final IProjectContext projectContext) {
        final Optional<MIObject> optObj = getAutosarObject(projectContext);
        if (optObj.isPresent()) {
            final Optional<METACLASS_TYPE> optTypedObj = (Optional<METACLASS_TYPE>) Optional.of(optObj.get());
            return optTypedObj;
        }
        return Optional.absent();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toDebugString() {
        return TypedAsrObjectLink.class.getSimpleName() + ": " + getObjectLinkString() + "<" + metaModelClass.getSimpleName() + ">";
    }

}
