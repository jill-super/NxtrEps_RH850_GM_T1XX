package com.vector.cfg.gen.core.utils.formatting;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The base interface for all primitive type of {@link IGenElement}s.
 * <p>
 * Attention: This interface is not intended to be implemented by the user!
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IPrimitiveGenElement extends IGenElement {

    /**
     * Adds a prefix value text to the element. The style is following : <br/>
     * <code><ul> prefixParamElementValue </ul></code>
     *
     * @param prefixParam The Value of the prefix
     * @return The GenElement
     *
     * @throws IllegalArgumentException<ul>
     * <li>if prefixParam is null.</li>
     * </ul>
     *
     * @throws IllegalStateException<ul>
     * <li>if a previous call to {@link #prefix(String)} was made to set the prefix.</li>
     * </ul>
     */
    @PublishedMethod
    IPrimitiveGenElement prefix(String prefixParam);

    /**
     * Adds a postfix value text to the element. The style is following : <br/>
     * <code><ul> ElementValuePostfixParam </ul></code>
     *
     * @param postfixParam The Value of the postfix
     * @return The GenElement
     *
     * @throws IllegalArgumentException<ul>
     * <li>if postfixParam is null.</li>
     * </ul>
     *
     * @throws IllegalStateException<ul>
     * <li>if a previous call to {@link #postfix(String)} was made to set the postfix.</li>
     * </ul>
     */
    @PublishedMethod
    IPrimitiveGenElement postfix(String postfixParam);

}
