package com.vector.cfg.gen.core.moduleinterface.exceptions;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Thrown to indicate that the GeneratorPackage has caused a during the initialization sequence. The type {@link GeneratorPackageInitializationException} should
 * only be thrown during the call of {@link IGeneratorPackage#initializePackage()}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GeneratorPackageInitializationException extends GeneratorPackageException {
    private static final long serialVersionUID = 5846747146607328043L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GeneratorPackageInitializationException.class);

    /**
     * Constructor for GeneratorPackageInitializationException.
     *
     * @param genResult the {@link IGeneratorResult}
     * @param innerEx the inner {@link Exception}.
     */
    @PublishedMethod
    public GeneratorPackageInitializationException(IGeneratorResult genResult, Throwable innerEx) {
        super(genResult, innerEx);
    }

    /**
     * Constructor for GeneratorPackageInitializationException.
     *
     * @param genResult the {@link IGeneratorResult}
     */
    @PublishedMethod
    public GeneratorPackageInitializationException(IGeneratorResult genResult) {
        super(genResult);
    }

    /**
     * Constructs a new GeneratorPackageInitializationException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genResultList The List of GeneratorResults. For each item a Error will be reported in the Configurator.
     * @param innerEx The cause (which is saved for later retrieval by the {@link #getCause()} method). (A <tt>null</tt> value is permitted, and indicates that
     * the cause is nonexistent or unknown.)
     */
    @PublishedMethod
    public GeneratorPackageInitializationException(List<? extends IGeneratorResult> genResultList, Throwable innerEx) {
        super(genResultList, innerEx);
    }

    /**
     * Constructs a new GeneratorPackageInitializationException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genResultList The List of GeneratorResults. For each item a Error will be reported in the Configurator.
     */
    @PublishedMethod
    public GeneratorPackageInitializationException(List<? extends IGeneratorResult> genResultList) {
        super(genResultList);
    }

}
