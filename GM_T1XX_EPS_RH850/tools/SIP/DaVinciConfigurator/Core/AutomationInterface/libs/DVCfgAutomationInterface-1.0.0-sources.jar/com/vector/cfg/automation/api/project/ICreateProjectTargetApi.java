package com.vector.cfg.automation.api.project;

import java.util.Collection;

import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.derivative.DerivativeInfo;
import com.vector.cfg.core.derivative.EImplementationProperties;
import com.vector.cfg.core.derivative.ImplementationProperty;

/**
 * {@link ICreateProjectTargetApi} provides means for specifying the new project's target settings.
 * <div class="extdoc" id="ICreateProjectTargetApi"><!--Label:ICreateProjectTargetApi-->{@link ICreateProjectTargetApi} provides means for specifying the new project's target
 * settings.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectTargetApi {

    /**
     * {@link #getAvailableDerivatives()} returns all possible input values for {@link #setDerivative(DerivativeInfo)}.
     * <div class="extdoc" id="getAvailableDerivatives"><!--Label:ICreateProjectTargetApi.getAvailableDerivatives-->
     * <h5>Available Derivatives</h5> {@link #getAvailableDerivatives()} returns all possible input values for {@link #setDerivative(DerivativeInfo)}.</div>
     *
     * @return all available {@link DerivativeInfo}s
     */
    @PublishedMethod
    Collection<DerivativeInfo> getAvailableDerivatives();

    /**
     * Alias for {@link #setDerivative(DerivativeInfo)}.
     */
    @PublishedMethod
    void derivative(@Nullable DerivativeInfo derivative);

    /**
     * Using {@link #setDerivative(DerivativeInfo)} the derivative for the new project can be specified.
     * <div class="extdoc" id="setDerivative"><!--Label:ICreateProjectTargetApi.setDerivative-->
     * <h5>Derivative</h5> Using {@link #setDerivative(DerivativeInfo)} the derivative for the new project can be specified. This is an optional parameter defaulting to the
     * first element in the collection returned by {@link #getAvailableDerivatives()} (or {@code null} if the collection is empty). The value given here must be one of the
     * values returned by {@link #getAvailableDerivatives()}.</div>
     *
     * @param derivative the derivative for the new project
     */
    @PublishedMethod
    void setDerivative(@Nullable DerivativeInfo derivative);

    /**
     * {@link #getAvailableCompilers()} returns all possible input values for {@link #setCompiler(ImplementationProperty)}.
     * <div class="extdoc" id="getAvailableCompilers"><!--Label:ICreateProjectTargetApi.getAvailableCompilers-->
     * <h5>Available Compilers</h5> {@link #getAvailableCompilers()} returns all possible input values for {@link #setCompiler(ImplementationProperty)}. Note: the available
     * compilers depend on the currently configured derivative. This method will return the empty collection if no derivative has been configured at the time it is called.</div>
     *
     * @return all available {@link ImplementationProperty}s of type {@link EImplementationProperties#COMPILER}
     */
    @PublishedMethod
    Collection<ImplementationProperty> getAvailableCompilers();

    /**
     * Alias for {@link #setCompiler(ImplementationProperty)}.
     */
    @PublishedMethod
    void compiler(@Nullable ImplementationProperty compiler);

    /**
     * Using {@link #setCompiler(ImplementationProperty)} the compiler for the new project can be specified.
     * <div class="extdoc" id="setCompiler"><!--Label:ICreateProjectTargetApi.setCompiler-->
     * <h5>Compiler</h5> Using {@link #setCompiler(ImplementationProperty)} the compiler for the new project can be specified. This is an optional parameter defaulting to the
     * first element in the collection returned by {@link #getAvailableCompilers()} (or {@code null} if the collection is empty). The value given here must be one of the values
     * returned by {@link #getAvailableCompilers()}.</div>
     *
     * @param compiler the compiler for the new project
     */
    @PublishedMethod
    void setCompiler(@Nullable ImplementationProperty compiler);

    /**
     * {@link #getAvailablePinLayouts()} returns all possible input values for {@link #setPinLayout(ImplementationProperty)}.
     * <div class="extdoc" id="getAvailablePinLayouts"><!--Label:ICreateProjectTargetApi.getAvailablePinLayouts-->
     * <h5>Available Pin Layouts</h5> {@link #getAvailablePinLayouts()} returns all possible input values for {@link #setPinLayout(ImplementationProperty)}. Note: the available
     * pin layouts depend on the currently configured derivative. This method will return the empty collection if no derivative has been configured at the time it is
     * called.</div>
     *
     * @return all available {@link ImplementationProperty}s of type {@link EImplementationProperties#PINLAYOUT}
     */
    @PublishedMethod
    Collection<ImplementationProperty> getAvailablePinLayouts();

    /**
     * Alias for {@link #setPinLayout(ImplementationProperty)}.
     */
    @PublishedMethod
    void pinLayout(@Nullable ImplementationProperty pinLayout);

    /**
     * Using {@link #setPinLayout(ImplementationProperty)} the pin layout for the new project can be specified.
     * <div class="extdoc" id="setPinLayout"><!--Label:ICreateProjectTargetApi.setPinLayout-->
     * <h5>Pin Layout</h5> Using {@link #setPinLayout(ImplementationProperty)} the pin layout for the new project can be specified. This is an optional parameter defaulting to
     * the first element in the collection returned by {@link #getAvailablePinLayouts()} (or {@code null} if the collection is empty). The value given here must be one of the
     * values returned by {@link #getAvailablePinLayouts()}.</div>
     *
     * @param pinLayout the pin layout for the new project
     */
    @PublishedMethod
    void setPinLayout(@Nullable ImplementationProperty pinLayout);

    /**
     * Alias for {@link #setvVIRTUALtargetSupport(boolean)}.
     */
    @PublishedMethod
    void vVIRTUALtargetSupport(boolean vVIRTUALtargetSupport);

    /**
     * Using {@link #setvVIRTUALtargetSupport(boolean)} it can be specified whether or not to support the vVIRTUALTarget for the new project.
     * <div class="extdoc" id="setvVIRTUALtargetSupport"><!--Label:ICreateProjectTargetApi.setvVIRTUALtargetSupport-->
     * <h5>vVIRTUALtarget Support</h5> Using {@link #setvVIRTUALtargetSupport(boolean)} it can be specified whether or not to support the vVIRTUALTarget for the new project.
     * This is an optional parameter defaulting to {@code false} if the parameter is not provided explicitly. The following constraints apply:
     * <ul>
     * <li>vVIRTUALtarget support may not be available depending on the purchased license</li>
     * </ul>
     * </div>
     *
     * @param vVIRTUALtargetSupport whether or not to support the vVIRTUALtarget for the new project
     */
    @PublishedMethod
    void setvVIRTUALtargetSupport(boolean vVIRTUALtargetSupport);

}
