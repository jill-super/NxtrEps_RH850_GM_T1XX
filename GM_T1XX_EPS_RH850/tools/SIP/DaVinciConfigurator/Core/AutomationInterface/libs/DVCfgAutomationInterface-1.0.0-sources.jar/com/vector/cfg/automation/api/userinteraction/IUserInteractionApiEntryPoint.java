package com.vector.cfg.automation.api.userinteraction;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUserInteractionApiEntryPoint {

    @PublishedMethod
    IUserInputApi getUserInputs();

    @PublishedMethod
    <T> T userInputs(@VDelegatesToWithClosureParam(IUserInputApi.class) Closure<T> inputCode);

    @PublishedMethod
    IUserInteractionApi getUserInteractions();

    @PublishedMethod
    <T> T userInteractions(@VDelegatesToWithClosureParam(IUserInteractionApi.class) Closure<T> interactionCode);
}
