package com.vector.cfg.gen.core.moduleinterface.fileservices;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The {@link ERetentionPolicy} specifies the life cycle of the folders or files created by the {@link IGenTempFileService}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum ERetentionPolicy {

    /**
     * Indicated that the file is deleted, when the project is closed.
     */
    PROJECT(3),
    /**
     * Indicated that the file is deleted, when the Generation phase ends.
     * <p>
     * Attention<br />
     * You can only create these files in the Validation/Generation phase.
     * </p>
     */
    VALIDATION_GENERATION_PROCESS(2),
    /**
     * Indicated that the file is deleted, when the Calculation phase ends.
     * <p>
     * Attention<br />
     * You can only create these files in the Calculation phase.
     * </p>
     */
    CALCULATION_PROCESS(1);

    private final int sequence;

    /**
     * Instantiates a new e retention policy.
     *
     * @param sequence the sequence
     */
    ERetentionPolicy(int sequence) {
        this.sequence = sequence;

    }

    /**
     * Checks if this retention policy allowed in the passed retention policy (assumedPolicy).
     *
     * @param assumedPolicy the current assumed policy
     * @return true, if is the retention policy allowed in current policy (assumedPolicy)
     */
    @PublishedMethod
    public boolean isTheRetentionPolicyAllowedInCurrentPolicy(ERetentionPolicy assumedPolicy) {

        if (this.sequence <= assumedPolicy.sequence) {
            return true;
        }

        return false;
    }

}
