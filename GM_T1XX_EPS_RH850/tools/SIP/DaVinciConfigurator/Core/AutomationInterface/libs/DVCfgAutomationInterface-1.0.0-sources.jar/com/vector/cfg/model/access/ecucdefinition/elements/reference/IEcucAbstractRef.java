package com.vector.cfg.model.access.ecucdefinition.elements.reference;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucCommonAttributes;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucParameterDefinition;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucAbstractRef extends IEcucParameterDefinition, IEcucCommonAttributes {

}
