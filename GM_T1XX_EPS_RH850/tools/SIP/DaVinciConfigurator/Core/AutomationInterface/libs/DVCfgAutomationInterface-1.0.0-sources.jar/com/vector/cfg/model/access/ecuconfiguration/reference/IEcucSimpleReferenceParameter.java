package com.vector.cfg.model.access.ecuconfiguration.reference;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucValueParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucSimpleReferenceParameter extends IEcucValueParameter<AsrPath> {

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    MIReferenceValue getEcucObject();

}
