package com.vector.cfg.consistency.contribution;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IHasDescription;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * This interface can be implemented by solving actions which want to deliver the description as mixed text.
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasDescriptionAsMixedText extends IHasDescription {
    /**
     * If a solving action implements this interface, this method is never called, and hence a default implementation is provided.
     */
    @Override
    @PublishedMethod
    default String getDescription() {
        return getDescriptionAsMixedText().toString();
    }

    /**
     * Gets the description as mixed text.
     *
     * @return the description as mixed text
     */
    @PublishedMethod
    IMixedText getDescriptionAsMixedText();
}
