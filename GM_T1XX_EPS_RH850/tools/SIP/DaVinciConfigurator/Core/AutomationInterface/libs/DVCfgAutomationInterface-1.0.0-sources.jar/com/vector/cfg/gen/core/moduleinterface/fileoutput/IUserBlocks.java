package com.vector.cfg.gen.core.moduleinterface.fileoutput;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 * <div class="extdoc" id="UserCodeBlocks"> {@link IUserBlocks} provides the interface to generate UserBlocks into an {@link IOutputFile}. In the format which
 * looks something like as follows:
 *
 * <pre>
 *  <code class="Java" id="UserCode block sample">
 * &#47;***********************************************************************
 *  DO NOT CHANGE THIS COMMENT!  &lt;USERBLOCK TagId&gt;     DO NOT CHANGE THIS COMMENT!
 * ***********************************************************************&#47;
 *     ....The default user block content ....
 * &#47;*********************************************************************
 *  DO NOT CHANGE THIS COMMENT!   &lt;&#47;USERBLOCK&gt;     DO NOT CHANGE THIS COMMENT!
 * **********************************************************************&#47;
 *  </code>
 * </pre>
 *
 *
 * <p>
 * <b>Initialization:</b><br/>
 * To Activate this Feature you should call the <code>AbstractOutputFile.enableUserBlockSupport()</code> method in the constructor of your {@link IOutputFile}.
 *
 *
 *
 * <pre>
 *  <code class="Java" id="UserBlock initialization sample - Constructor of OutputFile class">
 *    public MyFileWithBlocksC(IGeneratorPackage generatorPackage, MyDataRep dataRepresentation) {
 *         super("MyFile_Callout_Stubs.c", generatorPackage, dataRepresentation);
 *
 *         enableUserBlockSupport(); //Call this method to activate UserBlock support.
 *     }
 *  </code>
 * </pre>
 *
 * </p>
 * <p>
 * <b>Usage:</b><br/>
 * Then you can retrieve an instance of the {@link IUserBlocks} class by calling <code>getOutptFile(). getUserBlocks()</code> in your JET template. With the
 * instance you can generate UserBlocks or the UnrecognizedUserBlocksTag.
 *
 * <pre>
 *  <code class="Java" id="Generate a user block - In the JET template">
 *    &lt;% IUserBlocks userBlock =getOutptFile().getUserBlocks(); %&gt;
 *    ...
 *    &lt;%= userBlock.getUserBlockWithDefaultContent("MyBlock","MyDefault content")%&gt;
 *  </code>
 * </pre>
 *
 * </p>
 *
 * <p>
 * You should at least generate the UnrecognizedUserBlocksTag into your Output file by calling the method {@link #getUnrecognizedUserBlocksTag()} in you
 * JetTemplate, if you use UserCode blocks! This tag will trigger the generation of the unrecognized blocks at the specified location:
 *
 * <pre>
 *  <code class="Java" id="UnrecognizedUserBlocksTag sample">
 *  &#47;* Unrecognized UserBlocks Section *&#47;
 *  #if 0
 *  &#47;* UserBlocks here *&#47;
 *  #endif
 *    </code>
 * </pre>
 *
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 * @see AbstractOutputFile
 * @see IOutputFile
 * @see IGeneratedOutputFile
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IUserBlocks {

    /**
     * Gets the unrecognized user blocks tag. This method will generate a Tag which indicated where to write UserCodeBlocks which had no corresponding block in
     * the generated file.
     *
     * <p>
     * You have to include this String in your template.
     * </p>
     *
     * @return the unrecognized user blocks tag
     */
    @PublishedMethod
    String getUnrecognizedUserBlocksTag();

    /**
     * Gets a user block identified by the passed <code>tagId</code> with default content <code>defaultContent</code>.
     *
     * <p>
     * If no UserBlock was specified by the user, or no file was written. <br />
     * A default block with &lt;USERBLOCK tagId>*&#47;&#47;*&lt;/USERBLOCK&gt;
     * </p>
     *
     * <p>
     * If you want to identify the UserBlocks by a ModelObject( {@link MIHasDefinition}), you can use the UUIDs to recognize UserBlock through name changes.
     * </p>
     *
     * @param tagId the tag id
     * @param defaultContent the default content
     * @return the user block with default content
     *
     * @exception NullPointerException <ul>
     * <li>if the tagId is null</li>
     * <li>if the defaultContent is null</li>
     * </ul>
     * @exception IllegalArgumentException <ul>
     * <li>if the tagId is empty</li>
     * </ul>
     */
    @PublishedMethod
    String getUserBlockWithDefaultContent(String tagId, String defaultContent);

}
