package com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.IDescriptor;

/**
 * An {@link IRuleAlgorithmResult} represents the validation result for one context object of a particular {@link IRuleAlgorithm}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IRuleAlgorithmResult {
    /**
     * Returns whether the pre-condition is fulfilled. If it is not fulfilled, you can check whether the algorithm was executed at all or whether the algorithm
     * was blocked by another pre-condition with {@link IRuleAlgorithmResult#isConditionFulfilled()}
     *
     * @return
     */
    @PublishedMethod
    boolean isConditionFulfilled();

    /**
     * This returns whether the algorithm was executed at all. It may not be executable if the precondition-rule is blocked by one of its pre-condition rules
     * (chained precondition).
     *
     * @return
     */
    @PublishedMethod
    boolean algorithmExecuted();

    /**
     * Returns all CEs on which this result depends on.
     *
     * @return
     */
    @PublishedMethod
    Collection<IDescriptor> getGeneralCEs();
}
