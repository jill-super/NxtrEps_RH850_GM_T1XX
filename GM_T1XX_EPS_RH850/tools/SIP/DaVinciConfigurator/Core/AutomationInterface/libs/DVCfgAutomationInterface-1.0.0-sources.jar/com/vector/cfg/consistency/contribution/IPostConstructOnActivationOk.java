package com.vector.cfg.consistency.contribution;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.IProjectContext;

/**
 * An {@link IValidator} could implement the interface {@link IPostConstructOnActivationOk}, if the validator needs a hook method after the Consistency
 * activation check.
 *
 * <p>
 * Note: The interface {@link IConditionalActivation} is evaluated before this interface method is called.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IConditionalActivation
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@ThreadSafe
public interface IPostConstructOnActivationOk {

    /**
     * The method {@link #onActivationOk()} is called after the Consistency has verified, that the {@link IValidator} which implements the interface(
     * {@link IPostConstructOnActivationOk}), will be activated from the consistency. See {@link IConditionalActivation} for more detail.
     *
     * <p>
     * <b>Attention:</b> If you contribute the {@link IValidator} via an {@link IRuleFactory} which caches this instance (e.g. AbstractGeneratorPackage,
     * SwcValidationService), the {@link #onActivationOk()} method could be called more then once. E.g. when the Consistency is stopped and restarted with the
     * same {@link IProjectContext}!
     * </p>
     *
     * <p>
     * Note: The calling thread is arbitrary!
     * </p>
     */
    @PublishedMethod
    void onActivationOk();
}
