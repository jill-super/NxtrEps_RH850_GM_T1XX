package com.vector.cfg.automation.scripting.api.project;

import java.nio.file.Path;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.path.IHasURI;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IProjectRef} is a handle on a project not yet loaded but ready to be opened.
 *
 * <div class="extdoc" id="IProjectRef"><!--Label:IProjectRef-->{@link IProjectRef} is a handle on a project not yet loaded but ready to be opened. This could be used to open
 * the project.
 * <p>
 * {@link IProjectRef} instances can be obtained from form the following methods:
 * <ul>
 * <li>{@code IProjectHandlingApi.createProject(Closure)} <!--Ref:IProjectHandlingApi.createProject--></li>
 * <li>{@code IProjectHandlingApi.parameterizeProjectLoad(Closure)} <!--Ref:IProjectHandlingApi.parameterizeProjectLoad--></li>
 * </ul>
 * </p>
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 * @see IProject
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProjectRef extends IHasURI {

    /**
     * Returns the {@link Path} to the Dpa file of the referenced Project as absolute path.
     *
     * @return the project path to the Dpa file
     */
    @PublishedMethod
    Path getDpaProjectFilePath();

    /**
     * Opens this {@link IProjectRef}'s {@link IProject}. <div class="extdoc" id="openProject"><!--Label:IProjectRef.openProject-->The {@link IProject} is not really opened
     * until {@link IProjectRef#openProject(Closure)} is called. Here, the project is opened and the given {@link Closure} is executed on the opened project. When
     * {@link IProjectRef#openProject(Closure)} returns the project has already been closed.</div>
     *
     * @param code the code (a {@link Closure}) working with opened {@link IProject}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T openProject(@Nonnull @VDelegatesToWithClosureParam(IProject.class) Closure<T> code);

}
