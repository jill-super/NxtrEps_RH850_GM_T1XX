package com.vector.cfg.gen.core.bswmdmodel.groovy.api;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIModelFactory;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * {@link IBswmdModelApiEntryPoint} provides methods which allow retrieving BswmdModel objects in different ways .
 *
 * <div class="extdoc" id="Common"><!--Label:IBswmdModelApiEntryPoint-->
 * <p>
 * The <code>bswmdModelRead()</code> methods provide entry points to start navigation through the ActiveEcuc. Client code can use the {@link Closure} overloads to navigate into
 * the content of the found bswmd objects. Inside the called closure the related bswmd object is available as closure parameter.
 * </p>
 * <p>
 * The following types of entry points are provided here:
 * <ul>
 * <li>{@link #bswmdModelRead(WrappedTypedDefRef)} searches all objects with the specified definition and returns the BswmdModel instances</li>
 * <li>{@link #bswmdModelRead(MIHasDefinition, WrappedTypedDefRef)} returns the BswmdModel instance for the provided MDF model instance.</li>
 * </ul>
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswmdModelApiEntryPoint {

    /**
     * Return the BswmdModelFactory of the running script task. This could be used to access low level access methods of the generated BswmdModel.
     *
     * @return the bswmd model factory
     */
    @PublishedMethod
    GIModelFactory getBswmdModelFactory();

    /**
     * Calls the closure for each single bswmd object found with the specified {@link DefRef}.
     *
     *
     * @param <WRAPPER_TYPE> the bswmd model instance type
     * @param defRef an definition to search for
     * @return The found object list
     */
    @PublishedMethod
    <WRAPPER_TYPE extends GIModelObject> List<WRAPPER_TYPE> bswmdModelRead(@DelegatesTo.Target WrappedTypedDefRef<?, ?, ?, WRAPPER_TYPE> defRef,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "WRAPPER_TYPE") Closure<?> code);

    /**
     * Returns the bswmd objects found with the specified DefRef, or empty if no elements were found.
     *
     * @param <WRAPPER_TYPE> the bswmd model instance type
     * @param defRef an definition to search for
     * @return The found object list
     */
    @PublishedMethod
    <WRAPPER_TYPE extends GIModelObject> List<WRAPPER_TYPE> bswmdModelRead(WrappedTypedDefRef<?, ?, ?, WRAPPER_TYPE> defRef);

    /**
     * Returns the found bswmd object from the passed MDF model object.
     *
     *
     * @param <CONFIG_TYPE> the MDF model type
     * @param <WRAPPER_TYPE> the bswmd model instance type
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    <CONFIG_TYPE extends MIHasDefinition, WRAPPER_TYPE extends GIModelObject> WRAPPER_TYPE bswmdModelRead(
            CONFIG_TYPE obj,
            WrappedTypedDefRef<?, CONFIG_TYPE, ?, WRAPPER_TYPE> defRef);

    /**
     * Calls the closure on the found single bswmd object from the passed MDF model object.
     *
     *
     * @param <CONFIG_TYPE> the MDF model type
     * @param <WRAPPER_TYPE> the bswmd model instance type
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    <CONFIG_TYPE extends MIHasDefinition, WRAPPER_TYPE extends GIModelObject> WRAPPER_TYPE bswmdModelRead(
            CONFIG_TYPE obj,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "WRAPPER_TYPE") WrappedTypedDefRef<?, CONFIG_TYPE, ?, WRAPPER_TYPE> defRef,
            Closure<?> code);

}
