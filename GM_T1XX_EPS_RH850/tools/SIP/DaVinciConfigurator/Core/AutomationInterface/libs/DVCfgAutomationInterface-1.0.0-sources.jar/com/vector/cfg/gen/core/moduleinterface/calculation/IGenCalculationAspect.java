package com.vector.cfg.gen.core.moduleinterface.calculation;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects.IGeneratorPackageAspect;

/**
 * <div class="extdoc" id="Calculation_Common"> The GeneratorPackages have the possibility to change the Model before the Validation/Generation process is
 * started. This phase is called "Calculation". If a Generator wants to calculate something, the {@link IGeneratorPackage} has to provide and
 * {@link IGenCalculationAspect}, which has many {@link ICalculator} instances.
 *
 *
 * <pre>
 * <code class="Java" id="GenCalculationAspect registration">
 *  //Insert this code in your GeneratorPackage
 *
 * protected void registerGeneratorPackageAspects() {
 *    addPackageAspect(IGenCalculationAspect.class,
 *        GenCalculationAspect.create( &lt;Insert here your ICalculator instances&gt; ));
 * }
 * </code>
 * </pre>
 *
 * The calculation phase has subphases defined in the {@link ECalculationSubPhase} enum. A GeneratorPackage could have one {@link ICalculator} for each
 * subphase. defined in the enum {@link ECalculationSubPhase}.
 *
 * The class {@link GenCalculationAspect} provides create methods and a builder for an {@link IGenCalculationAspect}.
 *
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGenCalculationAspect extends IGeneratorPackageAspect {

    /**
     * Returns the {@link ICalculator} of the {@link IGeneratorPackage}.
     *
     * @param <T> the generic type
     * @return the calculators of the {@link IGeneratorPackage}.
     */
    @PublishedMethod
    <T extends ICalculator> List<T> getCalculators();
}
