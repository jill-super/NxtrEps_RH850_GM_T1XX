/**
 * DaVinci Configurator Core exceptions thrown by SIP queries.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.core.exceptions;