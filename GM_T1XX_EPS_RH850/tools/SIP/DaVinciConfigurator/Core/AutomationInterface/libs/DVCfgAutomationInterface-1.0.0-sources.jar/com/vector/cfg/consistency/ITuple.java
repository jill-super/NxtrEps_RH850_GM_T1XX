package com.vector.cfg.consistency;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.IDescriptor;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.<BR>
 * <BR>
 * An ITuple specifies a collection of CEs which form the context of a ValidationResult or of a CE dependency. <BR>
 * see {@link http://wiki.vi.vector.int/wiki-psc/Cfg5Development/Consistency}
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface ITuple {
    /**
     * See interface doc.
     */
    @PublishedMethod
    Collection<IDescriptor> getCEs();
}
