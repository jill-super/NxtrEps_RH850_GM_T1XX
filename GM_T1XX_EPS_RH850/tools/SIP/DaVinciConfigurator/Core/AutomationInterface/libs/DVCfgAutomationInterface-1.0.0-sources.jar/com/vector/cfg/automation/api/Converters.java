package com.vector.cfg.automation.api;

import java.nio.file.Path;
import java.util.function.Function;

import ru.novosoft.mdf.ext.MDFObject;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.ScriptExecutionContexts;
import com.vector.cfg.automation.scripting.base.paths.IAutomationPathsApi;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.util.version.IVersion;
import com.vector.cfg.util.version.Version;

/**
 * {@link Converters} provides general purpose {@link Function}s performing value conversions used throughout the automation interface.
 * <div class="extdoc" data-target-doc="AutomationInterfaceDocumentation" id="Converters"><!--Label:Converters-->{@link Converters} provides general purpose {@link Function}s
 * performing value conversions used throughout the automation interface. These converters are referenced from the AutomationInterface documentation wherever they apply. The
 * AutomationInterface is typed strongly. In some cases, however, e.g. when specifying file locations, it is desirable to allow for a range of possibly parameter types. This is
 * achieved by accepting parameters of type {@link Object} and converting the given parameters to the desired type.
 *
 * <p>
 * The following converters are provided:
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class Converters {

    @PublishedMethod
    private Converters() {
    }

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link Path}s. <div class="extdoc" id="TO_PATH">
     * <h5>TO_PATH</h5><!--Label:Converters.TO_PATH-->Attempts to convert arbitrary {@link Object}s to {@link Path}s using<br>
     * {@link IAutomationPathsApi#resolvePath(Object)} <!--Ref:IAutomationPathsApi.resolvePath-->.
     *
     * </div>
     */
    @PublishedField
    public static final Function<Object, Path> TO_PATH = object -> {

        return ScriptExecutionContexts.getCurrentContextOfThisThreadChecked().getPaths().resolvePath(object);

    };

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link Path}s. <div class="extdoc" id="TO_SCRIPT_PATH">
     * <h5>TO_SCRIPT_PATH</h5><!--Label:Converters.TO_SCRIPT_PATH-->Attempts to convert arbitrary {@link Object}s to {@link Path}s using
     * {@link IAutomationPathsApi#resolveScriptPath(Object)} <!--Ref:IAutomationPathsApi.resolveScriptPath-->.
     *
     * </div>
     */
    @PublishedField
    public static final Function<Object, Path> TO_SCRIPT_PATH = object -> {

        return ScriptExecutionContexts.getCurrentContextOfThisThreadChecked().getPaths().resolvePath(object);

    };

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link IVersion}s. <div class="extdoc" id="TO_VERSION">
     * <h5>TO_VERSION</h5><!--Label:Converters.TO_VERSION-->Attempts to convert arbitrary {@link Object}s to {@link IVersion}s. The following conversions are implemented:
     * <ul>
     * <li>For {@code null} or {@link IVersion} arguments the given argument is returned. No conversion is applied.</li>
     * <li>{@link String}s are converted using {@link Version#valueOf(String)}.</li>
     * <li>{@link Number}s are converted by converting the {@code int} obtained from {@link Number#intValue()} using {@link Version#valueOf(int)}.</li>
     * <li>All other {@link Object}s are converted by converting the {@link String} obtained from {@link Object#toString()}.</li>
     * </ul>
     * For thrown {@link Exception}s see the used functions described above.
     *
     * </div>
     */
    @PublishedField
    public static final Function<Object, IVersion> TO_VERSION = object -> {

        if (object == null || object instanceof IVersion) {
            return (IVersion) object;
        }

        if (object instanceof String) {
            return Version.valueOf((String) object);
        }

        if (object instanceof Number) {
            return Version.valueOf(((Number) object).intValue());
        }

        return Version.valueOf(object.toString());

    };

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link MDFObject}s. <div class="extdoc" id="TO_MDF">
     * <h5>TO_MDF</h5><!--Label:Converters.TO_MDF-->Attempts to convert arbitrary {@link Object}s to {@link MDFObject}s. The following conversions are implemented:
     * <ul>
     * <li>For {@code null} or {@link MDFObject} arguments the given argument is returned. No conversion is applied.</li>
     * <li>{@link IHasModelObject}s are converted using their {@link #getMdfModelElement()} method.</li>
     * <li>{@link IViewedModelObject}s are converted using their {@link #getMdfObject()} method.</li>
     * <li>For all other {@link Object}s {@link ClassCastException}s are thrown.</li>
     * </ul>
     * For thrown {@link Exception}s see the used functions described above.
     *
     * </div>
     */
    @PublishedField
    public static final Function<Object, MDFObject> TO_MDF = object -> {

        if (object == null || object instanceof MDFObject) {
            return (MDFObject) object;
        }

        if (object instanceof IHasModelObject) {
            return ((IHasModelObject) object).getMdfObject();
        }

        if (object instanceof IViewedModelObject) {
            return ((IViewedModelObject) object).getMdfObject();
        }

        // this will throw a class cast exception with appropriate information
        return (MDFObject) object;

    };

}
