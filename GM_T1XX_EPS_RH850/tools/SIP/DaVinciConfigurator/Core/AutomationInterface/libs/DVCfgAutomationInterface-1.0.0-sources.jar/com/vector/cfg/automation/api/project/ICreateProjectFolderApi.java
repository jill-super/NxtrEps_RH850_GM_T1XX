package com.vector.cfg.automation.api.project;

import java.nio.file.Path;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.api.Converters;
import com.vector.cfg.business.Constraints;

/**
 * {@link ICreateProjectFolderApi} provides means for specifying the new project's folders settings.
 * <div class="extdoc" id="ICreateProjectFolderApi"><!--Label:ICreateProjectFolderApi-->{@link ICreateProjectFolderApi} provides means for specifying the new project's folders
 * settings.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectFolderApi {

    /**
     * Alias for {@link #setEcucFileStructure(EEcucFileStructure)}.
     */
    @PublishedMethod
    void ecucFileStructure(@Nonnull EEcucFileStructure ecucFileStructure);

    /**
     * Using {@link #setEcucFileStructure(EEcucFileStructure)} the ECUC file structure for the new project can be specified.
     * <div class="extdoc" id="setEcucFileStructure"><!--Label:ICreateProjectFolderApi.setEcucFileStructure-->Using {@link #setEcucFileStructure(EEcucFileStructure)} the ECUC
     * file structure for the new project can be specified.<br/>
     * This is an optional parameter defaulting to {@link EEcucFileStructure#SINGLE_FILE} if the parameter is not provided explicitly.</div>
     *
     * @param ecucFileStructure the ECUC file structure for the new project
     */
    @PublishedMethod
    void setEcucFileStructure(@Nonnull EEcucFileStructure ecucFileStructure);

    /**
     * Alias for {@link #setModuleFilesFolder(Object)}.
     */
    @PublishedMethod
    void moduleFilesFolder(@Nonnull Object moduleFilesFolder);

    /**
     * Using {@link #setModuleFilesFolder(Object)} the module files folder for the new project can be specified.
     * <div class="extdoc" id="setModuleFilesFolder"><!--Label:ICreateProjectFolderApi.setModuleFilesFolder-->
     * <h5>Module Files Folder</h5> Using {@link #setModuleFilesFolder(Object)} the module files folder for the new project can be specified. This is an optional parameter
     * defaulting to ".\Appl\GenData" if the parameter is not provided explicitly. The value given here is converted to {@link Path} using {@link Converters#TO_PATH}
     * <!--Ref:Converters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project folder) should be given here. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </div>
     *
     * @param moduleFilesFolder the module files folder for the new project
     */
    @PublishedMethod
    void setModuleFilesFolder(@Nonnull Object moduleFilesFolder);

    /**
     * Alias for {@link #setTemplatesFolder(Object)}.
     */
    @PublishedMethod
    void templatesFolder(@Nonnull Object templatesFolder);

    /**
     * Using {@link #setTemplatesFolder(Object)} the templates folder for the new project can be specified.
     * <div class="extdoc" id="setTemplatesFolder"><!--Label:ICreateProjectFolderApi.setTemplatesFolder-->
     * <h5>Templates Folder</h5> Using {@link #setTemplatesFolder(Object)} the templates folder for the new project can be specified. This is an optional parameter defaulting to
     * ".\Appl\Source" if the parameter is not provided explicitly. The value given here is converted to {@link Path} using {@link Converters#TO_PATH}
     * <!--Ref:Converters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project folder) should be given here. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </div>
     *
     * @param templatesFolder the templates folder for the new project
     */
    @PublishedMethod
    void setTemplatesFolder(@Nonnull Object templatesFolder);

    /**
     * Alias for {@link #setServiceComponentFilesFolder(Object)}.
     */
    @PublishedMethod
    void serviceComponentFilesFolder(@Nonnull Object serviceComponentFilesFolder);

    /**
     * Using {@link #setServiceComponentFilesFolder(Object)} the service component files folder for the new project can be specified.
     * <div class="extdoc" id="setServiceComponentFilesFolder"><!--Label:ICreateProjectFolderApi.setServiceComponentFilesFolder-->
     * <h5>Service Components Folder</h5> Using {@link #setServiceComponentFilesFolder(Object)} the service component files folder for the new project can be specified. This is
     * an optional parameter defaulting to ".\Config\ServiceComponents" if the parameter is not provided explicitly. The value given here is converted to {@link Path} using
     * {@link Converters#TO_PATH} <!--Ref:Converters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project folder) should be given here. The following
     * constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </div>
     *
     * @param serviceComponentFilesFolder the service component files folder for the new project
     */
    @PublishedMethod
    void setServiceComponentFilesFolder(@Nonnull Object serviceComponentFilesFolder);

    /**
     * Alias for {@link #setApplicationComponentFilesFolder(Object)}.
     */
    @PublishedMethod
    void applicationComponentFilesFolder(@Nonnull Object applicationComponentFilesFolder);

    /**
     * Using {@link #setApplicationComponentFilesFolder(Object)} the application component files folder for the new project can be specified.
     * <div class="extdoc" id="setApplicationComponentFilesFolder"><!--Label:ICreateProjectFolderApi.setApplicationComponentFilesFolder-->
     * <h5>Application Components Folder</h5> Using {@link #setApplicationComponentFilesFolder(Object)} the application component files folder for the new project can be
     * specified. This is an optional parameter defaulting to ".\Config\ApplicationComponents" if the parameter is not provided explicitly. The value given here is converted to
     * {@link Path} using {@link Converters#TO_PATH} <!--Ref:Converters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project folder) should be given
     * here. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </div>
     *
     * @param applicationComponentFilesFolder the application component files folder for the new project
     */
    @PublishedMethod
    void setApplicationComponentFilesFolder(@Nonnull Object applicationComponentFilesFolder);

    /**
     * Alias for {@link #setLogFilesFolder(Object)}.
     */
    @PublishedMethod
    void logFilesFolder(@Nonnull Object logFilesFolder);

    /**
     * Using {@link #setLogFilesFolder(Object)} the log files folder for the new project can be specified.
     * <div class="extdoc" id="setLogFilesFolder"><!--Label:ICreateProjectFolderApi.setLogFilesFolder-->
     * <h5>Log Files Folder</h5> Using {@link #setLogFilesFolder(Object)} the log files folder for the new project can be specified. This is an optional parameter defaulting to
     * ".\Config\Log" if the parameter is not provided explicitly. The value given here is converted to {@link Path} using {@link Converters#TO_PATH}
     * <!--Ref:Converters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project folder) should be given here. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </div>
     *
     * @param logFilesFolder the log files folder for the new project
     */
    @PublishedMethod
    void setLogFilesFolder(@Nonnull Object logFilesFolder);

    /**
     * Alias for {@link #setMeasurementAndCalibrationFilesFolder(Object)}.
     */
    @PublishedMethod
    void measurementAndCalibrationFilesFolder(@Nonnull Object measurementAndCalibrationFilesFolder);

    /**
     * Using {@link #setMeasurementAndCalibrationFilesFolder(Object)} the measurement and calibration files folder for the new project can be specified.
     * <div class="extdoc" id="setMeasurementAndCalibrationFilesFolder"><!--Label:ICreateProjectFolderApi.setMeasurementAndCalibrationFilesFolder-->
     * <h5>Measurement And Calibration Files Folder</h5> Using {@link #setMeasurementAndCalibrationFilesFolder(Object)} the measurement and calibration files folder for the new
     * project can be specified. This is an optional parameter defaulting to ".\Config\McData" if the parameter is not provided explicitly. The folder object passed to the
     * method is converted to {@link Path} using {@link Converters#TO_PATH} <!--Ref:Converters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project
     * folder) should be given here. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </div>
     *
     * @param measurementAndCalibrationFilesFolder the measurement and calibration files folder for the new project
     */
    @PublishedMethod
    void setMeasurementAndCalibrationFilesFolder(@Nonnull Object measurementAndCalibrationFilesFolder);

    /**
     * Alias for {@link #setAutosarFilesFolder(Object)}.
     */
    @PublishedMethod
    void autosarFilesFolder(@Nonnull Object autosarFilesFolder);

    /**
     * Using {@link #setAutosarFilesFolder(Object)} the AUTOSAR files folder for the new project can be specified.
     * <div class="extdoc" id="setAutosarFilesFolder"><!--Label:ICreateProjectFolderApi.setAutosarFilesFolder-->
     * <h5>AUTOSAR Files Folder</h5> Using {@link #setAutosarFilesFolder(Object)} the AUTOSAR files folder for the new project can be specified. This is an optional parameter
     * defaulting to ".\Config\AUTOSAR" if the parameter is not provided explicitly. The value given here is converted to {@link Path} using {@link Converters#TO_PATH}
     * <!--Ref:Converters.TO_PATH-->. Normally a relative path (to be interpreted relative to the project folder) should be given here. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </div>
     *
     * @param autosarFilesFolder the AUTOSAR files folder for the new project
     */
    @PublishedMethod
    void setAutosarFilesFolder(@Nonnull Object autosarFilesFolder);

}
