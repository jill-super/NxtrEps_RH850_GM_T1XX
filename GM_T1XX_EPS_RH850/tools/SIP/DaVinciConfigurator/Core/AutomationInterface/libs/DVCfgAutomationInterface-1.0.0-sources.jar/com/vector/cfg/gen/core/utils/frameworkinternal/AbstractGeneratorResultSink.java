package com.vector.cfg.gen.core.utils.frameworkinternal;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.vector.cfg.consistency.EValidationSeverityType.INFO;

import java.text.MessageFormat;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasSetGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageException;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * This is not intended to be subclassed the a client.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public abstract class AbstractGeneratorResultSink implements IGeneratorResultSink {
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractGeneratorResultSink.class);

    private final IGeneratorPackage generatorPackage;

    /** The current highest severity. NULL is the lowest possible severity */
    private EValidationSeverityType currentHighestSeverity = null;

    /**
     * Constructor for GeneratorResultSinkWrapper.
     *
     * @param generatorPackage
     *
     * @param resultSink2
     */

    protected AbstractGeneratorResultSink(IGeneratorPackage generatorPackage) {
        this.generatorPackage = checkNotNull(generatorPackage);

    }

    protected AbstractGeneratorResultSink() {
        this.generatorPackage = null;

    }

    /**
     * {@inheritDoc}
     */

    @Override
    public IGeneratorPackage getGeneratorPackage() {
        if (generatorPackage == null) {
            throw new IllegalStateException("This ResultSink was not created with a GeneratorPackage.");
        }
        return generatorPackage;
    }

    /**
     * {@inheritDoc}
     */

    @Override
    public void reportGeneratorException(GeneratorPackageException ex) {
        if (ex == null) {
            throw new IllegalArgumentException("ex is null");
        }

        for (final IGeneratorResult genResult : ex.getGeneratorResultList()) {

            reportValidationResult(genResult);
        }
    }

    /**
     * {@inheritDoc}
     */

    @Override
    public void reportValidationResult(IValidationResult result) {
        if (result == null) {
            throw new IllegalArgumentException("result is null");
        }

        updateResultInformation(result);

        if (logger.isDebugEnabled()) {
            if (result instanceof IDebugable) {
                debug("Result added to ResultSink: {0}", ((IDebugable) result).toDebugString());
            } else {
                debug("Result added to ResultSink: {0}", result);

            }
        }

        reportValidationResultInternal(result);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public <T extends IValidationResult> void reportValidationResult(List<T> resultListParam) {
        if (resultListParam == null) {
            throw new IllegalArgumentException("resultListParam is null");
        }

        for (final T result : resultListParam) {
            reportValidationResult(result);
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isResultPresent() {
        return isResultPresent(INFO);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isResultPresent(EValidationSeverityType severity) {
        if (severity == null) {
            throw new IllegalArgumentException("severity is null");
        }

        final int value = compareSeverity(severity, getCurrentHighestSeverity());

        if (value == 0 || value > 0) {
            // The current Severity is higher then the requested return true, because there is a higher error level present
            return true;
        }

        return false;
    }

    @Override
    public void reportGeneratorResult(IGeneratorResult result) {
        if (result == null) {
            throw new IllegalArgumentException("result is null");
        }
        reportValidationResult(result);
    }

    protected abstract void reportValidationResultInternal(IValidationResult result);

    protected void resetCurrentSeverity() {
        setCurrentHighestSeverity(null);
    }

    private void updateResultInformation(IValidationResult result) {
        assignTheHighestSeverity(result);
        assignGeneratorPackage(result);
    }

    private synchronized EValidationSeverityType getCurrentHighestSeverity() {
        return currentHighestSeverity;
    }

    private synchronized void setCurrentHighestSeverity(EValidationSeverityType currentHighestSeverity) {
        this.currentHighestSeverity = currentHighestSeverity;
    }

    private synchronized void assignTheHighestSeverity(IValidationResult result) {

        final int value = compareSeverity(result.getSeverity(), getCurrentHighestSeverity());

        if (value < 0) {
            // The new severity is higher
            setCurrentHighestSeverity(result.getSeverity());
        }

    }

    /**
     * @param result
     */
    private void assignGeneratorPackage(IValidationResult result) {
        if (result instanceof IHasSetGeneratorPackage) {
            if (generatorPackage != null) {
                ((IHasSetGeneratorPackage) result).setGeneratorPackage(generatorPackage);
            }
        }

    }

    /**
     * Compare two severities.
     *
     * returns -1 if severity1 is higher then severity2 <br/>
     * Returns 0 if equals <br/>
     * Returns 1 if severity 1 is lower then severity2
     *
     * @param severity the severity
     * @param severity2 the severity2
     * @return the compare result
     */
    private int compareSeverity(EValidationSeverityType severity1, EValidationSeverityType severity2) {

        int value1;
        int value2;

        value1 = getIntFromSeverity(severity1);
        value2 = getIntFromSeverity(severity2);

        if (value1 < value2) {
            return -1;
        } else if (value1 == value2) {
            return 0;
        } else {
            return 1;
        }

    }

    /**
     * @param severity
     */
    private int getIntFromSeverity(EValidationSeverityType severity) {
        int value;

        if (severity == null) {
            /*
             * Null is the lowest severity
             */
            return Integer.MAX_VALUE;
        }

        switch (severity) {
        case FATAL_ERROR:
            value = 1;
            break;
        case ERROR:
            value = 2;
            break;
        case WARNING:
            value = 3;
            break;
        case IMPROVEMENT:
            value = 4;
            break;
        case INFO:
            value = 4;
            break;

        default:
            throw new IllegalArgumentException("Severity is out of range");
        }

        return value;
    }

    /*
     * LOGGING SECTION
     */

    private static void debug(String pattern, Object... arguments) {
        logger.debug(MessageFormat.format(pattern, arguments));
    }

    @SuppressWarnings("unused")
    private static void debug(String text) {
        logger.debug(text);
    }

    @SuppressWarnings("unused")
    private static void trace(String method, String pattern, Object... arguments) {
        logger.trace(method + ": " + MessageFormat.format(pattern, arguments));
    }

    @SuppressWarnings("unused")
    private static void trace(String method, String text) {
        logger.trace(method + ": " + text);
    }

}
