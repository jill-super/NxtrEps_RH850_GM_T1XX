package com.vector.cfg.automation.scripting.base;

import java.nio.file.Path;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.path.IHasURI;

/**
 * {@link IScriptPath} describes the file system location of an {@link IScript} or {@link IScriptContainer}.
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@Immutable
public interface IScriptPath extends Comparable<IScriptPath>, IHasURI {

    /**
     * Return the absolute file system {@link Path} the the script or script container.
     *
     * @return the absolute file system
     */
    @PublishedMethod
    Path toPath();

    /**
     * Returns the script name derived from the file system {@link Path}, see {@link #toPath()}.
     *
     * <p>
     * The naming rule will escape spaces, tabs and invalid file system characters to underscores.
     * </p>
     *
     * @return the script name
     */
    @PublishedMethod
    String getScriptName();
}
