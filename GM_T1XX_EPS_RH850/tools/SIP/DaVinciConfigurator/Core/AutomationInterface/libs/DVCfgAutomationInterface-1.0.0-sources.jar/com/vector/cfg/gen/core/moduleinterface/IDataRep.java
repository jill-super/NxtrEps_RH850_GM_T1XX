package com.vector.cfg.gen.core.moduleinterface;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;

/**
 * Base interface for all generator DataRepresentation implementations.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients. Please use abstract class AbstractDataRep
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IDataRep extends IGeneratorPackageReferable {

}
