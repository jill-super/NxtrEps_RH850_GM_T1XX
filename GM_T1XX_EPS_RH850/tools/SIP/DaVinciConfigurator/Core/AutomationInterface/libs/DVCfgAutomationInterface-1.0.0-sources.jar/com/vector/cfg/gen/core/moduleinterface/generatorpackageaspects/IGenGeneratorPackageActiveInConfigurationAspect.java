package com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IRequiresNoModuleDefinitionGeneratorPackage;

/**
 * <div class="extdoc" id="Common"> The {@link IGenGeneratorPackageActiveInConfigurationAspect} provides the ability to specify, if an {@link IGeneratorPackage}
 * is active in the UI in the current loaded configuration.
 *
 * <p>
 * The aspect could be used to disable a generator, if some input data is missing, e.g. some required SystemDescription data. This is especially useful for
 * {@link IRequiresNoModuleDefinitionGeneratorPackage}s. An example is the McSupportData generator, if no McSupportData is present in the loaded project, the
 * generator do not have any work to do, so it shall not be displayed to the user.
 * </p>
 *
 *
 * The {@link IGenGeneratorPackageActiveInConfigurationAspect} should be registered in the {@link IGeneratorPackage} and the following method must be
 * implemented:
 * <ul>
 * <li><code>isGeneratorPackageCurrentlyActive()</code> - shall return true, if the generator shall be display in the UI.</li>
 * </ul>
 *
 *
 * <p>
 * <b>Attention:</b><br/>
 * The implementation of this interface <b>must be</b> threadsafe, because this aspect is called from different threads!
 * </p>
 *
 * <pre>
 * <code class="Java" id="GeneratorPackageActiveInConfigurationAspect implementation sample">
 * public boolean  isGeneratorPackageCurrentlyActive(){
 *      //Access to model to determine if the required data is available
 *      boolean result = ...;
 *      return result
 * }
 * </code>
 * </pre>
 *
 *
 * <p>
 * The activation of the {@link IGeneratorPackage} is evaluated in the following order, a true means active:
 * <ul>
 * <li>If the {@link IGeneratorPackage} has an {@link IGenGeneratorPackageActiveInConfigurationAspect}. The aspect is evaluated and returned.</li>
 * <li>If the {@link IGeneratorPackage} implements IRequiresNoModuleDefinitionGeneratorPackage, <code>true</code> is returned.</li>
 * <li>If the project has a ModuleConfiguration matches the DefRef of the IGeneratorPackage, true is returned.</li>
 * <li>Otherwise false is returned.</li>
 * </ul>
 * </p>
 *
 * </div>
 *
 * <p>
 * See DAVID00128822:Provide PublishedAPI for RteVerify/Rte_proxy generator to determine, if generator is enabled in the GUI for display
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IGeneratorPackage
 * @see IGeneratorPackageAspect
 */
@ThreadSafe
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGenGeneratorPackageActiveInConfigurationAspect extends IGeneratorPackageAspect {

    /**
     * Returns <code>true</code>, if the generator shall currently be display in the UI.
     *
     * <p>
     * <b>Attention:</b> This method must be threadsafe, because it is called from different threads!
     * </p>
     *
     * @return true, if the generator shall be displayed, otherwise false.
     */
    @PublishedMethod
    boolean isGeneratorPackageCurrentlyActive();
}
