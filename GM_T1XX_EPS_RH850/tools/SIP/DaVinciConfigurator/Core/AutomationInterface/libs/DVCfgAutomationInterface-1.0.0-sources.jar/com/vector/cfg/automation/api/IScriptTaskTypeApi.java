package com.vector.cfg.automation.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.cfg.automation.scripting.api.EDefaultApplicationScriptTaskType;
import com.vector.cfg.automation.scripting.api.EDefaultProjectScriptTaskType;
import com.vector.cfg.automation.scripting.base.IScriptTaskType;
import com.vector.cfg.automation.scripting.base.IScriptTaskType.IApplicationScriptTaskType;
import com.vector.cfg.automation.scripting.base.IScriptTaskType.IProjectScriptTaskType;
import com.vector.cfg.gen.core.moduleinterface.automation.EGenerationAutomationScriptTaskType;
import com.vector.cfg.model.EModelAutomationScriptTaskType;

/**
 * {@link IScriptTaskTypeApi} defines all available {@link IScriptTaskType}s in the DaVinci Configurator.
 *
 * <div class="extdoc" id="Common"> The {@link IScriptTaskType} instances define where a script task is executed in the DaVinci Configurator. The types also define the arguments
 * passed to the script task execution and what return type an execution has.
 *
 * <p>
 * Every script task needs an {@link IScriptTaskType}. The type is set during creation of the script tasks.
 * </p>
 * </div>
 *
 * <div class="extdoc" id="TaskTypes">
 * <p>
 * The class {@link IScriptTaskTypeApi} defines all available {@link IScriptTaskType}s in the DaVinci Configurator. All task types start with the prefix <code>DV_</code>.
 * </p>
 *
 * <p>
 * <code>None</code> at parameters and return types mean, that any arguments could be passed and return to or from the task. Normally it will be nothing. The arguments are used,
 * when the task is called in unit tests for example.
 * </p>
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IScriptTaskType
 */
//@CHECKSTYLE:OFF Disable no methods in interface warning
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptTaskTypeApi {
    // @CHECKSTYLE:ON
    /**
     * The {@link #DV_APPLICATION} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_APPLICATION">
     * <h5>Application</h5> The type <b>{@link #DV_APPLICATION}</b> is for application wide script tasks. A task could create/open/close/update projects. Use this type, if you
     * need full control over the project handling, or you want to handle multiple project at once.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>Application</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_APPLICATION</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IApplicationScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td>None</td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td>None</td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Standalone</td>
     * </tr>
     * <tr>
     * <th>Required license option</th>
     * <td>Development: .WF Execution: .PRO</td>
     * </tr>
     * </table>
     *
     *
     * </div>
     *
     */
    @PublishedField
    IApplicationScriptTaskType DV_APPLICATION = EDefaultApplicationScriptTaskType.DV_APPLICATION;

    //@PublishedField
    //IApplicationScriptTaskType DV_WORKFLOW = EDefaultApplicationScriptTaskType.DV_WORKFLOW;

    /**
     * The {@link #DV_PROJECT} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_PROJECT">
     * <h5>Project</h5> The type <b>{@link #DV_PROJECT}</b> is for project script tasks. A task could access the currently loaded project. Manipulate the data, generate and save
     * the project. This is the default type, if no other type is specified.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>Project</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_PROJECT</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td>None</td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td>None</td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Standalone</td>
     * </tr>
     * <tr>
     * <th>Required license option</th>
     * <td>Development: .WF Execution: .PRO</td>
     * </tr>
     * </table>
     *
     *
     * </div>
     */
    @PublishedField
    IProjectScriptTaskType DV_PROJECT = EDefaultProjectScriptTaskType.DV_PROJECT;

    /**
     * The {@link #DV_EDITOR_SELECTION} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_EDITOR_SELECTION">
     * <h5>Editor selection</h5> The type <b>{@link #DV_EDITOR_SELECTION}</b> allows the script task to access the currently selected element of an editor. The task is executed
     * in context of the selection and is not callable by the user without an active selection.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>Editor selection</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_EDITOR_SELECTION</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td><code>MIObject selectedElement</code></td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>In context menu of an editor selection</td>
     * </tr>
     * <tr>
     * <th>Required license option</th>
     * <td>Development: .WF Execution: .PRO</td>
     * </tr>
     * </table>
     *
     *
     * </div>
     */
    @PublishedField
    IProjectScriptTaskType DV_EDITOR_SELECTION = EModelAutomationScriptTaskType.DV_EDITOR_SELECTION;

    /**
     * The {@link #DV_EDITOR_MULTI_SELECTION} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_EDITOR_MULTI_SELECTION">
     * <h5>Editor multiple selections</h5> The type <b>{@link #DV_EDITOR_MULTI_SELECTION}</b> allows the script task to access the currently selected elements of an editor. The
     * task is executed in context of the selection and is not callable by the user without an active selection. The type is also usable when the {@link #DV_EDITOR_SELECTION}
     * apply.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>Editor multiple selections</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_EDITOR_MULTI_SELECTION</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td><code>List&lt;MIObject&gt; selectedElements</code></td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>In context menu of an editor selection</td>
     * </tr>
     * <tr>
     * <th>Required license option</th>
     * <td>Development: .WF Execution: .PRO</td>
     * </tr>
     * </table>
     *
     *
     * </div>
     */
    @PublishedField
    IProjectScriptTaskType DV_EDITOR_MULTI_SELECTION = EModelAutomationScriptTaskType.DV_EDITOR_MULTI_SELECTION;

    /**
     * The {@link #DV_MODULE_ACTIVATION} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_MODULE_ACTIVATION">
     * <h5>Module activation</h5> The type <b>{@link #DV_MODULE_ACTIVATION}</b> allows the script to hook any Module Activation in a loaded project. Every
     * {@link #DV_MODULE_ACTIVATION} task is automatically executed, when an &quot;Activate Module&quot; operation is executed.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>Module activation</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_MODULE_ACTIVATION</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td><code>MIModuleConfiguration moduleConfiguration</code></td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Automatically during module activation</td>
     * </tr>
     * <tr>
     * <th>Required license option</th>
     * <td>Development: .WF Execution: .PRO</td>
     * </tr>
     * </table>
     *
     *
     * </div>
     *
     */
    @PublishedField
    IProjectScriptTaskType DV_MODULE_ACTIVATION = EModelAutomationScriptTaskType.DV_MODULE_ACTIVATION;

    /**
     * The {@link #DV_GENERATION_STEP} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_GENERATION_STEP">
     * <h5>Generation Step</h5> <!--LaTeX:\label{sec:TaskTypeGenStepDescription}--> The type <b>{@link #DV_GENERATION_STEP}</b> defines that the script task is executable as a
     * GenerationStep during generation. The user has to explicitly create an GenerationStep in the ProjectStettingsEditor, which references the script task.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>Generation Step</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_GENERATION_STEP</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td><code>EGenerationPhaseType phase</code></td>
     * </tr>
     * <tr>
     * <th></th>
     * <td><code>EGenerationProcessType processType</code></td>
     * </tr>
     * <tr>
     * <th></th>
     * <td><code>IValidationResultSink resultSink</code></td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Selected as GenerationStep in GenerationProcess</td>
     * </tr>
     * <tr>
     * <th>Required license option</th>
     * <td>Development: .MD Execution: None</td>
     * </tr>
     * </table>
     *
     * <!--LaTeX: See chapter \vref{sec:GenerationTasks} for usage samples.-->
     *
     * </div>
     *
     */
    @PublishedField
    IProjectScriptTaskType DV_GENERATION_STEP = EGenerationAutomationScriptTaskType.DV_GENERATION_STEP;

    /**
     * The {@link #DV_GENERATION_ON_START} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_GENERATION_ON_START">
     * <h5>Generation Process Start</h5> The type <b>{@link #DV_GENERATION_ON_START}</b> defines that the script task is automatically executed when the generation is started.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>Generation Process Start</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_GENERATION_ON_START</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td><code>List&lt;EGenerationPhaseType&gt; generationPhases</code></td>
     * </tr>
     * <tr>
     * <th></th>
     * <td><code>List&lt;IGenerator&gt; executedGenerators</code></td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Automatically before GenerationProcess</td>
     * </tr>
     * <tr>
     * <th>Required license option</th>
     * <td>Development: .MD Execution: None</td>
     * </tr>
     * </table>
     *
     * <!--LaTeX: See chapter \vref{sec:GenerationTasks} for usage samples.-->
     *
     * </div>
     *
     */
    @PublishedField
    IProjectScriptTaskType DV_GENERATION_ON_START = EGenerationAutomationScriptTaskType.DV_GENERATION_ON_START;

    /**
     * The {@link #DV_GENERATION_ON_END} {@link IScriptTaskType}.
     *
     * <div class="extdoc" id="DV_GENERATION_ON_END">
     * <h5>Generation Process End</h5> The type <b>{@link #DV_GENERATION_ON_END}</b> defines that the script task is automatically executed when the generation has finished.
     *
     * <table>
     * <tr>
     * <th>Name</th>
     * <td>Generation Process End</td>
     * </tr>
     * <tr>
     * <th>Code identifier</th>
     * <td>DV_GENERATION_ON_END</td>
     * </tr>
     * <tr>
     * <th>Task type interface</th>
     * <td>{@link IProjectScriptTaskType}</td>
     * </tr>
     * <tr>
     * <th>Parameters</th>
     * <td><code>EGenerationProcessResult processResult</code></td>
     * </tr>
     * <tr>
     * <th></th>
     * <td><code>List&lt;IGenerator&gt; executedGenerators</code></td>
     * </tr>
     * <tr>
     * <th>Return type</th>
     * <td><code>Void</code></td>
     * </tr>
     * <tr>
     * <th>Execution</th>
     * <td>Automatically after GenerationProcess</td>
     * </tr>
     * <tr>
     * <th>Required license option</th>
     * <td>Development: .MD Execution: None</td>
     * </tr>
     * </table>
     *
     * <!--LaTeX: See chapter \vref{sec:GenerationTasks} for usage samples.-->
     *
     * </div>
     *
     */
    @PublishedField
    IProjectScriptTaskType DV_GENERATION_ON_END = EGenerationAutomationScriptTaskType.DV_GENERATION_ON_END;

}
