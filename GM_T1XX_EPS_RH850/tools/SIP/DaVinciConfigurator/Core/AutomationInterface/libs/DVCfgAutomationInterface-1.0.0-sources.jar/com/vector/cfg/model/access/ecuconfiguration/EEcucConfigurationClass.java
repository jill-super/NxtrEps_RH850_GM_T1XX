package com.vector.cfg.model.access.ecuconfiguration;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.core.project.EConfigurationPhase;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucConfigurationClassEnum;

/**
 * This is the config class in AUTOSAR.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EEcucConfigurationClass {

    PRE_COMPILE,

    /**
     * This value is actually not supported currently.
     */
    LINK,

    POST_BUILD;

    /**
     * This method translates the MDF enum to this published enum. {@link MIEcucConfigurationClassEnum#PUBLISHED_INFORMATION} is not supported and the method returns
     * {@link #PRE_COMPILE} in this case.
     *
     * @param mdfConfigClass
     */
    @KeepSecretFromPublishedApi
    public static EEcucConfigurationClass fromMdf(MIEcucConfigurationClassEnum mdfConfigClass) {
        if (mdfConfigClass == null) {
            return PRE_COMPILE; // default
        }
        switch (mdfConfigClass) {
        case LINK:
            return LINK;
        case POST_BUILD:
            return POST_BUILD;
        default:
            return PRE_COMPILE;
        }
    }

    /**
     * Compares this enum value with the specified configuration phase. If this enum is smaller (earlier) than this configuration phase it returns -1. It returns 0 if both are
     * equal and 1 if this enum is larger (later) that this configuration phase.
     * <p>
     * <h1>Example</h1> Comparing {@link EEcucConfigurationClass#PRE_COMPILE} with {@link EConfigurationPhase#POST_BUILD} will return -1.
     * </p>
     *
     * @param configurationPhase
     * @return
     */
    @KeepSecretFromPublishedApi
    public int compareTo(EConfigurationPhase configurationPhase) {
        switch (this) {
        case PRE_COMPILE:
            if (configurationPhase == EConfigurationPhase.PRE_COMPILE) {
                return 0;
            }
            return -1;
        case LINK:
            if (configurationPhase == EConfigurationPhase.PRE_COMPILE) {
                return 1;
            } else if (configurationPhase == EConfigurationPhase.LINK_TIME) {
                return 0;
            }
            return -1;
        default: // POST_BUILD
            if (configurationPhase == EConfigurationPhase.POST_BUILD) {
                return 0;
            }
            return 1;
        }
    }

}
