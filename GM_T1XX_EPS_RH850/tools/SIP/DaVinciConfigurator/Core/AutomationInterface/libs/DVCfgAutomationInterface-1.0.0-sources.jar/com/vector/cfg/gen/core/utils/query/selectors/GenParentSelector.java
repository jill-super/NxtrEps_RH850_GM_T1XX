package com.vector.cfg.gen.core.utils.query.selectors;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.ElementSelector;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GenParentSelector<E extends GIHasContainer> extends ElementSelector<GIModelObject, E> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenParamSelector.class);

    @PublishedMethod
    public GenParentSelector() {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public E getSelection(GIModelObject childElement) {

        @SuppressWarnings("unchecked")
        final E parent = (E) childElement.getParent();

        return parent;
    }

}