package com.vector.cfg.gen.core.utils.abstractImpl;

import static com.google.common.base.Preconditions.checkNotNull;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.Map;

import javax.annotation.concurrent.ThreadSafe;

import com.google.common.base.Optional;
import com.google.common.collect.Maps;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGenerationProcessor;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageInitializationException;
import com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects.IGeneratorPackageAspect;
import com.vector.cfg.gen.core.utils.definitionrefs.GenDefinitionVerifier;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.query.definitionverify.AbstractDefinitionVerifier;
import com.vector.cfg.model.query.definitionverify.OptionalDefinitionDependency;
import com.vector.cfg.model.query.definitionverify.RequiredDefinitionDependency;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.version.IVersion;

/**
 * This class provides a skeletal implementation of the <tt>{@link IGeneratorPackage IGeneratorPackage}</tt> interface, to minimize the effort required to
 * implement this interface.
 *
 * <p>
 * The programmer must provide a void (no argument) constructor.
 * </p>
 *
 * <div class="extdoc" id="GeneratorPackageStates"> <h5>GeneratorPackage states</h5>A <code>GeneratorPackage</code> has two states:
 * <ol>
 * <li>Initialization <!--latex:(see \ref{subSec:GeneratorInitialization} for details)--></li>
 * <li>Execution <!--latex:(see \ref{subSec:GeneratorExecution} for details)--></li>
 * </ol>
 *
 * </div>
 *
 * <div class="extdoc" id="GeneratorInitialization"> <h2>Generator Initialization</h2><!--latex:\label{subSec:GeneratorInitialization}-->
 * <p>
 * The Initialization is called, when the project is loaded the initialization state will then call the initialize methods. You can override these methods to
 * add and adapt the generator functionality.
 * </p>
 * <!--latex:\includeJavaDoc{IDeployablePackage/InitializePackage}--> </div>
 *
 * <div class="extdoc" id="GeneratorExecution"> <h2>Generator Execution</h2><!--latex:\label{subSec:GeneratorExecution}-->
 * <p>
 * After the Initialization the generator is in the Execution state and can be called at any time, when the DaVinci Configurator will issue an generation
 * process. This will e.g. delegated to the {@link IGenerationProcessor}.
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 * @since 1.0
 * @author virtu
 * @see IGeneratorPackage
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public abstract class AbstractGeneratorPackage extends AbstractPackage implements IGeneratorPackage {
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractGeneratorPackage.class);

    private IGenerationProcessor generator;

    private GenDefinitionVerifier definitionVerifier;

    private Map<Class<? extends IGeneratorPackageAspect>, IGeneratorPackageAspect> aspectMapping = Maps.newHashMap();

    /**
     * Instantiates a new generator package.
     */
    @PublishedMethod
    protected AbstractGeneratorPackage() {

    }

    @Override
    final void ensureDataIsSetBeforeInit() {
        super.ensureDataIsSetBeforeInit();
        checkNotNull(getGeneratorVersionString(), "The generatorVersion must be set.");
        checkNotNull(getMSN(), "The MSN must be set.");
        checkNotNull(getGeneratorName(), "The GeneratorName must be set.");
        checkNotNull(getDescriptiveName(), "The DescriptiveName must be set.");

    }

    @Override
    void initBeforeEndPackagePrivate() {

        generator = registerGenerationProcessor();
        if (generator == null) {
            throw new IllegalStateException("The Generation Processor must not be null");
        }
    }

    /**
     * Verify preconditions of the Generator. For example check, if the DefinitionRef of the generator are available.
     *
     * <p>
     * The the Class {@link GenDefinitionVerifier} for more details
     * </p>
     *
     * <div class="extdoc" id="GenDefinitionVerifier_verifyGeneratorPreconditions"> The normal way to use the verification in your generator is to implement the
     * method <code>verifyGeneratorPreconditions()</code> in your {@link IGeneratorPackage GeneratorPackage} to verify for example DefRefs or other
     * dependencies.
     *
     * <pre>
     * <code  class="Java" id="verifyGeneratorPreconditions() implementation example in the GeneratorPackage">
     * //This code is in your GeneratorPackage class
     * protected void verifyGeneratorPreconditions() {
     *     // Preferred Way:
     *     // Use Your BswmdModelFactory to get all DefRef classes
     *     getDefinitionVerifier().verifyClasses(YourModelFactory.getAllDefRefClasses());
     *
     *
     *     // Or add each DefRef class explicitly
     *     getDefinitionVerifier().verifyClass(YourConstants.class);
     *     getDefinitionVerifier().verifyClass(YourBswmdModelDefRefs.class);
     * }
     * </code>
     * </pre>
     *
     * The first line in the sample with the <code>ModelFactory</code> is a convenient way to verify all classes with one call. This has the benefit, if a new
     * module is added you do not have to add a new line for the verifier call.
     *
     * </div>
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     */
    @Override
    @PublishedMethod
    protected void verifyGeneratorPreconditions() {
        // OVERRIDE THIS METHOD IF YOU WANT TO VERIFY THE PRECONDITIONS OF THE GENERATOR
    }

    /**
     * The {@link #initializeStartInternal()} method is used to perform initialization, before all other registrations (GenServices, Validators, ...) are done.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     */
    @Override
    @PublishedMethod
    protected void initializeStartInternal() {
        // OVERRIDE THIS METHOD IF YOU WANT TO EXECUTES CODE BEFORE THE NORMAL INITIALIZATION
    }

    /**
     * Register {@link IGeneratorPackageAspect}s.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     *
     */
    @PublishedMethod
    protected void registerGeneratorPackageAspects() {
        // OVERRIDE THIS METHOD IF YOU NEED A GENERATORPACKAGE ASPECT
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    protected void registerBswmdMigrationRules() {
        // OVERRIDE THIS METHOD IF YOU NEED THE BSWMD MIGRATION
    }

    /**
     * Adds a {@link IGeneratorPackageAspect} to this GeneratorPackage.
     *
     * @param aspectClass The class of the aspect
     * @param aspectImplementation The instance of the aspect
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the aspectClass is null</li>
     * <li>if the aspectImplementation is null</li>
     * </ul>
     * @exception IllegalStateException <ul>
     * <li>if there was already a aspectImplementation registered for the passed aspectClass.</li>
     * <li>if the initialization was already finished</li>
     * </ul>
     */
    @PublishedMethod
    protected final <T extends IGeneratorPackageAspect> void addPackageAspect(final Class<T> aspectClass, final T aspectImplementation) {
        if (aspectClass == null) {
            throw new IllegalArgumentException("aspectClass is null");
        }
        if (aspectImplementation == null) {
            throw new IllegalArgumentException("aspectImplementation is null");
        }

        ensureInitializationNotYetFinished();

        final IGeneratorPackageAspect existingElement = aspectMapping.put(aspectClass, aspectImplementation);
        if (existingElement != null) {
            throw new IllegalStateException("There is already a aspect registered for the class " + aspectClass.getName() + ". The aspect is " + existingElement
                    + " already registered. The new aspect to register is "
                    + aspectImplementation + ".");
        }
    }

    /**
     * Register internal {@link IGeneratorPackageAspect} before we call the subimplementation register.
     *
     */
    @Override
    void registerGeneratorPackageAspectsInternal() {

        // Call protected methods
        registerGeneratorPackageAspects();

        // Make aspectMap unmodifiable
        aspectMapping = Collections.unmodifiableMap(aspectMapping);

    }

    /**
     * The {@link #initializeEndInternal()} method is used to perform initialization, after all other registrations (GenServices, Validators, ...) are done.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     */
    @Override
    @PublishedMethod
    protected void initializeEndInternal() {
        // OVERRIDE THIS METHOD IF YOU WANT TO EXECUTES CODE AFTER THE NORMAL INITIALIZATION
    }

    /**
     * Gets the definition verifier of this {@link IGenerationProcessor}.
     *
     * <p>
     * See {@link #verifyGeneratorPreconditions()} for more details.
     * </p>
     *
     * @return the definition verifier
     *
     * @see AbstractDefinitionVerifier
     * @see RequiredDefinitionDependency
     * @see OptionalDefinitionDependency
     */
    @PublishedMethod
    protected final GenDefinitionVerifier getDefinitionVerifier() {
        checkNotNull(getProjectContext(), "The projectContext must be set.");
        if (definitionVerifier == null) {
            definitionVerifier = GenDefinitionVerifier.create(this);
        }
        return definitionVerifier;
    }

    /**
     * Register the generation processor.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     *
     * @return the generationProcessor
     */
    @PublishedMethod
    protected abstract IGenerationProcessor registerGenerationProcessor();

    /**
     * Register GenServices.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     *
     */
    @Override
    @PublishedMethod
    protected void registerGenServices() {
        // OVERRIDE THIS METHOD IF YOU NEED A GENSERVICE
    }

    /**
     * Adds a GenService to the {@link IGeneratorPackage}.
     *
     * @param <T> the generic type
     * @param clazz the class type of the service
     * @param service the service implementation object
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the clazz is null</li>
     * <li>if the service is null</li>
     * </ul>
     * @exception IllegalStateException <ul>
     * <li>if the initialization was already finished</li>
     * </ul>
     * @exception IllegalStateException <ul>
     * <li>if a service for the clazz already exists</li>
     * </ul>
     */
    @PublishedMethod
    protected final <T> void addGenService(final Class<T> clazz, final T service) {
        addGenService(getModuleDefinitionRef(), clazz, service);
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    public final <T extends IGeneratorPackageAspect> Optional<T> getPackageAspect(final Class<T> clazz) {

        if (clazz == null) {
            throw new IllegalArgumentException("clazz is null");
        }
        ensureInitializationFinished();

        final IGeneratorPackageAspect aspect = aspectMapping.get(clazz);
        if (aspect == null) {
            return Optional.absent();
        }

        return Optional.of((T) aspect);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final IGenerationProcessor getGenerationProcessor() {

        ensureInitializationFinished();

        if (generator == null) {
            throw new IllegalStateException("No Generator Found - The GeneratorPackage has not yet registered a Generator");
        }

        return generator;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final IGeneratorPackage getGeneratorPackage() {
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IVersion getArDefinitionSchemaVersion() {
        final DefRef defRefOfCurrentModule = getGeneratorPackage().getModuleDefinitionRef();

        if (defRefOfCurrentModule == null) {
            throw new IllegalStateException("getModuleDefinitionRef() is null. Is this a MultiModuleGenerator?");
        }

        final MIParamConfMultiplicity definitionObject = defRefOfCurrentModule.getDefinitionObject(getProjectContext());
        if (definitionObject != null) {
            final IVersion version = ModelUtil.getSchemaVersionOfMDFObject(definitionObject);
            if (version != null) {
                return version;
            }
        }

        throw new GeneratorPackageInitializationException(GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(this),
                "The ModuleDefinition({0:short}) of the generator does not exist in the model or has no version info. Can not retrieve the Ar schema version of the definition.",
                defRefOfCurrentModule).buildResult());
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * You could override this method to change the displayed origin of the ValdiationResults.
     */
    @Override
    @PublishedMethod
    public String getOrigin() {
        return getMSN().toUpperCase();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        try {
            return MessageFormat.format("{0}({1} - {2})", getGeneratorName(), getGeneratorVersionString(), getQualifiedJavaPackageName());
        } catch (final RuntimeException ex) {
            logger.error("GeneratorPackage (" + this.getClass().getName() + ") Exception occured during toString().", ex);
            return "GeneratorPackage (" + this.getClass().getName() + ")";
        }
    }

}
