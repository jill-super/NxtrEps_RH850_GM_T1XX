package com.vector.cfg.consistency.contribution.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class LoopExceptionHandler<T> extends CustomExceptionHandler {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(LoopExceptionHandler.class);

    private T currentObject;

    /**
     * Instantiates a new custom exception handler.
     */
    @PublishedMethod
    public LoopExceptionHandler() {

    }

    /**
     * Gets the object of the current iteration.
     *
     * <p>
     * Attention: You have to call {@link #setCurrentObject(Object)} before you can call this method.
     * </p>
     *
     * @return the current object
     *
     * @exception IllegalStateException <ul>
     * <li>if no current object was set</li>
     * </ul>
     */
    @PublishedMethod
    protected T getCurrentObject() {
        if (currentObject == null) {
            throw new IllegalStateException("No Current object assigned. You have to call setCurrentObject() before you can call getCurrentObject().");
        }
        return currentObject;
    }

    /**
     * Sets the object of the current iteration.
     *
     * @param currentObject the new current object
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the currentObject is null</li>
     * </ul>
     */
    @PublishedMethod
    public void setCurrentObject(T currentObject) {
        if (currentObject == null) {
            throw new IllegalArgumentException("currentObject is null");
        }
        this.currentObject = currentObject;
    }

}
