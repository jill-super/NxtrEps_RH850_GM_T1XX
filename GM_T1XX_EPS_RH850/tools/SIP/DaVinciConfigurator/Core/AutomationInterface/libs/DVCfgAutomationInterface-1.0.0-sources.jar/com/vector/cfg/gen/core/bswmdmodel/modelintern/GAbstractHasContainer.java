package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import java.util.List;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIExceptionCreator;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.gen.core.bswmdmodel.GIReferenceToContainer;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIEcucAddInfoParamValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GAbstractHasContainer extends GAbstractModelObject implements GIHasContainer {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GAbstractHasContainer.class);

    /**
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    protected GAbstractHasContainer(IInternalGeneratorModelAccess generatorModelAccess, MIHasDefinition mdfObject) {
        super(generatorModelAccess, mdfObject);
    }

    @PublishedMethod
    protected GAbstractHasContainer(IInternalGeneratorModelAccess generatorModelAccess, DefRef defRef, MIHasDefinition mdfObject) {
        super(generatorModelAccess, defRef, mdfObject);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getShortname() {
        try {
            switchView();
            return getMdfObject().getName();
        } finally {
            restoreView();
        }
    }

    void verifyWrapperClassWithList(WrappedTypedDefRef<?, ?, ?, ?> defRef, final List<? extends GIModelObject> list) {

        for (final GIModelObject bswmdObject : list) {
            verifyWrapperClass(defRef, bswmdObject);
            // We could break after the first element, because the factory must create the same element types
            break;
        }
    }

    /**
     * Verifies if the WrapperClass is instance of the GIModelObject class.
     *
     * @param defRef the WrappedTypedDefRef
     * @param bswmdObject the GIModelObject
     *
     * @throws IllegalStateException if the WrapperClass is not instance of the GIModelObject class
     */
    void verifyWrapperClass(WrappedTypedDefRef<?, ?, ?, ?> defRef, final GIModelObject bswmdObject) {

        final Class<?> wrapperClass = ((WrappedTypedDefRef<?, ?, ?, ?>) defRef).getModelWrapperClass();

        if (!(wrapperClass.isInstance(bswmdObject))) {
            throw new IllegalStateException(
                    "You shall use TypedDefRefs instead of WrappedTypedDefRefs, or use the Correct BswmdModelFactory (eG. <MSN>ModelFactory) instead of the GUntypedModelFactory. The WrapperClass "
                            + wrapperClass.getSimpleName() + " (BswmdModel) could not be mixed with a " + bswmdObject.getClass().getSimpleName() + " (DefRef-API Model).");
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setShortname(String newShortname) {
        final IModelViewManager vm = getGeneratorModelAccess().getModelViewManager();
        try (IModelViewExecutionContext viewContext = vm.executeWithModelView(getCreationModelView())) {
            try (IModelViewExecutionContext modeContext = vm.executeWithVariantSpecificModelChanges()) {
                getMdfObject().setName(newShortname);
            }
        }
    }

    private GIExceptionCreator getExCreator() {
        return getGenModelAccessInternal().getExceptionCreator();
    }

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * SubContainer section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean existsSubContainer(String defName) {
        try {
            return existsSubContainer(DefRef.create(this.getDefRef(), defName));
        } catch (final ModelException ex) {
            throw getExCreator().issueExceptionFromModelException(this, ex);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean existsSubContainer(DefRef defName) {
        try {
            return !getSubContainers(defName).isEmpty();
        } catch (final Exception e) {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final List<GIContainer> getSubContainers() {
        try {
            switchView();

            final List<GIContainer> contList = Lists.newArrayList();
            for (final MIContainer cont : getMdfObject().getSubContainer()) {
                contList.add((GIContainer) getGenModelAccessInternal().getGenModelObjectByMDFObject(cont));
            }
            return contList;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final List<GIContainer> getSubContainers(String defName) {
        try {
            return getSubContainers(DefRef.create(this.getDefRef(), defName));
        } catch (final ModelException ex) {
            throw getExCreator().issueExceptionFromModelException(this, ex);
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final List<GIContainer> getSubContainers(DefRef defRef) {

        try {
            switchView();

            final List<GIContainer> contList = Lists.newArrayList();
            final List<MIContainer> mdfContList = getGenModelAccessInternal().getMdfModelCheckedAccess().container(getMdfObject(), defRef).getManyContainers();
            for (final MIContainer cont : mdfContList) {
                if (defRef.isDefinitionOf(cont)) {
                    contList.add((GIContainer) getGenModelAccessInternal().getGenModelObjectByMDFObject(cont, defRef));
                } else {
                    throw getExCreator().issueInvalidRequestExceptionWithText(this,
                            MixedText.format("The element {0} below {1} does not conform the requested definition {2}.", cont, this, defRef), ImmutableList.of(cont));
                }
            }
            return contList;

        } catch (final ModelException ex) {
            throw getExCreator().issueExceptionFromModelException(this, ex);
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final <DEF extends MIContainerDef, CFG extends MIContainer, VALUE> List<GIContainer> getSubContainers(TypedDefRef<DEF, CFG, VALUE> defRef) {
        final DefRef defRefCasted = defRef;
        return getSubContainers(defRefCasted);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIContainerDef, CFG extends MIContainer, VALUE, WRAPPER extends GIContainer, T extends WRAPPER> List<T> getSubContainers(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {
        try {
            switchView();

            final List<GIContainer> subContainers = getSubContainers((TypedDefRef<DEF, CFG, VALUE>) defRef);

            verifyWrapperClassWithList(defRef, subContainers);

            @SuppressWarnings("unchecked")
            final List<T> wrapList = (List<T>) subContainers;

            return wrapList;
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public GIContainer getSubContainer(DefRef defRef) {
        try {
            switchView();

            final List<GIContainer> subContainers = getSubContainers(defRef);
            getModelVerifier().assertContainerIsExactyOneElement(getParentInternal(), subContainers, defRef);
            return subContainers.get(0);

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIContainerDef, CFG extends MIContainer, VALUE, WRAPPER extends GIContainer> WRAPPER getSubContainer(WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {
        try {
            switchView();

            final List<GIContainer> subContainers = getSubContainers((TypedDefRef<DEF, CFG, VALUE>) defRef);

            verifyWrapperClassWithList(defRef, subContainers);

            getModelVerifier().assertContainerIsExactyOneElement(getParentInternal(), subContainers, defRef);

            final WRAPPER result = defRef.getModelWrapperClass().cast(subContainers.get(0));

            return result;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final <DEF extends MIContainerDef, CFG extends MIContainer, VALUE> GIContainer getSubContainer(TypedDefRef<DEF, CFG, VALUE> defRef) {
        try {
            switchView();

            final List<GIContainer> subContainers = getSubContainers(defRef);
            getModelVerifier().assertContainerIsExactyOneElement(getParentInternal(), subContainers, defRef);
            return subContainers.get(0);

        } finally {
            restoreView();
        }
    }

    @PublishedMethod
    protected abstract GIHasContainer getParentInternal();

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * Parameter section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean existsParameter(DefRef defName) {
        try {
            return !getParameters(defName).isEmpty();
        } catch (final Exception e) {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE> List<GIParameter<VALUE>> getParameters(TypedDefRef<DEF, CFG, VALUE> defRef) {
        final DefRef defRefCasted = defRef;
        final List<GIParameter<?>> list = getParameters(defRefCasted);
        return (List) list;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<GIParameter<?>> getParameters(DefRef defRef) {
        try {
            switchView();

            final List<GIParameter<?>> refList = Lists.newArrayList();
            final IInternalGeneratorModelAccess modelAccess = getGenModelAccessInternal();

            for (final MIHasDefinition mdfParam : getManyElementsFromMca(defRef, false)) {
                if (mdfParam instanceof MINumericalValue || mdfParam instanceof MITextualValue || mdfParam instanceof MIEcucAddInfoParamValue) {
                    if (defRef.isDefinitionOf(mdfParam)) {
                        final GIParameter<?> ref = (GIParameter<?>) modelAccess.getGenModelObjectByMDFObject(mdfParam, defRef);
                        refList.add(ref);
                    } else {
                        throw getExCreator().issueInvalidRequestExceptionWithText(this,
                                MixedText.format("The element '{0}' below '{1}' does not conform the requested definition {2}.", mdfParam, this, defRef),
                                ImmutableList.of(mdfParam));
                    }
                } else {
                    throw getExCreator().issueInvalidRequestExceptionWithText(this,
                            MixedText.format("The element '{0}' below '{1}' is no Textual, Numerical or EcucAddInfo value.", mdfParam, this), ImmutableList.of(mdfParam));
                }
            }
            return refList;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE, WRAPPER extends GIParameter<VALUE>, T extends WRAPPER> List<T> getParameters(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {

        try {
            switchView();

            final List<GIParameter<VALUE>> params = getParameters((TypedDefRef<DEF, CFG, VALUE>) defRef);

            verifyWrapperClassWithList(defRef, params);

            @SuppressWarnings("unchecked")
            final List<T> wrapList = (List<T>) params;

            return wrapList;
        } finally {
            restoreView();
        }
    }

    private Iterable<? extends MIHasDefinition> getManyElementsFromMca(DefRef defRef, boolean isRef) {
        final IInternalGeneratorModelAccess modelAccess = getGenModelAccessInternal();

        try {
            Iterable<? extends MIHasDefinition> list;
            if (defRef instanceof TypedDefRef<?, ?, ?>) {
                list = modelAccess.getMdfModelCheckedAccess().simple().getManyElements(getMdfObject(), (TypedDefRef<?, ?, ?>) defRef);
            } else if (isRef) {
                list = modelAccess.getMdfModelCheckedAccess().reference(getMdfObject(), defRef).getManyReferences();
            } else {
                list = modelAccess.getMdfModelCheckedAccess().parameter(getMdfObject(), defRef).getManyParams();
            }
            return list;

        } catch (final ModelException ex) {
            throw getExCreator().issueExceptionFromModelException(this, ex);
        }
    }

    /*
     * ----------------------------------------------------------------------------------------------------------------------------
     * Reference section
     * ----------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean existsReference(DefRef defName) {
        try {
            return !getReferences(defName).isEmpty();
        } catch (final Exception e) {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable> List<GIReference<VALUE>> getReferences(TypedDefRef<DEF, CFG, VALUE> defRef) {
        final DefRef defRefCasted = defRef;
        final List<GIReference<?>> list = getReferences(defRefCasted);
        return (List) list;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE> List<GIReferenceToContainer> getReferencesToContainer(TypedDefRef<DEF, CFG, VALUE> defRef) {
        final List<GIReference<?>> list = getReferences(defRef);
        return (List) list;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @PublishedMethod
    @Override
    public List<GIReferenceToContainer> getReferencesToContainer(DefRef defRef) {
        final List<GIReference<?>> list = getReferences(defRef);

        for (final GIReference<?> ref : list) {
            if (!(ref instanceof GIReferenceToContainer)) {
                throw getExCreator().issueInvalidRequestExceptionWithText(this,
                        MixedText.format("The requested element '{0}' below '{1}' is no Reference to a container.", ref, this), ImmutableList.of(ref.getMdfObject()));
            }
        }
        return (List) list;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public List<GIReference<?>> getReferences(DefRef defRef) {

        try {
            switchView();

            final List<GIReference<?>> refList = Lists.newArrayList();
            final IInternalGeneratorModelAccess modelAccess = getGenModelAccessInternal();

            for (final MIHasDefinition mdfParam : getManyElementsFromMca(defRef, true)) {
                if (mdfParam instanceof MIReferenceValue || mdfParam instanceof MIInstanceReferenceValue) {
                    if (defRef.isDefinitionOf(mdfParam)) {

                        final GIReference<?> ref = (GIReference<?>) modelAccess.getGenModelObjectByMDFObject(mdfParam, defRef);
                        refList.add(ref);

                    } else {
                        throw getExCreator().issueInvalidRequestExceptionWithText(this,
                                MixedText.format("The element '{0}' below '{1}' does not conform the requested definition {2}.", mdfParam, this, defRef),
                                ImmutableList.of(mdfParam));
                    }

                } else {
                    throw getExCreator().issueInvalidRequestExceptionWithText(this, MixedText.format("The element '{0}' below '{1}' is no Reference.", mdfParam, this),
                            ImmutableList.of(mdfParam));
                }

            }
            return refList;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable, WRAPPER extends GIReference<VALUE>, T extends WRAPPER> List<T> getReferences(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {
        try {
            switchView();

            final List<GIReference<VALUE>> refs = getReferences((TypedDefRef<DEF, CFG, VALUE>) defRef);

            verifyWrapperClassWithList(defRef, refs);

            @SuppressWarnings("unchecked")
            final List<T> wrapList = (List<T>) refs;

            return wrapList;
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE, WRAPPER extends GIReferenceToContainer, T extends WRAPPER> List<T> getReferencesToContainer(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef) {
        try {
            switchView();

            final List<GIReferenceToContainer> refs = getReferencesToContainer((TypedDefRef<DEF, CFG, VALUE>) defRef);

            verifyWrapperClassWithList(defRef, refs);

            @SuppressWarnings("unchecked")
            final List<T> wrapList = (List<T>) refs;

            return wrapList;
        } finally {
            restoreView();
        }
    }
}
