package com.vector.cfg.gen.core.utils.time;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.concurrent.TimeUnit;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The GenTime class abstracts values of different time bases for calculation at the same time base.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenTime {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenTime.class);

    // Constants for conversion to nanoseconds
    private static final long MICRO_CONST = 1000L;

    private static final long MILLI_CONST = MICRO_CONST * 1000L;

    private static final long SECOND_CONST = MILLI_CONST * 1000L;

    /*
     * Members
     */
    private final long nanoInternal;

    /*
     * Constructors
     */
    /**
     * Constructor for GenTime.
     *
     * @param value
     * @param unit
     */
    private GenTime(long value, TimeUnit unit) {
        if (value < 0) {
            throw new IllegalArgumentException("The value " + value + " is negative. A Negative value could not be converted to an time.");
        }
        checkUnit(unit);
        nanoInternal = unit.toNanos(value);
    }

    /**
     * Constructor for GenTime.
     *
     * @param value
     * @param unit
     */
    private GenTime(double value, TimeUnit unit) {

        if (Double.isNaN(value) || Double.isInfinite(value)) {
            throw new IllegalArgumentException("The value " + value + " is NaN or pos/neg Infinitiy. These values are not allowed");
        }
        if (value < 0) {
            throw new IllegalArgumentException("The value " + value + " is negative. A Negative value could not be converted to an time.");
        }

        checkUnit(unit);
        nanoInternal = convertDoubleToLongNano(value, unit);

    }

    /**
     * Build the {@link GenTime} object from a value with the given {@link TimeUnit}.
     *
     * @param value The value in unit as long
     * @param unit The {@link TimeUnit} of the passed value
     * @return The new {@link GenTime} object
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the unit is null</li>
     * <li>if the unit has the value DAYS,HOURS or MINUTES.</li>
     * <li>if the value is < 0</li>
     * </ul>
     */
    @PublishedMethod
    public static GenTime valueOf(long value, TimeUnit unit) {
        return new GenTime(value, unit);
    }

    /**
     * Build the {@link GenTime} object from a value with the given {@link TimeUnit}.
     *
     * @param value The value in unit as long
     * @param unit The {@link TimeUnit} of the passed value
     * @return The new {@link GenTime} object
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the unit is null</li>
     * <li>if the unit has the value DAYS,HOURS or MINUTES.</li>
     * <li>if the value is < 0</li>
     * </ul>
     */
    @PublishedMethod
    public static GenTime valueOf(BigInteger value, TimeUnit unit) {
        return new GenTime(value.longValue(), unit);
    }

    /**
     * Build the {@link GenTime} object from a value with the given {@link TimeUnit}.
     *
     * @param value The value in unit as double
     * @param unit The {@link TimeUnit} of the passed value
     * @return The new {@link GenTime} object
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the unit is null</li>
     * <li>if the unit has the value DAYS,HOURS or MINUTES.</li>
     * <li>if the value is < 0</li>
     * <li>if the value is NaN, positive Infinity or negative Infinity</li>
     * <li>if the value is < 1 and the unit is NANOSECONDS</li>
     * </ul>
     */
    @PublishedMethod
    public static GenTime valueOf(double value, TimeUnit unit) {

        return new GenTime(value, unit);
    }

    /**
     * Build the {@link GenTime} object from a value with the given {@link TimeUnit}.
     *
     * @param value The value in unit as double
     * @param unit The {@link TimeUnit} of the passed value
     * @return The new {@link GenTime} object
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the unit is null</li>
     * <li>if the unit has the value DAYS,HOURS or MINUTES.</li>
     * <li>if the value is < 0</li>
     * <li>if the value is NaN, positive Infinity or negative Infinity</li>
     * <li>if the value is < 1 and the unit is NANOSECONDS</li>
     * </ul>
     */
    @PublishedMethod
    public static GenTime valueOf(BigDecimal value, TimeUnit unit) {

        return new GenTime(value.doubleValue(), unit);
    }

    /**
     * Converts a double value into the internal nanoseconds.
     *
     * @param value
     * @param unit
     * @return
     */
    private long convertDoubleToLongNano(double value, TimeUnit unit) {
        long result;

        switch (unit) {
        case NANOSECONDS:
            if (value < 1) {
                throw new IllegalArgumentException("The value " + value + " is < 1, and the uint is ns. A Value < 1 could not be converted to nanoseconds.");
            }
            result = Math.round(value);
            break;
        case MICROSECONDS:
            result = Math.round(value * MICRO_CONST);
            break;
        case MILLISECONDS:
            result = Math.round(value * MILLI_CONST);
            break;

        case SECONDS:
            result = Math.round(value * SECOND_CONST);
            break;
        default:
            throw new IllegalStateException("Wrong unit type");

        }
        return result;
    }

    private double convertLongNanoToDouble(long value, TimeUnit unit) {
        double result;
        final double valueDouble = value;

        switch (unit) {
        case NANOSECONDS:
            result = valueDouble;
            break;
        case MICROSECONDS:
            result = valueDouble / MICRO_CONST;
            break;
        case MILLISECONDS:
            result = valueDouble / MILLI_CONST;
            break;

        case SECONDS:
            result = valueDouble / SECOND_CONST;
            break;
        default:
            throw new IllegalStateException("Wrong unit type");

        }
        return result;
    }

    private void checkUnit(TimeUnit unit) {
        if (unit == null) {
            throw new IllegalArgumentException("unit is null");
        }
        switch (unit) {
        case DAYS:
        case HOURS:
        case MINUTES:
            throw new IllegalArgumentException("The unit type:" + unit + " is not supported");

        default:
            break;
        }
    }

    /**
     * Converts the {@link GenTime} into nanoseconds.
     *
     * @return The nanoseconds of the {@link GenTime}.
     */
    @PublishedMethod
    public long toNanos() {
        return nanoInternal;
    }

    /**
     * Converts the {@link GenTime} into microseconds.
     *
     * @return The microseconds of the {@link GenTime}.
     */
    @PublishedMethod
    public long toMicros() {
        return TimeUnit.NANOSECONDS.toMicros(nanoInternal);
    }

    /**
     * Converts the {@link GenTime} into milliseconds.
     *
     * @return The milliseconds of the {@link GenTime}.
     */
    @PublishedMethod
    public long toMillis() {
        return TimeUnit.NANOSECONDS.toMillis(nanoInternal);
    }

    /**
     * Converts the {@link GenTime} into seconds.
     *
     * @return The seconds of the {@link GenTime}.
     */
    @PublishedMethod
    public long toSeconds() {
        return TimeUnit.NANOSECONDS.toSeconds(nanoInternal);
    }

    /**
     * Converts the {@link GenTime} into the passed time unit.
     *
     * @return The value in the new time unit.
     */
    @PublishedMethod
    public long convert(TimeUnit unit) {
        checkUnit(unit);
        return unit.convert(nanoInternal, TimeUnit.NANOSECONDS);
    }

    /**
     * Converts the {@link GenTime} into the passed time unit and returns a double value.
     *
     * @return The value in the new time unit.
     */
    @PublishedMethod
    public double convertToDouble(TimeUnit unit) {
        checkUnit(unit);
        return convertLongNanoToDouble(nanoInternal, unit);
    }
}
