package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.function.Supplier;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIModuleConfiguration;
import com.vector.cfg.model.access.AsrObjectLink;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.state.CeStatePublishedFactory;
import com.vector.cfg.model.state.ICeStatePublished;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;

/**
 * The abstract base class for bswmd model all model objects.
 *
 * <p>
 * Attention: Please use {@link GIModelObject} interface in client code.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see GIModelObject
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GAbstractModelObject implements GIModelObject {

    private final IInternalGeneratorModelAccess generatorModelAccess;

    /**
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    protected GAbstractModelObject(@Nonnull IInternalGeneratorModelAccess generatorModelAccess, @Nullable MIHasDefinition mdfObject) {
        this.generatorModelAccess = generatorModelAccess;
        generatorModelAccess.assertIsBoundViewActive();

        if (mdfObject != null) {
            generatorModelAccess.setRelatedElement(this, mdfObject);
        }
    }

    @PublishedMethod
    protected GAbstractModelObject(@Nonnull IInternalGeneratorModelAccess generatorModelAccess, @Nonnull DefRef defRef, @Nullable MIHasDefinition mdfObject) {
        this.generatorModelAccess = generatorModelAccess;
        generatorModelAccess.assertIsBoundViewActive();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean isInstanceOfDefRef(DefRef defRef) {
        try {
            switchView();
            return defRef.isDefinitionOf(getMdfObject());
        } finally {
            restoreView();
        }
    }

    @Nullable
    MIHasDefinition getMdfObjectUnsafe() {
        return getMdfObject();
    }

    /**
     * Switches the current view to the bound view.
     */
    @PublishedMethod
    protected final void switchView() {
        getGenModelAccessInternal().switchView();
    }

    /**
     * Restores the old view.
     */
    @PublishedMethod
    protected final void restoreView() {
        getGenModelAccessInternal().restoreView();
    }

    /**
     * Assert is bound view active.
     */
    @PublishedMethod
    protected final void assertIsBoundViewActive() {
        getGenModelAccessInternal().assertIsBoundViewActive();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    protected void invalidateCache() {

    }

    /**
     * Check cache and invalidate if necessary.
     *
     * <p>
     * <b>Attention:</b> DO NOT USE THIS METHOD. THIS METHOD IS INTERNALLY USED!!!
     * </p>
     */
    @PublishedMethod
    protected void checkCacheAndInvalidateIfNecessary() {
        getGenModelAccessInternal().checkCacheAndInvalidateIfNecessary();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public ICeStatePublished getCeState() {

        try {
            switchView();

            return CeStatePublishedFactory.INSTANCE.createCeStateSystem(getMdfObject());
        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public GIModelAccess getGeneratorModelAccess() {
        return generatorModelAccess;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    public final IInternalGeneratorModelAccess getGenModelAccessInternal() {
        return generatorModelAccess;
    }

    /**
     * Gets the model verifier.
     *
     * @return the model verifier
     */
    @PublishedMethod
    protected final GIModelVerifier getModelVerifier() {
        return generatorModelAccess.getModelVerifier();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getObjectLink() {
        try {
            switchView();

            return AsrObjectLink.create(getMdfObject()).getObjectLinkString();

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public GIHasContainer getParent(DefRef parentDefRef) {
        checkNotNull(parentDefRef);
        if (!parentDefRef.isParentOf(getDefRef())) {
            throw new IllegalArgumentException("The passed parent " + parentDefRef + " could not be a parent of " + getDefRef() + ".");
        }
        try {
            switchView();

            final MIHasContainer parentByDefinition = getGeneratorModelAccess().getMdfModelAccess().getParentByDefinition(getMdfObject(), parentDefRef);
            if (parentByDefinition == null) {
                throw new AssertionError("This should never happen, becuase we have alredy checked, that the DefRef is the Parent!");
            }
            return (GIHasContainer) getGeneratorModelAccess().getGenModelObjectByMDFObject(parentByDefinition, parentDefRef);

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <DEF extends MIParamConfMultiplicity, CFG extends MIHasDefinition, VAL, WRAPPER extends GIHasContainer> WRAPPER getParent(
            WrappedTypedDefRef<DEF, CFG, VAL, WRAPPER> parentDefRef) {
        checkNotNull(parentDefRef);

        if (!parentDefRef.isParentOf(getDefRef())) {
            throw new IllegalArgumentException("The passed parent " + parentDefRef + " could not be a parent of " + getDefRef() + ".");
        }
        try {
            switchView();

            final DefRef parentCasted = parentDefRef;
            final GIHasContainer parent = getParent(parentCasted);

            final WRAPPER castedParent = parentDefRef.getModelWrapperClass().cast(parent);
            return castedParent;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public GIModuleConfiguration getModuleConfiguration() {

        if (getParent() == null && this instanceof GIModuleConfiguration) {
            return (GIModuleConfiguration) this;
        } else {
            return getParent().getModuleConfiguration();
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IModelView getCreationModelView() {
        return getGenModelAccessInternal().getCreationModelView();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IModelViewExecutionContext executeWithCreationModelView() {
        return getGeneratorModelAccess().getModelViewManager().executeWithModelView(getCreationModelView());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <T> T executeWithCreationModelView(Supplier<T> code) {
        try (IModelViewExecutionContext ctx = executeWithCreationModelView()) {
            return code.get();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void executeWithCreationModelView(Runnable code) {
        try (IModelViewExecutionContext ctx = executeWithCreationModelView()) {
            final IProjectContext projectContext = getGeneratorModelAccess().getProjectContext();
            if (projectContext.isServiceAvailable(IBswmdModelUpperLayerExtensions.class)) {
                projectContext.getService(IBswmdModelUpperLayerExtensions.class).executeWithCreationModelView(this, code);
            } else {
                code.run();
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public <T extends GIModelObject> T getInstanceInContextOfCreationModelView(Class<T> giModelClazz, MIHasDefinition mdfCfgElement) {
        return getGeneratorModelAccess().getFactory().getInstance(giModelClazz, mdfCfgElement, getCreationModelView());
    }

}
