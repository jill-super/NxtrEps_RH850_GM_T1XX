package com.vector.cfg.consistency.contribution;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * This interface informs a validator about the model changes that triggered the validator.
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IValidationEvents {

    /**
     * Returns a collection of {@link IRuleEvent}. The order has no meaning and is not related to the order in which the changes occurred.
     *
     * @return the events
     */
    @PublishedMethod
    Collection<IRuleEvent> getEvents();
}