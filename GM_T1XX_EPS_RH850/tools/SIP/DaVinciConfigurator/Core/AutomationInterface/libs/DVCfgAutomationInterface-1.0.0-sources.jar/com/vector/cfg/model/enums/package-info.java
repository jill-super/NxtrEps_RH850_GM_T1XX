/**
 * Classes to convert Model objects and values to Java enums and back.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.model.enums;