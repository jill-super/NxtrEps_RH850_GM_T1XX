package com.vector.cfg.gen.core.moduleinterface.fileservices;

import java.io.File;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * The IGenTempFileService interface. This service provides a handling for temporary files, when executing a generator.
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenTempFileService {

    /**
     * Creates a new temporary folder.
     *
     * <p>
     * Please read {@link ERetentionPolicy} javadoc for more details to the retentionPolicy
     * </p>
     *
     * @param prefix the prefix
     * @param policy the policy
     * @return The new Created Folder
     *
     * @exception NullPointerException <ul>
     * <li>if policy is null</li>
     * </ul>
     * @exception IllegalStateException <ul>
     * <li>if policy is not the same as the parent policy</li>
     * </ul>
     */
    @PublishedMethod
    File createTempFolder(String prefix, ERetentionPolicy policy);

    /**
     * Creates a new temporary folder.
     *
     * <p>
     * Please read {@link ERetentionPolicy} javadoc for more details to the retentionPolicy
     * </p>
     *
     * <p>
     * Attention: The parentFolder, must be created with the method {@link #createTempFolder(String, ERetentionPolicy)} or
     * {@link #createTempFolder(File, String, ERetentionPolicy)} and the same retention policy!
     * </p>
     *
     * @param parentFolder the parent folder
     * @param prefix the prefix
     * @param policy the policy
     * @return The new created folder
     *
     * @exception NullPointerException <ul>
     * <li>if policy is null</li>
     * </ul>
     * @exception IllegalStateException <ul>
     * <li>if policy is not the same as the parent policy</li>
     * </ul>
     */
    @PublishedMethod
    File createTempFolder(File parentFolder, String prefix, ERetentionPolicy policy);

    /**
     * Creates a new temporary file.
     * <p>
     * Please read {@link ERetentionPolicy} javadoc for more details to the retentionPolicy
     * </p>
     *
     * <p>
     * Attention: The parentFolder, must be created with the method {@link #createTempFolder(String, ERetentionPolicy)} or
     * {@link #createTempFolder(File, String, ERetentionPolicy)} and the same retention policy!
     * </p>
     *
     * @param parentFolder The parent folder created by a call to {@link #createTempFolder(String, ERetentionPolicy)} or other methods.
     * @param prefix The file prefix.
     * @param suffix The file suffix.
     * @param policy The {@link ERetentionPolicy} of the new file.
     * @return The new created file
     *
     * @exception NullPointerException <ul>
     * <li>if parentFolder is null</li>
     * <li>if policy is null</li>
     * </ul>
     *
     * @exception IllegalStateException <ul>
     * <li>if policy is not the same as the parent policy</li>
     * </ul>
     */
    @PublishedMethod
    File createTempFile(File parentFolder, String prefix, String suffix, ERetentionPolicy policy);

    /**
     * Gets the current active policy. Returns the current policy of the {@link IGenTempFileService}.
     *
     * <p>
     * You can only create temp files with the same policy as the current, except {@link ERetentionPolicy#PROJECT}.
     * </p>
     *
     * @return the current active policy
     */
    @PublishedMethod
    ERetentionPolicy getCurrentActivePolicy();

}
