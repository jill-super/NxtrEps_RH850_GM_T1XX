package com.vector.cfg.gen.core.utils.formatting;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.EnumSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link GenFormatterUtil} provides static method for the handling of formatting C language code. See {@link EFormatType} and {@link IGenFormatter} for more
 * details.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenFormatterUtil {
    // private static final ILogger logger = Logger.INSTANCE.createLogger(GenFormatterUtil.class);

    /**
     * The Constant PATTERN_ESCAPE_NON_ACSII_CHARS. Finds all chars not between <space> 0x20 and ~ 0x7E and the newLine Char \r\n and tabulator \t
     */
    private static final Pattern PATTERN_ESCAPE_NON_ACSII_CHARS = Pattern.compile("([^\\x20-\\x7E\r\n\t]+)");

    private static final String REPLACEMENT_ESCAPE_NON_ACSII_CHARS = "_";

    private static final Pattern PATTERN_SLASH_SLASH = Pattern.compile("(/){2,}");

    private static final String REPLACEMENT_SLASH_SLASH = "/ /";

    private static final Pattern PATTERN_SLASH_ASTERIX = Pattern.compile("((/\\*)|(\\*/))+");

    private static final String REPLACEMENT_SLASH_ASTERIX = "_/_";

    private static final Pattern PATTERN_NEW_LINE = Pattern.compile("(\\r\\n|\\r|\\n)+");

    private static final String REPLACEMENT_NEW_LINE = "    ";

    /**
     *
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @since 1.0
     * @see #escapeStringForCFile
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public enum ECEscapeOptions {
        /*
         * Note: The order of the Enum constants is important. The escape sequence is executed in the declaration order of the enum literals
         */

        ESCAPE_NON_ASCII_CHARS(PATTERN_ESCAPE_NON_ACSII_CHARS, REPLACEMENT_ESCAPE_NON_ACSII_CHARS),
        ESCAPE_SLASH_SLASH(PATTERN_SLASH_SLASH, REPLACEMENT_SLASH_SLASH),
        ESCAPE_SLASH_ASTERIX(PATTERN_SLASH_ASTERIX, REPLACEMENT_SLASH_ASTERIX),
        ESCAPE_NEW_LINE(PATTERN_NEW_LINE, REPLACEMENT_NEW_LINE),

        ;

        private final Pattern pattern;

        private final String replacement;

        ECEscapeOptions(Pattern pattern, String replacement) {
            this.pattern = pattern;
            this.replacement = replacement;

        }

        static void checkForInvalidOptions(EnumSet<ECEscapeOptions> options) {

            final String errorMsg = "Invalid ECEscapeOptions combination.";

            if (options.contains(ESCAPE_SLASH_SLASH)) {
                if (options.contains(ESCAPE_SLASH_ASTERIX)) {
                    throw new IllegalArgumentException(errorMsg);
                }
            }

            if (options.contains(ESCAPE_SLASH_ASTERIX)) {
                if (options.contains(ESCAPE_SLASH_SLASH)) {
                    throw new IllegalArgumentException(errorMsg);
                }
            }
        }

        /**
         * Getter method for pattern.
         *
         * @return Returns the pattern.
         */
        Pattern getPattern() {
            return pattern;
        }

        /**
         * Getter method for replacement.
         *
         * @return Returns the replacement.
         */

        String getReplacement() {
            return replacement;
        }
    }

    /**
     * Escapes the passed {@link String} content, by the passed {@link ECEscapeOptions}.
     *
     * @param content the content
     * @param options the options
     * @return the escaped string.
     */
    @PublishedMethod
    public static String escapeStringForCFile(String content, EnumSet<ECEscapeOptions> options) {
        checkNotNull(content);
        checkNotNull(options);
        ECEscapeOptions.checkForInvalidOptions(options);

        if (content.isEmpty()) {
            return content;
        }
        /*
         * Note: The order of the enum constants is important. The escape sequence is executed in the declaration order of the enum literals
         */
        String temp = content;
        for (final ECEscapeOptions opt : options) {
            final Matcher matcher = opt.getPattern().matcher(temp);
            temp = matcher.replaceAll(opt.getReplacement());
        }
        return temp;
    }

    private GenFormatterUtil() {

    }
}
