package com.vector.cfg.model.access.ecucdefinition.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationClass;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationVariant;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.state.ICeState;
import com.vector.cfg.model.state.IContainerStatePublished;

/**
 * <div class="extdoc" id="Common"> <b>{@link IEcucContainerDefinition}</b> is the interface of the container definition wrapper. It provides the following method(s): </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucContainerDefinition extends IEcucDefinition {

    /**
     * Returns the wrapped definition. This can never be <code> null</code>
     *
     * @return the wrapped definition.
     */
    @Override
    @SuppressWarnings("unchecked")
    @PublishedMethod
    MIContainerDef getDef();

    /**
     * Returns <code>true</code> if containers with this definition are allowed to be deleted in the post-build phase of a project. This method is intended to implement
     * {@link ICeState#isDeletable()} and related methods which check deletability of container instances.
     *
     * @return
     */
    @KeepSecretFromPublishedApi
    boolean isPostBuildDeletable();

    /**
     * <div class="extdoc" id="getMultiplicityConfigurationClass"> The {@link #getMultiplicityConfigurationClass(EEcucConfigurationVariant)} method returns the multiplicity
     * configuration class for the specified module implementation variant. The returned value defines in which configuration phase the number of container instances latest may
     * change if the module implements the specified variant.
     * <p>
     * Supported values for the variant are
     * <ul>
     * <li>{@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE}</li>
     * <li>{@link EEcucConfigurationVariant#VARIANT_LINK_TIME}</li>
     * <li>{@link EEcucConfigurationVariant#VARIANT_POST_BUILD_LOADABLE}</li>
     * </ul>
     * Other values lead to an {@link IllegalArgumentException}.
     * </p>
     * <p>
     * This method doesn't take the multiplicity into account. It only investigates the multiplicity configuration class as specified in the related container definition. So it
     * still may return {@link EEcucConfigurationClass#POST_BUILD} even if the multiplicity is 1:1 for example. The post-build loadable use case differs here from post-build
     * selectable (see {@link #supportsVariantMultiplicity()}) because the changeability in the post-build phase is being inherited from parent objects. So, if you want to find
     * out if a container actually permits changes in the post-build phase, you should use {@link IContainerStatePublished}.
     * </p>
     * <p>
     * This method is for post-build loadable only!
     * </p>
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the container definitions contained the <code>postBuildChangeable</code> flag to define post-build loadable
     * support. This method internally investigates the <code>postBuildChangeable</code> flag in this case but the <code>multiplicityConfigClass</code> table for AUROSAR 4.2.1
     * and newer versions.
     * </p>
     * </div>
     *
     * @param variant
     * @return The configuration class (never <code>null</code>)
     */
    @PublishedMethod
    EEcucConfigurationClass getMultiplicityConfigurationClass(EEcucConfigurationVariant variant);

    /**
     * <div class="extdoc" id="supportsVariantMultiplicity"> The {@link #supportsVariantMultiplicity()} method returns <code>true</code> if this container type supports variant
     * multiplicity. If <code>true</code> is returned this means that different variants may contain different number of instances of this container type.
     * <p>
     * This method takes the multiplicity into account. So, if the container definition specifies the multiplicity with lower == upper, it always returns <code>false</code>.
     * Concerning post-build selectable it never makes sense to permit variance if lower and upper multiplicity are equal.
     * </p>
     * <p>
     * This method is for post-build selectable only!
     * </p>
     * <p>
     * <b>Remark about AUTOSAR versions:</b> Prior to AUTOSAR 4.2.1 the container definitions contained the <code>postBuildChangeable</code> flag to define post-build loadable
     * support. This method internally investigates the <code>postBuildChangeable</code> flag in this case but the <code>postBuildVariantMultiplicity</code> flag for AUROSAR
     * 4.2.1 and newer versions.
     * </p>
     * </div>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsVariantMultiplicity();

    /**
     * <div class="extdoc" id="supportsVariantShortname"> The {@link #supportsVariantShortname()} method returns <code>true</code> if one of the following conditions apply.
     * <ul>
     * <li>{@link #supportsVariantMultiplicity()} returns <code>true</code></li>
     * <li>The ADMIN-DATA flag postBuildSelectableChangeable is <code>true</code></li>
     * </ul>
     * The use case for this specification are 1:1 containers. When this method returns <code>true</code>, 1:1 containers may have different shortnames in different variants.
     * This is a Vector specific semantic which is not provided by AUTOSAR. </div>
     *
     * @return
     */
    @PublishedMethod
    boolean supportsVariantShortname();

}
