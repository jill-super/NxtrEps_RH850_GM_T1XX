package com.vector.cfg.gen.core.moduleinterface.derivative;

import javax.annotation.concurrent.ThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.derivative.DerivativeGroup;
import com.vector.cfg.core.derivative.DerivativeInfo;
import com.vector.cfg.core.derivative.EImplementationProperties;
import com.vector.cfg.core.derivative.ImplementationProperty;
import com.vector.cfg.model.access.DefRef;

/**
 * Provides the current active Derivative settings of the Project.
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenDerivativeService {

    /**
     * Get Derivative selected by user.
     *
     * @return selected Derivative (Optional.absent() if no DerivativeMapping is used at all)
     */
    @PublishedMethod
    Optional<DerivativeInfo> getDerivative();

    /**
     * Get Derivative selected for specific module.
     *
     * @return Derivative selected for specific module (Optional.absent() if no DerivativeMapping is used at all)
     */
    @PublishedMethod
    Optional<DerivativeInfo> getDerivative(DefRef moduleDef);

    /**
     * Get 'active' DerivativeGroup of specific module.
     *
     * @return DerivativeGroup used for module (Optional.absent() if no DerivativeMapping is used at all)
     */
    @PublishedMethod
    Optional<DerivativeGroup> getDerivativeGroup(DefRef moduleDef);

    /**
     * Get value of Implementation Property selected for specific module.
     *
     * @return Implementation Property value selected for specific module (Optional.absent() if Implementation Property is not used at all)
     */
    @PublishedMethod
    Optional<ImplementationProperty> getImplPropertyValue(DefRef moduleDef, EImplementationProperties implProperty);
}
