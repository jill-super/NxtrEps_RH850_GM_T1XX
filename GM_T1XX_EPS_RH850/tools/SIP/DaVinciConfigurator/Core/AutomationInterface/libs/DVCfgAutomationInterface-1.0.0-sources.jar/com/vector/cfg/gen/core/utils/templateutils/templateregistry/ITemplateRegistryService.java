package com.vector.cfg.gen.core.utils.templateutils.templateregistry;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;

/**
 * <b>This interface is not intented to be used by a client</b>
 * <p>
 * {@link ITemplateRegistryService} provides a cache for the initialized {@link TemplateRegistry} objects by the {@link IGeneratorPackage}.
 * </p>
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@ThreadSafe
public interface ITemplateRegistryService {

    /**
     * <p>
     * <b>ATTENTION:</b> This method is ONLY for internal framework usage!
     * </p>
     * Gets the registry.
     *
     * @param genPack the gen pack
     * @return the registry
     * @exception IllegalArgumentException
     * <ul>
     * <li>if genPack is <code>null</code></li>
     * </ul>
     */
    <T> TemplateRegistry<T> getRegistry(IGeneratorPackage genPack, Class<T> keyClass);
}
