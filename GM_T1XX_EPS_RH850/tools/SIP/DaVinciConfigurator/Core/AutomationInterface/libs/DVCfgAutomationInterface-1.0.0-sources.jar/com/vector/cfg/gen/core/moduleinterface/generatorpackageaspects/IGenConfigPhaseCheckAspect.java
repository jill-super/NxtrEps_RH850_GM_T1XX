package com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects;

import java.util.EnumSet;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.project.EConfigurationPhase;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;

/**
 * <div class="extdoc" id="GenConfigPhaseCheckAspect"> The {@link IGenConfigPhaseCheckAspect} provides the ability to specify, if an {@link IGeneratorPackage}
 * supports certain {@link EConfigurationPhase EConfigurationPhases}.
 *
 * The {@link IGenConfigPhaseCheckAspect} should be registered in the {@link IGeneratorPackage}.
 * <ul>
 * <li>getAcceptedConfigPhases - shall return the supported {@link EConfigurationPhase EConfigurationPhases} of the generator.</li>
 * </ul>
 *
 * <p>
 * An {@link IGeneratorPackage} can optionally have the {@link IGenConfigPhaseCheckAspect} interface to specify if it supports only a subset of configuration
 * phases. If this aspect is not implemented it is assumed that the generator supports all configuration phases.
 * </p>
 *
 * <p>
 * <b>Attention:</b><br/>
 * The implementation of this interface and the returned {@link EnumSet} <b>must be</b> threadsafe, because this aspect is called from different threads!
 * </p>
 *
 * <pre>
 * <code class="Java" id="ConfigPhaseCheck implementation sample">
 * public EnumSet&lt;EConfigurationPhase&gt; getAcceptedConfigPhases(){
 *      //Disable PostBuild
 *      return EnumSet.of(EConfigurationPhase.PRE_COMPILE, EConfigurationPhase.LINK);
 * }
 * </code>
 * </pre>
 *
 * </div>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IGeneratorPackage
 */
@ThreadSafe
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGenConfigPhaseCheckAspect extends IGeneratorPackageAspect {

    /**
     * Returns a set of {@link EConfigurationPhase EConfigurationPhases} supported by the {@link IGeneratorPackage}.
     *
     * <p>
     * This method shall never return <code>null</code>.
     * </p>
     *
     * <p>
     * <b>Attention:</b> DO NOT modify the returned {@link EnumSet}, because this method is called from different threads!
     * </p>
     *
     * @return the the supported phases.
     */
    @PublishedMethod
    EnumSet<EConfigurationPhase> getAcceptedConfigPhases();
}
