package com.vector.cfg.model.access.ecuconfiguration;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucContainer;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucHasDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucModuleConfiguration;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucAddInfoParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucNumericalParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucTextualParameter;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucInstanceReferenceParameter;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucSimpleReferenceParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIEcucAddInfoParamValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;

/**
 * <div class="extdoc" id="Common">
 * <h2>IEcuConfigurationAccess</h2> The {@link IEcuConfigurationAccess} provides convenient and typesafe access to configuration objects (modules, containers,
 * parameters and references). The contained <code>cfg()</code> methods take MDF (ECU configuration) objects and return wrappers which can be used to retrieve
 * specific characteristics of the configuration content.
 *
 * <p>
 * Example:
 *
 * <pre>
 * <code class="Java" id="Integer parameter configuration access examples">
 *   IEcuConfigurationAccess eca;
 *   MINumericalValue intParam;
 *
 *   // Get the parameter wrapper
 *   IEcucNumericalParameter numCfg = eca.cfg(intParam);
 *
 *   // Check if this is an integer parameter
 *   if (numCfg instanceof IEcucIntegerParameter) {
 *       IEcucIntegerParameter intCfg = (IEcucIntegerParameter) numCfg;
 *
 *       // Get the parameter value
 *       boolean hasValue = intCfg.hasValue();
 *       BigInteger value = intCfg.getValue();
 *
 *       // Get the related definition wrapper
 *       IEcucIntegerDefinition def = intCfg.getEcucDefinition();
 *   }
 * </code>
 * </pre>
 * </p>
 * </div>
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcuConfigurationAccess {

    /**
     * Returns an access object for the specified ECUC object. Never returns <code>null</code>.
     *
     * @param hasDef
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    IEcucHasDefinition cfg(MIHasDefinition hasDef);

    /**
     * Returns an access object for the specified module configuration. Never returns <code>null</code>.
     *
     * @param module
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    IEcucModuleConfiguration cfg(MIModuleConfiguration module);

    /**
     * Returns an access object for the specified container. Never returns <code>null</code>.
     *
     * @param container
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    IEcucContainer cfg(MIContainer container);

    /**
     * Returns an access object for the specified parameter. Never returns <code>null</code>.
     * <p>
     * You may cast the returned object to a more specific type depending on the real Java- and definition-type of the specified parameter.
     * </p>
     *
     * @param param
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    IEcucParameter cfg(MIParameterValue param);

    /**
     * Returns an access object for the specified parameter. Never returns <code>null</code>.
     *
     * @param param
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    IEcucAddInfoParameter cfg(MIEcucAddInfoParamValue param);

    /**
     * Returns an access object for the specified parameter. Never returns <code>null</code>.
     *
     * @param param
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    IEcucInstanceReferenceParameter cfg(MIInstanceReferenceValue param);

    /**
     * Returns an access object for the specified parameter. Never returns <code>null</code>.
     * <p>
     * You may cast the returned object to a more specific type depending on the real Java- and definition-type of the specified parameter.
     * </p>
     *
     * @param param
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    @SuppressWarnings("rawtypes")
    IEcucNumericalParameter cfg(MINumericalValue param);

    /**
     * Returns an access object for the specified parameter. Never returns <code>null</code>.
     * <p>
     * You may cast the returned object to a more specific type depending on the real Java- and definition-type of the specified reference.
     * </p>
     *
     * @param param
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    IEcucSimpleReferenceParameter cfg(MIReferenceValue param);

    /**
     * Returns an access object for the specified parameter. Never returns <code>null</code>.
     * <p>
     * You may cast the returned object to a more specific type depending on the real Java- and definition-type of the specified parameter.
     * </p>
     *
     * @param param
     * @return
     * @throws IllegalArgumentException if the argument is <code>null</code>
     */
    @PublishedMethod
    IEcucTextualParameter cfg(MITextualValue param);

}
