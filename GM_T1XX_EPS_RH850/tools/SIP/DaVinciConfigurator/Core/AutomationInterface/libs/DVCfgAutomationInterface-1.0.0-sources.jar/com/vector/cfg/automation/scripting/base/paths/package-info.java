/**
 * Automation script path resolution API of running script tasks.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.scripting.base.paths;