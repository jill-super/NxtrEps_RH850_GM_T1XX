package com.vector.cfg.gen.core.moduleinterface.calculation;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;

/**
 * ISortRule represents one element in the Calculation Sorting Graph.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IGenCalculationSortingCriteria
 * @see GenCalculationSorterBuilder
 * @see IGenCalculationSortable
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface ISortRule {

    /**
     * Gets the before DefRef Element of this Sorting Rule (Graph-transition).
     *
     *
     * @return the before
     */
    @PublishedMethod
    DefRef getBefore();

    /**
     * Gets the after DefRef Element of this Sorting Rule (Graph-transition).
     *
     *
     *
     * @return the after
     */
    @PublishedMethod
    DefRef getAfter();
}
