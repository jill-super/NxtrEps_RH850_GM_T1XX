package com.vector.cfg.gen.core.moduleinterface.exceptions;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.exceptions.ExceptionUtil;

/**
 * Thrown to indicate that the GeneratorPackage has caused a failure.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GeneratorPackageException extends RuntimeException implements IDebugable {

    private static final long serialVersionUID = -3388604266618757868L;

    private static final EValidationSeverityType LEAST_SEVEIRTY = EValidationSeverityType.ERROR;

    private final List<IGeneratorResult> genResultList;

    static String buildExceptionMsg(final IGeneratorResult genResult) {

        if (genResult == null) {
            throw new IllegalArgumentException("genResult is null");
        }

        return genResult.toString("short");

    }

    /**
     * @param genResult
     */
    private void assignExToResult(final IGeneratorResult genResult) {
        if (genResult instanceof IHasSetExceptionAsCause) {
            ((IHasSetExceptionAsCause) genResult).setException(this);
        }

    }

    /**
     * Constructs a new GeneratorPackageException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genPackage - The GeneratorPackage which has caused this exception.
     * @param genResult - The GeneratorResult.
     */
    @PublishedMethod
    protected GeneratorPackageException(final IGeneratorResult genResult) {
        this(genResult, null);

    }

    /**
     * Constructs a new GeneratorPackageException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genPackage The GeneratorPackage which has caused this exception.
     * @param genResult The GeneratorResult.
     * @param innerEx The cause (which is saved for later retrieval by the {@link #getCause()} method). (A <tt>null</tt> value is permitted, and indicates that
     * the cause is nonexistent or unknown.)
     */
    @PublishedMethod
    protected GeneratorPackageException(final IGeneratorResult genResult, final Throwable innerEx) {
        super(buildExceptionMsg(genResult), innerEx);
        this.genResultList = new ArrayList<>();

        assignExToResult(genResult);

        genResultList.add(genResult);

        if (!checkResultSeverity(genResult)) {
            reportSeverityError();
        }
    }

    /**
     * Constructs a new GeneratorPackageException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genPackage The GeneratorPackage which has caused this exception.
     * @param genResultList The List of GeneratorResults. For each item a Error will be reported in the Configurator.
     *
     */
    @PublishedMethod
    protected GeneratorPackageException(final List<? extends IGeneratorResult> genResultList) {
        this(genResultList, null);
    }

    /**
     * Constructs a new GeneratorPackageException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genPackage The GeneratorPackage which has caused this exception.
     * @param genResultList The List of GeneratorResults. For each item a Error will be reported in the Configurator.
     * @param innerEx The cause (which is saved for later retrieval by the {@link #getCause()} method). (A <tt>null</tt> value is permitted, and indicates that
     * the cause is nonexistent or unknown.)
     */
    @PublishedMethod
    protected GeneratorPackageException(final List<? extends IGeneratorResult> genResultList, final Throwable innerEx) {
        super(("Multiple GeneratorResults"), innerEx);

        if (genResultList == null) {
            throw new IllegalArgumentException("genResultList is null");
        }

        if (genResultList.isEmpty()) {
            throw new IllegalArgumentException("genResultList is empty.");
        }

        this.genResultList = new ArrayList<>(genResultList);

        boolean reportSeverityError = true;

        for (final IGeneratorResult genResult : this.genResultList) {
            assignExToResult(genResult);
            if (checkResultSeverity(genResult)) {
                reportSeverityError = false;
            }

        }

        if (reportSeverityError) {
            reportSeverityError();
        }

    }

    /**
     * Constructs a new GeneratorPackageException for a GeneratorPackage
     * <p>
     * The new created GeneratorPackageException inserts the passed exception into the resultList.
     * <p>
     * <b>Attention:</b> One of the {@link IGeneratorResult}s must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param uselessCompiler Unused parameter to avoid compiler error
     * @param genExList The List of {@link GeneratorPackageException}s. For each item a Error will be reported in the Configurator.
     */
    @PublishedMethod
    protected GeneratorPackageException(final boolean uselessCompiler, final List<? extends GeneratorPackageException> genExList) {
        super(("Multiple GeneratorResults"), null);

        if (genExList == null) {
            throw new IllegalArgumentException("genResultList is null.");
        }

        if (genExList.isEmpty()) {
            throw new IllegalArgumentException("genResultList is empty.");
        }

        this.genResultList = new ArrayList<>();
        boolean reportSeverityProblem = true;

        for (final GeneratorPackageException ex : genExList) {

            for (final IGeneratorResult genResult : ex.getGeneratorResultList()) {
                if (checkResultSeverity(genResult)) {
                    reportSeverityProblem = false;
                }

                genResultList.add(genResult);
            }
        }

        if (reportSeverityProblem) {
            reportSeverityError();
        }

    }

    private boolean checkResultSeverity(final IGeneratorResult genResult) {

        if (genResult.getSeverity().compareTo(LEAST_SEVEIRTY) > 0) {

            return false;
        }

        return true;
    }

    /**
     * @param leastSeverity
     */
    private static void reportSeverityError() {
        //The Severity is lower then Error
        throw new IllegalArgumentException(
                MessageFormat
                        .format("None of the GeneratorResults have the Severity {0}, but Calculation/Validation or Generation is aborted with an exception. A GeneratorPackageException must have at least {0} as Severity.",
                                LEAST_SEVEIRTY));
    }

    /**
     * Gets the generatorResult list, which was added during creation of the exception.
     *
     * @return The list of results assign at the construction of the exception.
     */
    @PublishedMethod
    public List<IGeneratorResult> getGeneratorResultList() {
        return Collections.unmodifiableList(genResultList);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getMessage() {
        final StringBuilder builder = new StringBuilder();
        boolean first = true;

        if (genResultList.size() > 1) {
            builder.append("Results: \n");
        }
        for (final IGeneratorResult result : genResultList) {
            if (!first) {
                builder.append(" \n");

            } else {
                first = false;
            }
            builder.append(buildExceptionMsg(result));

        }
        return builder.toString();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append(getClass().getName());
        builder.append(":");
        for (final IGeneratorResult result : genResultList) {
            builder.append("\n  ");
            builder.append(result.toString());

        }
        return builder.toString();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toDebugString() {

        final StringBuilder builder = new StringBuilder();
        builder.append(getClass().getName());
        builder.append(":");
        for (final IGeneratorResult result : genResultList) {
            builder.append("\n  ");
            builder.append(result.toString());

        }
        builder.append("\n");
        ExceptionUtil.printStacktrace(this, builder);

        if (getCause() != null) {
            Throwable inner = this.getCause();

            while (inner != null) {

                builder.append("\r\nCause: ");
                builder.append(inner.toString().trim());
                builder.append("\r\n");
                ExceptionUtil.printStacktrace(inner, builder);
                inner = inner.getCause();
            }

        }

        builder.append("\n");

        return builder.toString();

    }

}
