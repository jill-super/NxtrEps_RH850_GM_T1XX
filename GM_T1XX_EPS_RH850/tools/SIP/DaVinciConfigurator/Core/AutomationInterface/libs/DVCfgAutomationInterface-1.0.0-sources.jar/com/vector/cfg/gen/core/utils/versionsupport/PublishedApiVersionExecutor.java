package com.vector.cfg.gen.core.utils.versionsupport;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.util.Collection;

import javax.annotation.concurrent.NotThreadSafe;

import org.eclipse.osgi.service.resolver.VersionRange;
import org.osgi.framework.Version;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.ECoreFeatureVersion;
import com.vector.cfg.core.GeneratorApiVersion;
import com.vector.cfg.core.GeneratorInternalAddonsVersion;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.format.FormattingService;

/**
 * <div class="extdoc" id="Common">
 * <h2>Executing newer PublishedApi code in older versions</h2><!--LaTeX:\label{sec:PublishedApiVersionExecutor}-->
 *
 * <h5>Prerequisites</h5> DO NOT use this feature, as long as you have another option, like upgrading the PublishedApi / GenDevKit version. This feature is really dangerous,
 * when used incorrectly. <b>No</b> version check will prevent you from doing this kind of mistakes! <b>Please inform the DaVinci Configuration team, if you want to use this
 * feature!</b>
 *
 * <p>
 *
 * The class {@link PublishedApiVersionExecutor} prevents a clientside code block from executing, if the passed version is out of range of the compatible version of the running
 * DaVinci Configurator.
 *
 * <p>
 * The executor could be used to try to execute code clientside code compiled against a certain GenDevKit (PublishedApi) version. If the PublishedApi version of the compiled
 * code is less or equal (but within the compatibility range) to the current version of the executing DaVinci Configurator, then the code is executed, otherwise the code is
 * ignored.
 * </p>
 *
 * An example a generator was compiled against version R12, but wants also to be executable in version R11. So the version check in the {@link IGeneratorPackage} returns R11,
 * but the R12 code is packed into a subclass of {@link PublishedApiVersionExecutor}.
 *
 * <h5>Execution</h5> The generator code requests the execution with the <code>PublishedApiVersionExecutor.create()</code> method by passing the full class name of the created
 * Subclass, and then calls {@link #invoke(Object...)}, if the returned {@link Optional} of the <code>create()</code> call has an {@link PublishedApiVersionExecutor} for the
 * requested version.
 *
 * <h5>Subclass with the code to execute</h5> As first you have to create a class which subclasses {@link PublishedApiVersionExecutor}. This class must have an no argument and
 * public constructor. The class implements it's logic in the {@link #invokeInternal(Object...)} method. You could use all Generator and PublishedApi types in this method. There
 * is no restriction, you could also use the API of the <em>newer version</em> .
 *
 * <pre>
 * <code class="Java" id="PublishedApiVersionExecutor: Subclass for the execution code">
 *  package com.vector.cfg.gen.testGen.r12;
 *
 * 	public class MyR12Code extends PublishedApiVersionExecutor {
 *
 * 	    protected Object invokeInternal(Object ... args){
 *          // This shall contain the newer code
 *
 *         return resultObj;
 *      }
 *
 * 	}
 * </code>
 * </pre>
 *
 * <h5>Calling the code</h5> You have to take precautions, when you try to call the <code>create()</code> code from above. There are multiple issues, when calling the <em>newer
 * API</em> code:
 * <ul>
 * <li>Don’t use classes or other types from the newer version outside of your VersionExecutor class. This includes return types and argument types. Because usages of these
 * types could lead to an <code>java.lang.LinkageError</code>. E.g. an initialization of the class MyR12Code is not possible outside the {@link PublishedApiVersionExecutor}.
 * Therefore the {@link PublishedApiVersionExecutor} API will instantiate your VersionExecutor class via reflection (second argument in <code>create()</code> ).</li>
 * <li>You have to pass the correct version number as {@link String} literal to the <code>create()</code> method (Third argument). It is important to use a {@link String}
 * literal from {@link GeneratorApiVersion} and not the {@link ECoreFeatureVersion} enum literal reference, because the enum literal does not exist in the older versions. You
 * shall use the class {@link GeneratorApiVersion} and the contained fields like {@link GeneratorApiVersion#VERSION_GENERATORS_R14} for the version parameter.</li>
 * </ul>
 *
 * <pre>
 * <code class="Java" id="Clientside execution of the MyR12Code class with PublishedApiVersionExecutor">
 *  Optional&lt;PublishedApiVersionExecutor&gt; exec = PublishedApiVersionExecutor.create(genPackage, "com.vector.cfg.gen.testGen.r12.MyR12Code", GeneratorApiVersion.VERSION_GENERATORS_R14);
 *  // CAUTION: NEVER encode the real type MyR12Code into the code
 *  // This could lead to an java.lang.LinkageError!
 *
 *  // Execute the code, if correct version:
 *  if(exec.isPresent()){
 *      Object result = exec.invoke();
 *      // Do something with the result.
 *  }
 *
 *
 * </code>
 * </pre>
 *
 * </p>
 * <p>
 * The code below shows the mistakes, when creating a {@link PublishedApiVersionExecutor} instance. <b> Wrong code, NOT VALID, do not copy:</b>
 *
 * <pre>
 * <code class="Java" id="Wrong and invalid clientside code for PublishedApiVersionExecutor">
 *  // DO NOT COPY THIS CODE
 *  // !WRONG, NOT VALID JAVA CODE!
 *
 *  Optional&lt;MyR12Code&gt; exec =        // Do not encode the subclass in clientside code.
 *          PublishedApiVersionExecutor.create(
 *              genPackage,
 *              MyR12Code.class.getName(),  // Do not encode the subclass
 *              ECoreFeatureVersion.VERSION_4_6_0 // Do not use the enum!
 *           )
 *
 *  // DO NOT COPY THIS CODE
 *
 * </code>
 * </pre>
 *
 * </p>
 *
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@NotThreadSafe
public abstract class PublishedApiVersionExecutor {
    private static final ILogger logger = Logger.INSTANCE.createLogger(PublishedApiVersionExecutor.class);

    private Version version;

    private org.osgi.framework.VersionRange versionRange;

    private DomainType domainType;

    /**
     * The default constructor of the {@link PublishedApiVersionExecutor} class. This is used the the clientside created subclasses.
     */
    @PublishedMethod
    protected PublishedApiVersionExecutor() {

    }

    /**
     * Creates an PublishedApiVersionExecutor for the passed {@link IGeneratorPackageReferable}, the clientside impl class classname and the expected version for the passed
     * {@link DomainType} as string.
     *
     * <p>
     * For the expectedVersionStr please use a version field of one of the version classes {@link GeneratorApiVersion} or {@link GeneratorInternalAddonsVersion} . E.g.
     * {@link GeneratorApiVersion#VERSION_GENERATORS_R14}
     * </p>
     * <p>
     * For the expectedPublishedApiDomain please use the field in the version classes {@link GeneratorApiVersion} or {@link GeneratorInternalAddonsVersion}. E.g.
     * {@link GeneratorApiVersion#DOMAIN_GENERATORS}. <br/>
     * The expectedPublishedApiDomain must be the literal name of the literal in {@link DomainType} enum. Attention: DO NOT use the {@link DomainType} enum literal, otherwise a
     * {@link Exception} will occur in older version, where the literal is not defined!
     * </p>
     *
     * Example:
     *
     * <pre>
     * <code class="Java" id="PublishedApiVersionExecutor.create() usage sample">
     * 	 Optional&lt;PublishedApiVersionExecutor&gt; exec =
     *      PublishedApiVersionExecutor.create(genPackage, "com.vector.cfg.gen.testGen.MyClass", GeneratorApiVersion.VERSION_GENERATORS_R14, GeneratorApiVersion.DOMAIN_GENERATORS);
     * </code>
     * </pre>
     *
     * @param genPack the generatorPackage
     * @param classname the classname of the class to execute.
     * @param expectedVersionStr the expected version of the DaVinci Configurator.
     * @param expectedPublishedApiDomain the expected {@link DomainType} of the passed version number.
     * @return the PublishedApiVersionExecutor, or {@link Optional#absent()}, if version is not present, or does not match the current running DaVinci Configurator.
     */
    @PublishedMethod
    public static Optional<PublishedApiVersionExecutor> create(IGeneratorPackageReferable genPack, String classname, String expectedVersionStr, String expectedPublishedApiDomain) {
        DomainType domainType;
        try {
            domainType = DomainType.valueOf(expectedPublishedApiDomain);
        } catch (final IllegalArgumentException ex) {
            if (logger.isDebugEnabled()) {
                logger.debug("Requested DomainType not found in current version. Requested: " + expectedPublishedApiDomain + " Compatible Domains : " + DomainType.values());
            }
            return Optional.absent();
        }
        return create(genPack, classname, expectedVersionStr, domainType);
    }

    /**
     * Creates an PublishedApiVersionExecutor for the passed {@link IGeneratorPackageReferable}, the clientside impl class classname and the expected {@link ECoreFeatureVersion}
     * of the {@link DomainType#GENERATORS}.
     *
     * <p>
     * For the expectedVersionStr please use a version field of the class {@link GeneratorApiVersion}. E.g. {@link GeneratorApiVersion#VERSION_GENERATORS_R14}
     * </p>
     *
     * Example:
     *
     * <pre>
     * <code class="Java" id="PublishedApiVersionExecutor.create() usage sample">
     *   Optional&lt;PublishedApiVersionExecutor&gt; exec =
     *      PublishedApiVersionExecutor.create(genPackage, "com.vector.cfg.gen.testGen.MyClass", GeneratorApiVersion.VERSION_GENERATORS_R14);
     * </code>
     * </pre>
     *
     * @param genPack the generatorPackage
     * @param classname the classname of the class to execute.
     * @param expectedVersionStr the expected version of the DaVinci Configurator.
     * @return the PublishedApiVersionExecutor, or {@link Optional#absent()}, if version is not present, or does not match the current running DaVinci Configurator.
     */
    @PublishedMethod
    public static Optional<PublishedApiVersionExecutor> create(IGeneratorPackageReferable genPack, String classname, String expectedVersionStr) {
        return create(genPack, classname, expectedVersionStr, DomainType.GENERATORS);
    }

    /**
     * Creates an PublishedApiVersionExecutor for the passed {@link IGeneratorPackageReferable}, the clientside impl class classname and the expected version selected by the
     * passed {@link DomainType}.
     *
     * @param genPack the generatorPackage
     * @param classname the classname of the class to execute.
     * @param expectedVersionStr the expected version of the DaVinci Configurator.
     * @param domainTypeLoc the DomainType to check for the version.
     * @return the PublishedApiVersionExecutor, or {@link Optional#absent()}, if version is not present, or does not match the current running DaVinci Configurator.
     */
    private static Optional<PublishedApiVersionExecutor> create(IGeneratorPackageReferable genPack, String classname, String expectedVersionStr, DomainType domainTypeLoc) {
        checkNotNull(genPack);
        checkNotNull(classname);
        checkArgument(!classname.trim().isEmpty());
        checkNotNull(expectedVersionStr);
        checkArgument(!expectedVersionStr.trim().isEmpty());
        if (domainTypeLoc != DomainType.GENERATORS && domainTypeLoc != DomainType.GENERATOR_INTERNAL_ADDONS) {
            throw new IllegalArgumentException("Currently only DomainType.GENERATORS and  DomainType.GENERATOR_INTERNAL_ADDONS supported");
        }
        // Verify Format
        Version.parseVersion(expectedVersionStr);

        /*
         * Note this version getter must be changed, when we will support different versions for different domainTypes. Currently all APIs are versioned with the ECoreFeatureVersion so we could use it.
         */
        final Optional<ECoreFeatureVersion> versionOf = ECoreFeatureVersion.versionOf(expectedVersionStr);
        if (!versionOf.isPresent()) {
            return Optional.absent();
        }

        final ECoreFeatureVersion expectedCoreFeatureVersion = versionOf.get();
        final Version expectedVersion = expectedCoreFeatureVersion.getVersion();
        final VersionRange currentCompatibleRange = ECoreFeatureVersion.getCurrentVersion().getCompatibleCoreVersionRange();
        if (!currentCompatibleRange.includes(expectedVersion)) {
            if (logger.isDebugEnabled()) {
                logger.debug("Requested version is no compatible with current version. Requested: " + expectedVersion + " Compatible range of current: " + currentCompatibleRange);
            }
            return Optional.absent();
        }

        final Optional<PublishedApiVersionExecutor> executor = createClassViaReflection(genPack, classname);
        if (!executor.isPresent()) {
            return executor;
        }
        executor.get().setFields(expectedVersion, currentCompatibleRange, domainTypeLoc);
        return executor;
    }

    private void setFields(Version expectedVersion, VersionRange currentCompatibleRange, DomainType domainTypeLoc) {
        this.version = expectedVersion;
        this.versionRange = currentCompatibleRange;
        this.domainType = domainTypeLoc;
    }

    private static Optional<PublishedApiVersionExecutor> createClassViaReflection(IGeneratorPackageReferable genPack, String classname) {

        try {
            final ClassLoader loader = genPack.getGeneratorPackage().getClass().getClassLoader();
            final Class<?> loadClass = loader.loadClass(classname);
            final Object newInstance = loadClass.newInstance();
            final PublishedApiVersionExecutor exec = (PublishedApiVersionExecutor) newInstance;
            return Optional.of(exec);
        } catch (final Exception ex) {
            logger.debug("Could not instantiate the subclass of PublishedApiVersionExecutor, provided by the clientside. Return Optional.absent().", ex);
            return Optional.absent();
        }
    }

    /**
     * Invokes the clientside code of the passed clientside class during construction.
     *
     * <p>
     * Note: The client implementation method was changed in R14 to {@link #invokeInternal(Object...)}. Please override {@link #invokeInternal(Object...)} in your subclass.
     * </p>
     *
     * @param args the arguments for the clientside code.
     * @return the result of the clientside code.
     */
    @PublishedMethod
    public final Object invoke(Object... args) {
        final PublishedApiVersionExecutorVerificationStack stack = PublishedApiVersionExecutorVerificationStack.INSTANCE;
        stack.startExecution(this);
        try {
            return invokeInternal(args);
        } finally {
            stack.stopExecution(this);
        }
    }

    /**
     * Invokes the clientside code of the passed clientside class during construction.
     *
     * <p>
     * Subclass shall implement the execution logic here
     * </p>
     *
     * @param args the arguments for the clientside code.
     * @return the result of the clientside code.
     */
    @PublishedMethod
    protected abstract Object invokeInternal(Object... args);

    /**
     * Verifies that the passed Version and {@link DomainType}, are valid for the currently running Thread.
     * <p>
     * This means in this call stack exists a call to an {@link PublishedApiVersionExecutor#invoke(Object...)} with a compatible version range to the passed versionStr.
     * </p>
     *
     * @param versionStr the version to check for
     * @param domainStr the {@link DomainType} to check for
     * @exception IllegalStateException
     * <ul>
     * <li>if the there is no {@link PublishedApiVersionExecutor} in the current callstack, which guards the passed version</li>
     * <li>if the passed version is not parsable</li>
     * </ul>
     */
    @PublishedMethod
    public static void verifyExpectedVersionCompatibilityCheckOnCurrentlyExecutingThread(String versionStr, String domainStr) {
        final Version version = parseVersionForExpectedVersionCompatibilityCheckVerification(versionStr);
        final Collection<PublishedApiVersionExecutor> activeExecutors = PublishedApiVersionExecutorVerificationStack.INSTANCE.getCurrentRunningExecutors();

        for (final PublishedApiVersionExecutor exec : activeExecutors) {
            if (exec.verifyCurrentExecutionVersionCompatibilityInternal(version, domainStr)) {
                return;
            }
        }

        issueExceptionForExpectedVersionCompatibilityVerificationFailure(domainStr, activeExecutors, versionStr);
    }

    private static void issueExceptionForExpectedVersionCompatibilityVerificationFailure(String domainStr,
            final Collection<PublishedApiVersionExecutor> activeExecutors, String versionStr) {
        String versionMsg = versionStr;
        final Optional<ECoreFeatureVersion> eCoreFeatureVersion = ECoreFeatureVersion.versionOf(versionStr);
        if (eCoreFeatureVersion.isPresent()) {
            versionMsg = eCoreFeatureVersion.get().toString();
        }

        if (activeExecutors.isEmpty()) {
            throw new IllegalStateException(
                    "Missing PublishedApiVersionExecutor check:\r\n" +
                            "You have to execute your client side code with a correct PublishedApiVersionExecutor check in the calling stack to prevent this exception.\r\n" +
                            "This is a client side implementation error, e.g. in the Generator code.\r\n" +
                            "Normally this exception is thrown by calls to classes which use newer APIs than the minimal GenDevKit version of the generator.\r\n" +
                            "These calls must be always guarded by an PublishedApiVersionExecutor instance. See GenDevKit documentation for details.\r\n" +
                            "You are trying to call code requiring DaVinci Configurator PublishedApi version " + versionMsg + " and PublishedApi Domain " + domainStr + ". \r\n" +
                            "No PublishedApiVersionExecutor found at all in the calling stack.");
        } else {
            throw new IllegalStateException(
                    " Wrong PublishedApiVersionExecutor check:\r\n" +
                            "You have to execute your client side code with a correct PublishedApiVersionExecutor check in the calling stack to prevent this exception.\r\n" +
                            "This is a client side implementation error, e.g. in the Generator code.\r\n" +
                            "Normally this exception is thrown by calls to classes which use newer APIs than the minimal GenDevKit version of the generator.\r\n" +
                            "These calls must be always guarded by an PublishedApiVersionExecutor instance. See GenDevKit documentation for details.\r\n" +
                            "You are trying to call code requiring DaVinci Configurator PublishedApi version " + versionMsg + " and PublishedApi Domain " + domainStr + ". \r\n" +
                            "Currently active PublishedApiVersionExecutors in the calling stack:\r\n  " +
                            FormattingService.INSTANCE.formatCollection(activeExecutors, "\r\n  "));
        }
    }

    private static Version parseVersionForExpectedVersionCompatibilityCheckVerification(String versionStr) {
        final Version version;
        try {
            version = Version.parseVersion(versionStr);
        } catch (final IllegalArgumentException ex) {
            throw new IllegalStateException("PublishedApiVersionExecutor verificaton check: the passed version number is not parsable: " + versionStr, ex);
        }
        return version;
    }

    /**
     * Returns <code>true</code>, if the passed expectedVersion and the passed expectedDomainTypeStr are compatible to this {@link PublishedApiVersionExecutor}.
     *
     * @param expectedVersion the expected version
     * @param expectedDomainTypeStr the expected {@link DomainType} as String.
     * @return <code>true</code>, if compatible, otherwise <code>false</code>
     */
    private boolean verifyCurrentExecutionVersionCompatibilityInternal(Version expectedVersion, String expectedDomainTypeStr) {
        if (domainType.name().equals(expectedDomainTypeStr)) {
            if (versionRange.includes(expectedVersion)) {
                return true;
            }
        }
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("PublishedApiVersionExecutor [");
        builder.append("Version: ");
        builder.append(version);
        builder.append(" Compatible VersionRange: ");
        builder.append(versionRange);
        builder.append(" PublishedApi Domain: ");
        builder.append(domainType);
        builder.append(" Client side class: ");
        builder.append(getClass().getName());
        builder.append("]");
        return builder.toString();
    }

}
