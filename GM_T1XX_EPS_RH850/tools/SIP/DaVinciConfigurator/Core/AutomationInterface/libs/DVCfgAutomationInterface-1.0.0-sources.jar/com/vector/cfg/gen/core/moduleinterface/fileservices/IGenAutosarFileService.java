package com.vector.cfg.gen.core.moduleinterface.fileservices;

import java.io.File;
import java.io.IOException;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageException;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.persistency.filters.IPersistencyExportFilter;
import com.vector.cfg.util.version.IVersion;

/**
 * The IGenAutosarFileService interface. The service provides a functionality to retrieve the current active AUTOSAR configuration files (Ecuc, System
 * description).
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenAutosarFileService {

    /**
     * Returns the current Project as a whole Ecuc-File.
     *
     * <p>
     * Every call to this method, will return a new file, but the content is cached for each GenerationProcess.
     * </p>
     *
     * <p>
     * You don't have to delete this file. The file is deleted after the GenerationPorcess.
     * </p>
     *
     * <p>
     * Attention: This service will export the data, which is currently visible in the currently active {@link IModelView} (See
     * {@link IModelViewManager#getCurrentlyActiveView()}). If you want to see other exported data, you have to switch to the correct {@link IModelView}, before
     * calling this method!
     * </p>
     *
     * @param msnPrefixForFile The passed prefix is added to all created files.
     * @return the ecuc project file
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the msnPrefixForFile is null or empty</li>
     * </ul>
     *
     * @exception IllegalStateException <ul>
     * <li>if the service is not ready</li>
     * </ul>
     *
     *
     * @exception GeneratorPackageException <ul>
     * <li>if an {@link IOException} or {@link PersistencyException} occurred during the creation</li>
     * </ul>
     */
    @PublishedMethod
    File getTemporaryEcucProjectFile(String msnPrefixForFile);

    /**
     * Returns the current Project as a whole Ecuc-File in the specified autosarVersion.
     *
     * <p>
     * Every call to this method, will return a new file, but the content is cached for each GenerationProcess.
     * </p>
     *
     * <p>
     * You don't have to delete this file. The file is deleted after the GenerationPorcess.
     * </p>
     *
     * <p>
     * Attention: This service will export the data, which is currently visible in the currently active {@link IModelView} (See
     * {@link IModelViewManager#getCurrentlyActiveView()}). If you want to see other exported data, you have to switch to the correct {@link IModelView}, before
     * calling this method!
     * </p>
     *
     * @param msnPrefixForFile The passed prefix is added to all created files.
     * @param autosarVersion The specified AUTOSAR version.
     * @return the ecuc project file
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the msnPrefixForFile is null or empty</li>
     * </ul>
     *
     * @exception IllegalStateException <ul>
     * <li>if the service is not ready</li>
     * </ul>
     *
     * @exception GeneratorPackageException <ul>
     * <li>if an {@link IOException} or {@link PersistencyException} occurred during the creation</li>
     * </ul>
     */
    @PublishedMethod
    File getTemporaryEcucProjectFile(String msnPrefixForFile, IVersion autosarVersion);

    /**
     * Returns the current Project filter by the {@link IPersistencyExportFilter}. This method uses the AUTOSAR schema version of the MIEcuConfiguration node.
     *
     * <p>
     * If the filter object implements {@link Object#equals(Object)} and returns equal for the same type of filter, the internal caching is used to reduce the
     * exports of files.
     * </p>
     *
     * <p>
     * Every call to this method, will return a new file, but the content is cached for each GenerationProcess.
     * </p>
     *
     * <p>
     * You don't have to delete this file. The file is deleted after the GenerationPorcess.
     * </p>
     *
     * <p>
     * Attention: This service will export the data, which is currently visible in the currently active {@link IModelView} (See
     * {@link IModelViewManager#getCurrentlyActiveView()}). If you want to see other exported data, you have to switch to the correct {@link IModelView}, before
     * calling this method!
     * </p>
     *
     * @param msnPrefixForFile The passed prefix is added to all created files.
     * @param filter the used {@link IPersistencyExportFilter} to export the file.
     * @return the temporary project file
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the msnPrefixForFile is null or empty</li>
     * </ul>
     *
     * @exception IllegalStateException <ul>
     * <li>if the service is not ready</li>
     * </ul>
     *
     * @exception GeneratorPackageException <ul>
     * <li>if an {@link IOException} or {@link PersistencyException} occurred during the creation</li>
     * </ul>
     *
     */
    @PublishedMethod
    File getTemporaryProjectFile(String msnPrefixForFile, IPersistencyExportFilter filter);

    /**
     * Returns the current Project filter by the {@link IPersistencyExportFilter} in the specified autosarVersion.
     *
     * <p>
     * If the filter object implements {@link Object#equals(Object)} and returns equal for the same type of filter, the internal caching is used to reduce the
     * exports of files.
     * </p>
     *
     * <p>
     * Every call to this method, will return a new file, but the content is cached for each GenerationProcess.
     * </p>
     *
     * <p>
     * You don't have to delete this file. The file is deleted after the GenerationPorcess.
     * </p>
     *
     * <p>
     * Attention: This service will export the data, which is currently visible in the currently active {@link IModelView} (See
     * {@link IModelViewManager#getCurrentlyActiveView()}). If you want to see other exported data, you have to switch to the correct {@link IModelView}, before
     * calling this method!
     * </p>
     *
     * @param msnPrefixForFile The passed prefix is added to all created files.
     * @param filter the used {@link IPersistencyExportFilter} to export the file.
     * @param autosarVersion the autosarVersion to export
     * @return the temporary project file
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the msnPrefixForFile is null or empty</li>
     * </ul>
     *
     * @exception IllegalStateException <ul>
     * <li>if the service is not ready</li>
     * </ul>
     *
     * @exception GeneratorPackageException <ul>
     * <li>if an {@link IOException} or {@link PersistencyException} occurred during the creation</li>
     * </ul>
     *
     */
    @PublishedMethod
    File getTemporaryProjectFile(String msnPrefixForFile, IPersistencyExportFilter filter, IVersion autosarVersion);
}
