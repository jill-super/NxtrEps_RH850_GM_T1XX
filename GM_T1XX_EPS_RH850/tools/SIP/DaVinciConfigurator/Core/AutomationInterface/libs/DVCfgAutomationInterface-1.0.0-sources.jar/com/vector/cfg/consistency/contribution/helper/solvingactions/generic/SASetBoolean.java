package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * This class is an {@link ISolvingAction} that sets a boolean parameter when executed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SASetBoolean extends SASetNumTextRef<MINumericalValue> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SASetBoolean.class);

    private final Boolean targetValue;

    /**
     * Constructor for SASetBoolen.
     *
     * @param numerical the parameter to be adjusted
     * @param targetValue the target Value
     */
    @PublishedMethod
    public SASetBoolean(MINumericalValue numerical, Boolean targetValue) {
        super(numerical, MixedText.newBuilder().append(targetValue.toString()).flushResult());
        this.targetValue = targetValue;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {
        ModelUtil.getModelAccess(getParam()).setAsBoolean(getParam(), targetValue);
    }
}