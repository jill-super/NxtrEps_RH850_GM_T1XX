package com.vector.cfg.model.access.ecuconfiguration.elements;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.exceptions.ModelCeHasNoValueException;
import com.vector.cfg.model.exceptions.ModelCeHasWrongValueTypeException;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucValueParameter<VALUE> extends IEcucParameter {

    /**
     * Returns <code>true</code> if the parameter has a value of the correct type.
     *
     * @return
     */
    @PublishedMethod
    boolean hasValue();

    /**
     * Returns the parameter value.
     * <p>
     * This method doesn't throw exceptions if {@link #hasValue()} returns <code>true</code>.
     * </p>
     *
     * @return
     * @throws ModelCeHasNoValueException if the parameter has no value
     * @throws ModelCeHasWrongValueTypeException if the parameter value has the wrong type
     */
    @PublishedMethod
    VALUE getValue();

    /**
     * Sets the parameter value. <code>null</code> is permitted to remove the parameters value.
     *
     * @param value
     * @throws IllegalArgumentException if the specified value has the wrong type
     */
    @PublishedMethod
    void setValue(VALUE value);

}
