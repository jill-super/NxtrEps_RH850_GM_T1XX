package com.vector.cfg.gen.core.utils.abstractImpl;

import static com.google.common.base.Preconditions.checkNotNull;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.annotation.concurrent.GuardedBy;
import javax.annotation.concurrent.ThreadSafe;

import com.google.common.collect.Maps;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidator;
import com.vector.cfg.gen.core.moduleinterface.IDeployablePackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.genservices.IGenServiceContributor;
import com.vector.cfg.gen.core.moduleinterface.genservices.IGenServiceRegistry;
import com.vector.cfg.gen.core.moduleinterface.genservices.exceptions.GenServiceContributionException;
import com.vector.cfg.gen.core.utils.definitionrefs.GenDefinitionVerifier;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.ImmutablePair;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * This class provides a skeletal implementation of the <tt>{@link IGeneratorPackage IGeneratorPackage}</tt> interface, to minimize the effort required to
 * implement this interface.
 *
 * <p>
 * The programmer shall generally provide a void (no argument) constructor.
 * <p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 * @since 1.0
 * @author virtu
 * @see IGeneratorPackage
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public abstract class AbstractPackage implements IDeployablePackage, IGenServiceContributor {
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractPackage.class);

    private volatile boolean initialized = false;

    private volatile IProjectContext projectContext;

    @GuardedBy("initialized volatile write")
    private Map<Class<?>, ImmutablePair<DefRef, Object>> classToServiceMapping = Maps.newHashMap();

    @GuardedBy("initialized volatile write")
    private List<IValidator> validatorList = new ArrayList<>();

    /**
     * Instantiates a new generator package.
     */
    @PublishedMethod
    protected AbstractPackage() {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final String getQualifiedJavaPackageName() {
        String temp = getQualifiedJavaClassNameTestOnly();

        if (temp == null) {
            temp = this.getClass().getCanonicalName();
        }

        return temp.substring(0, temp.lastIndexOf('.'));
    }

    /**
     * Gets the qualified java class name.
     * <p>
     * This could be overridden, to allow test classes to set the used JavaPackageName. DO NOT CALL this in production code!
     * </p>
     *
     * @return the qualified java class name test only
     */
    @KeepSecretFromPublishedApi
    protected String getQualifiedJavaClassNameTestOnly() {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void initializePackage() {

        ensureInitializationNotYetFinished();

        ensureDataIsSetBeforeInit();

        verifyGeneratorPreconditions();

        initializeStartInternal();

        registerGenServicesInternal();

        classToServiceMapping = Collections.unmodifiableMap(classToServiceMapping);

        registerGeneratorPackageAspectsInternal();

        registerValidators();

        validatorList = Collections.unmodifiableList(validatorList);

        registerBswmdMigrationRules();

        initBeforeEndPackagePrivate();

        initializeEndInternal();

        initialized = true;
    }

    /**
     * Inits the before end package private. This is overridden by package private subclasses.
     */
    void initBeforeEndPackagePrivate() {

    }

    /**
     * Verify preconditions of the Generator. For example check, if the DefinitionRef of the generator are available.
     *
     * <p>
     * The the Class {@link GenDefinitionVerifier} for more details
     * </p>
     *
     * <div class="extdoc" id="GenDefinitionVerifier_verifyGeneratorPreconditions"> You can use this feature in your generator by implementing the method
     * <code>verifyGeneratorPreconditions()</code> in your {@link IGeneratorPackage GeneratorPackage} to verify for example DefRefs or other dependencies.
     *
     * <pre>
     * <code class="Java" id="verifyGeneratorPreconditions() implementation example">
     * protected void verifyGeneratorPreconditions() {
     *     getDefinitionVerifier().verifyClass(YourConstants.class);
     *     getDefinitionVerifier().verifyClass(YourBswmdModelDefRefs.class);
     * }
     * </code>
     * </pre>
     *
     * </div>
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     */
    @PublishedMethod
    protected void verifyGeneratorPreconditions() {
        // OVERRIDE THIS METHOD IF YOU WANT TO VERIFY THE PRECONDITIONS OF THE GENERATOR
    }

    /**
     * The {@link #initializeStartInternal()} method is used to perform initialization, before all other registrations (GenServices, Validators, ...) are done.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     */
    @PublishedMethod
    protected void initializeStartInternal() {
        // OVERRIDE THIS METHOD IF YOU WANT TO EXECUTES CODE BEFORE THE NORMAL INITIALIZATION
    }

    /**
     * The {@link #initializeEndInternal()} method is used to perform initialization, after all other registrations (GenServices, Validators, ...) are done.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     */
    @PublishedMethod
    protected void initializeEndInternal() {
        // OVERRIDE THIS METHOD IF YOU WANT TO EXECUTES CODE AFTER THE NORMAL INITIALIZATION
    }

    void registerGeneratorPackageAspectsInternal() {

    }

    /**
     *
     */

    void ensureDataIsSetBeforeInit() {
        checkNotNull(projectContext, "The projectContext must be set.");

    }

    final void ensureInitializationFinished() {
        if (!initialized) {
            throw new IllegalStateException("DeployablePackage was not initialized before Usage.");
        }
    }

    final void ensureInitializationNotYetFinished() {
        if (initialized) {
            throw new IllegalStateException("The DeployablePackage initialization was already finished. You can't modify the generatorPackage anymore.");
        }
    }

    /**
     * Register Live-Validators.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     */
    @PublishedMethod
    protected abstract void registerValidators();

    /**
     * Adds a LiveValidator, with consistency interfaces.
     *
     * @param validator The validator
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the validator is null</li>
     * </ul>
     * @exception IllegalStateException <ul>
     * <li>if the initialization was already finished</li>
     * </ul>
     */
    @PublishedMethod
    protected final void addValidator(IValidator validator) {

        if (validator == null) {
            throw new IllegalArgumentException("Validator is null");
        }
        ensureInitializationNotYetFinished();

        validatorList.add(validator);
    }

    /**
     * Register GenServices.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     *
     */
    @PublishedMethod
    protected void registerGenServices() {
        // OVERRIDE THIS METHOD IF YOU NEED A GENSERVICE
    }

    /**
     * Register internal GenServices before we call the subimplementation register.
     *
     */
    private void registerGenServicesInternal() {

        // Call protected methods
        registerGenServices();

    }

    /**
     * Register Bswmd Migration Rules.
     *
     * <p>
     * This method is called during initialization of the {@link IGeneratorPackage}.
     * </P>
     * <p>
     * This method is intended to be overwritten by subclasses
     * </p>
     *
     */
    @PublishedMethod
    protected void registerBswmdMigrationRules() {

    }

    /**
     * Adds a GenService to the {@link IGeneratorPackage}.
     *
     * @param <T> the generic type
     * @param clazz the class type of the service
     * @param service the service implementation object
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the clazz is null</li>
     * <li>if the service is null</li>
     * </ul>
     * @exception IllegalStateException <ul>
     * <li>if the initialization was already finished</li>
     * </ul>
     * @exception IllegalStateException <ul>
     * <li>if a service for the clazz already exists</li>
     * </ul>
     */
    @PublishedMethod
    protected final <T> void addGenService(DefRef moduleDef, Class<T> clazz, T service) {

        if (moduleDef == null) {
            throw new IllegalArgumentException("moduleDef is null");
        }

        if (clazz == null) {
            throw new IllegalArgumentException("clazz is null");
        }
        if (service == null) {
            throw new IllegalArgumentException("service is null");
        }
        ensureInitializationNotYetFinished();

        final ImmutablePair<DefRef, Object> pair = classToServiceMapping.get(clazz);
        if (pair != null) {
            throw new IllegalStateException("There is already a service registered for the class " + clazz.getName() + ". The service is " + pair.getSecond()
                    + " registered for ModuleDef " + pair.getFirst() + ".");
        }

        classToServiceMapping.put(clazz, ImmutablePair.create(moduleDef, (Object) service));

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final List<IValidator> getValidationRules() {

        ensureInitializationFinished();
        return validatorList;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void setProjectContext(IProjectContext projectContext) {
        if (this.projectContext != null && this.projectContext != projectContext) {
            throw new IllegalStateException("You could not change the projectContext of the DeployablePackage!");
        }
        this.projectContext = projectContext;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final IProjectContext getProjectContext() {
        return projectContext;

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        try {
            return MessageFormat.format("DeployablePackage({0})", getQualifiedJavaPackageName());
        } catch (final RuntimeException ex) {
            logger.error("DeployablePackage (" + this.getClass().getName() + ") Exception occured during toString().", ex);
            return "DeployablePackage (" + this.getClass().getName() + ")";
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    @Override
    public final <T> T getGenService(Class<T> clazz) {

        ensureInitializationFinished();
        checkNotNull(clazz, "clazz is null");

        final ImmutablePair<DefRef, Object> object = classToServiceMapping.get(clazz);

        if (object == null) {
            throw new IllegalArgumentException("There is no service associated with the class " + clazz.getName() + ".");
        }

        return (T) object.getSecond();
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    public final void createGenServicesForRegistry(IProjectContext ctx, IGenServiceRegistry registry) throws GenServiceContributionException {

        for (final Map.Entry<Class<?>, ImmutablePair<DefRef, Object>> entry : classToServiceMapping.entrySet()) {
            @SuppressWarnings("rawtypes")
            final Class clazz = entry.getKey();
            final DefRef defRef = entry.getValue().getFirst();
            final Object impl = entry.getValue().getSecond();
            registry.addGenService(defRef, impl, clazz);
        }

    }
}
