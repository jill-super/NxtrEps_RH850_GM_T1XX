package com.vector.cfg.gen.core.bswmdmodel.param;

import java.math.BigDecimal;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIFloatParameter;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractParam;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.gen.core.utils.formatting.primitives.FloatGenElement;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucFloatDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucFloatParameter;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.varianthandling.attributevaluevariationpoints.MINumericalValueVariationPoint;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Float parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GFloat extends GAbstractParam<BigDecimal> implements GIFloatParameter {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GFloat.class);

    private BigDecimal value;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GFloat(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MINumericalValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MINumericalValue getMdfObject() {
        return (MINumericalValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MINumericalValue getMdfObjectUnsafe() {
        return (MINumericalValue) super.getMdfObjectUnsafe();
    }

    private MINumericalValueVariationPoint getValueVariationPoint() {
        try {
            switchView();

            if (getMdfObject() != null) {
                return getMdfObject().getValue();
            }
            return null;

        } finally {
            restoreView();
        }
    }

    private BigDecimal getValueInternal() {

        try {
            switchView();

            final MINumericalValue parameter = getMdfObjectUnsafe();
            if (parameter != null) {
                if (getGeneratorModelAccess().getMdfModelAccess().containsFloat(parameter)) {
                    return getGeneratorModelAccess().getMdfModelAccess().getAsFloat(parameter);
                }
            }
            return null;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Double getValue() {
        try {
            switchView();

            final BigDecimal valueLoc = getBigDecimalValue();
            getModelVerifier().assertFloatParameterValueInJavaDoubleRange(this, valueLoc);

            return valueLoc.doubleValue();

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Double getValueOrDefault(Double defaultValue) {
        if (hasValue()) {
            return getValue();
        }

        return defaultValue;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasValue() {
        if (isValueChecked()) {
            return true;
        }
        return getValueInternal() != null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BigDecimal getValueMdf() {
        return getBigDecimalValue();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BigDecimal getBigDecimalValue() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            getModelVerifier().assertParameterOrReferenceNotNull(getParent(), this);
            getModelVerifier().assertParameterValueNotNull(this, getValueVariationPoint());
            getModelVerifier().assertParameterHasLegalValue(this, "Float");

            value = getValueInternal();
            setValueChecked();
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public FloatGenElement formatValue() {
        return F.formatFloat(this);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(BigDecimal valueOf) {
        final IModelViewManager vm = getGeneratorModelAccess().getModelViewManager();
        try (IModelViewExecutionContext viewContext = vm.executeWithModelView(getCreationModelView())) {
            try (IModelViewExecutionContext modeContext = vm.executeWithVariantSpecificModelChanges()) {
                getGeneratorModelAccess().getMdfModelAccess().setAsFloat(getMdfObject(), valueOf);
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(double valueLoc) {
        final IModelViewManager vm = getGeneratorModelAccess().getModelViewManager();
        try (IModelViewExecutionContext viewContext = vm.executeWithModelView(getCreationModelView())) {
            try (IModelViewExecutionContext modeContext = vm.executeWithVariantSpecificModelChanges()) {
                getGeneratorModelAccess().getMdfModelAccess().setAsFloat(getMdfObject(), valueLoc);
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIFloatParamDef getDefinition() {
        return (MIFloatParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucFloatDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucFloatParameter getEcuConfiguration() {

        final IEcucParameter cfg = super.getEcuConfiguration();
        return (IEcucFloatParameter) cfg;
    }

}
