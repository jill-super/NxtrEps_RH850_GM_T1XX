package com.vector.cfg.consistency.contribution.helper.validationresults;

import java.util.Collection;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IUISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.contribution.IVariantSolvingAction;
import com.vector.cfg.consistency.contribution.annotations.VariantAware;
import com.vector.cfg.consistency.contribution.helper.EAutoSolvingActionUsage;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SolvingActionBuilder;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SolvingActions;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.model.view.config.variant.IInvariantView;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;

/**
 * The {@link IValidationResultBuilder} interface provides the build API for different {@link ValidationResultBuilder}s, which are the common method to build an
 * {@link IValidationResult}.
 *
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation;GenDevKitDocumentation" id="PBSelect">
 * <p>
 *
 * The created {@link IValidationResult} will have an implicit {@link IModelView} context. The {@link IModelView} which was active during creation of the
 * {@link IValidationResult} is used! If you want to override this behavior, please call the addXXXContext (e.g. <code>addPredefinedVariantContext()</code>) methods.
 *
 * The following methods could be used to set the affected Variants of the result:
 * <ul>
 * <li><code>addPredefinedVariantContext()</code></li>
 * <li><code>addModelViewContext()</code></li>
 * <li><code>addInvariantViewContext()</code></li>
 *
 * </ul>
 *
 * <p>
 * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
 * </p>
 *
 * </p>
 *
 * <p>
 * <b>Requirements</b> for the {@link IValidationResultBuilder}s in Post-build selectable, Variants and View:
 * <ul>
 * <li><em>REQ1</em>: A ValidationResult shall know which Variants are affected by the Results</li>
 * <li><em>REQ2</em>: The client shall be able to set the affected PredefinedVariants and InvariantViews explicitly via API</li>
 * <li><em>REQ3</em>: A ValidationResult shall know when a {@link IPredefinedVariantView} or {@link IInvariantView} was "added" during creation.
 * <ul>
 * <li>Either via explicit API</li>
 * <li>Or implicit over <code>GIModelObject</code></li>
 * <li>Or current active ModelView</li>
 * </ul>
 * </li>
 * <li><em>REQ4</em>: The ValidationResultBuilder shall save the active variant during creation.</li>
 * <li><em>REQ5</em>: The GeneratorResultBuilder shall save the creation ModelViews of passed <code>GIModelObject</code>s</li>
 * <li><em>REQ6</em>: If a ModelView (Predefined or Invariant) is added explicitly via client API, then all implicit set Views shall be deleted from the
 * {@link IValidationResult}.</li>
 * </ul>
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 *
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IValidationResultBuilder<T extends IValidationResultBuilder<T>> {

    /**
     * Builds a new instance of {@link IValidationResult} with the given content of the builder and returns it.
     *
     *
     * <p>
     * Note: The created {@link IValidationResult} will have an implicit ModelView context. The {@link IModelView} which is active during this creation call of the
     * {@link IValidationResult} is used! <br />
     * If you want to override this behavior, please call the addXXXContext (e.g.
     * {@link #addPredefinedVariantContext(com.vector.cfg.model.view.config.variant.IPredefinedVariantView)}) methods.
     * </p>
     *
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. Your could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     * </p>
     *
     * <p>
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     * </p>
     *
     *
     * @return A new {@link IValidationResult}
     *
     * @see IValidationResultSink
     * @see IValidationResult
     * @exception IllegalArgumentException
     * <ul>
     * <li>if no description text is in the result</li>
     * </ul>
     */
    @PublishedMethod
    IValidationResult buildResult();

    /**
     * Adds all {@link IDescriptor}s in the collection to the internal set of dependent ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * @param descriptorList The list of {@link IDescriptor}s describing the dependent ces.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if descriptorList is null</li>
     * </ul>
     */
    @PublishedMethod
    T addDependentDescriptorList(Collection<? extends IDescriptor> descriptorList);

    /**
     * Adds the specified {@link IDescriptor} to the internal set of dependent ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * @param descriptor One {@link IDescriptor} describing the erroneous ce.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if descriptor is null</li>
     * </ul>
     */
    @PublishedMethod
    T addDependentDescriptor(IDescriptor descriptor);

    /**
     * Adds all {@link IDescriptor}s in the collection to the internal set of erroneous ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * @param descriptorList The list of {@link IDescriptor}s describing the erroneous ces.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if descriptorList is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends IDescriptor> T addErrorDescriptorList(final Collection<R> descriptorList);

    /**
     * Adds the specified {@link IDescriptor} to the internal set of erroneous ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     * @param descriptor One {@link IDescriptor} describing the erroneous ce.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if descriptor is null</li>
     * </ul>
     */
    @PublishedMethod
    T addErrorDescriptor(IDescriptor descriptor);

    /**
     * Adds a {@link IDescriptor} which marks the Definition of defRef as dependent, but only within the subtree of parentMdfObject.
     *
     * <p>
     * You can use this method to mark a certain object as missing or needed.
     * </p>
     *
     * <p>
     * Note: This element is not marked as erroneous.
     * </p>
     *
     * To mark a missing module, create a descriptor with the project service {@link IDescriptorFactoryUtil.createDescriptor(defRefModule, null, null)}
     *
     * @param parentMdfObject The parent element. If it is an instance of {@link MIHasDefinition}, it can even be any grandparent.
     * @param missingCeDefRef The {@link DefRef} object of the missing element.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if parentMdfObject is null</li>
     * <li>if missingCeDefRef is null</li>
     * </ul>
     */
    @PublishedMethod
    T addDependentMissingObject(MIObject parentMdfObject, DefRef missingCeDefRef);

    /**
     * Adds a {@link IDescriptor} which marks the Definition of defRef as erroneous, but only within the subtree of parentMdfObject.
     *
     * <p>
     * You can use this method to mark a certain object as missing or needed.
     * </p>
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     * To mark a missing module, create a descriptor with the project service {@link IDescriptorFactoryUtil.createDescriptor(defRefModule, null, null)}
     *
     * @param parentMdfObject The parent element. If it is an instance of {@link MIHasDefinition}, it can even be any grandparent.
     * @param missingCeDefRef The {@link DefRef} object of the missing element.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if parentMdfObject is null</li>
     * <li>if missingCeDefRef is null</li>
     * </ul>
     */
    @PublishedMethod
    T addErrorMissingObject(MIObject parentMdfObject, DefRef missingCeDefRef);

    /**
     * Adds all objects in the collection to the internal set of dependent ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * @param mdfCollection A collection of MDF model objects
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if mdfCollection is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends MIObject> T addDependentMdfObjectList(Collection<R> mdfCollection);

    /**
     * Adds all objects in the collection to the internal set of dependent ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * @param dependentModelCollection A collection of model objects
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if dependentModelCollection is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends IViewedModelObject> T addDependentViewedModelObjectList(Collection<R> dependentModelCollection);

    /**
     * Adds the specified {@link MIObject} to the internal set of dependent ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * @param dependentMdfObject One MDF model object
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if dependentMdfObject is null</li>
     * </ul>
     */
    @PublishedMethod
    T addDependentObject(MIObject dependentMdfObject);

    /**
     * Adds the specified {@link IViewedModelObject} to the internal set of dependent ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * @param dependentModelObject One model object
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if dependentModelObject is null</li>
     * </ul>
     */
    @PublishedMethod
    T addDependentObject(IViewedModelObject dependentModelObject);

    /**
     * Adds the contained modelObject, which could be transformed into an {@link IDescriptor} to the internal set of dependent ConfigurationElements (CEs). It is ensured that
     * the internal set never contain duplicate ConfigurationElements.
     *
     *
     * @param mixedText the text to retrieve the error objects from
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if mixedText is null</li>
     * </ul>
     */
    @PublishedMethod
    T addDependentObjectsFromMixedText(IMixedText mixedText);

    /**
     * Adds all objects in the collection to the internal set of erroneous ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     * @param erroneousMdfCollection A collection of MDF model objects
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if erroneousMdfCollection is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends MIObject> T addErrorMdfObjectList(Collection<R> erroneousMdfCollection);

    /**
     * Adds all objects in the collection to the internal set of erroneous ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     * @param erroneousModelCollection A collection of MDF model objects
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if erroneousModelCollection is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends IViewedModelObject> T addErrorViewedModelObjectList(Collection<R> erroneousModelCollection);

    /**
     * Adds the specified {@link MIObject} model object to the internal set of erroneous ConfigurationElements (CEs). It is ensured that the internal set never contain duplicate
     * ConfigurationElements.
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     * @param erroneousMdfObject One MDF model object
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if erroneousMdfObject is null</li>
     * </ul>
     */
    @PublishedMethod
    T addErrorObject(MIObject erroneousMdfObject);

    /**
     * Adds the specified {@link IViewedModelObject} model object to the internal set of erroneous ConfigurationElements (CEs). It is ensured that the internal set never contain
     * duplicate ConfigurationElements.
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     * @param erroneousModelObject One model object
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if erroneousModelObject is null</li>
     * </ul>
     */
    @PublishedMethod
    T addErrorObject(IViewedModelObject erroneousModelObject);

    /**
     * Adds the contained modelObject, which could be transformed into an {@link IDescriptor} to the internal set of erroneous ConfigurationElements (CEs). It is ensured that
     * the internal set never contain duplicate ConfigurationElements.
     *
     * <p>
     * Note: Every erroneous entry is also added to the dependent list.
     * </p>
     *
     * @param mixedText the text to retrieve the error objects from
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if mixedText is null</li>
     * </ul>
     */
    @PublishedMethod
    T addErrorObjectsFromMixedText(IMixedText mixedText);

    /**
     * Gets the current active {@link IMixedTextBuilder}, if available.
     * <p>
     * Attention: The {@link IMixedTextBuilder} is <b>NOT</b> available, if the builder was already constructed, with an {@link IMixedText}.
     * </p>
     *
     * @return The active {@link IMixedTextBuilder} used for the {@link IValidationResult}.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if there was already a IMixedText passed to the constructor.</li>
     * </ul>
     */
    @PublishedMethod
    IMixedTextBuilder getMixedTextBuilder();

    /**
     * Assigns the ValidationResult a caught exception.
     *
     * <p>
     * Attention: Only one Exception is allowed!
     * </p>
     *
     * @param ex The caught exception to assign to the ValidationResult.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the ex is null</li>
     * <li>if {@link #assignException(Throwable)} was already called with another exception.</li>
     * </ul>
     */
    @PublishedMethod
    T assignException(Throwable ex);

    /*
     * -------------------------------------------------------------- Solving actions --------------------------------------------------------------
     */

    /**
     * Adds a SovlingAction to the internal set of SolvingActions. It is ensured that the internal set never contain duplicate SolvingActions. This method also assigns the
     * solving action to a solving action group, see {@link #assignSolvingActionToGroup(ISolvingAction, ISolvingActionGroup)}.
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. Your could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * <p>
     * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s. The class {@link SolvingActions} provides static method to combines and
     * process {@link ISolvingAction}s.
     * </p>
     *
     * @param solvingAction A solving action
     * @param solvingActionGroup array of or single {@link ISolvingActionGroup}
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if solvingAction is null</li>
     * </ul>
     */
    @PublishedMethod
    T addSolvingAction(ISolvingAction solvingAction, ISolvingActionGroup... solvingActionGroup);

    /**
     * Adds a SovlingAction to the internal set of SolvingActions. It is ensured that the internal set never contain duplicate SolvingActions.
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. You could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * <p>
     * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s. The class {@link SolvingActions} provides static method to combines and
     * process {@link ISolvingAction}s.
     * </p>
     *
     * @param solvingAction A solving action
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if solvingAction is null</li>
     * </ul>
     */
    @PublishedMethod
    T addSolvingAction(ISolvingAction solvingAction);

    /**
     * Adds all SovlingActions in the collection to the internal set of SolvingActions. It is ensured that the internal set never contain duplicate SolvingActions.
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. You could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * <p>
     * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s. The class {@link SolvingActions} provides static method to combines and
     * process {@link ISolvingAction}s.
     * </p>
     *
     * @param solvingActions A collection of solving actions
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if solvingActions is null</li>
     * </ul>
     */
    @PublishedMethod
    T addSolvingAction(Collection<? extends ISolvingAction> solvingActions);

    /**
     * Sets an preferred solving action to the ValidationResult.
     *
     * <p>
     * Attention: It is forbidden to call this method more then once on a builder, because you can only have one PreferredSolvingAction. The method will throw an
     * {@link IllegalStateException}, when it is called more then once.
     * </p>
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. You could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * <p>
     * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s. The class {@link SolvingActions} provides static method to combines and
     * process {@link ISolvingAction}s.
     * </p>
     *
     * @param preferredSolvingActionParam The solving action to add
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if preferredSolvingActionParam is null</li>
     * </ul>
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if {@link #setPreferredSolvingAction(ISolvingAction)} was already called with another solvingAction.</li>
     * </ul>
     */
    @PublishedMethod
    T setPreferredSolvingAction(ISolvingAction preferredSolvingActionParam);

    /**
     * Sets an {@link IUISolvingAction} as preferred solving action.
     *
     * @throws IllegalStateException if any kind of preferred solving action was already set.
     * @param uiSolvingAction the ui solving action
     * @return the t
     */
    @PublishedMethod
    T setPreferredUISolvingAction(IUISolvingAction uiSolvingAction);

    /**
     * Sets an preferred solving action to the ValidationResult.
     *
     * <p>
     * Attention: It is forbidden to call this method more then once on a builder, because you can only have one PreferredSolvingAction. The method will throw an
     * {@link IllegalStateException}, when it is called more then once.
     * </p>
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. You could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * <p>
     * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s. The class {@link SolvingActions} provides static method to combines and
     * process {@link ISolvingAction}s.
     * </p>
     *
     * @param preferredSolvingActionParam The solving action to add
     * @param solvingActionGroups the solving action groups to which the solving action has to be assigned to, see
     * {@link IValidationResultBuilder#assignSolvingActionToGroup(ISolvingAction, ISolvingActionGroup...)}
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if preferredSolvingActionParam is null</li>
     * </ul>
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if {@link #setPreferredSolvingAction(ISolvingAction)} was already called with another solvingAction.</li>
     * </ul>
     */
    @PublishedMethod
    T setPreferredSolvingAction(ISolvingAction preferredSolvingActionParam, ISolvingActionGroup... solvingActionGroups);

    /**
     * Sets an Auto Solving action to the ValidationResult.
     *
     * <p>
     * Attention: It is forbidden to call this method more then once on a builder, because you can only have one AutoSolvingAction. The method will throw an
     * {@link IllegalStateException}, when it is called more then once.
     * </p>
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. You could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * <p>
     * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s. The class {@link SolvingActions} provides static method to combines and
     * process {@link ISolvingAction}s.
     * </p>
     *
     * @param autoSolvingActionParam The solving action to add
     * @param usage Specify an additional usage of the AutoSolvingAction
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if autoSolvingActionParam is null</li>
     * </ul>
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if {@link #addAutoSolvingAction(ISolvingAction)} was already called with another solvingAction.</li>
     * </ul>
     */
    @PublishedMethod
    T setAutoSolvingAction(ISolvingAction autoSolvingActionParam, EAutoSolvingActionUsage usage);

    /**
     * Sets an Auto Solving action to the ValidationResult.
     *
     * <p>
     * Attention: It is forbidden to call this method more then once on a builder, because you can only have one AutoSolvingAction. The method will throw an
     * {@link IllegalStateException}, when it is called more then once.
     * </p>
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. You could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * <p>
     * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s. The class {@link SolvingActions} provides static method to combines and
     * process {@link ISolvingAction}s.
     * </p>
     *
     * @param autoSolvingActionParam The solving action to add
     * @param usage Specify an additional usage of the AutoSolvingAction
     * @param the solving action groups to which the solving action has to be assigned to, see
     * {@link IValidationResultBuilder#assignSolvingActionToGroup(ISolvingAction, ISolvingActionGroup...)}
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if autoSolvingActionParam is null</li>
     * </ul>
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if {@link #addAutoSolvingAction(ISolvingAction)} was already called with another solvingAction.</li>
     * </ul>
     */
    @PublishedMethod
    T setAutoSolvingAction(ISolvingAction autoSolvingActionParam, EAutoSolvingActionUsage usage, ISolvingActionGroup... solvingActionGroups);

    /**
     * Sets an Auto Solving action to the ValidationResult.
     *
     * <p>
     * Attention: It is forbidden to call this method more then once on a builder, because you can only have one AutoSolvingAction. The method will throw an
     * {@link IllegalStateException}, when it is called more then once.
     * </p>
     *
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. You could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * <p>
     * Please also see the class {@link SolvingActionBuilder} to construct {@link ISolvingAction}s. The class {@link SolvingActions} provides static method to combines and
     * process {@link ISolvingAction}s.
     * </p>
     *
     * @param autoSolvingActionParam The solving action to add
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if autoSolvingActionParam is null</li>
     * <li>if {@link #addAutoSolvingAction(ISolvingAction)} was already called with another solvingAction.</li>
     * </ul>
     */
    @PublishedMethod
    T setAutoSolvingAction(ISolvingAction autoSolvingActionParam);

    /**
     * Assigns a solving action to a group. Multiple calls with different groups will accumulate the groups. See interface description of {@link ISolvingActionGroup}
     *
     * <p>
     * Note: The {@link ISolvingAction}s of the {@link IValidationResult} will be executed in the implicit ModelView context, if the {@link IVariantSolvingAction}s do not
     * provide an own {@link IModelView}. If you want to override this behavior, you have to create {@link ISolvingAction} s with an {@link IModelView} active. You could use:
     * {@link SolvingActions#executeInView(IModelView,ISolvingAction)}.
     *
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during the call to {@link #buildResult()}!
     *
     * See also {@link #buildResult()} for more details!
     * </p>
     *
     * @param solvingAction A solving action
     * @param solvingActionGroup a solving action group
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if any parameter is null</li>
     * </ul>
     */
    @PublishedMethod
    T assignSolvingActionToGroup(ISolvingAction solvingAction, ISolvingActionGroup... solvingActionGroup);

    /**
     * Adds a SovlingAction to the internal set of SolvingActions. It is ensured that the internal set never contain duplicate SolvingActions.
     *
     * @param uiSolvingAction A solving action
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if solvingAction is null</li>
     * </ul>
     */
    @PublishedMethod
    T addUISolvingAction(IUISolvingAction uiSolvingAction);

    /**
     * Adds all UISovlingActions in the collection to the internal set of UISovlingActions. It is ensured that the internal set never contain duplicate UISovlingActions.
     *
     * @param uiSolvingActions A collection of solving actions
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if solvingActions is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends IUISolvingAction> T addUISolvingAction(Collection<R> uiSolvingActions);

    /*
     * -------------------------------------------------------------- Predefined Variants and views
     * --------------------------------------------------------------
     */

    /**
     * Adds the passed predefined variant to the variant set, in which this Result will be valid.
     *
     * This method must not be called by variant unaware validators, see{@link VariantAware}<BR>
     *
     * If no or all predefined variants are added, the result is a "general" result.
     *
     * <p>
     * Note: This explicit method for views will remove all implicit set {@link IModelView}s, {@link IInvariantView}s or {@link IPredefinedVariantView}s of other methods. Except
     * the data of the other explicit set methods for views.
     *
     * The explicit set methods for views are:
     * <ul>
     * <li>{@link #addPredefinedVariantContext(IPredefinedVariantView)}</li>
     * <li>{@link #addPredefinedVariantContexts(Collection)}</li>
     * <li>{@link #addInvariantViewContext(IInvariantView)}</li>
     * <li>{@link #addInvariantViewContexts(Collection)}</li>
     * <li>{@link #addModelViewContext(IModelView)}</li>
     * <li>{@link #addModelViewContexts(Collection)}</li>
     * </ul>
     * </p>
     *
     * @param predefinedVariantView the variant view
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if predefinedVariantView is null</li>
     * </ul>
     */
    @PublishedMethod
    T addPredefinedVariantContext(IPredefinedVariantView predefinedVariantView);

    /**
     * Adds the passed predefined variant to the variant set, in which this Result will be valid.
     *
     * This method must not be called by variant unaware validators, see{@link VariantAware}<BR>
     *
     * If no or all predefined variants are added, the result is a "general" result.
     *
     * <p>
     * Note: This explicit method for views will remove all implicit set {@link IModelView}s, {@link IInvariantView}s or {@link IPredefinedVariantView}s of other methods. Except
     * the data of the other explicit set methods for views.
     *
     * The explicit set methods for views are:
     * <ul>
     * <li>{@link #addPredefinedVariantContext(IPredefinedVariantView)}</li>
     * <li>{@link #addPredefinedVariantContexts(Collection)}</li>
     * <li>{@link #addInvariantViewContext(IInvariantView)}</li>
     * <li>{@link #addInvariantViewContexts(Collection)}</li>
     * <li>{@link #addModelViewContext(IModelView)}</li>
     * <li>{@link #addModelViewContexts(Collection)}</li>
     * </ul>
     * </p>
     *
     *
     * @param predefinedVariantViews a collection of variant views
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if predefinedVariantViews is null</li>
     * </ul>
     */
    @PublishedMethod
    T addPredefinedVariantContexts(Collection<IPredefinedVariantView> predefinedVariantViews);

    /**
     * Adds the passed {@link IInvariantView} to the set of InvariantViews contexts.
     *
     * <p>
     * Note: This explicit method for views will remove all implicit set {@link IModelView}s, {@link IInvariantView}s or {@link IPredefinedVariantView}s of other methods. Except
     * the data of the other explicit set methods for views.
     *
     * The explicit set methods for views are:
     * <ul>
     * <li>{@link #addPredefinedVariantContext(IPredefinedVariantView)}</li>
     * <li>{@link #addPredefinedVariantContexts(Collection)}</li>
     * <li>{@link #addInvariantViewContext(IInvariantView)}</li>
     * <li>{@link #addInvariantViewContexts(Collection)}</li>
     * <li>{@link #addModelViewContext(IModelView)}</li>
     * <li>{@link #addModelViewContexts(Collection)}</li>
     * </ul>
     * </p>
     *
     * @param invariantView the Invariant view
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if invariantView is null</li>
     * </ul>
     */
    @PublishedMethod
    T addInvariantViewContext(IInvariantView invariantView);

    /**
     * Adds all elements in the passed collection to the set of InvariantViews contexts.
     *
     * <p>
     * Note: This explicit method for views will remove all implicit set {@link IModelView}s, {@link IInvariantView}s or {@link IPredefinedVariantView}s of other methods. Except
     * the data of the other explicit set methods for views.
     *
     * The explicit set methods for views are:
     * <ul>
     * <li>{@link #addPredefinedVariantContext(IPredefinedVariantView)}</li>
     * <li>{@link #addPredefinedVariantContexts(Collection)}</li>
     * <li>{@link #addInvariantViewContext(IInvariantView)}</li>
     * <li>{@link #addInvariantViewContexts(Collection)}</li>
     * <li>{@link #addModelViewContext(IModelView)}</li>
     * <li>{@link #addModelViewContexts(Collection)}</li>
     * </ul>
     * </p>
     *
     * @param invariantViews the Collection of {@link IInvariantView}s.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if invariantViews is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends IInvariantView> T addInvariantViewContexts(Collection<R> invariantViews);

    /**
     * Adds the passed {@link IModelView} either to the PredefinedVariantView, if the instance is of type {@link IPredefinedVariantView}, or to the invariantViews, if the type
     * is instance of {@link IInvariantView}.
     * <p>
     * If the instance is none of the above, nothing will happen.
     * </p>
     *
     * <p>
     * See also the methods {@link #addPredefinedVariantContext(IPredefinedVariantView)} and {@link #addInvariantViewContext(IInvariantView)} for more details!
     * </p>
     *
     *
     * <p>
     * Note: This explicit method for views will remove all implicit set {@link IModelView}s, {@link IInvariantView}s or {@link IPredefinedVariantView}s of other methods. Except
     * the data of the other explicit set methods for views.
     *
     * The explicit set methods for views are:
     * <ul>
     * <li>{@link #addPredefinedVariantContext(IPredefinedVariantView)}</li>
     * <li>{@link #addPredefinedVariantContexts(Collection)}</li>
     * <li>{@link #addInvariantViewContext(IInvariantView)}</li>
     * <li>{@link #addInvariantViewContexts(Collection)}</li>
     * <li>{@link #addModelViewContext(IModelView)}</li>
     * <li>{@link #addModelViewContexts(Collection)}</li>
     * </ul>
     * </p>
     *
     * @param view the {@link IModelView} to add to the views in context.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if view is null</li>
     * </ul>
     */
    @PublishedMethod
    T addModelViewContext(IModelView view);

    /**
     * Adds all elements in the passed collection either to the PredefinedVariantView, if the instance is of type {@link IPredefinedVariantView}, or to the invariantViews, if
     * the type is instance of {@link IInvariantView}.
     * <p>
     * If the instance is none of the above, nothing will happen.
     * </p>
     *
     * <p>
     * See also the methods {@link #addPredefinedVariantContext(IPredefinedVariantView)} and {@link #addInvariantViewContext(IInvariantView)} for more details!
     * </p>
     *
     *
     * <p>
     * Note: This explicit method for views will remove all implicit set {@link IModelView}s, {@link IInvariantView}s or {@link IPredefinedVariantView}s of other methods. Except
     * the data of the other explicit set methods for views.
     *
     * The explicit set methods for views are:
     * <ul>
     * <li>{@link #addPredefinedVariantContext(IPredefinedVariantView)}</li>
     * <li>{@link #addPredefinedVariantContexts(Collection)}</li>
     * <li>{@link #addInvariantViewContext(IInvariantView)}</li>
     * <li>{@link #addInvariantViewContexts(Collection)}</li>
     * <li>{@link #addModelViewContext(IModelView)}</li>
     * <li>{@link #addModelViewContexts(Collection)}</li>
     * </ul>
     * </p>
     *
     * @param views the Collection of {@link IModelView}s to add to the views in context.
     * @return This builder
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if views is null</li>
     * </ul>
     */
    @PublishedMethod
    <R extends IModelView> T addModelViewContexts(Collection<R> views);

    /**
     * This method should only be used in exceptional cases. Usually, validation-results are distinguished by result-id, the erroneous-CE-set and the dependent-CE-set. If
     * results are replaced by each other even if they shouldn't, consider using different result-IDs. If this is not meaningful, you can set any additional distinguishing
     * object with this method. Be careful, because this object has influence on the consistency performance and functionality. E.g. you may use class objects or constant string
     * objects. Be extremely careful if you tend to implement your own object to be used here.
     *
     * @param additionalDistinguishingObjectParam
     * @return this
     */
    @PublishedMethod
    T setAdditionalDistinguishingObject(Object additionalDistinguishingObjectParam);
}
