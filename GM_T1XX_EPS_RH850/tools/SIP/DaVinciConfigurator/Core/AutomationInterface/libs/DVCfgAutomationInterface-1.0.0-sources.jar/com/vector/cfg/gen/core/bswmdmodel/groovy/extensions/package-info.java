/**
 * Automation scripting extensions of bswmd model types for convenient access in Groovy code.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.bswmdmodel.groovy.extensions;