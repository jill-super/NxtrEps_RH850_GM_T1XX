package com.vector.cfg.gen.core.gencore.generationsteps;

import java.util.List;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationResultSource;
import com.vector.cfg.gen.core.moduleinterface.EGenerationPhaseType;

/**
 *
 * <p>
 * The {@link IGenerationStep} must implement {@link #equals(Object)} and {@link #hashCode()}, or must ensure, that object identity is given.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IGenerationStep extends IValidationResultSource {

    @PublishedMethod
    String getName();

    @PublishedMethod
    List<EGenerationPhaseType> getPhasesToExecute();

    @PublishedMethod
    EGenStepExecutionType getExecutionType();
}
