package com.vector.cfg.consistency.contribution.helper.modeltraverser;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.consistency.contribution.IValidator;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.IRuleAlgorithm;

/**
 * {@link ERuleTraverserAlgorithmExecutionType} is internally used to indicate if the currelty executed {@link IRuleTraverserAlgorithm} is executed form another
 * {@link IRuleAlgorithm} or from an {@link IValidator}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum ERuleTraverserAlgorithmExecutionType {

    /**
     * ALGORITHM indicates, that the calls in the validation rule ( AbstractModelTraverserAlgorithmValidation) are issued by a
     * {@link IRuleTraverserAlgorithm#perform(com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition, java.util.Collection)} call.
     */
    ALGORITHM,

    /**
     * VALIDATION indicates, that the calls in the validation rule ( AbstractModelTraverserAlgorithmValidation) are issued by a
     * {@link IValidator#onModelEvent(com.vector.cfg.consistency.contribution.IValidationResultSink, java.util.Collection)} call.
     */
    VALIDATION;
}
