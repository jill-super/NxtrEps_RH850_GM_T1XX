package com.vector.cfg.gen.core.utils.query.sorters;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.IGeneratorModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.param.GInteger;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.CompareResult;
import com.vector.cfg.util.query.ElementSorter;

/**
 * The {@link GenIntParameterSorter} is a {@link ElementSorter} for two {@link GInteger} objects.
 *
 * You could specify the {@link EValueSorterType}, to allow or forbid equal values.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenIntParameterSorter extends ElementSorter<GInteger> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenIntParameterSorter.class);

    private final EValueSorterType sorterType;

    /**
     * Constructor for GenIntValueSorter.
     *
     * @param sorterType the sorter type
     */
    @PublishedMethod
    public GenIntParameterSorter(EValueSorterType sorterType) {
        this.sorterType = sorterType;
    }

    /**
     * Constructor for GenIntValueSorter.
     *
     */
    @PublishedMethod
    public GenIntParameterSorter() {
        this(EValueSorterType.VALUE_EQUAL_ALLOWED);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected CompareResult compareElements(GInteger element1, GInteger element2) {

        final IGeneratorModelAccess genMa = (IGeneratorModelAccess) element1.getGeneratorModelAccess();

        if (element1.getValue() < element2.getValue()) {
            return CompareResult.ELEMENT_1_BEFORE_ELEMENT_2;
        } else if (element1.getValue().equals(element2.getValue())) {
            if (sorterType.equals(EValueSorterType.VALUE_EQUAL_ALLOWED)) {
                return CompareResult.ELEMENTS_EQUAL;
            } else if (sorterType.equals(EValueSorterType.VALUE_EQUAL_FORBIDDEN)) {

                final IGeneratorResult result = GeneratorResultBuilder
                        .newBuilder(CommonGeneratorResultIds.getElementNotUniqueErrorId(genMa.getValidationResultOrigin()),
                                "The two Integer values {0} and {1} are the same. These values should be unique.", element1.getObjectLink(), element2.getObjectLink())
                        .addErrorObject(element1).addErrorObject(element2).addErrorObject(element1.getParent()).addErrorObject(element2.getParent()).buildResult();

                throw new ValidationFailedException(result);

            } else {
                throw new IllegalArgumentException("The sorterType has an unknown value.");
            }

        } else {
            return CompareResult.ELEMENT_1_AFTER_ELEMENT_2;
        }
    }
}
