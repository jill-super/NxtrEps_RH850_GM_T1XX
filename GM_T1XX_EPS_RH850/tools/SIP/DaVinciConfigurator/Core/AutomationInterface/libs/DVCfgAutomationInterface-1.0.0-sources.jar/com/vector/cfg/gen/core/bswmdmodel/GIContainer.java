package com.vector.cfg.gen.core.bswmdmodel;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucContainer;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.state.IContainerStatePublished;

/**
 * Base interface of bswmd model container.
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see MIContainer
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIContainer extends GIHasContainer {
    // CHECKSTYLE:ON

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    MIContainerDef getDefinition();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucContainerDefinition getEcucDefinition();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucContainer getEcuConfiguration();

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    MIContainer getMdfObject();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IContainerStatePublished getCeState();

    /*----------------------------------------------------------------
     * existsParameter() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns <code>true</code> if the specified parameter exists.
     *
     * @param defRef The {@link DefRef} of the requested element
     * @return true, if the element exists.
     */
    @Override
    @PublishedMethod
    boolean existsParameter(DefRef defRef);

    /**
     * Returns <code>true</code> if the specified parameter exists.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return true, if the element exists.
     *
     * @deprecated Please use {@link #existsParameter(DefRef)}.
     */
    @Deprecated
    @PublishedMethod
    boolean existsParameter(String defRef);

    /*----------------------------------------------------------------
     * getParameter() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns one parameter with the specified definition-name stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return The Parameters which has the definition {@link DefRef}.
     */
    @PublishedMethod
    GIParameter<?> getParameter(DefRef defRef);

    /**
     * Returns one parameter with the specified definition-name stored in the MDF model.
     *
     * @param defRef The {@link TypedDefRef} of the requested element.
     * @return The Parameters which has the definition {@link TypedDefRef}.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE> GIParameter<VALUE> getParameter(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns one parameter with the specified definition-name stored in the MDF model.
     *
     * @param defRef The {@link WrappedTypedDefRef} of the requested element.
     * @return a List of Parameters which has the definition {@link WrappedTypedDefRef}.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE, WRAPPER extends GIParameter<VALUE>> WRAPPER getParameter(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * getParameters() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns the list of parameters. (Textual and Numerical parameter).
     *
     * <p>
     * This request is <b>NON</b> recursive, so only the immediate childs are returned!
     * </p>
     *
     * <p>
     * This method will not return any references!
     * </p>
     *
     * @return
     */
    @PublishedMethod
    List<GIParameter<?>> getParameters();

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return a List of Parameters which has the definition.
     *
     * @deprecated Please use {@link #getParameters(DefRef)}.
     */
    @Deprecated
    @PublishedMethod
    List<GIParameter<?>> getParameters(String defRef);

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return a List of Parameters which has the definition {@link DefRef}.
     */
    @Override
    @PublishedMethod
    List<GIParameter<?>> getParameters(DefRef defRef);

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link TypedDefRef} of the requested element.
     * @return a List of Parameters which has the definition {@link TypedDefRef}.
     */
    @Override
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE> List<GIParameter<VALUE>> getParameters(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link WrappedTypedDefRef} of the requested element.
     * @return a List of Parameters which has the definition {@link WrappedTypedDefRef}.
     */
    @Override
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE, WRAPPER extends GIParameter<VALUE>, T extends WRAPPER> List<T> getParameters(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * existsReference() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns <code>true</code> if the specified reference exists.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return true, if the reference exists.
     */
    @Override
    @PublishedMethod
    boolean existsReference(DefRef defRef);

    /**
     * Returns <code>true</code> if the specified reference exists.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return true, if the reference exists.
     *
     * @deprecated Please use {@link #existsReference(DefRef)}.
     */
    @Deprecated
    @PublishedMethod
    boolean existsReference(String defRef);

    /*----------------------------------------------------------------
     * getReference() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns the one reference pointing to the container with the specified definition-name stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return a Reference which has the definition.
     */
    @PublishedMethod
    GIReference<?> getReference(DefRef defRef);

    /**
     * Returns the one reference pointing to the container with the specified definition-name stored in the MDF model.
     *
     * @param defRef The {@link TypedDefRef} of the requested element.
     * @return a Reference which has the definition.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable> GIReference<VALUE> getReference(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns the one reference pointing to the container with the specified definition-name stored in the MDF model.
     *
     * @param defRef The {@link WrappedTypedDefRef} of the requested element.
     * @return a Reference which has the definition.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable, WRAPPER extends GIReference<?>> WRAPPER getReference(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * getReferenceToContainer() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns the one reference pointing to the container with the specified definition-name stored in the MDF model.
     *
     * @param defRef The {@link TypedDefRef} of the requested element.
     * @return The Reference which has the definition.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE extends MIContainer> GIReferenceToContainer getReferenceToContainer(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns the one reference pointing to the container with the specified definition-name stored in the MDF model.
     *
     * @param defRef The {@link TypedDefRef} of the requested element.
     * @return a Reference which has the definition.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE extends MIContainer, WRAPPER extends GIReferenceToContainer> WRAPPER getReferenceToContainer(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * getReferences() section
     * ----------------------------------------------------------------
     */

    /**
     *
     * Returns the list of references. (MIReferenceValue and MIInstanceReferenceValue references).
     *
     * <p>
     * This request is <b>NON</b> recursive, so only the immediate childs are returned!
     * </p>
     *
     * <p>
     * This method will not return any parameters like {@link MINumericalValue}!
     * </p>
     *
     * @return a List of References.
     */
    @PublishedMethod
    List<GIReference<?>> getReferences();

    /**
     * Returns all references with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested element
     * @return a List of References which has the definition.
     *
     * @deprecated Please use {@link #getReferences(DefRef)}.
     */
    @Deprecated
    @PublishedMethod
    List<GIReference<?>> getReferences(String defRef);

    /**
     * Returns all references with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * <p>
     * Non immediate child {@link DefRef}s are also permitted for the request.
     * </p>
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return a List of References which has the definition.
     */
    @Override
    @PublishedMethod
    List<GIReference<?>> getReferences(DefRef defRef);

    /**
     * Returns all references with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return a List of References which has the definition.
     */
    @Override
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable> List<GIReference<VALUE>> getReferences(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns all references with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link WrappedTypedDefRef} of the requested element.
     * @return a List of References which has the definition.
     */
    @Override
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable, WRAPPER extends GIReference<VALUE>, T extends WRAPPER> List<T> getReferences(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * getReferencesToContainer() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns all references with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested element.
     * @return a List of References which has the definition.
     */
    @Override
    @PublishedMethod
    List<GIReferenceToContainer> getReferencesToContainer(DefRef defRef);

    /**
     * Returns all references pointing to containers with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested element
     * @return a List of References which has the definition.
     */
    @Override
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE> List<GIReferenceToContainer> getReferencesToContainer(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns all references pointing to containers with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link WrappedTypedDefRef} of the requested element
     * @return a List of References which has the definition.
     */
    @Override
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE, WRAPPER extends GIReferenceToContainer, T extends WRAPPER> List<T> getReferencesToContainer(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * getReferencesPointingToMe() section
     * ----------------------------------------------------------------
     */

    /**
     * Gets all {@link GIReferenceToContainer} that are currently pointing to this {@link GIContainer}.
     *
     * @return the {@link GIReferenceToContainer}s
     */
    @PublishedMethod
    List<GIReferenceToContainer> getReferencesPointingToMe();

    /**
     * Gets all {@link GIReferenceToContainer} with the passed definition (definitionOfReferenceParameter) that are currently pointing to this
     * {@link GIContainer}.
     *
     * @param definitionOfReferenceParameter the DefRef of the requested references.
     * @return the {@link GIReferenceToContainer}s
     */
    @PublishedMethod
    List<GIReferenceToContainer> getReferencesPointingToMe(DefRef definitionOfReferenceParameter);

    /**
     * Gets all {@link GIReferenceToContainer} with the passed definition (definitionOfReferenceParameter) that are currently pointing to this
     * {@link GIContainer}.
     *
     * @param definitionOfReferenceParameter the DefRef of the requested references.
     * @return the {@link GIReferenceToContainer}s
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE, WRAPPER, T extends WRAPPER> List<T> getReferencesPointingToMe(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> definitionOfReferenceParameter);

}
