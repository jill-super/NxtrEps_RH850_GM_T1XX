package com.vector.cfg.consistency.contribution.helper.rulebuilding.usecases.requirenonemptytextualvalue;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.IValidator;
import com.vector.cfg.consistency.internal.contribution.helper.rulebuilding.usecases.requirenonemptytextualvalue.RequireNonEmptyTextualValue;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class RequireNonEmptyTextualValueRuleBuilder {

    @PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
    public interface IValidationResultTextBuilder {
        /**
         * Use the builder to specify the full VR text.
         *
         * @param builder
         * @param param
         */
        @PublishedMethod
        void buildText(IMixedTextBuilder builder, MITextualValue param);
    }

    @PublishedMethod
    public RequireNonEmptyTextualValueRuleBuilder(IValidationResultId id, DefRef textualValueDefRef) {
        this.id = id;
        this.textualValueDefRef = textualValueDefRef;
    }

    private final IValidationResultId id;

    private final DefRef textualValueDefRef;

    private String ruleName;

    /**
     * Set the rule name if you don't want the default rule Name.
     *
     * @param ruleNameParam
     */
    @PublishedMethod
    public RequireNonEmptyTextualValueRuleBuilder setRuleName(String ruleNameParam) {
        ruleName = ruleNameParam;
        return this;
    }

    private String ruleDescription;

    /**
     * Set the rule description if you don't want the default rule Description.
     *
     * @param ruleDescriptionParam
     */
    @PublishedMethod
    public RequireNonEmptyTextualValueRuleBuilder setRuleDescription(String ruleDescriptionParam) {
        ruleDescription = ruleDescriptionParam;
        return this;
    }

    private IValidationResultTextBuilder optTextBuilder;

    /**
     * Set your own Text Builder if you don't want the default validation result text.
     *
     * @param textBuilder
     */
    @PublishedMethod
    public RequireNonEmptyTextualValueRuleBuilder setTextBuilder(IValidationResultTextBuilder textBuilder) {
        optTextBuilder = textBuilder;
        return this;
    }

    @PublishedMethod
    public IValidator build() {
        if (ruleName == null) {
            ruleName = textualValueDefRef.getLastShortname() + " not empty validation";
        }
        if (ruleDescription == null) {
            ruleDescription = "This validator checks that a " + textualValueDefRef.getLastShortname() + " parameter instance doesn't have an empty value";
        }
        return new RequireNonEmptyTextualValue(ruleName, ruleDescription, textualValueDefRef, id, optTextBuilder);
    }
}
