package com.vector.cfg.consistency.contribution.helper.solvingactions;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IHasDescription;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.internal.shared.ProjectService;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.operations.IModelOperationsPublished;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.IModelSimpleAccess;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.IProjectService;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation;GenDevKitDocumentation" id="Common"> <h5>Creation of SolvingActions</h5> The
 * {@link SolvingActionBuilder} provides an API to construct an {@link ISolvingAction}, which provides certain features:
 * <ul>
 * <li>You can define the {@link IModelView}, which shall be active during {@link #run()}</li>
 * <li>You can use the provided {@link IProjectService}s, without retrieving them, like:
 * <ul>
 * <li>modelOperations: {@link IModelOperationsPublished}</li>
 * <li>mca: {@link IModelCheckedAccess}</li>
 * <li>msa: {@link IModelSimpleAccess}</li>
 * <li>ma: {@link IModelAccess}</li>
 * <li>modelViewMgr: {@link IModelViewManager}</li>
 * </ul>
 * </li>
 * <li>You can override the {@link #getDescription()} to lazily provide a description, instead during construction time.</li>
 * </ul>
 *
 * The sample code constructs a {@link ISolvingAction}, which simply sets a float parameter to the value 3.
 *
 * <pre>
 * <code class="Java" id="Sample code to construct an ISolvingAction with SolvingActionBuilder">
 *  final ValidationResultBuilder valBuilder = ...;
 *
 *  final ISolvingAction sa =
 *      new SolvingActionBuilder(projectContext, "Set value to 3") {
 *
 *    @Override
 *    public void run() {
 *        ma.setAsFloat(param1, 3);
 *    }
 *
 *  }.build();
 *
 *  valBuilder.addSolvingAction(sa);
 * </code>
 * </pre>
 *
 * </div>
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation;GenDevKitDocumentation" id="PostBuildSelectable">
 *
 * For the Post-build selectable use case, you could also explicitly pass an {@link IModelView}, which will be active during the {@link #run()} method call.
 *
 * <pre>
 * <code class="Java" id="Construct an ISolvingAction with an ModelView">
 *  final IModelView variantFrontLeft = ...;
 *
 *  final ISolvingAction sa =
 *      new SolvingActionBuilder(projectContext,
 *          "Set value to 3 in Variant Front Left",
 *          variantFrontLeft) {
 *
 *    @Override
 *    public void run() {
 *        ma.setAsFloat(param1, 3);
 *    }
 *
 *  }.build();
 *
 * </code>
 * </pre>
 *
 *
 * You can use {@link ProjectService}s in the run method like in the sample below:
 *
 * <pre>
 * <code class="Java" id="Usage of ProjectServices in the SolvingActionBuilder">
 *  final ISolvingAction sa =
 *      new SolvingActionBuilder(projectContext, "Create and set all values to 3") {
 *
 *    @Override
 *    public void run() {
 *        //Use of the modelOperations
 *        final MIParameterValue param1 = modelOperations.createParameterByDefinition(parent, DEFREF);
 *        final MIParameterValue param2 = modelOperations.createParameterByDefinition(parent, DEFREF);
 *
 *        //Use the ModelAccess
 *        ma.setAsFloat(param1, 3);
 *
 *        //Use the ModelViewManager
 *        IInvariantEcucDefView ecucDefView = modelViewMgr.getInvariantEcucDefView();
 *    }
 *
 *  }.build();
 *
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@NotThreadSafe
public abstract class SolvingActionBuilder implements Runnable, IHasDescription {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SolvingActionBuilder.class);

    @Nonnull
    private final IModelView viewToActivate;

    @Nullable
    private final String description;

    @PublishedField
    protected final IModelOperationsPublished modelOperations;

    @PublishedField
    protected final IModelCheckedAccess mca;

    @PublishedField
    protected final IModelSimpleAccess msa;

    @PublishedField
    protected final IModelAccess ma;

    @PublishedField
    protected final IModelViewManager modelViewMgr;

    /**
     * Create a {@link SolvingActionBuilder} with the passed description.
     *
     * <p>
     * The {@link IModelView} context is the {@link IModelView}, which is passed as parameter to this constructor.
     * </p>
     *
     * <p>
     * You have to call {@link #build()}, at the end of the construction process. You will get the {@link ISolvingAction}, from the {@link #build()} method.
     * </p>
     *
     * @param projectContext the project context
     * @param description The Description of the {@link ISolvingAction}
     * @param viewToActivate The {@link IModelView}, which is active during {@link #run()}
     */
    @PublishedMethod
    public SolvingActionBuilder(IProjectContext projectContext, String description, IModelView viewToActivate) {
        checkNotNull(projectContext);

        this.description = description;
        modelOperations = projectContext.getService(IModelOperationsPublished.class);
        ma = projectContext.getService(IModelAccess.class);
        mca = projectContext.getService(IModelCheckedAccess.class);
        msa = projectContext.getService(IModelSimpleAccess.class);

        modelViewMgr = projectContext.getService(IModelViewManager.class);

        if (viewToActivate == null) {
            this.viewToActivate = modelViewMgr.getCurrentlyActiveView();
        } else {
            this.viewToActivate = viewToActivate;
        }

    }

    /**
     * Create a {@link SolvingActionBuilder} with the passed description.
     *
     * <p>
     * The implicit {@link IModelView} context is the {@link IModelView}, which is active during this constructor call!
     * </p>
     *
     * <p>
     * You have to call {@link #build()}, at the end of the construction process. You will get the {@link ISolvingAction}, from the {@link #build()} method.
     * </p>
     *
     * @param projectContext the project context
     * @param description The Description of the {@link ISolvingAction}
     */
    @PublishedMethod
    public SolvingActionBuilder(IProjectContext projectContext, String description) {
        this(projectContext, description, null);

    }

    /**
     * Create a {@link SolvingActionBuilder} with no description.
     *
     * <p>
     * Caution: You have to override the {@link #getDescription()} method to return a Description, if you use this constructor!
     * </p>
     *
     * <p>
     * You have to call {@link #build()}, at the end of the construction process. You will get the {@link ISolvingAction}, from the {@link #build()} method.
     * </p>
     *
     * @param projectContext the project context
     */
    @PublishedMethod
    public SolvingActionBuilder(IProjectContext projectContext) {
        this(projectContext, null, null);

    }

    /**
     * Creates the {@link ISolvingAction}, with the specified execution code.
     *
     * @return the new {@link ISolvingAction} created from the builder.
     */
    @PublishedMethod
    public final ISolvingAction build() {
        final String descLoc = getDescription();
        checkNotNull(descLoc, "You must set a description in the constructor, or by overriding the method getDescription().");
        checkArgument(!descLoc.isEmpty());

        final ISolvingAction sa = SolvingActions.createSolvingActionWrapper(descLoc, this);
        return SolvingActions.executeInView(viewToActivate, sa);

    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Note: You could override this method, to lazily create the description. Then please use the {@link #SolvingActionBuilder(IProjectContext)} constructor.
     * </p>
     */
    @Override
    @PublishedMethod
    public String getDescription() {
        return description;
    }

}
