package com.vector.cfg.gen.core.utils.generatorpackage;

import static com.google.common.base.Preconditions.checkArgument;

import java.text.MessageFormat;
import java.util.Collections;
import java.util.List;

import org.eclipse.osgi.service.resolver.VersionRange;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.business.model.vtt.IVttUtilServicePublished;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.EDefRefWildcard;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBswImplementation;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBswImplementationARRef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.query.modelcheckedaccess.elements.IMcaRequest;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * A generator specific utility class for {@link IGeneratorPackage}s.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GeneratorPackageUtil {
    private static final DefRef CDD_MODULE = DefRef.create(EDefRefWildcard.ANY, "Cdd");

    private static final ILogger logger = Logger.INSTANCE.createLogger(GeneratorPackageUtil.class);

    @PublishedField
    public static final String MAX_VERSION_RANGE_STRING = "[0.0.0," + Integer.MAX_VALUE + "." + Integer.MAX_VALUE + "." + Integer.MAX_VALUE + "]";

    @PublishedField
    public static final VersionRange MAX_VERSION_RANGE = new VersionRange(MAX_VERSION_RANGE_STRING);

    private GeneratorPackageUtil() {

    }

    /**
     * @param generatorPackage
     * @return
     */
    @PublishedMethod
    public static String getAlmComponentName(IGeneratorPackage generatorPackage) {
        if (generatorPackage == null) {
            throw new IllegalArgumentException("generatorPackage is null");
        }

        final String[] split = generatorPackage.getQualifiedJavaPackageName().split("\\.");

        return split[split.length - 1];
    }

    /**
     * Returns the MSN WITHOUT VendorApiInfix and Vendor Id for a the passed module configuration. <br/>
     *
     * CDD:<br/>
     * In case of CDD module the short name of the module configuration is returned or if apiServicePrefix is available, this value is used instead. <br/>
     * In case of CDD no VendorApiInfix or Vendor Id is applied. <br/>
     *
     * VTT:<br/>
     * VTT modules are evaluated directly. NO Real module is used instead. <br/>
     *
     * @param moduleConfig Module configuration
     * @return Module short name (MSN)
     */
    @PublishedMethod
    public static String getMsn(MIModuleConfiguration moduleConfig) {
        return getMsnInternal(moduleConfig, false, false);
    }

    /**
     * Returns the MSN WITHOUT VendorApiInfix and Vendor Id for a the passed module configuration. <br/>
     * If a VTT module is passed the corresponding real module is used instead. <br/>
     *
     * CDD:<br/>
     * In case of CDD module the short name of the module configuration is returned or if apiServicePrefix is available, this value is used instead. <br/>
     * In case of CDD no VendorApiInfix or Vendor Id is applied. <br/>
     *
     * VTT:<br/>
     * If a VTT module is passed, the corresponding real module is used instead. <br/>
     * If no Real module could be found, the VTT module is used as default.<br/>
     * Only active module configuration are taken into account for the real module lookup. <br/>
     *
     * @param moduleConfig Module configuration
     * @return Module short name (MSN)
     */
    @PublishedMethod
    public static String getMsnReal(MIModuleConfiguration moduleConfig) {
        return getMsnInternal(moduleConfig, true, false);

    }

    /**
     * Returns the official Module Short Name of the related Module Configuration. <br>
     * CDD: <br>
     * The MSN is the short name of the module definition. The only exception is CDD Module.<br>
     * For CDD modules the short name of the module configuration is returned or the apiServicePrefix if specified. <br/>
     *
     * VTT: <br>
     * If shallVttModulesBeResolved is set the real related module configuration is used instead of VTT. (Only instantiated module configs are evaluated)<br>
     * If the related module can not be found, the VTT module is used instead.
     *
     * @param moduleConfig Module configuration
     * @param shallVttModulesBeResolved True: If a VTT module is passed, the corresponding real module is looked up and the real Msn is used. False: the passed
     * module is used.
     * @param shallApiInfixAndIdBeUsed True: <Module short name>_<Vendor Id>_<Vendor specific Name>. See requirement BSW00347. False: Just MSN.
     * @return
     */
    private static String getMsnInternal(MIModuleConfiguration moduleConfig, boolean shallVttModulesBeResolved, boolean shallApiInfixAndIdBeUsed) {
        if (moduleConfig == null) {
            throw new IllegalArgumentException("Passed ModuleConfiguration must not be null");
        }

        /*
         * Replace module config by real one if available.
         */
        if (shallVttModulesBeResolved) {
            final MIModuleConfiguration vttModuleConfig = fetchRealFromVttModule(moduleConfig);
            // If a valid VTT module config was found replace the passed module config
            if (vttModuleConfig != null) {
                moduleConfig = vttModuleConfig;
            }
        }

        if ((moduleConfig.getDefinitionRef() == null) || (moduleConfig.getDefinitionRef().getRefTarget() == null)) {
            throw new IllegalArgumentException(MessageFormat.format("ModuleDefinition of ModuleConfiguration {0} could not be resolved.", moduleConfig.getName()));
        }

        final IProjectContext projectContext = ModelUtil.getProjectContext(moduleConfig);
        final IModelAccess ma = projectContext.getService(IModelAccess.class);

        final MIModuleDef moduleDef = moduleConfig.getDefinitionRef().getRefTarget();
        final String moduleDefName = moduleDef.getName();
        final DefRef moduleDefRef = DefRef.create(moduleConfig);

        if (moduleDefRef.isRefinedOf(CDD_MODULE, ma)) {
            /*
             * Check if "API Service Prefix" exists for this module
             */
            final String apiServicePrefix = moduleDef.getApiServicePrefix();
            if ((apiServicePrefix == null) || (apiServicePrefix.isEmpty())) {
                // No ApiServicePrefis is present so use the configuration name
                return moduleConfig.getName();
            } else {
                return apiServicePrefix;
            }
        } else {
            if (shallApiInfixAndIdBeUsed) {
                /*
                 * Attach <Vendor Id> and <Vendor specific Name>
                 */
                final MIBswImplementationARRef moduleDescription = moduleConfig.getModuleDescription();

                /*
                 * If no BSW Implementation Node, no VendorApiInfix or no VendorId are present, just the short name of the MSN is returned. -> Shortname
                 * of AUTOSAR Standard Def is used.
                 */
                if ((moduleDescription == null) || (moduleDescription.getRefTarget() == null) || (moduleDescription.getRefTarget().getVendorApiInfix() == null)
                        || (moduleDescription.getRefTarget().getVendorApiInfix().equals("")) || (moduleDescription.getRefTarget().getVendorId() == null)) {
                    return String.format("%s", moduleDefName);
                }
                final MIBswImplementation bswImpl = moduleDescription.getRefTarget();
                return String.format("%s_%s_%s", moduleDefName, bswImpl.getVendorId().toString(), bswImpl.getVendorApiInfix());
            } else {
                return moduleDefName;
            }
        }
    }

    /**
     * Returns the real module config of a passed VTT module config or NULL in case of an error. <br>
     * One VTT module can have multiple real module Configs. In this case the first module config is returned. <br>
     *
     * @param moduleConfigVtt The VTT module config.
     * @return Real Module Config or NULL if no could be found.
     */
    private static MIModuleConfiguration fetchRealFromVttModule(MIModuleConfiguration moduleConfigVtt) {
        final DefRef defrefVtt = DefRef.create(moduleConfigVtt);

        final IProjectContext pc = ModelUtil.getProjectContext(moduleConfigVtt);
        final IVttUtilServicePublished vus = pc.getService(IVttUtilServicePublished.class);
        if (vus.isVttDefRef(defrefVtt)) {

            List<MIModuleConfiguration> realModuleConfigs = null;
            try {
                realModuleConfigs = getActiveRealModuleConfigsByVttDefRef(defrefVtt, pc);
            } catch (final IllegalArgumentException e) {
                logger.error("getMsn() DefRef of VTT could not be resolved to the corresponding real DefRef. No real DefRef was found. "
                        + defrefVtt.getDefRefString(), e);
            }

            if ((realModuleConfigs == null) || (realModuleConfigs.isEmpty())) {
                // no Real module config was found
                return null;
            }
            return realModuleConfigs.get(0);
        }
        return moduleConfigVtt;

    }

    /**
     * Returns the MSN with VendorApiInfix and Vendor Id for a the passed module configuration. <br/>
     *
     * Return following name: <Module short name>_<Vendor Id>_<Vendor specific Name>. See requirement BSW00347.<br/>
     * E.g. Eep_21_LDExt<br/>
     * If instances shall be accessed an index has to be appended manually. See requirement BSW00413.
     *
     * If no BSW Implementation Node, no VendorApiInfix or no VendorId are present, just the short name of the module definition is returned.<br/>
     * E.g. Eep<br/>
     *
     * CDD:<br/>
     * In case of CDD module the short name of the module configuration is returned or if apiServicePrefix is available, this value is used instead. <br/>
     * In case of CDD no VendorApiInfix or Vendor Id is applied. <br/>
     *
     * VTT:<br/>
     * If a VTT module is passed, the corresponding real module is used instead. <br/>
     * If no Real module could be found, the VTT module is used as default.<br/>
     * Only active module configuration are taken into account for the real module lookup. <br/>
     *
     * @param moduleConfig Module configuration
     * @return Module short name (MSN)
     */
    @PublishedMethod
    public static String getMsnWithVendorApiInfixAndIdReal(MIModuleConfiguration moduleConfig) {
        return getMsnInternal(moduleConfig, true, true);
    }

    /**
     * Takes a VTT DefRef and returns a list of corresponding Real module configurations. <br>
     *
     * @param vttDefRef DefREf of VTT module
     * @param pc ProjectContext
     * @return
     * @exception IllegalArgumentException
     */
    private static List<MIModuleConfiguration> getActiveRealModuleConfigsByVttDefRef(DefRef vttDefRef, IProjectContext pc) {
        checkArgument(pc != null);
        final IVttUtilServicePublished vus = pc.getService(IVttUtilServicePublished.class);
        checkArgument(vus.isVttDefRef(vttDefRef));

        final DefRef moduleDefRef = vus.getGenericModuleDefRefByVttDefRef(vttDefRef);

        final IModelCheckedAccess mca = pc.getService(IModelCheckedAccess.class);
        final IMcaRequest<List<MIModuleConfiguration>> realConfigsRequest = mca.moduleConfig(moduleDefRef).getManyModuleConfigsAsRequest();
        if ((!realConfigsRequest.isValid()) || (realConfigsRequest.getResult().isEmpty())) {
            return Collections.emptyList();
        }
        return realConfigsRequest.getResult();
    }

}
