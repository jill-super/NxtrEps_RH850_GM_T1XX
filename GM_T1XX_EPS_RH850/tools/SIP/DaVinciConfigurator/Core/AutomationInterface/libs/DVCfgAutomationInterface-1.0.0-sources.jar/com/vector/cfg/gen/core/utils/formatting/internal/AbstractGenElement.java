package com.vector.cfg.gen.core.utils.formatting.internal;

import java.util.EnumSet;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.EFormatType;
import com.vector.cfg.gen.core.utils.formatting.GenFormatterUtil;
import com.vector.cfg.gen.core.utils.formatting.GenFormatterUtil.ECEscapeOptions;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatProvider;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * {@link AbstractGenElement} provides the abstract impl for {@link IGenElement}s.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractGenElement<E extends AbstractGenElement<E>> implements IGenElement {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractGenElement.class);

    private String comment;

    private String prefixComment;

    private boolean isImmutable = false;

    /**
     * Instantiates a new abstract gen element.
     */
    @PublishedMethod
    protected AbstractGenElement() {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String generate() {
        return generate(EFormatType.NO_FORMAT);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String generate(IGenFormatProvider formatProvider) {
        final StringBuilder builder = new StringBuilder();

        generateInternal(builder, formatProvider.getFormatter(), 0, true);

        return builder.toString();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void generate(StringBuilder builder, IGenFormatter formatter, int indentLevel, boolean isRootElement) {
        generateInternal(builder, formatter, indentLevel, isRootElement);
    }

    /**
     * Generate internal.
     *
     * @param builder the builder
     * @param formatter the formatter
     * @param indent the indent
     * @param isRootElement the is root element
     */
    @PublishedMethod
    protected abstract void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean isRootElement);

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {

        return generate();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public E comment(String commentParam) {
        ensureObjectIsMutable();
        if (commentParam == null) {
            throw new IllegalArgumentException("commentParam is null");
        }

        if (comment != null) {
            /*
             * Append the new Comment to the existing
             */
            comment += " " + commentParam;
        } else {
            comment = commentParam;
        }

        return (E) this;
    }

    private static String escapeComment(String comment) {
        return GenFormatterUtil.escapeStringForCFile(comment, EnumSet.of(ECEscapeOptions.ESCAPE_NON_ASCII_CHARS, ECEscapeOptions.ESCAPE_SLASH_ASTERIX));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public E prefixComment(String commentParam) {
        ensureObjectIsMutable();
        if (commentParam == null) {
            throw new IllegalArgumentException("commentParam is null");
        }

        if (prefixComment != null) {
            /*
             * Append the new Comment to the existing
             */
            prefixComment += commentParam;
        } else {
            prefixComment = commentParam;
        }

        return (E) this;
    }

    /**
     * Gets the postfix comment.
     *
     * @return the postfix comment
     */
    @PublishedMethod
    protected final String getPostfixComment() {
        return comment;
    }

    /**
     * Gets the prefix comment.
     *
     * @return the prefix comment
     */
    @PublishedMethod
    protected final String getPrefixComment() {
        return prefixComment;
    }

    /**
     * Generate comment internal.
     *
     * @param builder the builder
     * @param content the content
     */
    @PublishedMethod
    protected void generateCommentInternal(StringBuilder builder, String content) {
        builder.append(" /*  ");
        builder.append(escapeComment(content));
        builder.append("  */ ");
    }

    /**
     * Generate postfix comment.
     *
     * @param builder the builder
     */
    @PublishedMethod
    protected void generatePostfixComment(StringBuilder builder) {
        if (getPostfixComment() != null) {
            generateCommentInternal(builder, getPostfixComment());
        }
    }

    /**
     * Generate prefix comment.
     *
     * @param builder the builder
     */
    @PublishedMethod
    protected void generatePrefixComment(StringBuilder builder) {
        if (getPrefixComment() != null) {
            generateCommentInternal(builder, getPrefixComment());
        }
    }

    /**
     * Ensure object is mutable.
     */
    @PublishedMethod
    protected void ensureObjectIsMutable() {
        if (isImmutable) {
            throw new IllegalStateException("The object is already immutable. You can't change the object");
        }
    }

    /**
     * Checks if the {@link AbstractGenElement} is immutable.
     *
     * @return true, if is immutable
     */
    @PublishedMethod
    public boolean isImmutable() {
        return isImmutable;
    }

    /**
     * Sets the {@link AbstractGenElement} to immutable.
     *
     * @return the e
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public E setImmutable() {
        this.isImmutable = true;
        return (E) this;
    }

}
