/**
 * The domain APIs are specifically designed to provide high convenience support for typical domain use cases. <div class="extdoc" id="DomainAPI"><!--Label:DomainAPI-->The
 * domain APIs are specifically designed to provide high convenience support for typical domain use cases.</div> See the <code>com.vector.cfg.dom...</code> packages for
 * examples.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.api.domain;