package com.vector.cfg.consistency.contribution;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.helper.modeltraverser.AbstractModelTraverserValidation;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved. <BR>
 * <BR>
 * This interface represents a validator Rule. If an implementation of this interface throws an exception in the optional initialization methods
 * {@link IConditionalActivation#activate(ISipContext)} or {@link IPostConstructOnActivationOk#onActivationOk()}, or any upcoming, the validator won't be
 * activated.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IValidator extends IHasOnModelEvent, IHasName {
    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    String getName();

    /**
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="getDescription"> The description should explain the consistency rule of the validator,
     * e.g. "This validator assures that the PDU IDs of Com modules comply to the rules described in technical reference XY.", or "This validator assures that
     * the PDU IDs of Com are 0 based and contiguous (without gaps).". The description will be shown to the user e.g. if a validator made a parameter dependent
     * (read-only) to let the user understand why the parameter is read-only. </div>
     */
    @PublishedMethod
    String getDescription();

    /**
     * The {@link AbstractModelTraverserValidation} automatically builds a correct filter, otherwise create one with RuleFilterBuilder.
     *
     * @return an {@link IRuleFilterContribution}
     */
    @PublishedMethod
    IRuleFilterContribution getFilter();
}
