package com.vector.cfg.gen.core.utils.query.sorters;

import java.math.BigInteger;
import java.text.MessageFormat;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.IGeneratorModelAccess;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.CompareResult;
import com.vector.cfg.util.query.ElementSorter;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenIntParameterInContainerSorter extends ElementSorter<GIContainer> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenIntParameterInContainerSorter.class);

    private final EValueSorterType sorterType;

    private final DefRef paramName;

    /**
     * Constructor for GenIntValueSorter.
     *
     * @param paramDefRef the param def ref
     * @param sorterType the sorter type
     */
    @PublishedMethod
    public GenIntParameterInContainerSorter(DefRef paramDefRef, EValueSorterType sorterType) {
        this.sorterType = sorterType;
        this.paramName = paramDefRef;
    }

    /**
     * Constructor for GenIntValueSorter.
     *
     * @param paramDefRef the param def ref
     */
    @PublishedMethod
    public GenIntParameterInContainerSorter(DefRef paramDefRef) {
        this(paramDefRef, EValueSorterType.VALUE_EQUAL_ALLOWED);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected CompareResult compareElements(GIContainer element1, GIContainer element2) {

        final IGeneratorModelAccess genMa = (IGeneratorModelAccess) element1.getGeneratorModelAccess();

        final List<GIParameter<?>> paramList1 = element1.getParameters(paramName);
        final List<GIParameter<?>> paramList2 = element2.getParameters(paramName);

        if (paramList1.size() != 1) {
            throw new IllegalArgumentException(MessageFormat.format("The Parameter {0} with multiplicity != 1 is not permitted. Parameter location: {1}", paramName,
                    element1.getObjectLink()));
        }

        if (paramList2.size() != 1) {
            throw new IllegalArgumentException(MessageFormat.format("The Parameter {0} with multiplicity != 1 is not permitted. Parameter location: {1}", paramName,
                    element2.getObjectLink()));
        }

        final Long value1;
        final Long value2;

        final GIParameter<?> param1 = paramList1.get(0);
        final Object val1Obj = param1.getValueMdf();
        if (val1Obj instanceof BigInteger) {
            value1 = ((BigInteger) val1Obj).longValue();
        } else {
            throw new IllegalArgumentException("The evaluated Parameter is no Integer parameter!");
        }

        final GIParameter<?> param2 = paramList2.get(0);
        final Object val2Obj = param2.getValueMdf();
        if (val2Obj instanceof BigInteger) {
            value2 = ((BigInteger) val2Obj).longValue();
        } else {
            throw new IllegalArgumentException("The evaluated Parameter is no Integer parameter!");
        }

        if (value1 < value2) {
            return CompareResult.ELEMENT_1_BEFORE_ELEMENT_2;
        } else if (value1.equals(value2)) {
            if (sorterType.equals(EValueSorterType.VALUE_EQUAL_ALLOWED)) {
                return CompareResult.ELEMENTS_EQUAL;
            } else if (sorterType.equals(EValueSorterType.VALUE_EQUAL_FORBIDDEN)) {

                final IGeneratorResult result = GeneratorResultBuilder
                        .newBuilder(CommonGeneratorResultIds.getElementNotUniqueErrorId(genMa.getValidationResultOrigin()),
                                "The two Integer values {0} and {1} of the containers {2} and {3} are the same. These values should be unique.", param1.getObjectLink(),
                                param2.getObjectLink(), element1.getObjectLink(), element2.getObjectLink())
                        .addErrorObject(element1).addErrorObject(element2)
                        .addErrorObject(element1.getParent()).addErrorObject(element2.getParent()).buildResult();

                throw new ValidationFailedException(result);

            } else {
                throw new IllegalArgumentException("The sorterType has an unknown value.");
            }

        } else {
            return CompareResult.ELEMENT_1_AFTER_ELEMENT_2;
        }
    }
}
