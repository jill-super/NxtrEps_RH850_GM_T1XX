package com.vector.cfg.gen.core.moduleinterface;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.util.text.format.IFormattable;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * A GeneratorResult represents a result, which is shown in the GUI of the Cfg. A Result could be a ERROR, WARNING, IMPROVEMENT or INFO.
 *
 * <p>
 * Please use <code>com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder</code> to create instances of {@link IGeneratorResult}s.
 * </p>
 *
 * <div class="extdoc" id="Common">
 *
 * An {@link IGeneratorResult} is also an {@link IValidationResult} so we will to the terms interchangeably. You should always use {@link IGeneratorResult}s, because they
 * provide a broader API for the generator use case, such as API for the Definition model <!--LaTeX: (See \vref{sec:BswmdModel})-->
 *
 * The figure <!--LaTeX:\vref{fig:IGeneratorResultClasses}--> show the class hierarchy of {@link IGeneratorResult}s.
 *
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAc8AAAE+CAYAAADrtpuXAAAABmJLR0QA/wD/AP+gvaeTAAAgAElEQVR4nO3deVxU9f7H8TdmLrnlbu4LapaZFWmukJbrxQXRDLK0pDQzNa2r3tCy0hattLIS09REU1zJXUtw38rSSjFzzcItFQ3v/ZXz+wMZGObMMF+2EXg9H4+J4Xu+5/v9nDMPeHcOx3N8bDabTQAAwGMFvF0AAAC5DeEJAIAhwhMAAEOEJwAAhghPAAAMFfTm5P/884/WrVunhIQEb5YBSJIKFCggf39/lStXztulALjBeTU816xZo86dO3uzBMDB008/rU8//dTbZQC4wXk1PC9cuCBJ6vqv9urds1uqJTaHL6neuPnW6p+rXl/i6l+y2qzWs+7s2NW5AJuL9SzHtRjH1dDOfdzvi1QFOXVyW6HNagvSjuO6tpRhXKzg8JF6sM9d7Ae3n4OrFot9YdU5bNirunz5snMtAJCGV8MzWY9unRXcLfURqC3NF6vAsAgVV79w3YZw2l/n1uOYh6ebbXAZni62wV3w2NKOYTWOB8HjQXg6b4Mn4Zl2P6RZz/KzlMX/8aSzDTanClMWpNkXjqunWjjMaWUAsMQFQwAAGCI8AQAwRHgCAGCI8AQAwBDhmY6i5eupaPn6Dm23VLhdt1S43aP1i1W6Q8Uq3ZFl9ZSscrdKVrk7y8bLbSrUbaUK9Vp5uwwA+VyuDs9CpWupUOla9u8HDw9X4TK1deLkKae+J06eUpGyvho8YkxOlphhJSrfpRKV7/LK3KVr+F1/3a/SNZNes+Yt9UotnqhQr7Uq1G/t7TIA5CM3xD9VySqPPRqkaTPnatvOPapWtbLDsm07v5Uk9ekdlOl5/jp9INNjZNSl377Psbn+PLZLskmxW3epa8izSrh8WYPCQnNsfgC4UeXqI8+0mvrdo84d2qpP/yFOyx4PG6LOHdqoiV9je9vO3XtVpFxdFSlXV8Ghz2jhkq88msfVaduYzds15KVXVaxiAw156VXt+/Gg5fo793yv4rfdqeK3NVSvJ55T1NJVDstTH3GWqNxIJao0sn/v6rRtzJadGjbqDZWq2ljDRr2h2C07nfrcWu1e3Vr9Xu3/KU4vjJ6gW6vfpxdGT9DJ3/5wu72tm98vSQp/Y7LTstituzX85bdUplZThfQfoU3bdjv1OXvuT41/d5rK1mmmcnWaac785Tp5Kt6hTznfFirn28KhrXzdlipft6Xb2irUSznirFDfXxXr+7vtDwBZIU+FpyQ99XhvSdKO3d/Z23Zef/9kn94Off9KTFT8r9/q6tlDmjBupB4PG6aFS1ZkaN6YzdvVqUc/tWx+v67E/6zJb4/VgUOHLfsmJl7VqYPbdfn3/Ro/doT6DnzRIUATTu1L9f4HJfz2g/u5t+xU4CNPq12blrp4cq/atWmpwN7PWAaoJB385YjeHT9Kuzcu1owvovTuRzMzsMVJwdktdJBaNL1X54/s0AuD+qpb6HNOATpk5HhN+mimvt+0VGcPb1PHh1vpm9gdGZozrdNxsSnvD8Yo/mBMlowLAO7kufBs2byJJOmLeYvtbXPmL76+7H6HvgGtmqlUyRKSpLp1kv52+mVUdIbmXbx8jSSpfZuUi1lSv0/Nv2VTlbw+r2/tmpKkBRkMbUla+tU6SVLHh/0dvi5Zsc6yf48u7a/PXUOSNOOLKLfjx27dJUma/sHrDu3LVm6QJD0U0EyS5HdPw+vtXzv0W71hsySpSOFCkqRyZUurT+8ubucEgBtZngvPUiVLaM70yZo2c65OnDylEydPKWJmpGZHTLYHpSSdOXtO70/9zH7atmi5upKkFWu+djW0W9NnzZckeyimfZ8y73lN+eRz+2nb4rclBc6qtRszNK8kfTZnoWX7jDnuQzE9yRcMdQ15Vv1CeygosJ3D8plzk/6npGajtipTq6nK1Grq0J4sZsVsSVL9Jp1Urk4zTXh3mg4fOZ6p2gDAm/LUBUPJmjW5T1LKRUJJbfc69BkwZJRWrP5ah/bGqFrVyrJJ9gDNiP5P9Nb0WfN16VKCPTQvXXJ+1NqgF8K1cu1G/bx7vapVqSRJ9gDNqI4P+2vVOufTlU/2Cc7UuMkXDC2OXqunBv9H/R4LUsMGKfuoX2iQZs5drPNHUk7BWt0YvmGDujp3eJtOnorX7/Fn1CE4TPsP/KK5097OVH0A4C157shTkqpVray3XhutPv2HqE//IXpz3Cinq2+TFSlSWJI8vljIlaDrp0LXfL3J3pb6vdO8hZPmTXuxUEY82z/pCtjkAE3+2r3zw5keW5KCAtupw0OtNH7SJw7tXTu1lSQtjk45PXz4yHF9ND3Sod/s+ct09tyfqlq5ompWr2I5R9+QbtfXPyFJWvLV+iypHQCyQ54MT0nq3KGt5ftkb44bpbC+Iap2+wMaPGKMalSrmqn5/Fs+oJWLZmrz1l32q21vr1vHqd/4sS+q/+OPqNZdrTT03+NUvZp1qH+1YLo6PhzgdLWt5dwtmujLmZM1K3KxSlVtrLVfb1b0/E/VukWTTG1TagOffFSr12/S7FT/3rN1cz+tXfyZDsT9aj9tu2XHd+raqY3Dui2a3qMvl6xS2TrNdHuTTho+qK8mTxjl0GfkkP7qG9JNDzzcWy+OeUf1fGt6XNui2e+rfZsWXG0LIMf42Fw+gDH7RUZGKjQ0VLOnT9Gjbp7nySPJ0vRxWMwjyVIvyMwjySo1aKOQkBDNnTvXaRQASC3PHnkCAJBdCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAIcITAABDhCcAAIYITwAADBGeAAAYuiEeSbZz93e6+eabU7U43g/V+p60ab+1ukVv2nvbWi12cS9Wt109ubetdS2Ob63u6ep6Pet727qYy9W9bV2W58l9YV3XljKMixXc3Z/XahJX9yl2WGZZsXOLxb5wNS0AeOKGCM8PP5mpDz+Z6e0yAADwyA0Rns8N6KcWzVI/PosjT6v1OPLM3iPPsGGvOtcBABZuiPBs4nePgrt1TtWS9jFWVoFhESqufuG6DeG0v86txzEPTzfb4DI8XWyDu+DhkWQO43gSno6rp1o4zGllALDEBUMAABgiPAEAMER4AgBgiPAEAMAQ4QkAgCHCEwAAQ4QnAACGCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAIcITAABDhCcAAIYITwAADBGeAAAYIjwBADBEeAIAYIjwBADAEOEJAIAhwhMAAEOEJwAAhghPAAAMEZ4AABgiPAEAMFTQ2wVI0qKlK3TzzTenarE5fEn1xs23aRpTL7FaZF+cdqF1Z8euzgXYXKxnOa7FOK6Gdu7jfl+kKsipk9sKbVZbkHYc17WlDONiBYeP1IN97mI/uP0cXLVY7AtX0wKAJ7wanrfeeqskadlXa7TsqzXeLAWQJBUvXtzbJQDIBXxsLg8Vst8///yjdevWKSEhwVsl5AnPPPOM/vzzT02bNs3+PyQwV6BAAfn7+6tcuXLeLgXADc6rR5433XSTOnTo4M0Scr1Tp07p4sWLKlWqlP766y+FhYV5uyQAyPO4YCiXmz9/vvz8/BQeHq558+Z5uxwAyBe8etoWmefn56c+ffooKChItWrVUlxcnGrXru3tsgAgT+PIMxeLi4vTd999p0ceeUTVqlVTy5YtOfoEgBxAeOZi8+fPV0BAgCpVqiRJCgkJUWRkpJerAoC8j/DMxSIjIxUSEmL/vkePHjp06JB++OEHL1YFAHkf4ZlL7dmzR0ePHlWPHj3sbWXLllW7du04dQsA2YzwzKUiIyPVqVMnp3/XGRISonnz5rm+0w8AINMIz1zo2rVrWrhwoR555BGnZV27dtXZs2e1ZcsWL1QGAPkD4ZkLbdq0SRcuXFBgYKDTsmLFiikwMJBTtwCQjQjPXCgyMlLdunXTLbfcYrn80UcfVVRUlP7+++8crgwA8gfCM5f53//+p6ioKIerbNPq0KGD/v77b61fvz4HKwOA/IPwzGXWrl2rAgUKqG3bti77FCpUSMHBwfybTwDIJoRnLjNv3jz17NkzzfNPnfXu3VtLly7V1atXc6gyAMg/uLdtLnLlyhUVL15cY8eOVcuWLd32vXbtmtq3b6+FCxcqODg4hyoEgPzBq48kg5nLly9LkmbPnq05c+bY2xMTE3X16lWVLl3aaZ1z587lWH0AkF9w5JkHfPzxx4qMjNSmTZu8XQoA5Av8zRMAAEOEJwAAhghPAAAMEZ4AABgiPAEAMER4AgBgiPAEAMAQ4QkAgCHCEwAAQ4QnAACGCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAIcITAABDhCcAAIYITwAADBGeAAAYIjwBADBEeAIAYIjwBADAEOEJAIAhwhMAAEOEJwAAhghPAAAMEZ4AABgiPAEAMER4AgBgiPAEAMAQ4QkAgCHCEwAAQ4QnAACGCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAIcITAABDhCcAAIZ8bDabzVuTnzt3Ti+99JISEhK8VUKecPjwYR0/flwPPvigt0vJ1QoUKKABAwYoICDA26UAuMEV9Obk69at04wZM7xZQp6ycOFCb5eQ6xUsWJDwBJAur4bntWvXJEmzp0/Roz27pVpiS/MlzcGxLdVC+zub0nazL7E5fm81jsNoFuM4Tuk8jlON7rbBYhy322BL08dhcdoxrMZJtabLbXDegrTjOG+DxRpOJzLS7oc061l+lnLYLqc1rbbB5lRhyoI0+8Jx9ZSFlRq0sagfAJzxN08AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhiVyjfN1WqlC3lbfLAIDcHZ6FStdSodK1LJetWL1Bg4eHq3CZOipSto56hD6t9z/6LIcrzB4lq9ytklXuzpaxS9fwS/W6X6Vr3q9Z85Zmy1xZoUK91qpQr7W3ywCQz3j133lml8HDw/Xb73/oldHD9MGk12SzSYcOH9GK1Ru8XVqu8eex3ZJsit2yS11DnlXC5csaFBbq7bIA4IaQq488rSxYHK1pM+fqldEvqFHDBvb2unVqaeigp5z6b9y0TYNHjFHRcnUVHPqMNm7a7tSnaPn6uqV8fe378YCef/EV3VLhdj3/4is6cfJ3p74xm7dryEuvqljFO9SzzyDFbN7h1Kf4bXeq+G13auee79XriedU/LaG9mW79vygEpXvUonKd6nXE4MVtWy1w7qpjzhLVrlbJas2dho/dstODRv9hkpVu0fDRr+h2C27nPrcWv0+3Vr9Pu36dp96PzlMt9bwc+ojSa2b3y9JCn9jsvM8W3dr+MtvqUytpgrpP0KxW3c79Tl77k+Nf3eaytZpprJ1mmnO/GU6eSreoU853xYq59vCoa183ZYqX7elZU3JUh9xVqjfWhXq+7vtDwBZJc+F5/yo5ZLkEJyubNy0TR26P65WLZoo8ewhvTRsoDp2f9wyQCXpQNxhTXnnFX2/bbWmz5qvdyZ/6rA8ZvN2derRTy2b368r8T/pxaFPq1NwP8sAlaTjJ05pwawPdfn3/fa2vxIT9duBbUo4tU/jx45Qv4EvOQTopd++d3h/6eRehzFjt+xU4CPPqN2DLXXxxHdq92BLBfZ+xjJAJen4yVOaP+M9XTjmHHzuxG7drW6hg9Si6b06f2SHXhjUV91CB2nTNsdxhowcr0kfztT3m5bq3OFt6vhwa30Ta70/TJ2Oi015fzBWpw/GZMm4AJCePBeerk7NFilbR0XK+qpIWV9726JlqyRJ7dsmHbE08Us6ilu8fJXlGD27d5Yk1a1TU5I0fdZ8h+WLl69JGq9N0kUtTe5LOkpcHO149JgsuFtHpzb/lk1VsmRxSZJv7RqSpAVLVliub2XJV+skSR0f9nf4umTFOsv+Pbq0dzte7Nak0P3sgzcc2petXC9JeiigmSTJ756G19u/dui3esNmSVKRwoUkSeXKllaf3l082BIAuHHlufDs3KGtZfvVc4ed2iI+j5QkVax9r4qWq6ui5epeb5+XobmTw/S2uk1UrOIdKlbxjuvtX3q0/pmz5zXlk1n207YlKt8lSVq1zvMjqhlzrG8OP2NOlMdjSLJfMNQ15Fn1C+2hoMB2Dstnzl0sSarZqK3K1GqqMrWaOrQni1kxW5JUv0knla3TTBPenabDR44b1QIAN5o8F569g5OOajbGbku3b1jfEEnS1bOHlGh/xSnxTFyG5u7/RG9J0pX4n3Ul/qek1x9JL08MGj5W/xk3UT/tWquEU/uUcGqfcQ3JR5ppPdkn2GicP4/t1p/HdumzD97QzLmLtP/nQw7L+4UGSZLOH9nh8Dr3q+Mp74YN6urcr9v0/aalWhMVoUkfzdSYCR8a1QIAN5o8F569ggI1asRzat8t1CFAL15yfmZoj65Jp00XLPnK3nbo8FFNnpqxx6QFXT8FunDpSofxpnw802icIoULS5KillmfPnbn2f5JV8QmH60mf+3e+WHjsSQpKLCdOjzUSm9M+tihvWunhyRJi6NTTgcfPnJcH02PdOg3e/4ynT33p6pWrqia1atYztE3pNv19U9IkpZ8tT5DtQJATslz4SlJr4x+QWuWztXGzdvs/86zYq3GenPcKM2OeN/eL6BVM8WuXqifDxyyn7bdtHWngrp0yNC8/i0f0Dcr5+vnA7/YT9tu3rZL3T0cb/zYEXrq8V6q3chfQ0e+phpVrcMmekGEOj7sb3m1besWTTR/5vuaNW+JSlW7R2u/2azo+Z+qdYv7M7RNkjTwyUe1ev0mzU717z1bN/fT2sWf6UDcr/bTtlt2fKuundo4rNui6T36cskqla3TTPWbdNLwQf00ecIohz4jh/RX35Buavpwb7045h3Vu/43ZU8smv2+2rdpwdW2AHKUj82LDzCMjIxUaGgoz/NMbxt4nqfS3YYsep5nSEiI5s6d6zQKAKSWJ488AQDIToQnAACGCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAIcITAABDhCcAAIYITwAADBX0dgGS9OEnM7X8qzUul1vffNeiNd279LruYHErWJOBXY/o+MWzdYymt7q3rSfdzbfJ+v68Hk/o0WLDrUmzYkb2stdu7QwgF7shwnPn7u+0c/d33i4DAACP3BDhyVNVeKqKU1VeeqoKAHiCv3kCAGCI8AQAwBDhCQCAIcITAABDhCcAAIYITwAADBGeAAAYIjwBADBEeAIAYIjwBADAEOEJAIAhwhMAAEOEJwAAhghPAAAMEZ4AABgiPAEAMER4AgBgiPAEAMAQ4QkAgCHCEwAAQ4QnAACGCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAoYLeLkCSHu//vJZ/tcblcpunrdYdPepgc/mNRwO7HtHxi2frGE1v0z//XNP//d//qXCRwgZTmG+TLfU6Hq+eTkebq28N67N5vo7NzXcA4Amvhuedd95pfx+1dIUXKwGSNGrUyNslAMgFfGw2G//rnYtduHBB5cuX199//60vv/xSvXr18nZJAJDn8TfPXG769Om6+eab5ePjo/Hjx3u7HADIFzjyzMX+/vtvValSRadPn5YkFSxYUOvXr5e/v7+XKwOAvI0jz1xswYIFunjxokPbW2+95aVqACD/4MgzF7vjjjt04MABpf4ICxQooIMHD8rX19eLlQFA3saRZy61ceNG/fLLL0r7/z4FCxbk6BMAshlHnrlU+/bttWHDBv3zzz9Oy26++WadOnVK5cqV80JlAJD3ceSZC/30009at26dZXBKSUefH3/8cQ5XBQD5B+GZC02cOFGFChVyak9uS0xM1HvvvaerV6/mdGkAkC8QnrnM2bNn9cUXX+i///2vJOmmm26yL6tQoYIKFky6aVRiYqLmzJnjlRoBIK8jPHOZyZMn2wPz5ptv1gcffKC77rpLkvTNN9+oWLFiuummm3T16lW9+eabThcUAQAyj/DMRRITEzVlyhRdvXpVhQoV0iuvvKKBAwfal/v6+mrNmjX2Ow6dOHFCa9eu9WLFAJA3EZ65yBdffKHLly+rUKFCeuKJJzR69GinPk2bNtWKFStUsGBB/f3333r11Ve9UCkA5G2EZy5x7do1jR49WteuXVPbtm3dXk3bpk0bzZw5UzabTdu2bdN3332Xg5UCQN5HeOYSixYt0tmzZ9W4cWMtWrTI4UIhK6GhofYbxfft2zcHKgSA/IObJOQSPj4+kpIeQVaqVCmHZY0aNdK+ffssLw5q27atvv76a/3++++qVKlSjtQKAHmdVx+GDc998cUX8vPzcwpOSerVq5euXbtmud769ev11ltvqWzZstldIgDkG4RnLhEaGupyWdmyZVW6dGnLZT4+Pho5cmR2lQUA+RJ/8wQAwBDhCQCAIcIzD6hatar8/Py8XQYA5BtcbQsAgCGOPAEAMER4AgBgiPAEAMAQ4QkAgCHCEwAAQ4QnAACGCE8AAAwRngAAGCI884CTJ09q9+7d3i4DAPINwjMPiI6O1rBhw7xdBgDkG4QnAACGCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAIcLzBuTj4+PtEgAAbuTb8Ny+fbvCw8O9XUaWqFq1qvz8/IzXCw8P1/bt27OhIgDI2/JVeMbFxSkiIkJdunTR0aNHFRYW5rQ8PDxcPj4+GjhwoL7//nuH5T4+Pg59Uh8hprduatHR0fLx8VGXLl00f/58pzmSv6adw9Vc1atX13vvvefQ5/Tp04qIiLCPER4erri4OIc+YWFhOnr0qLp06aKIiAin5QAAF2x5XHx8vG358uW2wMBA28SJE2179+617Hfw4EFbYGCg7dixYzabzWa7cOGCbdq0aQ59JNlefvllW3x8fLrrvvzyy7aDBw86zRMYGOhQw7x582zz5s1zmscVT+caMGCAbdu2bQ77Ie32pLZ3717bxIkTbYGBgbbly5c7bSMAIIWPzWazeTvAs0t4eLjOnj2rTp06qXXr1ipVqpTbvn369FG9evVc9vHx8VF8fLwqVKiQ7rqnT5/W2LFj9fHHH6dbZ5cuXbR8+XKHeVx9LJ7O5W4Mdy5evKjY2FitXLlS5cqV02uvvWY8BgDkdYTndZ6Ejas+7i7wSdt//vz5ioyMVHR0tMt+7mrxdK7o6GhFREQoJCREDRo0UM2aNd1ufzLCEwDSl6fDU0o6KtuxY4ciIiLk7++vhx56SHfffbdTv8yGpye7cdKkSapXr55TkKddP73w9PQjO336tPbv36/Dhw8rOjpaQ4cOVZs2bSz7fv/991q/fr1iYmIUFhampk2bOh1hAwCS5PnwTC0uLk4xMTGKjo5WSEiImjdvrurVq0vy/LSt1e4KDw9XWFiYfSyT9Y8fP64aNWp4HJ6ezuXJ/MePH9fWrVsVGRmpwMBA+fv7u91+AECSfHW1bb169RQWFqbly5erZs2aioiIsC/r06ePRowYoePHj0tKOn2Zerk7YWFhioiI0OnTp+1tyVf2pjZgwAB9/fXXDn2ee+45p/ECAwMdxsrIXJMmTXK4enb79u0aMGCAQ5+IiAjVrFlTy5cvV1hYGMEJAJ7KoQuTcoWDBw/aXn75ZZsk24ABA5yuzHW3u44dO2abNm2aTZJNkm3ixIlOV8DGx8fbJk6caO+TfJVs2nH37t1rCwwMtPfLyFwHDx50mGvatGlcQQsAWSRfnbYFACAr5KvTtnnVyZMntXv3bm+XAQD5BuGZB0RHR2vYsGHeLgMA8g3CEwAAQ4QnAACGCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAKat79l24cMFWqFAh+31RefHilbWvhQsX5uh9OPmZ5sUr5VWgQAHb8OHDM/UzVVAWjh8/rv/973+SpOBuna26OLFlYIm7RaadLZd63mjI5jSU+agerOHRoDaLdxkpIfP7xZZ2jAwNabCS2+my4HO2mY9j3Tul9ee4I/rl1+Pas2ePgoODM1GcmdQ/00Hdg3JsXuBGc+nSJa3fsF6TJk1S0aJF9dprr2VoHMvwTPbvFwbp9bH/tlhiFR4WvzZc/PKxJf83vXCzpRMNqca3nMXF+LZUXSzndRjCapAbb/ude+Ts9qcZ2bI+p74ebH/Kl6zbfuvSXI/v6hN0XmBzMWTq8PxVD3btb1VYjhjxwgi99mrGflkAecH+H/dr/Yb1uq3SbXr99dclKUMByt88AQD5TnBwsO73u1+vv/66wsPDjdcnPAEA+U7hQoUVvSw6wwFKeAIA8qVSJUtlOEAJTwBAvpXRACU8YaR0DT+VrnG/1+YvV6e5ytVp7tjm20LlfFt4tH75uq1Uvm6r7CgNQC6VkQB1e7VtZq1YvV6r1n6jaTPnSpI6d2ir1i2aauhzYdk5bY4pVukOSdKVP37K0nFLVG7k1Dbl7THqG9ojS+fJKqVrJoXp+aM7HdrL1Gri1LdD21YK7tpebQMeUMnixXOkPgBIT3KABnYN9Ogq3GwLz+de+I9+OxWvV//zgj58N6mQQ78c0Ver12fXlHlOwm8/yCYpZstOBfbqr4TLVzT4mce9XZax80d22N/v/m6/2gU9pXGjn9eg/iHGY509vDUrSwMAO5MAzZbTtgsWRWvajLl69T/D1ahhA3t7Xd9aGmZx1LkxdpsGDw9X4TK1FRTytDbGbnPqU6Ssr4qU9dUP+3/W4BFjVKSsrwaPGKMTJ085j7dpm54fMVZFy9dT8GMDtHHTdqc+t5Svr1sq1NfOPXsV3Gegbqlwu8PynXu+1y0Vb1exig3Us8+zWrh0pcPyYhXvSHlf6Q4Vr3Snw/KYzTs09N/jVPy2hhr673GK2bxDaZWofJdKVL5Lu/b8oF5PDFaJync59ZEk/xZJR3D/GTfJaVnMlp0aNuoNlazaWL37DVHslp1Ofc6cPa/X35mqUtXuUalq92pW5GKd/O0Phz63Vr9Pt1a/z7Gtxn0qXcPPsqZkyUedklSmZhOVqel8tJma3z0NJUljxk9xaC9b+wGVrVagK7UAAAw6SURBVP2AY1udZipbp5lDm9VpW1c2bdujF8dMVPm6LfXimIn68cAv1v22f6sXx05ShXqt1WfAKG3a/q1Tn4r1/VWxvr/27P1JfQaOVsX6AR7VAODGUrRoUdWsWVMT352ooiWKOr0qVamkXbt3SZJef/11zZs3z3KcbAnPeQuXSZJDcLqyMXab2ncLVasWTfTf87/q3y8MVPtuj1kGqCQdiDusDyaO076d6xTxeaTefv8Tx/E2bVPH7o+rVYsmSjwTp5eGDlDHoMctA1SSjh3/TVFzPtZfpw84tP/1V6L+OLRLV+J/1vhXXlLfZ4Y7BOiV+JRTtVf++EmX//jR/n3M5h3qHPyk2rVtrcu/71e7tq3VuedTlgEqScdO/qYFsz5Qwql97ndWGjFbdirwkafV4oH7dOnkXg0f/JQCH3naKUAHvzRO70yJ0I/bV+niiW/VqV2ANsRkzRHcn0d32d+fP7rT6dRtWru/2y9JGjf6+SyZ35VN2/Yo6PEhat6ksc4c2qx3xo1Q3C9Hnftt/1Y9rvc7HReroQMeU4/Hh1oGqCSd+O13zfl4vOIPbszW+gFkjzq16+izaZ8pqHuQ25d/a39J0g8//GA5Tractl3h4tRsodK17O//++evkqRFy5ICqf1DAZKkpn732NsDWjkedUhSr6B/SZLq1kkaK+Lzefpg4jj78sXLVkmS2rVtLUlq4tc4qX35KgW0cjyykaSe3a1vPxjQ6gH7HXbq1qkpSVqw6Cv17NbJsn9qS6LXSJI6tQuQZLv+Nandv2VTp/7BXTu6HS/mehjOmPqWQ/vSr9ZKktq1aSlJuv/epL+VLvlqnVq3SDkiXLUuRpJUuHAhSVL5cmX0REhQ1typ0ANlajlvc9fObbJ1zuWrvpEktfVP+cxTv3fq1zpp2X2N77S3t2p6r1P/bp3bKsd2HIBs0bxZczVv5v4M1v4f9+v+B1xfHJktR56dOzxk2f6/P484tSVfTFSh5t0qXKa2Cpepc709MkNzR3yedIhdqfZ9Klq+noqWr+fQ7okzZ89p8tSZ9tO2xSomHUGvXPuNR+tPn/WldfvsBR7XIEklqjRSySqNFNirv57q01PBXTs4LP9szkJJUtUGLVWyamOVqpr0Pwozrrcn27ImqR7fe9qqVLV79cY7U/XLr8eMasmM80d22F+xK7+QJM2etyxb5/w8cqkkqWSJlIuSUr9PNmteUj/f+zqqQr3WqlCv9fX27K0PQO6WLeH5aM+ukqRvYtM/Nfh0v1BJ0n/P/3r9ddj+yoiwvo9KkhLPxinxjOPLUwOHvaxRr7ylg99+oyvxP+tK/M9GNSQfaabV//FeRuMk/PaDLv32g2ZMfVufzVmofT8ddFj+VJ+ekqRLJ/fq0sm9upjqlVrDO+rp4onv9OP2VVq/bJbemTJdL7/+nlEtWaVhg7qSpEkfzszWefqGdJMkXUq4bG9L/T7ZE48m9TsdF+v0AgBXsiU8e/UI1OgXB6t91xCHAL14KcGpb4+uSadBFyyOtrcdOnxE7380PUNzB10/BbpwyYpU4x3V5KkzjMcqcv00Z9qLhdIz6OmkK2JXrt3o8LV7YHvjGiQpuGsHdXzYX6+//ZFDe7d/tZMkRS1bbW/75ddj+uDT2Q79ZkUu1pmz51W1SiXVrF7Fco4nHwu2ry9Ji5avyVCt6Un+m2e/UMcneyR/f/jIcUnS4uh1mZqnS8cHJUkbYlL+1p36fdp+S1ZssLcdPnpCU2dYnz0AACkbb5Lwyn+Ga82ySMVs2qZCpWupUOlaKl+jkd56bbTmfJZypWVA62aKXbtIPx04ZD9tG7tlhz1UTQW0aqaY1Qv104FD9tO2m7buVFCXDumvfN2EV/6t/k/0Vo07W2jIS6+qRjXrwFkZNVOd2j3odLWtf8umWjD7I30+d6GK39ZQazfEasXCzyz/3umpZ8Me06p1Mfp87qKUeVo00Ybls3Ug7rD9tO2W7XvU/XqoJmvxwH2av3iFSlW7R773PKQXn++vD94e49Bn1PBn9ORjwfILCNILoyeovm8teWpZ5FR1eKiVy6tty9Rqan+1C3pK708YpZHDHK+6Hjk0TP1Cg9Sk7SMaEf626vnW9Hh+K62a3afFsydr68699qttrcZs9cC9WrXgEx08dMR+2nbrzr3q0iEgU/MDyNt8bDab09UP+/btU6NGjXgkGY8k45Fk2fRIspEjR2rChAlWBWaL5J9pHkkGeCb5giFXP6vcng8AAEOEJwAAhghPAAAMEZ4AABgiPAEAMER4Ash1ipYo6u0SkINuxM+b8ASQJ92Iv3CRdxCeANLlLoiyO6QyOn5iQqJX5r2R5IVtsHIjbBfhCQCAIcITQJY59MshPT/0eRUtUVTPD31eP+yzfhbiilUrFNwrWEVLFNWMz13fdzr5CCP5QcWp7dy102GuM2fOWK5rWlt68y6MWmhvXxi10Gp1J8nbG9wrWBtjNjrMszFmo31fuFrPaj9dvHRRMz6fYa9l8pTJHm+Dp/vfkzrTGyu9/W613Z6c6Ui7XSafb1YgPAFkmVGjR+nF4S8qMSFRr417TQcPHnTqszFmo+Lj4xW1IEqJCYkqUbyEyxBKPvWamJDodBr22LFjmvL+FCUmJCqoe5CmfjI107WlN++KVSuUcDnB3p5wOUErVq1wNYx9e3859IuiFkQpakGUrvx1xWH5mTNn7Psi7Xru9lP4mHA93PZhey133323w3JX22Cy/9Or05OxTPa7J1xtV1bPk55seRg2APdWr16t8+fPu+3z6aefejTWM888k26f9ObKSr//8btKliqpUiVLqWdwT6fli5cs1mvjUu6v2zO4p4J7BVv2dSd1/wD/AHX8V0eNDR+bqdrSM3PmTH02/TP79z2Ceuip/k+pc8fOLtf58KMPHdZJ29dVHentpynvT3HoH+Af4NF+zOj+z8xnmdn97qmcmkdK58bwALJH48aN1aSJ8xNoUsvq8IyKisrwjeGLlijq8gKc1MvOnDmj6BXRWrlypSpXrqzBzw1WXd+6Tv2teDK+SVva7z2pLSvm9WQcT5dZSb2vp34yVW++/ablcnf1uhvXpE5Pxkpvv2fks7Rax/TzTU96N4Z3e+R5ez1fNbyjvkcTWT87w/0Sd4tMO6f3gI4MTup+NucHgJiPkcku6Tx3xWD8zO8X66eqmI+S0a5OT1XJLDdPhXG7ipvWhIQr2rhltzp06JBlT1XxJGT37dunqKioDM8R9lSYLl66qFIlSzm0X7x0UWFPpTxernz58nqy75N6su+TOnHihIYNH6aoBVFOY6U9asoJntSWns4dOzvsh4uXLro96rRax1Pp7aeBgwZqwvgJDkfbnlyFmpX735OxsmK/eyKn5knmNjy7/qs9jyTjkWSua+SRZE7tnjySbGPX/laF3dCCugfp/cnv69kBz6p8+fKSUo58grqnPNh8xucz1COoh9ugCOoe5NDv4qWLWrR4kZ7s+6Rl//TCyVOe1JbevP369XOoddHiRerXr5/bcZ4b9Jw+//xzDXl+iKSkv5t6sk2e7KcihYtISgrxtWvXerQNpvs/szWmt99HvjRSG2M2KsA/QJI8+vur1XaZfr6ZxQVDANIV4B8g/9b+mvrJVPtVjlM/mSr/1v72X3qS1KplK4WPCVfREkX1zqR3NGG889F1gH+Aateqbe8XPiZcrVq2cjn3c4Oes7xi1JQntaU3b+eOnVWieAl7e4niJdINwgD/APnW9bVfbVvslmIe1ZvefpowfoLemfSOfVny/9Sktw2m+z8zNUrp7/dnBzyrmNgY+1WyNWrUSHdeq+0y/Xwzi4dhpzM+R54ceWb1kScPwwZufDwMGwCALEZ4AgBgiPAEAMAQ4QkAgCHCEwAAQ4QnAACGCE8AAAwRngAAGCI8AQAwRHgCAGCI8AQAwBDhCQCAIcITAABDhCcAAIYITwAADBGeAAAYIjwBADBEeAIAYIjwBADAEOEJAIAhwhMAAEOEJwAAhghPAAAMEZ4AABgiPAEAMFTQqrFAgaRMfevdj/TWux/laEFAfnDTTTfl6HzJP9MT352oie9OzNG5gdzM1c+qZXg2aNBAzz//vH7//fdsLQrIjwoVKqTQ0NAcnZOfacCcu59VH5vNZsvhegAAyNX4mycAAIYITwAADBGeAAAYIjwBADBEeAIAYOj/AWCInHWBsAsTAAAAAElFTkSuQmCC" alt="IGeneratorResult and IValidationResult" id="fig:IGeneratorResultClasses
 * " data-latex-style="scale=0.7" />
 *
 * <pre>
 * <!--UML: ClassDiag IGeneratorResultClasses{
 *
 * [G:{@link IGeneratorResult}]-^[ {@link IValidationResult}],
 * [B:GeneratorResultBuilder]"<creates>"-.->[G],
 * [note:"Use this to create results"]-[B],
 * }
 * -->
 * </pre>
 *
 * You must not implement the {@link IGeneratorResult} interface to make you own results!
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see GeneratorResultBuilder
 * @noimplement This interface is not intended to be implemented by clients. Please use GeneratorResultBuilder
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGeneratorResult extends IValidationResult, IFormattable {
    /**
     * Gets the exception which has caused this generator result, or null if no exception has caused this result.
     *
     * @return The exception or <code>null</code>.
     */
    @PublishedMethod
    Throwable getException();

    /**
     * Gets the Result Id (Origin,Id, etc.) of this Result. The ResultId is used to group certain messages together.
     *
     * @return The ValidationResultId
     */
    @PublishedMethod
    @Override
    IValidationResultId getId();

    /**
     * Gets the description of the Result.
     *
     * @return The Description
     */
    @PublishedMethod
    @Override
    IMixedText getDescription();

    /**
     * Gets the Severity of the Result.
     *
     * <p>
     * The severity "<b>Improvement</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The settings are correct and valid but may not be optimal with respect to embedded code generation. E.g. modifying this value may reduce memory consumption or CPU
     * load.</li>
     * <li>The detection of Improvement may be executed during generation or in a separate step that has to be triggered by the user (e.g. "Find Improvements").</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Info</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>Some settings have been adapted by a clearly defined rule (e.g. using of a default value). Applying this rule has not modified the behavior of the software.</li>
     * <li>General information for the user e.g. the finalization of the generation process.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Warning</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The configuration may be faulty or in some way incorrect but there are reasons why the user might require such a way of configuration.</li>
     * <li>The output files can be processed without problems (e.g. no compile errors...)</li>
     * <li>It may happen that the output files will lead to a non functioning system in case the warning is ignored by the user.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Error</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>Input data is not consistent e.g. conflicting settings</li>
     * <li>Using the output files lead to problems in the following processing steps or in an invalid runtime behavior of the ECU.</li>
     * </ul>
     * </p>
     *
     * <p>
     * The severity "<b>Fatal Error</b>" shall be used for the following classes of findings:<br />
     * <ul>
     * <li>The detected internal fatal error is so severe that processing (e.g. generation or validation) cannot be continued.</li>
     * </ul>
     * Hint: Do not report Fatal Errors!
     * </p>
     *
     *
     * @return The Severity of the result
     */
    @PublishedMethod
    @Override
    EValidationSeverityType getSeverity();

    /**
     * Gets the erroneous Configuration entities involved in the result.
     *
     * @return Collection of CEs.
     */
    @PublishedMethod
    @Override
    Collection<IDescriptor> getErroneousCEs();

    /**
     * Gets the solving actions registered to this Result.
     *
     * @return Collection of Solving Actions
     */
    @PublishedMethod
    @Override
    Collection<ISolvingAction> getSolvingActions();

    /**
     * Gets auto solving Action.
     *
     * @return A auto Solving Action
     */
    @PublishedMethod
    @Override
    ISolvingAction getAutoSolvingAction();

}
