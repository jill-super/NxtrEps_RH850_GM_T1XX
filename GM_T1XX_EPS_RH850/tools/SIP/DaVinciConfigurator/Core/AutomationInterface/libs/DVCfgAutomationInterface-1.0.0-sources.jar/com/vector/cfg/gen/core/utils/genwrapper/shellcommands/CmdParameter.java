package com.vector.cfg.gen.core.utils.genwrapper.shellcommands;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The {@link CmdParameter} class represents one parameter for the {@link ShellCommandExecutor} call.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class CmdParameter {

    private final String parameter;

    private final String value;

    /**
     * Instantiates a new CmdParameter instance.
     *
     * @param parameter the parameter
     * @param value the value
     */
    @PublishedMethod
    public CmdParameter(String parameter, String value) {
        super();
        this.parameter = parameter;
        this.value = value;
    }

    /**
     * Instantiates a new CmdParameter instance.
     *
     * @param parameter the parameter
     */
    @PublishedMethod
    public CmdParameter(String parameter) {
        super();
        this.parameter = parameter;
        this.value = "";
    }

    /**
     * Getter method for parameter.
     *
     * @return Returns the parameter.
     */
    @PublishedMethod
    public String getParameter() {
        return parameter;
    }

    /**
     * Getter method for value.
     *
     * @return Returns the value.
     */
    @PublishedMethod
    public String getValue() {
        return value;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        return "CmdParameter [parameter=" + parameter + ", value=" + value + "]";
    }

}
