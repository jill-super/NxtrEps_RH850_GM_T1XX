package com.vector.cfg.model.access.ecucdefinition.elements.parameter;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucCommonAttributes;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucParameterDefinition extends IEcucCommonAttributes {

    /**
     * Returns the wrapped definition. This can never be <code> null</code>
     *
     * @return the wrapped definition.
     */
    @Override
    @PublishedMethod
    MIConfigParameter getDef();

    /**
     * Returns the withAuto flag.
     *
     * @return This never returns <code>null</code>. It implements the AUTOSAR standard semantic: If the request flag is not defined in the model, this method returns false.
     */
    @PublishedMethod
    boolean getWithAuto();

}
