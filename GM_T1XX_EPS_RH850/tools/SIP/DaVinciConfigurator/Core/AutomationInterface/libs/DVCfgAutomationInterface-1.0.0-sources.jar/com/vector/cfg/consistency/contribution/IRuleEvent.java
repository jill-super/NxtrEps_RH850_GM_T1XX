package com.vector.cfg.consistency.contribution;

import ru.novosoft.mdf.ext.event.MDFFeatureEvent;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IDeletedObjectsInfo;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved. <BR>
 * <BR>
 * This is the event type that a consistency contribution receives. Data model and other events are transformed, filtered, aggregated,... to IRuleEvents. Using this approach,
 * the number of cases can be reduced which makes a Rule implementation easier.
 *
 * All IRuleEvent implementations implement the interface {@link IRuleEvent}. This interface can be used to get information about an event even if the related objects
 * (source-,added-, removed-object) is no more part of the model.
 * </p>
 *
 * @since 1.0
 */

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IRuleEvent {

    /**
     * If the event source object is of type {@link MIHasDefinition}, this method returns its {@link DefRef}, even if the object was removed from the model. Otherwise it returns
     * null.
     */
    @PublishedMethod
    DefRef getSourceDefRef();

    /**
     * This method returns the {@link MIObject} that was modified. If this object is no more part of the model, this method returns <code>null</code>. In that call
     * {@link #getSourceInfo()} to get further information of this object.
     */
    @PublishedMethod
    MIObject getSource();

    /**
     * This returns the object on which the event occurred. If this is an added or removed event, this method returns the owner of the collection. In all known cases this is the
     * object that you want from the rule event.
     *
     * @return
     */
    @PublishedMethod
    IDeletedObjectsInfo getSourceInfo();

    /**
     * This method returns the {@link ERuleEventType}. Don't evaluate this during validation, because you always have to validate based on the modified source object. Evaluate
     * this only if you decide to set a solving-action to be the auto-solving-action.
     */
    @PublishedMethod
    ERuleEventType getEventType();

    /**
     * This returns the MDF feature name that was modified. Don't evaluate this during validation, because you always have to validate based on the modified source object.
     * Evaluate this only if you decide to set a solving-action to be the auto-solving-action.
     */
    @PublishedMethod
    String getFeatureName();

    /**
     * This method returns the object that was added as a child to the modified source object. If this object is no more part of the model, this method returns <code>null</code>
     * . In that case, you can cast the rule event to {@link IRuleEvent} to get further information of this object.
     */
    @PublishedMethod
    MIObject getAddedValue();

    /**
     * See interface doc.
     */
    @PublishedMethod
    DefRef getAddedDefRef();

    /**
     * This method returns the object that was removed as a child from the modified source object. If this object is no more part of the model, this method returns
     * <code>null</code>. In that case, you can cast the rule event to {@link IRuleEvent} to get further information of this object.
     */
    @PublishedMethod
    MIObject getRemovedValue();

    /**
     * This method returns the position of an added/removed child object, see {@link MDFFeatureEvent#getPosition()}. The result of this method should not be evaluated.
     */
    @PublishedMethod
    int getPosition();

    /**
     * If this is an "added" event, this method returns the object that was added to a collection. In all known cases this is not what you want. Better check the source object
     * of the event.
     *
     * @return
     */
    @PublishedMethod
    IDeletedObjectsInfo getAddedInfo();

    /**
     * If this is a "removed" event, this method returns the object that was added to a collection. In all known cases this is not what you want. Better check the source object
     * of the event.
     *
     * @return
     */
    @PublishedMethod
    IDeletedObjectsInfo getRemovedInfo();
}
