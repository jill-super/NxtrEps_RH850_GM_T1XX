package com.vector.cfg.gen.core.utils.query;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.param.GInteger;
import com.vector.cfg.gen.core.bswmdmodel.param.GReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GSymbolicNameReference;
import com.vector.cfg.gen.core.utils.query.sorters.EValueSorterType;
import com.vector.cfg.gen.core.utils.query.sorters.GenIntParameterInContainerSorter;
import com.vector.cfg.gen.core.utils.query.sorters.GenIntParameterSorter;
import com.vector.cfg.gen.core.utils.query.sorters.GenReferenceToIntegerInContainerSorter;
import com.vector.cfg.gen.core.utils.query.sorters.GenSymbolicNameRefToIntegerInContainerSorter;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.ElementSorter;
import com.vector.cfg.util.query.StandardSorters;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@SuppressWarnings("rawtypes")
public class GenSorters extends StandardSorters {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenSorters.class);

    /**
     * Constructor for GenSorters.
     *
     */

    @PublishedMethod
    public GenSorters() {

    }

    /**
     * Returns an {@link ElementSorter} which sorts a {@link GInteger} list ascending by their values.
     *
     * <p>
     * Attention: If no {@link EValueSorterType} is specified equal values are allowed. See {@link #genIntValueSorter(EValueSorterType)}.
     * </p>
     *
     * @return A new {@link GenIntParameterSorter} object
     */
    @PublishedMethod
    public static ElementSorter<GInteger> genIntValueSorter() {
        return new GenIntParameterSorter();
    }

    /**
     * Returns an {@link ElementSorter} which sorts a {@link GInteger} list ascending by their values.
     *
     * @param sorterType specifies if equal values are allowed or not.
     * @return A new {@link GenIntParameterSorter} object
     */
    @PublishedMethod
    public static ElementSorter<GInteger> genIntValueSorter(final EValueSorterType sorterType) {
        return new GenIntParameterSorter(sorterType);
    }

    /**
     * Returns an {@link ElementSorter} which sorts a {@link GIContainer} list ascending by a {@link GInteger} parameter in the Container.
     *
     *
     * <p>
     * Attention: If no {@link EValueSorterType} is specified equal values are allowed. See {@link #genIntParamInContainerSorter(String, EValueSorterType)}.
     * </p>
     *
     * @param paramName The definition name of the integer parameter (shortname or absolute path).
     * @return A new {@link GenIntParameterInContainerSorter} object
     */
    @PublishedMethod
    public static ElementSorter<GIContainer> genIntParamInContainerSorter(DefRef paramDefRef) {
        return new GenIntParameterInContainerSorter(paramDefRef);
    }

    /**
     * Returns an {@link ElementSorter} which sorts a {@link GIContainer} list ascending by a {@link GInteger} parameter in the Container.
     *
     *
     * @param paramName The definition name of the integer parameter (shortname or absolute path).
     * @param sorterType specifies if equal values are allowed or not.
     * @return A new {@link GenIntParameterInContainerSorter} object
     */
    @PublishedMethod
    public static ElementSorter<GIContainer> genIntParamInContainerSorter(DefRef paramDefRef, final EValueSorterType sorterType) {
        return new GenIntParameterInContainerSorter(paramDefRef, sorterType);
    }

    /**
     * Returns an {@link ElementSorter} which sorts a {@link GIContainer} list ascending by a {@link GSymbolicNameReference} in the Container. The
     * {@link GSymbolicNameReference} must point to a Integer value ({@link MINumericalValue}).
     *
     * <p>
     * Attention: If no {@link EValueSorterType} is specified equal values are allowed. See
     * {@link #genSymbolicNameRefToIntegerInContainerSorter(String, EValueSorterType)}.
     * </p>
     *
     * @param symbolicNameReferenceName The definition name of the SymbolicNameReference (shortname or absolute path).
     * @return A new {@link GenSymbolicNameRefToIntegerInContainerSorter} object
     */
    @PublishedMethod
    public static ElementSorter<GIContainer> genSymbolicNameRefToIntegerInContainerSorter(DefRef symbolicNameReferenceName) {
        return new GenSymbolicNameRefToIntegerInContainerSorter(symbolicNameReferenceName);
    }

    /**
     * Returns an {@link ElementSorter} which sorts a {@link GIContainer} list ascending by a {@link GSymbolicNameReference} in the Container. The
     * {@link GSymbolicNameReference} must point to a Integer value ({@link MINumericalValue}).
     *
     *
     *
     * @param symbolicNameReferenceName The definition name of the SymbolicNameReference (shortname or absolute path).
     * @param sorterType specifies if equal values are allowed or not.
     * @return A new {@link GenSymbolicNameRefToIntegerInContainerSorter} object
     */
    @PublishedMethod
    public static ElementSorter<GIContainer> genSymbolicNameRefToIntegerInContainerSorter(DefRef symbolicNameReferenceName, final EValueSorterType sorterType) {
        return new GenSymbolicNameRefToIntegerInContainerSorter(symbolicNameReferenceName, sorterType);
    }

    /**
     * Returns an {@link ElementSorter} which sorts a {@link GIContainer} list ascending by a {@link GReference} in the Container. The {@link GReference} must
     * point to a container that has a Integer value ({@link MINumericalValue}) with the definition name intParameterNameInTargetContainer.
     *
     * <p>
     * Attention: If no {@link EValueSorterType} is specified equal values are allowed. See
     * {@link #genReferenceToIntegerInContainerSorter(String, String, EValueSorterType)}.
     * </p>
     *
     * @param referenceName The definition name of the reference (shortname or absolute path).
     * @param intParameterNameInTargetContainer The definition name of the integer parameter (shortname or absolute path) in the target container.
     *
     * @return A new {@link GenSymbolicNameRefToIntegerInContainerSorter} object
     */
    @PublishedMethod
    public static ElementSorter<GIContainer> genReferenceToIntegerInContainerSorter(DefRef referenceName, DefRef intParameterNameInTargetContainer) {
        return new GenReferenceToIntegerInContainerSorter(referenceName, intParameterNameInTargetContainer);
    }

    /**
     * Returns an {@link ElementSorter} which sorts a {@link GIContainer} list ascending by a {@link GReference} in the Container. The {@link GReference} must
     * point to a container that has a Integer value ({@link MINumericalValue}) with the definition name intParameterNameInTargetContainer.
     *
     *
     *
     * @param referenceName The definition name of the reference (shortname or absolute path).
     * @param intParameterNameInTargetContainer The definition name of the integer parameter (shortname or absolute path) in the target container.
     * @param sorterType specifies if equal values are allowed or not.
     * @return A new {@link GenSymbolicNameRefToIntegerInContainerSorter} object
     */
    @PublishedMethod
    public static ElementSorter<GIContainer> genReferenceToIntegerInContainerSorter(DefRef referenceName, DefRef intParameterNameInTargetContainer,
            final EValueSorterType sorterType) {
        return new GenReferenceToIntegerInContainerSorter(referenceName, intParameterNameInTargetContainer, sorterType);
    }

}
