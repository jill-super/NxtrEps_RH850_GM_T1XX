package com.vector.cfg.gen.core.utils.templateutils.templateregistry;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IArgumentedJetTemplate;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IArgumentedJetTemplateKey;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IGeneratedOutputFile;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IJetTemplate;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The TemplateRegistry allows a JET template to generate ({@link TemplateRegistry#generateTemplate(IJetTemplate, Object)}) an inner template by a key object.
 *
 * <p>
 * This mechanism could be used to implement a BaseGenerator, which generates HW-Specific templates parts into the BaseTemplate. <br />
 * <b>Example:</b><code><pre>
 * typedef struct CanTrcv_ChannelTypeTag
{
  CanIf_TransceiverModeType CanTrcvInitState;
  boolean CanTrcvWakeupByBusUsed;
  boolean CanTrcvChannelUsed;
&lt;%= templateRegistry.generateTemplate(this,ECanTrcvTemplates.CHANNEL_TYPE_STRUCT_HW_SPECIFIC) %&gt;
} CanTrcv_ChannelType;</pre></code> We generate a generic structure, which has a HW-specific part. This part is generated via the TemplateRegistry.
 * </p>
 *
 * <p>
 * you have to register the templates ({@link TemplateRegistry#registerTemplate(Object, IJetTemplate)}), before you can generate them.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@NotThreadSafe
public final class TemplateRegistry<KEY> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(TemplateRegistry.class);

    private final Class<KEY> keyClass;

    /**
     * Request the templateRegistry for the passed gernatorPackage, which the specified Key-Type.
     *
     * <p>
     * You should use a custom enum for the key class. This will guide the user of the templateRegistry which templates are available.
     * </p>
     *
     * @param <T> The Key Type
     * @param generatorPackage The generatorPackage
     * @param keyClass The class object for the key class. Please use enumerations.
     * @return The templateRegisry for the generatorPackage
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the generatorPackage is null</li>
     * <li>if the keyClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <T> TemplateRegistry<T> getRegistry(IGeneratorPackage generatorPackage, Class<T> keyClass) {
        if (generatorPackage == null) {
            throw new IllegalArgumentException("generatorPackage is null");
        }
        if (keyClass == null) {
            throw new IllegalArgumentException("keyClass is null");
        }

        final ITemplateRegistryService service = generatorPackage.getProjectContext().getService(ITemplateRegistryService.class);

        final TemplateRegistry<T> registry = service.getRegistry(generatorPackage, keyClass);

        return registry;
    }

    /*
     * Object Section
     */
    private final Map<KEY, Class<? extends IJetTemplate>> templateMap = new HashMap<>();

    TemplateRegistry(Class<KEY> keyClass) {

        this.keyClass = keyClass;

    }

    /**
     * Registers a JET-template class which a key object. The template stays registered as long as the generatorPackage exists. You must not register a template
     * for each generation call. For each generation call a new JetTemplate Instance is created.
     *
     * @param key The key to retrieve the template from the registry.
     * @param template The JET-template
     * @throws IllegalAccessException
     * @throws InstantiationException
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the key is null</li>
     * <li>if the template is null</li>
     * <li>if key.isArgumentedTemplate() returns true and template is no IArgumentedJetTemplate.class</li>
     * <li>if the key does already exist in the registry, and the registered template for the key is not the passed template.</li>
     * </ul>
     */
    @PublishedMethod
    public void registerTemplate(KEY key, Class<? extends IJetTemplate> template) {
        if (key == null) {
            throw new IllegalArgumentException("key is null");
        }
        if (template == null) {
            throw new IllegalArgumentException("template is null");
        }
        if (key instanceof IArgumentedJetTemplateKey) {
            if (((IArgumentedJetTemplateKey) key).isArgumentedTemplate() && !(IArgumentedJetTemplate.class.isAssignableFrom(template))) {
                throw new IllegalArgumentException(MessageFormat.format(
                        "The key: [{0}] is specified as IArgumentedJetTemplate but the template: [{1}] is no IArgumentedJetTemplate.class.", key, template));
            }
        }
        if (templateMap.containsKey(key)) {
            if (templateMap.get(key) != template) {
                throw new IllegalArgumentException(MessageFormat.format(
                        "There is already the template ({0}) registered with the key({1}; Type:{2}). You can not register the template ({3}})", templateMap.get(key), key, key
                                .getClass().getName(),
                        template));
            } else {
                return;
            }
        }
        // Register the template
        templateMap.put(key, template);

    }

    /**
     * Generates a template, that was registered with the <code>key</code>, and returns the generated string.
     *
     * <p>
     * The DataRepresentation, which is passed to the template is the same object from the parent template.
     * </p>
     *
     * @param parentTemplate The parent JET-template. In the most cases, you can write <code>this</code>.
     * @param key The Key of the requested template.
     * @return The generated string
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentTemplate is null</li>
     * <li>if the key is null</li>
     * <li>if template is a instance of IArgumentedJetTemplate</li>
     * <li>if the registry does not contain a template with the passed key.</li>
     * </ul>
     */
    @PublishedMethod
    public String generateTemplate(IJetTemplate parentTemplate, KEY key) {
        if (parentTemplate == null) {
            throw new IllegalArgumentException("parentTemplate is null");
        }
        if (key == null) {
            throw new IllegalArgumentException("key is null");
        }

        final IJetTemplate template = createTemplateByKey(parentTemplate, key);

        if (isArgumentedJetTemplate(template)) {
            throw new IllegalArgumentException(
                    "The registered template is a ArgumentedTemplate. Please use generateTemplate(IJetTemplate, KEY, secondArgument) for ArgumentedTemplates.");
        }

        return generateInternal(parentTemplate, template);
    }

    /**
     * Generates a template, that was registered with the <code>key</code>, and returns the generated string.
     *
     * <p>
     * You can pass a <b>second argument</b> to the registered jet template to specify the specific behavior of the template.
     * </p>
     *
     * <p>
     * The DataRepresentation, which is passed to the template is the same object from the parent template.
     * </p>
     *
     * @param parentTemplate The parent JET-template. In the most cases, you can write <code>this</code>.
     * @param key The Key of the requested template.
     * @param secondArgument the secondArgument for the template
     * @return The generated string
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentTemplate is null</li>
     * <li>if the key is null</li>
     * <li>if template is no instance of IArgumentedJetTemplate</li>
     * <li>if the registry does not contain a template with the passed key.</li>
     * </ul>
     */
    @PublishedMethod
    @SuppressWarnings("unchecked")
    public <T> String generateTemplate(IJetTemplate parentTemplate, KEY key, T secondArgument) {
        if (parentTemplate == null) {
            throw new IllegalArgumentException("parentTemplate is null");
        }
        if (key == null) {
            throw new IllegalArgumentException("key is null");
        }
        if (secondArgument == null) {
            throw new IllegalArgumentException("secondArgument is null");
        }

        final IJetTemplate template = createTemplateByKey(parentTemplate, key);

        if (!isArgumentedJetTemplate(template)) {
            throw new IllegalArgumentException("The registered template is no ArgumentedTemplate. Please use generateTemplate(IJetTemplate, KEY) for non ArgumentedTemplates.");
        }

        ((IArgumentedJetTemplate<T>) template).setSecondArgument(secondArgument);

        return generateInternal(parentTemplate, template);
    }

    private boolean isArgumentedJetTemplate(IJetTemplate template) {

        return (template instanceof IArgumentedJetTemplate);
    }

    /**
     * @param parentTemplate
     * @param template
     * @return
     */
    private String generateInternal(IJetTemplate parentTemplate, final IJetTemplate template) {
        final String genData = template.generate(((IGeneratedOutputFile) parentTemplate.getOutputFile()).getDataRepresentation());

        return genData;
    }

    /**
     * @param key
     * @return
     */
    private IJetTemplate createTemplateByKey(IJetTemplate parentTemplate, KEY key) {

        if (!templateMap.containsKey(key)) {
            throw new IllegalArgumentException(MessageFormat.format("No Template specified with key: {0} Type:{1}", key, key.getClass().getName()));
        }

        final Class<? extends IJetTemplate> classObj = templateMap.get(key);

        return instantiateJetTemplate(parentTemplate, classObj);
    }

    /**
     * Instantiate a new template of class classObj with the parent parentTemplate.
     *
     * @param parentTemplate
     * @param classObj
     * @return the new child template
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if parentTemplate is null</li>
     * <li>if classObj is null</li>
     * </ul>
     *
     * @exception RuntimeException
     * <ul>
     * <li>if the class could not be instantiated.</li>
     * <li>if there is no access to the class</li>
     * </ul>
     *
     */
    @PublishedMethod
    public static IJetTemplate instantiateJetTemplate(IJetTemplate parentTemplate, Class<? extends IJetTemplate> classObj) {
        if (parentTemplate == null) {
            throw new IllegalArgumentException("parentTemplate is null");
        }
        if (classObj == null) {
            throw new IllegalArgumentException("classObj is null");
        }

        IJetTemplate template = null;

        try {
            template = classObj.newInstance();
        } catch (final InstantiationException ex) {
            throw new RuntimeException("Can't instantiate JetTemplate", ex);
        } catch (final IllegalAccessException ex) {
            throw new RuntimeException("Can't access JetTemplate", ex);
        }

        template.setOutputFile(parentTemplate.getOutputFile());

        return template;

    }

    /**
     * Gets the key class.
     *
     * @return the key class
     */
    Class<KEY> getKeyClass() {
        return keyClass;
    }
}
