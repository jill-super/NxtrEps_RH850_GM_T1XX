package com.vector.cfg.consistency.contribution.helper;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.mdf.MIObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved. <BR>
 * <BR>
 * This interface contains setter methods for needed CE data properties of an IActionTuple implementation.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IDependencyTupleCeStorage<IMPLTYPE> {
    /**
     * With this method you can add a single CE to the general CE collection and the source CE collection.
     */
    @PublishedMethod
    IMPLTYPE addSourceDescriptor(IDescriptor obj);

    /**
     * With this method you can add multiple CEs to the general CE collection and the source CE collection.
     */
    @PublishedMethod
    IMPLTYPE addSourceDescriptors(Collection<? extends IDescriptor> objs);

    /**
     * With this method you can add a single CE to the general CE collection and the destination CE collection.
     */
    @PublishedMethod
    IMPLTYPE addDestinationDescriptor(IDescriptor obj);

    /**
     * With this method you can add multiple CEs to the general CE collection and the destination CE collection.
     */
    @PublishedMethod
    IMPLTYPE addDestinationDescriptors(Collection<? extends IDescriptor> objs);

    /**
     * With this method you can add a single CE to the general CE collection and the source CE collection.
     */
    @PublishedMethod
    IMPLTYPE addSourceCE(MIObject obj);

    /**
     * With this method you can add multiple CEs to the general CE collection and the source CE collection.
     */
    @PublishedMethod
    IMPLTYPE addSourceCEs(Collection<? extends MIObject> objs);

    /**
     * With this method you can add a single CE to the general CE collection and the destination CE collection.
     */
    @PublishedMethod
    IMPLTYPE addDestinationCE(MIObject obj);

    /**
     * With this method you can add multiple CEs to the general CE collection and the destination CE collection.
     */
    @PublishedMethod
    IMPLTYPE addDestinationCEs(Collection<? extends MIObject> objs);
}
