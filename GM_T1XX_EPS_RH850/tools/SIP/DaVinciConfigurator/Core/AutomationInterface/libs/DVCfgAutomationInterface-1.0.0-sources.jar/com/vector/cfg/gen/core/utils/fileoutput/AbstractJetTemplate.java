package com.vector.cfg.gen.core.utils.fileoutput;

import static com.google.common.base.Preconditions.checkNotNull;

import java.text.MessageFormat;
import java.util.concurrent.Callable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.contribution.exceptions.CustomExceptionHandler;
import com.vector.cfg.gen.core.moduleinterface.IDataRep;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IArgumentedJetTemplate;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IGeneratedOutputFile;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IJetTemplate;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IOutputFile;
import com.vector.cfg.gen.core.utils.exceptions.ErrorHandlingContext;
import com.vector.cfg.gen.core.utils.frameworkinternal.GeneratorUtilFrameworkHelper;
import com.vector.cfg.gen.core.utils.templateutils.templateregistry.TemplateRegistry;
import com.vector.cfg.persistency.IProjectPersistencySettings;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The abstract implementation class for jet templates.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractJetTemplate implements IJetTemplate {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractJetTemplate.class);

    @PublishedField
    protected IProjectContext projectContext;

    @PublishedField
    protected IGeneratorPackage generatorPackage;

    @PublishedField
    protected IGeneratedOutputFile outputFile;

    @SuppressWarnings("unused")
    private IProjectPersistencySettings projectSettings;

    private StringBuffer templateStringBuffer;

    /**
     * Instantiates a new abstract jet template.
     */

    @PublishedMethod
    public AbstractJetTemplate() {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final IGeneratorPackage getGeneratorPackage() {
        return generatorPackage;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void setOutputFile(IOutputFile outputFile) {
        if (outputFile == null) {
            throw new IllegalArgumentException("outputFile is null");
        }
        if (!(outputFile instanceof IGeneratedOutputFile)) {
            throw new IllegalArgumentException("The outputFile must be a IGeneratedOutputFile. Please use AbstractJetTemplate as base class!");
        }

        this.outputFile = (IGeneratedOutputFile) outputFile;

        this.generatorPackage = outputFile.getGeneratorPackage();
        this.projectContext = generatorPackage.getProjectContext();
        this.projectSettings = projectContext.getService(IProjectPersistencySettings.class);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final IGeneratedOutputFile getOutputFile() {
        return this.outputFile;
    }

    /**
     * Assign template string builder.
     *
     * <p>
     * This method is use to provide the generated content, even if the generation was aborted.
     * </p>
     *
     * <p>
     * Every JetTemplate shall assign its current used StringBuilder
     * </p>
     *
     *
     * @param buffer the buffer from the generated jet template
     */
    @PublishedMethod
    protected final void assignTemplateStringBuffer(final StringBuffer buffer) {
        if (buffer == null) {
            throw new IllegalArgumentException("buffer is null");
        }

        this.templateStringBuffer = buffer;
    }

    @PublishedMethod
    @Override
    public String toString() {
        return MessageFormat.format("JetTemplate({0}) in Outputfile ({1})", getClass().getName(), getOutputFile().getOutputFilename());
    }

    /**
     * Includes a JetTemplate at the current position. The passed jet template is generated with the dataRepresentation of this template.
     *
     * <p>
     * Example: &lt;%= includeTemplate(MyBlockTemplateJet.class) %&gt;
     * </p>
     *
     *
     * @param templateClass inner jet template
     * @return The generated Template content
     *
     * @exception IllegalArgumentException <ul>
     * <li>if templateClass is null</li>
     * </ul>
     */
    @PublishedMethod
    protected final String includeTemplate(Class<? extends IJetTemplate> templateClass) {
        if (templateClass == null) {
            throw new IllegalArgumentException("templateClass is null");
        }

        final IJetTemplate innerTemplate = TemplateRegistry.instantiateJetTemplate(this, templateClass);

        final String content = innerTemplate.generateTemplate();

        return content;
    }

    /**
     * Includes a JetTemplate at the current position. The passed jet template is generated with the dataRepresentation of this template.
     *
     * <p>
     * You can pass a <b>second argument</b> to the jet template to specify the specific behavior of the template.
     * </p>
     * <p>
     * Example: &lt;%= includeTemplate(MyBlockTemplateJet.class, &ltYour Second Argument&gt) %&gt;
     * </p>
     *
     *
     * @param templateClass inner jet template
     * @return The generated Template content
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if templateClass is null</li>
     * <li>if secondArgument is null</li>
     * </ul>
     */
    @PublishedMethod
    protected final <T> String includeTemplate(Class<? extends IArgumentedJetTemplate<T>> templateClass, T secondArgument) {
        if (templateClass == null) {
            throw new IllegalArgumentException("templateClass is null");
        }
        if (secondArgument == null) {
            throw new IllegalArgumentException("secondArgument is null");
        }

        @SuppressWarnings("unchecked")
        final IArgumentedJetTemplate<T> innerTemplate = (IArgumentedJetTemplate<T>) TemplateRegistry.instantiateJetTemplate(this, templateClass);

        innerTemplate.setSecondArgument(secondArgument);

        final String content = innerTemplate.generateTemplate();

        return content;

    }

    /**
     * Includes a registered JetTemplate from the {@link TemplateRegistry} at the current position. The passed jet template is generated with the
     * dataRepresentation of this template.
     *
     * <p>
     * Example: &lt;%= includeRegisteredTemplate(EMyTemplates.HW_SPEC_CONFIG) %&gt;
     * </p>
     *
     * @param key The key for the {@link TemplateRegistry}
     * @return The generated Template content
     *
     * @exception IllegalArgumentException <ul>
     * <li>if the key is null</li>
     * <li>if the registry does not contain a template with the passed key.</li>
     * </ul>
     *
     * @see TemplateRegistry
     */
    @PublishedMethod
    protected final String includeRegisteredTemplate(Object key) {

        final TemplateRegistry<Object> templateRegistry = getTemplateRegistry(key);

        return templateRegistry.generateTemplate(this, key);
    }

    /**
     * Includes a registered ArgumentedJetTemplate from the {@link TemplateRegistry} at the current position. The passed jet template is generated with the dataRepresentation of
     * this template.
     * <p>
     * You can pass a <b>second argument</b> to the jet template to specify the specific behavior of the template.
     * </p>
     * <p>
     * Example: &lt;%= includeRegisteredArgumentedTemplate(EMyTemplates.HW_SPEC_CONFIG, &ltYour Second Argument&gt) %&gt;
     * </p>
     *
     * @param key The key for the {@link TemplateRegistry}
     * @param secondArgument the secondArgument for the template
     * @return The generated Template content
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the key is null</li>
     * <li>if the key secondArgument is null</li>
     * <li>if the registry does not contain a template with the passed key.</li>
     * </ul>
     *
     * @see TemplateRegistry
     */
    @PublishedMethod
    protected final <T> String includeRegisteredArgumentedTemplate(Object key, T secondArgument) {

        if (secondArgument == null) {
            throw new IllegalArgumentException("secondArgument is null");
        }

        final TemplateRegistry<Object> templateRegistry = getTemplateRegistry(key);

        return templateRegistry.generateTemplate(this, key, secondArgument);
    }

    /**
     * Gets the template registry.
     *
     * @param key the key
     * @return the template registry
     */
    @SuppressWarnings("unchecked")
    private TemplateRegistry<Object> getTemplateRegistry(Object key) {
        return (TemplateRegistry<Object>) TemplateRegistry.getRegistry(getGeneratorPackage(), key.getClass());
    }

    /**
     * Generate template internal.
     *
     * <p>
     * This method is for advanced error and exception handling. The Framework should use this method instead of the normal generate()
     * </p>
     *
     * @return the string
     */
    @PublishedMethod
    @Override
    public String generateTemplate() {

        checkNotNull(getOutputFile());

        final ErrorHandlingContext context = ErrorHandlingContext.create(getOutputFile().getGeneratorPackage());

        context.addCustomExceptionHandler(new CustomExceptionHandler() {
            /**
             * {@inheritDoc}
             */
            @Override
            public boolean suppressReThrowOfUnhandledExceptions() {
                return true;
            }

            /**
             * {@inheritDoc}
             */
            @Override
            public void onUnhandledException(IValidationResultSink resultSink, Exception ex) {

                final IGeneratorResult result = GeneratorUtilFrameworkHelper.createGenResultFromUnhandeledException(getOutputFile().getGeneratorPackage(), ex, "Generation",
                        getOutputFile().getOutputFilename());
                resultSink.reportValidationResult(result);

            }
        });

        final IDataRep dataRepresentation = getOutputFile().getDataRepresentation();

        final String content = context.execute(new Callable<String>() {

            @Override
            public String call() throws Exception {
                return AbstractJetTemplate.this.generate(dataRepresentation);

            }
        });

        if (content == null) {
            /*
             * There was an error, check if there is any intermediate data in the stringBuilder
             */
            if (templateStringBuffer != null) {
                return templateStringBuffer.toString();
            }
        }

        return content;
    }
}
