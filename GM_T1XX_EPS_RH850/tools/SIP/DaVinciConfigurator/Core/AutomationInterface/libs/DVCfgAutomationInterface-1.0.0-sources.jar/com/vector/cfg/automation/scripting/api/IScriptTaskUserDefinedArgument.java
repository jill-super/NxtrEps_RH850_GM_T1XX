package com.vector.cfg.automation.scripting.api;

import java.util.List;
import java.util.Optional;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.IScriptCreationApi.IScriptTaskBuilder;
import com.vector.cfg.automation.scripting.base.IScriptTask;

/**
 * {@link IScriptTaskUserDefinedArgument} defines an script user defined argument create during {@link IScriptTask} by an {@link IScriptTaskBuilder}. The actual value of the
 * argument could be retrieve during {@link IScriptTask} execution, by calling {@link #getValue()} or {@link #getValues()}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @param <T> the value type of the argument.
 * @see IScriptCreationApi
 * @see IScriptTaskBuilder
 * @see IScriptTask
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptTaskUserDefinedArgument<T> {

    /**
     * Gets the argument name.
     *
     * @return the argument name
     */
    @PublishedMethod
    String getArgumentName();

    /**
     * Gets the qualified argument name, prefixed with - or --, if the {@link #getArgumentName()} is more then one character.
     *
     * @return the qualified argument name
     */
    @PublishedMethod
    String getQualifiedArgumentName();

    /**
     * Gets the value type of the argument. Valid value types are:
     * <ul>
     * <li>String</li>
     * <li>Void</li>
     * <li>File</li>
     * <li>Path</li>
     * <li>Integer</li>
     * <li>Long</li>
     * <li>Double</li>
     * <li>Boolean</li>
     * </ul>
     *
     * @return the value type
     */
    @PublishedMethod
    Class<T> getValueType();

    /**
     * Gets the help text of the argument.
     *
     * @return the help
     */
    @PublishedMethod
    String getHelp();

    /**
     * Returns the default value, or {@link Optional#empty()}, if this is a required argument.
     *
     * @return the default value
     */
    @PublishedMethod
    Optional<T> getDefaultValue();

    /**
     * Returns <code>true</code>, if the argument has at least one value.
     *
     * @return true, it has a value, otherwise <code>false</code>.
     */
    @PublishedMethod
    boolean hasValue();

    /**
     * See {@link #hasValue()}.
     *
     * @return true, it has a value, otherwise <code>false</code>.
     */
    @PublishedMethod
    boolean isHasValue();

    /**
     * Returns the value of the argument.
     *
     * @return the value
     * @exception IllegalStateException
     * <ul>
     * <li>If {@link #hasValue()} returns false</li>
     * </ul>
     */
    @PublishedMethod
    T getValue();

    /**
     * Returns the List of values of the argument. This is used, if the argument specified multiple times. The {@link List} is empty, if no argument was specified.
     *
     * @return the values
     */
    @PublishedMethod
    List<T> getValues();

    /**
     * Returns the value of the argument, or <code>null</code>, if the argument has no value.
     *
     * @return the value or <code>null</code>
     */
    @PublishedMethod
    @Nullable
    T getValueOrNull();

}
