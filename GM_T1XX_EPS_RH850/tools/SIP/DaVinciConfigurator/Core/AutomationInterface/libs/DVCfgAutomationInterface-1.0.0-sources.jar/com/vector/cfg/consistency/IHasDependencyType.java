package com.vector.cfg.consistency;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasDependencyType {
    /**
     * The DependencyType "HARD" will make CEs not modifyable (greyed). "SOFT" specifies the dependency (which might be shown to the user as description text in the future), but
     * keeps the CE modifiable. “SOFT” would be interesting when synchronizing 2 parameters in both directions.
     *
     * @return the {@link EDependencyType}
     */
    @PublishedMethod
    EDependencyType getDependencyType();
}
