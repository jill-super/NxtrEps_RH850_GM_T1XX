package com.vector.cfg.automation.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.api.project.IProjectHandlingApiEntryPoint;
import com.vector.cfg.automation.scripting.api.IScriptCreationApi;
import com.vector.cfg.automation.scripting.api.ScriptCreationApiHolder;
import com.vector.cfg.automation.scripting.api.project.IProject;
import com.vector.cfg.automation.scripting.base.IScriptExecutionContext;
import com.vector.cfg.automation.scripting.base.ScriptExecutionContexts;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.scripting.groovy.ClosureCalls;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link ScriptApi} provides static entry point methods to many Automation APIs.
 *
 * <div class="extdoc" id="Common"> In your own methods and classes the automation API is not automatically available differently as inside of the script task
 * <code>code{ }</code> block. But it is often the case, that methods need access to the automation API.
 *
 * <p>
 * The class <b>{@link ScriptApi} provides static methods as entry points</b> into the automation API. The static methods either return the API objects, or you could pass a
 * {@link Closure}, which will activate the API inside of the {@link Closure}.
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IScriptExecutionContext
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class ScriptApi {

    /**
     * The {@link ScriptApi#daVinci()} method provides the entry point into the {@link IScriptCreationApi} during script initialization. The main use it to enable the IDE code
     * completion support in a script file.
     *
     * <div class="extdoc" id="daVinciClosure"> The IDE could not know which API is available inside of a script file. So a glue code is needed to tell the IDE, what API is
     * callable inside of a script file.
     * <p>
     * The {@link ScriptApi#daVinci()} method enables the IDE code completion support in a script file. You have to write the <code>daVinci{ }</code> block and inside of the
     * block the code completion is available. The following sample shows the glue code for the IDE:
     * </p>
     * </div>
     * <p>
     * See automation documentation for a usage sample.
     * </p>
     *
     * @param code the initialization code to execute
     * @see IScriptCreationApi
     */
    @PublishedMethod
    public static void daVinci(@VDelegatesToWithClosureParam(IScriptCreationApiWithFields.class) final Closure<?> code) {
        final IScriptCreationApi creationApi = ScriptCreationApiHolder.INSTANCE.getCurrentCreationApi();
        ClosureCalls.callWithDelegateFirstAndReset(creationApi, code);
    }

    /**
     * <div class="extdoc" id="scriptCodeClosure"> The {@link ScriptApi#scriptCode(Closure)} method provides access to all automation APIs defined in the
     * {@link IScriptExecutionContext} (inside of the normal script <code>code{}</code> block. This is useful, when you want to call script code API inside of your own methods
     * and classes.
     *
     *
     * <p>
     * The method will call the passed {@link Closure} with the running {@link IScriptExecutionContext} as delegate.
     * </p>
     *
     * <pre>
     * <code class="Java" id="ScriptApi.scriptCode{} usage in own method">
     * def yourMethod(){
     *      // Needs access to an automation API
     *      ScriptApi.scriptCode{
     *          // API is now available
     *          workflow.update()
     *      }
     * }
     * </code>
     * </pre>
     *
     * </div>
     *
     * @param <T> the generic type of the return type
     * @param code the code to call
     * @return the return value of the called user {@link Closure}.
     */
    @PublishedMethod
    public static <T> T scriptCode(
            @VDelegatesToWithClosureParam(IScriptExecutionContext.class) final Closure<T> code) {
        return ClosureCalls.callWithDelegateFirst(scriptCode(), code);
    }

    /**
     * The {@link ScriptApi#scriptCode()} method provides access to all automation APIs defined in the {@link IScriptExecutionContext} (inside of the normal script
     * <code>code{}</code> block. This is useful, when you want to call script code API inside of your own methods and classes.
     *
     *
     * <div class="extdoc" id="scriptCode">
     * <p>
     * The {@link ScriptApi#scriptCode()} without a {@link Closure} method returns the currently running {@link IScriptExecutionContext}. This can be used to call API in Java
     * style.
     * </p>
     *
     * <pre>
     * <code class="Java" id="ScriptApi.scriptCode() usage in own method">
     * def yourMethod(){
     *      // Needs access to an automation API
     *      ScriptApi.scriptCode().workflow.update()
     * }
     * </code>
     * </pre>
     *
     * </div>
     *
     *
     * @return the currently running {@link IScriptExecutionContext}.
     */
    @PublishedMethod
    public static IScriptExecutionContext scriptCode() {
        final IScriptExecutionContext scriptContext = ScriptExecutionContexts.getCurrentContextOfThisThreadChecked();
        return scriptContext;
    }

    /**
     * The {@link ScriptApi#getScriptLogger()} method provides access active script logger of the currently executed script task.
     *
     *
     * @return the logger of the currently executed script task.
     */
    @PublishedMethod
    public static ILogger getScriptLogger() {
        return scriptCode().getScriptLogger();
    }

    /**
     * <div class="extdoc" id="activeProjectClosure"> The {@link ScriptApi#activeProject()} method provides access to the project automation API of the currently active project.
     * This is useful, when you want to call project API inside of your own methods and classes.
     *
     * <p>
     * The method will call the passed {@link Closure} with the current active {@link IProject} as delegate.
     * </p>
     *
     * <pre>
     * <code class="Java" id="ScriptApi.activeProject{} usage in own method">
     * def yourMethod(){
     *      // Needs access to an automation API
     *      ScriptApi.activeProject{
     *          // Project API is now available
     *          transaction{
     *              // Now model modifications are allowed
     *          }
     *      }
     * }
     * </code>
     * </pre>
     *
     * </div>
     *
     * @param <T> the generic type of the return type
     * @param code the code to call with the active {@link IProject}.
     * @return the return value of the called user {@link Closure}.
     * @see IProject
     */
    @PublishedMethod
    public static <T> T activeProject(@VDelegatesToWithClosureParam(IProject.class) final Closure<T> code) {
        final IScriptExecutionContext scriptContext = ScriptExecutionContexts.getCurrentContextOfThisThreadChecked();
        return scriptContext.getInstance(IProjectHandlingApiEntryPoint.class).getProjects().activeProject(code);
    }

    /**
     * The {@link ScriptApi#activeProject()} method provides access to the project automation API of the currently active project. This is useful, when you want to call project
     * API inside of your own methods and classes.
     *
     * <div class="extdoc" id="activeProject">
     * <p>
     * The {@link ScriptApi#activeProject()} method returns the current active {@link IProject}.
     * </p>
     *
     * <pre>
     * <code class="Java" id="ScriptApi.activeProject() usage in own method">
     * def yourMethod(){
     *      // Needs access to an automation API
     *      IProject theActiveProject = ScriptApi.activeProject()
     * }
     * </code>
     * </pre>
     *
     * </div>
     *
     * @return the current active {@link IProject}.
     * @see IProject
     */
    @PublishedMethod
    public static IProject activeProject() {
        final IScriptExecutionContext scriptContext = ScriptExecutionContexts.getCurrentContextOfThisThreadChecked();
        return scriptContext.getInstance(IProjectHandlingApiEntryPoint.class).getProjects().getActiveProject();
    }

    /**
     * The {@link ScriptApi#activeProject()} method provides access to the project automation API of the currently active project. This is useful, when you want to call project
     * API inside of your own methods and classes.
     *
     * <p>
     * The {@link ScriptApi#activeProject()} method returns the current active {@link IProject}.
     * </p>
     *
     * @return the current active {@link IProject}.
     * @see IProject
     */
    @PublishedMethod
    public static IProject getActiveProject() {
        return activeProject();
    }

    private ScriptApi() {

    }
}
