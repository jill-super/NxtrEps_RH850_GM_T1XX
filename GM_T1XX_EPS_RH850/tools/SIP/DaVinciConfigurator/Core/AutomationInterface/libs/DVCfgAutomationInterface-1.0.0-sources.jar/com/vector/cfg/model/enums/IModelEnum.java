package com.vector.cfg.model.enums;

import com.google.common.collect.ImmutableMap;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The IModelEnum interface helps you to abstract from "AUTOSAR" Enum Literals in a Definition file to Java Enums.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * <p>
 * Example Client code:
 *
 * <pre>
 * <code>
 * public enum ESyncPrioModelEnumTest implements IModelEnum<ESyncPrioModelEnumTest> {
 *     LOW("Low", "LowAr4"), //<-- Add here all used AUTOSAR literals for the JavaLiteral as a comma separated list.
 *     MIDDLE("Middle", "MiddleAr4"),
 *     HIGH("High", "HighAr4");
 *
 *     //Code Section
 *     private static final ImmutableMap<String, ESyncPrioModelEnumTest> map;
 *
 *     private List<String> asrLitList;
 *
 *     private ESyncPrioModelEnumTest(String... str) {
 *         asrLitList = Arrays.asList(str);
 *     }
 *
 *     static {
 *         final ImmutableMap.Builder<String, ESyncPrioModelEnumTest> builder = ImmutableMap.builder();
 *         for (final ESyncPrioModelEnumTest elem : ESyncPrioModelEnumTest.values()) {
 *             for (final String str : elem.asrLitList) {
 *                 builder.put(str, elem);
 *             }
 *             elem.asrLitList = null;
 *         }
 *         map = builder.build();
 *     }
 *
 *     @Override
 *     public ImmutableMap<String, ESyncPrioModelEnumTest> getAutosarEnumLiterals() {
 *         return map;
 *     }
 * }
 * </code>
 * </pre>
 *
 * </p>
 *
 * @since 1.0
 * @see EnumUtil
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IModelEnum<T extends Enum<T>> {

    /**
     * Returns a Map, with keys "AUTOSAR" enum values, and values the Enum literals.
     *
     * <p>
     * This map must be complete in every Enum element. This means any Enum element must contain any other Enum element it's map. See code example above!
     * </p>
     *
     * @return the Mapping map
     */
    @PublishedMethod
    ImmutableMap<String, T> getAutosarEnumLiterals();
}
