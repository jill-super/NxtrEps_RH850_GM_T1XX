package com.vector.cfg.consistency.contribution.helper;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EAutoSolvingActionUsage {
    /**
     * Use only as auto solving action. If it could not be executed, it won't be visible in the validation view and will not be executed with the SolveAll
     * feature of the validation view.
     */
    ONLY_AUTO_SOLVE,
    /**
     * Use also as normal solving action and as preferred action. If it could not be executed, it will be visible in the validation view and will be executed
     * with the SolveAll feature of the validation view.
     */
    ALSO_NORMAL_SOLVING_ACTION_AND_PREFERRED_ACTION,
    /**
     * Use also as normal solving action but not as preferred action. If it could not be executed, it will be visible in the validation view but will not be
     * executed with the SolveAll feature of the validation view.
     */
    ALSO_NORMAL_SOLVING_ACTION,
}
