package com.vector.cfg.automation.api.project;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * The literals of {@link ESelectiveImport} define the alternative modes for the selective import into the DaVinci Developer workspace during project updates.
 * <div class="extdoc" id="ESelectiveImport"><!--Label:ESelectiveImport-->The literals of {@link ESelectiveImport} define the alternative modes for the selective import into the
 * DaVinci Developer workspace during project updates. The following alternatives are supported:</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum ESelectiveImport {

    /**
     * {@link #ALL} results in selective import for all elements. <div class="extdoc" id="ALL"><!--Label:ESelectiveImport.ALL-->{@link #ALL} results in selective import for all
     * elements.</div>
     */
    ALL,

    /**
     * {@link #COMMUNICATION_ONLY} results in selective import for communication elements only.
     * <div class="extdoc" id="COMMUNICATION_ONLY"><!--Label:ESelectiveImport.COMMUNICATION_ONLY-->{@link #COMMUNICATION_ONLY} results in selective import for communication
     * elements only.</div>
     */
    COMMUNICATION_ONLY

}
