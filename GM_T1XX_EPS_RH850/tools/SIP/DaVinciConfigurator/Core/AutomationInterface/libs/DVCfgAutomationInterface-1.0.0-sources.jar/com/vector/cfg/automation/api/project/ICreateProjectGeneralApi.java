package com.vector.cfg.automation.api.project;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.api.Converters;
import com.vector.cfg.business.Constraints;
import com.vector.cfg.util.version.IVersion;

/**
 * {@link ICreateProjectGeneralApi} provides means for specifying the new project's general settings.
 * <div class="extdoc" id="ICreateProjectGeneralApi"><!--Label:ICreateProjectGeneralApi-->{@link ICreateProjectGeneralApi} provides means for specifying the new project's
 * general settings.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectGeneralApi {

    /**
     * Alias for {@link #setAuthor(String)}.
     */
    @PublishedMethod
    void author(@Nonnull String author);

    /**
     * Using {@link #setAuthor(String)} the author for the new project can be specified. <div class="extdoc" id="setAuthor"><!--Label:ICreateProjectGeneralApi.setAuthor-->
     * <h5>Author</h5> Using {@link #setAuthor(String)} the author for the new project can be specified. This is an optional parameter defaulting to the name of the currently
     * logged in user if the parameter is not provided explicitly. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_NON_EMPTY_STRING} <!--Ref:Constraints.IS_NON_EMPTY_STRING--></li>
     * </ul>
     * </div>
     *
     * @param author the author for the new project
     */
    @PublishedMethod
    void setAuthor(@Nonnull String author);

    /**
     * Alias for {@link #setVersion(Object)}.
     */
    @PublishedMethod
    void version(@Nonnull Object version);

    /**
     * Using {@link #setVersion(Object)} the version for the new project can be specified. <div class="extdoc" id="setVersion"><!--Label:ICreateProjectGeneralApi.setVersion-->
     * <h5>Version</h5> Using {@link #setVersion(Object)} the version for the new project can be specified. This is an optional parameter defaulting to "1.0" if the parameter is
     * not provided explicitly. The value given here is converted to {@link IVersion} using {@link Converters#TO_VERSION} <!--Ref:Converters.TO_VERSION-->. The following
     * constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_NOT_NULL} <!--Ref:Constraints.IS_NOT_NULL--></li>
     * </ul>
     * </div>
     *
     * @param version the version for the new project
     */
    @PublishedMethod
    void setVersion(@Nonnull Object version);

    /**
     * Alias for {@link #setDescription(String))}.
     */
    @PublishedMethod
    void description(@Nonnull String description);

    /**
     * Using {@link #setDescription(String)} the description for the new project can be specified.
     * <div class="extdoc" id="setDescription"><!--Label:ICreateProjectGeneralApi.setDescription-->
     * <h5>Description</h5> Using {@link #setDescription(String)} the description for the new project can be specified. This is an optional parameter defaulting to "" if the
     * parameter is not provided explicitly. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_NOT_NULL} <!--Ref:Constraints.IS_NOT_NULL--></li>
     * </ul>
     * </div>
     *
     * @param description the description for the new project
     */
    @PublishedMethod
    void setDescription(@Nonnull String description);

    /**
     * Alias for {@link #setCreateStartMenuEntries(boolean)}.
     */
    @PublishedMethod
    void createStartMenuEntries(boolean createStartMenuEntries);

    /**
     * Using {@link #setCreateStartMenuEntries(boolean)} it can be specified whether or not to create start menu entries for the new project.
     * <div class="extdoc" id="setCreateStartMenuEntries"><!--Label:ICreateProjectGeneralApi.setCreateStartMenuEntries-->
     * <h5>Start Menu Entries</h5> Using {@link #setCreateStartMenuEntries(boolean)} it can be specified whether or not to create start menu entries for the new project. This is
     * an optional parameter defaulting to {@code false} if the parameter is not provided explicitly.</div>
     *
     * @param createStartMenuEntries whether or not to create start menu entries for the new project
     */
    @PublishedMethod
    void setCreateStartMenuEntries(boolean createStartMenuEntries);

}
