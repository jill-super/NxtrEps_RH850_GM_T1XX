package com.vector.cfg.gen.core.utils.frameworkinternal;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.exceptions.IHasSetExceptionAsCause;
import com.vector.cfg.gen.core.moduleinterface.multipleModuleGenerators.IModule;
import com.vector.cfg.gen.core.moduleinterface.multipleModuleGenerators.IMultipleModuleGeneratorPackage;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.cedescriptor.IDescriptorBuilder;
import com.vector.cfg.model.cedescriptor.IDescriptorFactoryUtil;
import com.vector.cfg.model.uow.IExtendedStatus;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.exceptions.InterruptedRuntimeException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.log.IUserMessage;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;
import com.vector.cfg.util.text.mixedtext.IStrictMixedTextBuilder;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * Utility class for the Framework to retrieve internal objects, like the current active {@link IGeneratorPackage}, when nothing else is available.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GeneratorUtilFrameworkHelper {

    private static final ILogger logger = Logger.INSTANCE.createLogger(GeneratorUtilFrameworkHelper.class);

    private static final Object FRAMEWORK_INTERNAL_TOKEN = new Object();

    private static ThreadLocal<IGeneratorPackage> currentPackage = new ThreadLocal<>();

    private GeneratorUtilFrameworkHelper() {

    }

    /**
     * DO NOT USE THIS METHOD! IT IS FOR INTERNAL GenCore USE ONLY!
     *
     * @return the framework internal token
     */
    @PublishedMethod
    public static Object getFrameworkInternalToken() {
        return FRAMEWORK_INTERNAL_TOKEN;
    }

    /**
     * DO NOT USE THIS METHOD! IT IS FOR INTERNAL GenCore USE ONLY! Ensure token is correct.
     *
     * @param token the token
     */
    @PublishedMethod
    public static void ensureTokenIsCorrect(Object token) {
        if (token != FRAMEWORK_INTERNAL_TOKEN) {
            throw new IllegalArgumentException(
                    "The passed token is not the FRAMEWORK_INTERNAL_TOKEN. DO NOT USE methods with an framework token. These methods are not design to be called by a generator!");
        }
    }

    /**
     * Check thread interrupted. Throws an {@link InterruptedRuntimeException} if the Thread was interrupted.
     */
    @PublishedMethod
    public static void checkThreadInterrupted() {
        if (Thread.interrupted()) {
            throw new InterruptedRuntimeException(new InterruptedException("The exectution is already marked for cancelation."));
        }
    }

    /**
     * Gets the current active generator package.
     *
     * <p>
     * The generator framework will active the {@link IGeneratorPackage} before the generator is called.
     * </p>
     *
     * <p>
     * <b>Attention:</b> You can not use this class during Live-Validation. calls to this class are only permitted during the generation process.
     * </p>
     *
     * @return the current generator package, or null if no genratorPackage is currently available.
     */
    @PublishedMethod
    public static IGeneratorPackage getCurrentGeneratorPackage() {

        final IGeneratorPackage currentGeneratorPackage = currentPackage.get();

        return currentGeneratorPackage;

    }

    /**
     * DO NOT USE THIS METHOD! IT IS FOR INTERNAL GenCore USE ONLY!
     *
     * @param currentGeneratorPackage
     */
    @KeepSecretFromPublishedApi
    public static void setCurrentGeneratorPackageInternal(IGeneratorPackage currentGeneratorPackage) {
        if (currentGeneratorPackage == null) {
            currentPackage.remove();
        } else {
            currentPackage.set(currentGeneratorPackage);
        }

    }

    /**
     * Creates a {@link IGeneratorResult} from any {@link Throwable} and transforms it to a unhandled Exception {@link IGeneratorResult}.
     *
     * @param e the {@link Throwable} to wrap
     * @return the {@link IGeneratorResult} for the unhandled exception.
     */
    @PublishedMethod
    public static IGeneratorResult createGenResultFromUnhandeledException(Throwable e) {

        final IGeneratorPackage generatorPackage = getCurrentGeneratorPackage();
        return createGenResultFromUnhandeledException(generatorPackage, e, null, null);

    }

    /**
     * Creates a {@link IGeneratorResult} from any {@link Throwable} and transforms it to a unhandled Exception {@link IGeneratorResult}.
     *
     * @param generatorPackage the generator package
     * @param e the {@link Throwable} to wrap
     * @param genPhase the GenerationPhase where the {@link Throwable} was thrown.
     * @return the {@link IGeneratorResult} for the unhandled exception.
     */
    @PublishedMethod
    public static IGeneratorResult createGenResultFromUnhandeledException(IGeneratorPackage generatorPackage, Throwable e, String genPhase) {

        return createGenResultFromUnhandeledException(generatorPackage, e, genPhase, null);

    }

    /**
     * Creates a {@link IGeneratorResult} from any {@link Throwable} and transforms it to a unhandled Exception {@link IGeneratorResult}.
     *
     * @param generatorPackage the generator package
     * @param e the {@link Throwable} to wrap
     * @param genPhase the GenerationPhase where the {@link Throwable} was thrown.
     * @param fileName the file name
     * @return the {@link IGeneratorResult} for the unhandled exception.
     */
    @PublishedMethod
    public static IGeneratorResult createGenResultFromUnhandeledException(IGeneratorPackage generatorPackage, Throwable e, String genPhase, String fileName) {

        final StringBuilder builder = new StringBuilder();

        builder.append("Exception in ");
        builder.append(generatorPackage.getMSN());
        builder.append(" generator ");
        if (genPhase != null) {
            builder.append("during ");
            builder.append(genPhase);
            builder.append(" ");
        }

        if (fileName != null) {
            builder.append("of ");
            builder.append(fileName);
            builder.append(" ");
        }

        builder.append("encountered: \r\n");
        builder.append(e);
        builder.append(" ");
        Throwable inner = e.getCause();
        while (inner != null) {
            builder.append("\r\n");
            builder.append("Caused by: ");
            builder.append(inner);
            inner = inner.getCause();
        }

        logger.fatal("Unhandled Exception: " + builder.toString(), e);

        final GeneratorResultBuilder resultBuilder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getGeneratorUnhandledExceptionFailureId(generatorPackage),
                builder.toString());

        createDescriptorOfGenPack(generatorPackage, resultBuilder);

        final IGeneratorResult result = resultBuilder.buildResult();

        assignExToResult(result, e);
        return result;
    }

    /**
     * Creates the gen result warning for previous unit of work error.
     *
     * @param generatorPackage the generator package
     * @param uowStatus the uow status
     * @param genPhase the gen phase
     * @return the {@link IValidationResult} for the UOW error.
     */
    @KeepSecretFromPublishedApi
    public static IValidationResult createGenResultWarningForPreviousUnitOfWorkError(IGeneratorPackage generatorPackage, IExtendedStatus uowStatus, String genPhase) {

        final IMixedTextBuilder builder = MixedText.newBuilder();

        builder.append("The execution of ");
        builder.append(generatorPackage.getMSN());
        builder.append(" generator could not be started");
        if (genPhase != null) {
            builder.append(" for ");
            builder.append(genPhase);
        }
        builder.append(".");
        builder.append(" The previous calculation execution was erroneous.");
        builder.append("\r\nEncountered problem: \r\n");
        builder.append(uowStatus.getUserMessage());
        builder.append(" ");

        final IGeneratorResult result = GeneratorResultBuilder
                .newBuilder(CommonGeneratorResultIds.getPreviousUOWErrorInCalculationWarning(generatorPackage), builder.flushResult()).buildResult();
        if (uowStatus.getException() != null) {
            assignExToResult(result, uowStatus.getException());
        }
        return result;
    }

    /**
     * Creates the gen result from unit of work error.
     *
     * @param generatorPackage the generator package
     * @param uowStatus the uow status
     * @param genPhase the gen phase
     * @return the {@link IValidationResult} for the UOW error.
     */
    @KeepSecretFromPublishedApi
    public static IGeneratorResult createGenResultFromUnitOfWorkError(IGeneratorPackage generatorPackage, Exception ex,
            String genPhase) {

        final IStrictMixedTextBuilder builder = MixedText.newStrictBuilder();

        builder.append("The calculation of ");
        builder.append(generatorPackage.getMSN());
        builder.append(" generator ");
        if (genPhase != null) {
            builder.appendFormat("during \"{0}\"", genPhase);
        }
        builder.appendFormat(" aborted.\r\nEncountered problem: \r\n");

        IMixedText userMessage = null;
        if (ex instanceof IUserMessage) {
            userMessage = ((IUserMessage) ex).getUserMessage();
            builder.append(userMessage);
        } else {
            builder.append(ex.getMessage());

            builder.append(" ");
            Throwable inner = ex.getCause();
            while (inner != null) {
                builder.appendFormat("\r\n");
                builder.append("Caused by: ");
                builder.append(inner);
                inner = inner.getCause();
            }
        }

        final GeneratorResultBuilder resultBuilder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getUOWErrorInCalculation(generatorPackage), builder.build());

        createDescriptorOfGenPack(generatorPackage, resultBuilder);

        if (userMessage != null) {
            resultBuilder.addErrorObjectsFromMixedText(userMessage);
        }

        final IGeneratorResult result = resultBuilder.buildResult();
        assignExToResult(result, ex);
        return result;
    }

    /**
     * Creates the descriptor of the {@link IGeneratorPackage}.
     *
     * @param generatorPackage the generator package
     * @param resultBuilder the result builder
     */
    private static void createDescriptorOfGenPack(IGeneratorPackage generatorPackage, GeneratorResultBuilder resultBuilder) {
        final IProjectContext projectContext = generatorPackage.getProjectContext();
        if (projectContext != null) {
            final IDescriptorFactoryUtil descFactoryUtil = generatorPackage.getProjectContext().getService(IDescriptorFactoryUtil.class);
            if (descFactoryUtil != null) {
                if (generatorPackage instanceof IMultipleModuleGeneratorPackage) {
                    for (final IModule module : ((IMultipleModuleGeneratorPackage) generatorPackage).getCurrentModulesToProcess()) {
                        final IDescriptorBuilder moduleDescriptor = descFactoryUtil.createBuilder(module.getModuleDefinitionRef(), null, null);
                        resultBuilder.addErrorDescriptor(moduleDescriptor.create());
                    }
                    return;
                }

                final IDescriptorBuilder moduleDescriptor = descFactoryUtil.createBuilder(generatorPackage.getModuleDefinitionRef(), null, null);
                resultBuilder.addErrorDescriptor(moduleDescriptor.create());

            }
        }
    }

    /**
     * Assign ex to result.
     *
     * @param genResult the gen result
     * @param ex the ex
     */
    private static void assignExToResult(IGeneratorResult genResult, Throwable ex) {
        if (genResult instanceof IHasSetExceptionAsCause) {
            ((IHasSetExceptionAsCause) genResult).setException(ex);
        }

    }

}
