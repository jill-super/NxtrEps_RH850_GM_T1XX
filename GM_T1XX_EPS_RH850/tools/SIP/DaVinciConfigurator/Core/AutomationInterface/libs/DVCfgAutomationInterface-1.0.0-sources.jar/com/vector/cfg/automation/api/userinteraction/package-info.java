/**
 * Automation script API for user interaction and input in a running script task.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.api.userinteraction;