package com.vector.cfg.gen.core.moduleinterface.generatorpackageaspects;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.calculation.GenCalculationAspect;

/**
 * <div class="extdoc" id="GenAutomaticOnDemandValidationAspect">
 *
 * The {@link GenAutomaticOnDemandValidationAspect} provides the possibility to enable or disable the automatic generator validation. This feature is usually disabled and can
 * only be enabled if the generator does not make contributions to the calculation phase ({@link GenCalculationAspect}). The automatic generator validation starts the on demand
 * validation after project load or relevant modifications of the module configuration. This feature triggers the method IGenerationProcessor.buildDataStructures(). <br/>
 * The {@link GenAutomaticOnDemandValidationAspect} should be registered in the {@link IGeneratorPackage}.
 *
 * <pre>
 * <code class="Java" id="GenPostBuildSelectableAspect implementation sample in a GeneratorPackage">
 *   //Insert this code in your GeneratorPackage
 *
 * protected void registerGeneratorPackageAspects() {
 *
 *    // Create and registers a IGenModuleDependenciesAspect
 *    addPackageAspect(IGenAutomaticOnDemandValidationAspect.class,
 *      new IGenAutomaticOnDemandValidationAspect(){
 *         public boolean isAutomaticValidationEnabled(){
 *            return true;
 *         }
 *      });
 * }
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IGenAutomaticOnDemandValidationAspect extends IGeneratorPackageAspect {

    /**
     * Checks if is automatic validation enabled.
     *
     * @return true, if is automatic validation enabled
     */
    @PublishedMethod
    boolean isAutomaticValidationEnabled();

}
