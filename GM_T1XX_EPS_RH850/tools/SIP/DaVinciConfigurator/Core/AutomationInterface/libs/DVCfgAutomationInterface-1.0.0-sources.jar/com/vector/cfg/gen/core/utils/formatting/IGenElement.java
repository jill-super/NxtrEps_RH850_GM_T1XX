package com.vector.cfg.gen.core.utils.formatting;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The base interface of all GenElements, which support the generation of data with formating information.
 * <p>
 * Attention: This interface is not intended to be implemented by the user!
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenElement {

    /**
     * Adds a comment text after the element. <br />
     * The style is following : <br/>
     * <code><ul> ElementValue &#47;*  commentParam  *&#47; </ul></code>
     *
     * <p>
     * Subsequent calls to {@link #comment(String)} are appended to one comment.
     * </p>
     *
     * @param commentParam The comment
     * @return The GenElement
     *
     * @throws IllegalArgumentException<ul>
     * <li>if commentParam is null.</li>
     * </ul>
     *
     */
    @PublishedMethod
    IGenElement comment(String commentParam);

    /**
     * Adds a comment text to the element. <br />
     * The style is following : <br/>
     * <code><ul>&#47;*  commentParam  *&#47; ElementValue  </ul></code>
     *
     * <p>
     * Subsequent calls to {@link #prefixComment(String)} are appended to one comment.
     * </p>
     *
     * @param commentParam The comment
     * @return The GenElement
     *
     * @throws IllegalArgumentException<ul>
     * <li>if commentParam is null.</li>
     * </ul>
     *
     */
    @PublishedMethod
    IGenElement prefixComment(String commentParam);

    /**
     * Generates the String with NO format.
     *
     * @return The generated String
     */
    @PublishedMethod
    String generate();

    /**
     * Generates the String with specified format.
     *
     * <p>
     * See {@link EFormatType} for convenient formatter.
     * </p>
     * <p>
     * Example:<br/>
     * <code> yourArray.generate(EFormatType.TWO_SPACES_PER_ELEMENT);</code>
     * </p>
     *
     * @return The generated String
     */
    @PublishedMethod
    String generate(IGenFormatProvider formatProvider);

    /**
     * Generates the String with the internal context Information.
     *
     * <p>
     * <b>Attention:</b> This method is NOT intended to be used by a CLIENT.
     * </p>
     *
     * <p>
     * USE {@link IGenElement#generate(IGenFormatProvider)} INSTEAD
     * </p>
     *
     * @return The generated String
     * @see IGenElement
     */
    @PublishedMethod
    void generate(StringBuilder builder, IGenFormatter formatter, int indentLevel, boolean isRootElement);

}
