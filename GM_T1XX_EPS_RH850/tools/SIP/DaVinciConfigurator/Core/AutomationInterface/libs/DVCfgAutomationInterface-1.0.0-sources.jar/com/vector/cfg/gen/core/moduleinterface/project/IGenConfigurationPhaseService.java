package com.vector.cfg.gen.core.moduleinterface.project;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.core.project.EConfigurationPhase;

/**
 * The {@link IGenConfigurationPhaseService} provides the current {@link EConfigurationPhase}.
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenConfigurationPhaseService {

    /**
     * Get the current project configuration phase.
     *
     * @return the current configuration phase.
     */
    @PublishedMethod
    EConfigurationPhase getConfigurationPhase();

}
