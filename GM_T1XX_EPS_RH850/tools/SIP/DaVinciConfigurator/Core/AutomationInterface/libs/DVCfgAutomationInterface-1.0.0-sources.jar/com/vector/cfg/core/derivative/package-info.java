/**
 * DaVinci Configurator derivative interfaces and base types.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.core.derivative;