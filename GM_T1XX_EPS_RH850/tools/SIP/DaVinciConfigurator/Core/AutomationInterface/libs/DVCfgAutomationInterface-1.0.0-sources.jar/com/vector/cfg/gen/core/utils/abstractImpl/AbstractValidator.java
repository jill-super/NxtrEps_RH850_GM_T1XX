package com.vector.cfg.gen.core.utils.abstractImpl;

import java.text.MessageFormat;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IRuleEvent;
import com.vector.cfg.consistency.contribution.IValidationEvents;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.contribution.IValidator;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageException;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.utils.exceptions.ModelExceptionProcessor;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultSinkWrapper;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * This class provides a skeletal implementation of the <tt>{@link IValidator IValidator}</tt> interface, to minimize the effort required to implement this
 * interface.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IValidator
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractValidator extends AbstractGeneratorPackageReferableWithModel implements IValidator {
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractValidator.class);

    private final ThreadLocal<IGeneratorResultSink> resultSinkPrivate;

    /**
     * Instantiates a new abstract validator.
     *
     * <p>
     * The FullValidation feature is disabled with this Constructor. Please use {@link #AbstractValidator(IGeneratorPackage, long)} instead, if you want use the
     * FullValidation feature.
     * </p>
     *
     * @param generatorPackage the generator package
     */
    @PublishedMethod
    protected AbstractValidator(IGeneratorPackage generatorPackage) {
        super(generatorPackage);

        resultSinkPrivate = new ThreadLocal<>();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void onModelEvent(IValidationResultSink results, IValidationEvents validationEvents) {
        // final Collection<IRuleEvent> events = validationEvents.getEvents(); // use this only if you can not use any of the new IValidationEvents methods

        final IGeneratorResultSink resultSink = GeneratorResultSinkWrapper.wrap(getGeneratorPackage(), results);

        this.resultSinkPrivate.set(resultSink);
        try {
            onModelEventInternal(resultSink, validationEvents);

        } catch (final GeneratorPackageException e) {
            if (logger.isDebugEnabled()) {
                logger.debug(e);
            }
            resultSink.reportGeneratorException(e);

        } catch (final ModelException modelEx) {

            if (logger.isDebugEnabled()) {
                logger.debug("ModelException caught in AbstractValidator.onModelEvent() and mapped to a ValidationResult.", modelEx);
            }
            ModelExceptionProcessor.addExceptionToResultSink(resultSink, modelEx, generatorPackage);

        } finally {
            this.resultSinkPrivate.set(null);
        }

    }

    /**
     * Within this method you have to validate the changes which are indicated by the rule events and create ValidationResults if you detect inconsistencies.
     * <BR>
     * See {@link http://wiki.vi.vector.int/wiki-psc/Cfg5Development/Consistency#BBB} Validation Event Observation
     *
     * <p>
     * The default implementation of this method will call {@link #onEachModelEvent(IGeneratorResultSink, IRuleEvent)} for each {@link IRuleEvent}.
     * </p>
     * <p>
     * You can override this method to process all events in one block. Then the method
     * {@link AbstractValidator#onEachModelEvent(IGeneratorResultSink, IRuleEvent)} shall throw an {@link UnsupportedOperationException}.
     * </p>
     *
     * <p>
     * Calling point:<br/>
     * This method is called during the Configuration. This method will be called multiple time.
     * </p>
     *
     * @param resultSink The method will append it results to the resultSink. The caller must provide an appropriate resultSink.
     * @param validationEvents The events that has triggered this validation.
     * @throws ValidationFailedException
     *
     */
    @PublishedMethod
    protected abstract void onModelEventInternal(IGeneratorResultSink resultSink, IValidationEvents validationEvents);

    /**
     * Getter method for resultSink.
     *
     * @return Returns the resultSink.
     */
    @PublishedMethod
    protected final IGeneratorResultSink getResultSink() {

        final IGeneratorResultSink sink = resultSinkPrivate.get();
        if (sink == null) {
            throw new IllegalStateException("The Validator is not in a validation process. No ResultSink is defined.");
        }
        return sink;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toString() {
        return MessageFormat.format("GeneratorLiveValidation ({0},{2}) in ({1})", getName(), getGeneratorPackage(), getClass().getCanonicalName());
    }

}
