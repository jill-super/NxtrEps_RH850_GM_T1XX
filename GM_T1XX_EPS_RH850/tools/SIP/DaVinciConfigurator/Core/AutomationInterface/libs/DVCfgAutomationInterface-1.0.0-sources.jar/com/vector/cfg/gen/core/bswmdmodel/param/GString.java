package com.vector.cfg.gen.core.bswmdmodel.param;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIStringParameter;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractParam;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.gen.core.utils.formatting.primitives.StringGenElement;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucStringDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucStringParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIStringParamDef;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * String parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GString extends GAbstractParam<String> implements GIStringParameter {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GString.class);

    private String value;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GString(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MITextualValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MITextualValue getMdfObject() {
        return (MITextualValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MITextualValue getMdfObjectUnsafe() {
        return (MITextualValue) super.getMdfObjectUnsafe();
    }

    private String getValueInternal() {
        try {
            switchView();

            final MITextualValue mdfObjectUnsafe = getMdfObjectUnsafe();
            if (mdfObjectUnsafe != null) {
                return mdfObjectUnsafe.getValue();
            }
            return null;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean hasValue() {
        if (isValueChecked()) {
            return true;
        }

        return getValueInternal() != null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getValue() {
        return getValueMdf();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getValueOrDefault(String defaultValue) {
        return getValueOrDefaultMdf(defaultValue);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String getValueMdf() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            getModelVerifier().assertParameterOrReferenceNotNull(getParent(), this);
            getModelVerifier().assertParameterValueNotNull(this, getValueInternal());

            value = getValueInternal();
            setValueChecked();
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public StringGenElement formatValue() {
        return F.formatString(this);
    }

    /**
     * Checks if the parameter has a value node AND the string is not empty("").
     *
     * @return true if the value node exists and the string is not "".
     */
    @Override
    @PublishedMethod
    public boolean hasValueAndNotEmpty() {
        if (hasValue()) {
            return (!getValue().isEmpty());
        }
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(String valueOf) {
        final IModelViewManager vm = getGeneratorModelAccess().getModelViewManager();
        try (IModelViewExecutionContext viewContext = vm.executeWithModelView(getCreationModelView())) {
            try (IModelViewExecutionContext modeContext = vm.executeWithVariantSpecificModelChanges()) {
                getGeneratorModelAccess().getMdfModelAccess().setAsString(getMdfObject(), valueOf);
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIStringParamDef getDefinition() {
        return (MIStringParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucStringDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucStringParameter getEcuConfiguration() {

        final IEcucParameter cfg = super.getEcuConfiguration();
        return (IEcucStringParameter) cfg;
    }

}
