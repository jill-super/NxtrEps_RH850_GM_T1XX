package com.vector.cfg.gen.core.moduleinterface.notification;

import java.io.File;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.multipleModuleGenerators.IModule;
import com.vector.cfg.gen.core.moduleinterface.multipleModuleGenerators.IMultipleModuleGeneratorPackage;

/**
 * IGeneratorNotificationService interface provides functionality to fire Notifications from an GeneratorPackage
 *
 * <p>
 * This is a ProjectService.
 * </p>
 *
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGeneratorNotificationService {

    /**
     * Fire generated file notification.
     *
     * @param genPackage the gen package
     * @param outputFile the output file
     * @param fileInfo the file info
     */
    @PublishedMethod
    void fireGeneratedFileNotification(IGeneratorPackageReferable genPackage, File outputFile, EFileInfo fileInfo);

    /**
     * Fire generated file notification.
     *
     * @param genPackage the gen package
     * @param module the module
     * @param outputFile the output file
     * @param fileInfo the file info
     */
    @PublishedMethod
    void fireGeneratedFileNotification(IMultipleModuleGeneratorPackage genPackage, IModule module, File outputFile, EFileInfo fileInfo);

    /**
     * Fire console content notification.
     *
     * @param genPackage the gen package
     * @param text the text
     */
    @PublishedMethod
    void fireConsoleContentNotification(IGeneratorPackageReferable genPackage, String text);

    /**
     * Fire console content notification.
     *
     * @param genPackage the gen package
     * @param module the module
     * @param text the text
     */
    @PublishedMethod
    void fireConsoleContentNotification(IMultipleModuleGeneratorPackage genPackage, IModule module, String text);

    /**
     * Fire a notification of the {@link IModule} of an {@link IMultipleModuleGeneratorPackage}. The {@link EExecutionResult} indicates if the process was
     * successful or not.
     *
     *
     * @param genPackage the gen package
     * @param module the module
     * @param executionResult the execution result
     */
    @PublishedMethod
    void fireMultiModuleGeneratorModuleFinishedNotification(IMultipleModuleGeneratorPackage genPackage, IModule module, EExecutionResult executionResult);

    /**
     * The {@link EFileInfo} enums describes the possible file state of a file notification. See
     * {@link IGeneratorNotificationService#fireGeneratedFileNotification(IGeneratorPackageReferable, File, EFileInfo)}.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    enum EFileInfo {
        FILE_CREATED,
        FILE_UPDATED,
        FILE_IS_UP_TO_DATE;
    }

    /**
     * The {@link EExecutionResult} enum is used to indicate if the generation of t {@link IModule} was ok or has failed. See
     * {@link IGeneratorNotificationService#fireMultiModuleGeneratorModuleFinishedNotification(IMultipleModuleGeneratorPackage, IModule, EExecutionResult)}.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    enum EExecutionResult {
        OK,
        FAILURE;
    }
}
