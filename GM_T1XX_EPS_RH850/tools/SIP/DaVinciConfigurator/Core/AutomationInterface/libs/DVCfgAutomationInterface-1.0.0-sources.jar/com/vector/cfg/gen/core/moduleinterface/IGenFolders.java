package com.vector.cfg.gen.core.moduleinterface;

import java.io.File;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IGenFolders} specifies all possible output folder of an {@link IGenerationProcessor}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IGenFolders {

    /**
     * Gets the code output folder.
     *
     * @return the code output folder
     */
    @PublishedMethod
    File getCodeOutputFolder();

    /**
     * Gets the code template output folder.
     *
     * @return the code template output folder
     */
    @PublishedMethod
    File getCodeTemplateOutputFolder();

    /**
     * Gets the McData folder.
     *
     * @return the McData folder
     */
    @PublishedMethod
    File getMcDataFolder();

    /**
     * Gets the Log folder.
     *
     * @return the Log folder
     */
    @PublishedMethod
    File getLogFolder();
}
