package com.vector.cfg.model.access.ecucdefinition;

import javax.annotation.concurrent.ThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucModuleDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucParamConfContainerDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucAddInfoDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucBooleanDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucEnumDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucFloatDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucFunctionNameDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucIntegerDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucLinkerSymbolDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucParameterDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucStringDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucChoiceRefDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucForeignRefDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucInstanceRefDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucRefDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucSymbolicNameRefDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucUriReferenceDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBooleanParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucAddInfoParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucUriReferenceDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEnumerationParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIForeignReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFunctionNameDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIInstanceReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIIntegerParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MILinkerSymbolDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIStringParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MISymbolicNameReferenceParamDef;

/**
 * <div class="extdoc" id="Common">
 * <h2>IEcucDefinitionAccess</h2> The {@link IEcucDefinitionAccess} provides convenient and typesafe access to definition objects (module, container, parameter and reference
 * definitions). The contained <code>def()</code> methods take MDF definition objects and return wrappers which can be used to retrieve specific characteristics of definitions.
 *
 * <p>
 * Example:
 *
 * <pre>
 * <code class="Java" id="Integer parameter definition access examples">
 *   IEcucDefinitionAccess eda;
 *   MIIntegerParamDef intParamDef;
 *
 *   // Get the integer definition wrapper
 *   IEcucIntegerDefinition def = eda.def(intParamDef);
 *
 *   // Get the (optional) default value
 *   Optional<BigInteger> defaultOpt = def.getDefault();
 *   boolean hasDefault = defaultOpt.isPresent();
     BigInteger defaultValue = defaultOpt.get();
 *
 *   // Get the multiplicity
 *   IEcucDefMultiplicity multiplicity = def.getMultiplicity();
 *   BigInteger lower = multiplicity.getLower();
 *   BigInteger upper = multiplicity.getUpper();
 * </code>
 * </pre>
 * </p>
 * </div>
 *
 * <p>
 * This is a ProjectService.
 * </p>
 * <p>
 * This ProjectService is threadsafe.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucDefinitionAccess {

    /**
     * starts a query for a definition of type {@link MIParamConfMultiplicity}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myContainerDef).getEcucScope()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucDefinition def(MIParamConfMultiplicity def);

    /**
     * starts a query for a definition of type {@link MIModuleDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myContainerDef).getRefinedModuleDef()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucModuleDefinition def(MIModuleDef module);

    /**
     * Returns the definition of the specified configuration object if available.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param module is an ECUC module configuration
     * @return a ecuc definition access query object if available
     */
    @PublishedMethod
    Optional<IEcucModuleDefinition> def(MIModuleConfiguration module);

    /**
     * starts a query for a definition of type {@link MIContainerDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myContainerDef).isPostBuildChangeable()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucContainerDefinition def(MIContainerDef container);

    /**
     * Returns the definition of the specified configuration object if available.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param container is an ECUC container
     * @return a ecuc definition access query object if available
     */
    @PublishedMethod
    Optional<IEcucContainerDefinition> def(MIContainer container);

    /**
     * starts a query for a definition of type {@link MIParamConfContainerDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myContainerDef).getSymbolicNameValue()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucParamConfContainerDefinition def(MIParamConfContainerDef container);

    /*
     * ------------ parameters ------------
     */

    /**
     * starts a query for a definition of type {@link MIBooleanParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getWithAuto()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucBooleanDefinition def(MIBooleanParamDef param);

    /**
     * starts a query for a definition of type {@link MIEnumerationParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getWithAuto()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucEnumDefinition def(MIEnumerationParamDef param);

    /**
     * starts a query for a definition of type {@link MIFloatParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getWithAuto()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucFloatDefinition def(MIFloatParamDef param);

    /**
     * starts a query for a definition of type {@link MIIntegerParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getWithAuto()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucIntegerDefinition def(MIIntegerParamDef param);

    /**
     * starts a query for a definition of type {@link MIConfigParameter}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getWithAuto()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucParameterDefinition def(MIConfigParameter param);

    /**
     * Returns the definition of the specified configuration object if available.
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param param is an ECUC parameter
     * @return a ecuc definition access query object if available
     */
    @PublishedMethod
    Optional<IEcucParameterDefinition> def(MIParameterValue param);

    /**
     * starts a query for a definition of type {@link MIFunctionNameDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getValidationRegex()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucFunctionNameDefinition def(MIFunctionNameDef param);

    /**
     * starts a query for a definition of type {@link MILinkerSymbolParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getValidationRegex()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucLinkerSymbolDefinition def(MILinkerSymbolDef param);

    /**
     * starts a query for a definition of type {@link MIStringParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getValidationRegex()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucStringDefinition def(MIStringParamDef param);

    /**
     * starts a query for a definition of type {@link MIEcucAddInfoParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myParamDef).getConfigurationType()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucAddInfoDefinition def(MIEcucAddInfoParamDef param);

    /*
     * ------------ references ------------
     */

    /**
     * starts a query for a definition of type {@link MIChoiceReferenceParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myRefDef).getTargetDefinitions()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucChoiceRefDefinition def(MIChoiceReferenceParamDef param);

    /**
     * starts a query for a definition of type {@link MIForeignReferenceParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myRefDef).getTargetRefClass()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucForeignRefDefinition def(MIForeignReferenceParamDef param);

    /**
     * starts a query for a definition of type {@link MIInstanceReferenceParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myRefDef).getTargetRefClass()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucInstanceRefDefinition def(MIInstanceReferenceParamDef param);

    /**
     * starts a query for a definition of type {@link MIReferenceParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myRefDef).getTargetDefinition()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucRefDefinition def(MIReferenceParamDef param);

    /**
     * starts a query for a definition of type {@link MISymbolicNameReferenceParamDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myRefDef).getTargetDefinition()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucSymbolicNameRefDefinition def(MISymbolicNameReferenceParamDef param);

    /**
     * starts a query for a definition of type {@link MIEcucUriReferenceDef}.
     *
     * <p>
     * Example:<br/>
     * <code>
        eda.def(myRefDef).getConfigurationType()
     * </code>
     * </p>
     *
     * @param param the definition
     * @return a ecuc definition access query object
     */
    @PublishedMethod
    IEcucUriReferenceDefinition def(MIEcucUriReferenceDef param);

}
