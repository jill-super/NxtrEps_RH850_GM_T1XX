package com.vector.cfg.gen.core.moduleinterface.calculation;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.notification.IGenerationSubPhase;
import com.vector.cfg.util.IDebugable;

/**
 * The enum {@link ECalculationSubPhase} specifies all possible (sub) phases of the Calculation phase, of an {@link IGeneratorPackage}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see ICalculator
 * @see IGenCalculationAspect
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
/* JavaListing ECalculationSubPhase */
public enum ECalculationSubPhase implements IGenerationSubPhase, IDebugable {

    MODULE_INTERNAL_CALCULATION("Module internal ecuc data calculation", /* ordinalOrder */0),
    MODULE_EXTERNAL_CALCULATION("Module ecuc data calculation using external data", 5),
    SWC_SYNCHRONIZATION("Swc Synchronization", 20),
    BSW_INTERNAL_BEHAVIOR_SYCHNRONIZATION("BswInternalBehavior data synchronization", 30),
    RTE_CALCULATION("RTE calculation", 40),
    POST_RTE_CALCULATION("Post RTE calculation", 41),
    MC_SUPPORT_DATA_SYCHNRONIZATION("Measurement and Calibration support data synchronization", 45),
    ECUC_CONFIG_HASH_CALCULATION("EcuC Configuration hash calculation", 50)
    /* End JavaListing */
    ;

    private final int orderId;

    private final String descriptivePhaseName;

    /**
     * Creates a {@link ECalculationSubPhase} in the order of the passed orderId. The order is ascending, e.g. 1 before 2.
     *
     * @param orderId the order id
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the orderId is negative</li>
     * </ul>
     */
    ECalculationSubPhase(String descriptivePhaseName, int orderId) {
        this.descriptivePhaseName = checkNotNull(descriptivePhaseName);
        this.orderId = orderId;
        checkArgument(orderId >= 0);
    }

    /**
     * Gets the comparator for the {@link ECalculationSubPhase}s. The comparator compares the literals by their orderId (ordinalOrder).
     *
     * @return the comparator
     */
    @PublishedMethod
    public static Comparator<ECalculationSubPhase> getComparator() {
        return new Comparator<ECalculationSubPhase>() {

            @Override
            public int compare(ECalculationSubPhase o1, ECalculationSubPhase o2) {
                return o1.orderId - o2.orderId;
            }
        };
    }

    /**
     * Gets the all literals as a list of sorted values, sorted by the comparator of {@link #getComparator()}.
     *
     * @return the sorted values of all literals.
     */
    @PublishedMethod
    public static List<ECalculationSubPhase> getSortedValues() {
        final List<ECalculationSubPhase> list = new ArrayList<>(Arrays.asList(values()));
        Collections.sort(list, getComparator());

        return list;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String getName() {
        return descriptivePhaseName;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        return getName();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public String toDebugString() {
        return super.name();
    }
}
