package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Stack;

import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.GIModelFactory;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.untyped.GUntypedContainer;
import com.vector.cfg.gen.core.bswmdmodel.untyped.GUntypedEnumeration;
import com.vector.cfg.gen.core.bswmdmodel.untyped.GUntypedModuleConfiguration;
import com.vector.cfg.gen.core.moduleinterface.variants.IGenPostBuildSelectableVariantsService;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.IReferrableAccess;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.access.ecucdefinition.IEcucDefinitionAccess;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucDefMultiplicity;
import com.vector.cfg.model.access.ecuconfiguration.IEcuConfigurationAccess;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIEcucAddInfoParamValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBooleanParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucAddInfoParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEcucMultilineStringParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIEnumerationParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIForeignReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFunctionNameDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIInstanceReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIIntegerParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MILinkerSymbolDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIReferenceParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIStringParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MISymbolicNameReferenceParamDef;
import com.vector.cfg.model.query.modelcheckedaccess.IModelCheckedAccess;
import com.vector.cfg.model.view.IModelViewExecutionContext;
import com.vector.cfg.model.view.IModelViewManager;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.math.MBigDecimal;

/**
 * The abstract base class for bswmd model access class overridden in every generated bswmd model.
 *
 * <p>
 * <b>Attention:</b> DO NOT USE THIS CLASS. THIS CLASS IS INTERNALLY USED!!!
 * </p>
 * <p>
 * Attention: Please use {@link GIModelAccess} interface in client code.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@NotThreadSafe
public abstract class AbstractBswmdModelAccess implements IInternalGeneratorModelAccess {
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractBswmdModelAccess.class);

    /*
     * Static constants
     */

    protected static final BigInteger LONG_MIN = BigInteger.valueOf(Long.MIN_VALUE);

    protected static final BigInteger LONG_MAX = BigInteger.valueOf(Long.MAX_VALUE);

    protected static final BigDecimal DOUBLE_MIN = MBigDecimal.valueOf(Double.MIN_VALUE);

    protected static final BigDecimal DOUBLE_MAX = MBigDecimal.valueOf(Double.MAX_VALUE);

    protected static final BigDecimal DOUBLE_MIN_NEG = DOUBLE_MIN.negate();

    protected static final BigDecimal DOUBLE_MAX_NEG = DOUBLE_MAX.negate();

    protected static final BigDecimal ZERO = BigDecimal.ZERO;

    /*
     * Final fields
     */
    protected final IModelAccess modelAccess;

    protected final IReferrableAccess referrableAccess;

    private final IEcucDefinitionAccess ecucDefinitionAccess;

    private final IEcuConfigurationAccess ecuConfigurationAccess;

    private final IProjectContext projectContext;

    private final GAbstractModelFactory modelFactory;

    private final IModelViewManager modelViewManager;

    private final IModelCheckedAccess mca;

    private final IGenPostBuildSelectableVariantsService variantsService;

    private final Map<MIHasDefinition, GAbstractModelObject> relatedElementMap = new HashMap<>();

    private final IModelView boundView;

    private final boolean isProjectVariant;

    @Nullable
    private final Stack<IModelViewExecutionContext> executionContextStack;

    /*
     * mutable fields
     */

    /**
     * Constructor.
     *
     * @param moduleSpecificFactory
     *
     * @param genModuleConfiguration
     */

    protected AbstractBswmdModelAccess(GIModelFactory modelFactory, IProjectContext projectContext) {
        this.modelFactory = (GAbstractModelFactory) checkNotNull(modelFactory);
        this.projectContext = checkNotNull(projectContext);
        modelAccess = projectContext.getService(IModelAccess.class);
        referrableAccess = projectContext.getService(IReferrableAccess.class);
        modelViewManager = projectContext.getService(IModelViewManager.class);
        ecucDefinitionAccess = projectContext.getService(IEcucDefinitionAccess.class);
        ecuConfigurationAccess = projectContext.getService(IEcuConfigurationAccess.class);
        mca = projectContext.getService(IModelCheckedAccess.class);
        variantsService = projectContext.getService(IGenPostBuildSelectableVariantsService.class);

        boundView = checkNotNull(modelViewManager.getCurrentlyActiveView());
        isProjectVariant = !modelViewManager.getAllVariantViews().isEmpty();
        if (isProjectVariant) {
            executionContextStack = new Stack<>();
        } else {
            executionContextStack = null;
        }

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public GIModelFactory getFactory() {
        return modelFactory;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IModelAccess getMdfModelAccess() {
        assertIsBoundViewActive();
        return modelAccess;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IModelView getCreationModelView() {
        return boundView;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IModelCheckedAccess getMdfModelCheckedAccess() {
        assertIsBoundViewActive();
        return mca;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IReferrableAccess getMdfReferrableAccess() {
        assertIsBoundViewActive();
        return referrableAccess;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IEcucDefinitionAccess getEcucDefinitionAccess() {
        return ecucDefinitionAccess;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IEcuConfigurationAccess getEcuConfigurationAccess() {
        return ecuConfigurationAccess;
    }

    @Override
    public IProjectContext getProjectContext() {
        return projectContext;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IModelViewManager getModelViewManager() {
        return modelViewManager;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public IGenPostBuildSelectableVariantsService getGenPostBuildSelectableVariantsService() {
        return variantsService;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setRelatedElement(GIModelObject bswmdModelObject, MIHasDefinition mdfObject) {
        checkNotNull(bswmdModelObject);
        checkNotNull(mdfObject);
        assertIsBoundViewActive();

        final GIModelObject oldElement = relatedElementMap.put(mdfObject, (GAbstractModelObject) bswmdModelObject);
        if (oldElement != null && bswmdModelObject != oldElement) {
            checkArgument(bswmdModelObject.getClass() == oldElement.getClass());
            logger.warn(
                    "There were multiple BswmdModel instances created for the same MIObject "
                            + ModelAccessUtil.toDebugStringMDFObject(mdfObject)
                            + ". Existing Element is: "
                            + oldElement
                            + " New created element is: "
                            + bswmdModelObject
                            + "."
                            + "\r\nThis is probably a problem of R8 and R9 Generated BswmdModel. Try to upgrade to a newer BswmdModel version. This could potentially lead to error in hash based data structures. Also see EVAL00120881.",
                    new RuntimeException("Stacktrace of warning."));
        }

    }

    /**
     * {@inheritDoc}
     */

    @Override
    public GIModelObject getRelatedElement(MIHasDefinition mdfObject) {
        if (mdfObject == null) {
            return null;
        }
        assertIsBoundViewActive();

        return relatedElementMap.get(mdfObject);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public GIModelObject getGenModelObjectByMDFObject(MIHasDefinition mdfCfgElement) {
        if (mdfCfgElement == null) {
            throw new IllegalArgumentException("mdfCfgElement is null");
        }
        return getGenModelObjectByMDFObject(mdfCfgElement, DefRef.create(mdfCfgElement));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void invalidateCache() {
        try {
            switchViewInternal();

            final Iterator<Entry<MIHasDefinition, GAbstractModelObject>> it = relatedElementMap.entrySet().iterator();
            while (it.hasNext()) {
                final Entry<MIHasDefinition, GAbstractModelObject> entry = it.next();
                final MIHasDefinition mdfObject = entry.getKey();
                final GAbstractModelObject gElem = entry.getValue();
                if (mdfObject != null) {
                    if (ModelAccessUtil.isRemovedOrInvisible(mdfObject)) {
                        it.remove();
                        continue;
                    }
                }
                gElem.invalidateCache();

            }

        } finally {
            restoreView();
        }

    }

    @Override
    public void checkCacheAndInvalidateIfNecessary() {
        modelFactory.checkCacheAndInvalidateIfNecessary();
    }

    @Override
    public void switchView() {
        switchViewInternal();
        checkCacheAndInvalidateIfNecessary();
    }

    private void switchViewInternal() {
        if (isProjectVariant) {
            switchViewPBSelect();
        }

    }

    private void switchViewPBSelect() {

        final IModelViewExecutionContext executionContext = modelViewManager.executeWithModelView(boundView);
        executionContextStack.push(executionContext);
    }

    @Override
    public void restoreView() {
        if (isProjectVariant) {
            restoreViewPBSelect();
        }
    }

    private void restoreViewPBSelect() {
        if (executionContextStack.isEmpty()) {
            final IModelView activeViewFromMgr = checkNotNull(modelViewManager.getCurrentlyActiveView());
            throw new IllegalStateException("The View could not be resetted, because the have no elements left on the View Stack: CurrentActiveView: " + activeViewFromMgr + ".");
        }

        final IModelViewExecutionContext executionContext = executionContextStack.pop();
        executionContext.close();
    }

    @Override
    public void assertIsBoundViewActive() {
        modelFactory.checkCacheAndInvalidateIfNecessary();
        if (isProjectVariant) {
            assertIsBoundViewActivePBSelect();
        }
    }

    private void assertIsBoundViewActivePBSelect() {
        final IModelView activeViewFromMgr = checkNotNull(modelViewManager.getCurrentlyActiveView());
        if (activeViewFromMgr.equals(boundView)) {
            return;
        }
        throw new IllegalStateException("The current active view is not the Bound view. This is NOT permitted! CurrentActiveView: " + activeViewFromMgr + " BoundView: "
                + boundView + ".");
    }

    abstract void assertMdfConfigElementHasCorrectDefinition(MIHasDefinition mdfCfgElement, MIParamConfMultiplicity definition, DefRef defRef);

    /**
     * {@inheritDoc}
     */
    @Override
    public GIModelObject getGenModelObjectByMDFObject(MIHasDefinition mdfCfgElement, DefRef defRef) {
        try {
            switchView();

            if (mdfCfgElement == null) {
                throw new IllegalArgumentException("mdfCfgElement is null");
            }
            if (defRef == null) {
                throw new IllegalArgumentException("defRef is null");
            }

            final MIParamConfMultiplicity mdfDefElem = ModelUtil.getDefinition(mdfCfgElement);
            assertMdfConfigElementHasCorrectDefinition(mdfCfgElement, mdfDefElem, defRef);

            final GIModelObject relatedContainer = getRelatedElement(mdfCfgElement);

            if (relatedContainer != null) {
                return relatedContainer;
            }

            DefRef defRefToUseToCreate = defRef;
            if (defRef.hasWildcards()) {
                // DAVID00130205: Fix bug that came with DAVID00129070 (I2c Usecase with enum literals StMD <-> VSMD)
                // The BswmdModel instance shall never use Wildcard DefRefs, for the instance.
                defRefToUseToCreate = DefRef.create(mdfCfgElement);
            }

            return createBswmdObjectByMdfObject(mdfCfgElement, defRefToUseToCreate);

        } finally {
            restoreView();
        }
    }

    protected GIModelObject createBswmdObjectByMdfObject(MIHasDefinition mdfCfgElement, DefRef defRef) {

        if (mdfCfgElement instanceof MIModuleConfiguration) {
            return GUntypedModuleConfiguration.create(this, (MIModuleConfiguration) mdfCfgElement, defRef);
        } else if (mdfCfgElement instanceof MIContainer) {
            return GUntypedContainer.create(this, (MIContainer) mdfCfgElement, defRef);
        }

        if (mdfCfgElement instanceof MIParameterValue) {
            final MIParameterValue mdfParam = (MIParameterValue) mdfCfgElement;

            final MIConfigParameter mdfDefElem = ModelUtil.getDefinition(mdfCfgElement);
            final IEcucDefMultiplicity paramMul = ecucDefinitionAccess.def(mdfDefElem).getMultiplicity();
            final boolean isOnlyOneElement = paramMul.is1To1() || paramMul.is0To1();

            @SuppressWarnings("unchecked")
            final Class<? extends MIParamConfMultiplicity> mdfDefClass = mdfDefElem.mdfGetInterfaceClass();

            final GIContainer parent = (GIContainer) this.getGenModelObjectByMDFObject(mdfParam.getParent());
            // Params
            if (mdfDefClass == MIIntegerParamDef.class) {
                return GeneratorModelParameterFactory.createInteger(defRef, mdfParam, this, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MIFloatParamDef.class) {
                return GeneratorModelParameterFactory.createFloat(defRef, (MINumericalValue) mdfCfgElement, this, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MIBooleanParamDef.class) {
                return GeneratorModelParameterFactory.createBoolean(defRef, mdfParam, this, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MIEnumerationParamDef.class) {
                return GUntypedEnumeration.create(this, defRef, (MITextualValue) mdfCfgElement, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MIFunctionNameDef.class) {
                return GeneratorModelParameterFactory.createFunctionName(defRef, (MITextualValue) mdfCfgElement, this, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MILinkerSymbolDef.class) {
                return GeneratorModelParameterFactory.createLinkerSymbol(defRef, mdfParam, this, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MIEcucMultilineStringParamDef.class) {
                return GeneratorModelParameterFactory.createMultilineString(defRef, (MITextualValue) mdfCfgElement, this, parent, isOnlyOneElement);

            }

            if (mdfDefClass == MIStringParamDef.class) {
                return GeneratorModelParameterFactory.createString(defRef, (MITextualValue) mdfCfgElement, this, parent, isOnlyOneElement);
            }

            // Refs
            if (mdfDefClass == MISymbolicNameReferenceParamDef.class) {
                return GeneratorModelParameterFactory.createSymbolicNameReference(defRef, (MIReferenceValue) mdfCfgElement, this, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MIChoiceReferenceParamDef.class) {
                return GeneratorModelParameterFactory.createChoiceReference(defRef, (MIReferenceValue) mdfCfgElement, this, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MIReferenceParamDef.class) {
                return GeneratorModelParameterFactory.createReference(defRef, (MIReferenceValue) mdfCfgElement, this, parent, isOnlyOneElement);
            }

            if (mdfDefClass == MIForeignReferenceParamDef.class) {
                return GeneratorModelParameterFactory.createForeignReference(defRef, (MIReferenceValue) mdfCfgElement, this, parent, isOnlyOneElement);

            }

            if (mdfDefClass == MIInstanceReferenceParamDef.class) {
                return GeneratorModelParameterFactory.createInstanceReference(defRef, (MIInstanceReferenceValue) mdfCfgElement, this, parent, isOnlyOneElement);

            }

            if (mdfDefClass == MIEcucAddInfoParamDef.class) {
                return GeneratorModelParameterFactory.createAddInfo(defRef, (MIEcucAddInfoParamValue) mdfCfgElement, this, parent, isOnlyOneElement);

            }
        }

        throw new IllegalArgumentException("Can not create GIType for passed MDF Configuration element: " + ModelAccessUtil.toDebugStringMDFObject(mdfCfgElement) + ".");
    }
}