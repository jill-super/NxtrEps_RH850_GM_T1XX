package com.vector.cfg.gen.core.utils.query;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIHasContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.utils.query.selectors.GenParamManySelector;
import com.vector.cfg.gen.core.utils.query.selectors.GenParamSelector;
import com.vector.cfg.gen.core.utils.query.selectors.GenParentSelector;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.query.ElementManySelector;
import com.vector.cfg.util.query.ElementSelector;
import com.vector.cfg.util.query.StandardSelectors;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@SuppressWarnings("rawtypes")
public class GenSelectors extends StandardSelectors {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenSelectors.class);

    @PublishedMethod
    public GenSelectors() {

    }

    @PublishedMethod
    public static <E extends GIHasContainer> ElementSelector<GIModelObject, E> genParentSelector(Class<E> clazz) {
        return new GenParentSelector<>();
    }

    @PublishedMethod
    public static <E extends GIParameter> ElementSelector<GIContainer, E> genParamSelector(DefRef paramName, Class<E> clazz) {
        return new GenParamSelector<>(paramName);
    }

    @PublishedMethod
    public static <E extends GIParameter> ElementManySelector<GIContainer, E> genParamManySelector(DefRef paramName, Class<E> clazz) {
        return new GenParamManySelector<>(paramName);
    }
}
