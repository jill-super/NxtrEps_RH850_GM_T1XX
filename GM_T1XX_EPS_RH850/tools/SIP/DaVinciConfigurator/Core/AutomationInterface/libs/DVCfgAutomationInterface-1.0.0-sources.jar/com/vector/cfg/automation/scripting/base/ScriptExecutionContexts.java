package com.vector.cfg.automation.scripting.base;

import java.util.Optional;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link ScriptExecutionContexts} provides methods to retrieve the current active {@link IScriptExecutionContext}.
 *
 * <p>
 * The {@link IScriptExecutionContext} is saved for each thread.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IScriptExecutionContext
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public final class ScriptExecutionContexts {

    /**
     * Returns the current active {@link IScriptExecutionContext} of this currently running thread. Or {@link Optional#empty()}, if there is no running {@link IScriptTask}.
     *
     * @return the current active {@link IScriptExecutionContext} of this thread.
     */
    @PublishedMethod
    @Nonnull
    public static Optional<IScriptExecutionContext> getCurrentContextOfThisThread() {
        return ScriptExecutionContextHolder.INSTANCE.getCurrentContextOfThisThread();
    }

    /**
     * Returns the current active {@link IScriptExecutionContext} of this currently running thread.
     *
     * @return the current context of this thread checked
     * @exception IllegalStateException
     * <ul>
     * <li>if the is no running {@link IScriptTask} in this thread.</li>
     * </ul>
     */
    @PublishedMethod
    @Nonnull
    public static IScriptExecutionContext getCurrentContextOfThisThreadChecked() {
        return ScriptExecutionContextHolder.INSTANCE.getCurrentContextOfThisThreadChecked();
    }

    private ScriptExecutionContexts() {

    }
}
