package com.vector.cfg.gen.core.genusage.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.EGenerationProcessResult;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IGenerationApi} is the entry point to the generation APIs and provide functionality for the generation process.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationApi {

    /**
     * Opens an empty settings block. This block contains settings related to generation or validation.
     *
     * @param code Content of the block
     * @return
     */
    @PublishedMethod
    IGenerationSettingsApi settings(
            @VDelegatesToWithClosureParam(IGenerationSettingsApi.class) Closure<?> code);

    /**
     * Opens a settings block which already pre configured with the project settings from the dpa file. This block contains settings related to generation or validation.
     *
     * @param code Content of the block
     * @return
     */
    @PublishedMethod
    IGenerationSettingsApi settingsFromProject(
            @VDelegatesToWithClosureParam(IGenerationSettingsApi.class) Closure<?> code);

    /**
     * Returns the recently created settings object.
     *
     * @return The recently created settings object
     */
    @PublishedMethod
    IGenerationSettingsApi getSettings();

    /**
     * Starts the generation.<br/>
     * This method takes a settings object as an argument.<br/>
     * So it is possible to reuse a settings object.
     *
     * @param settings IGenerationSettingsApi object
     * @return The result of the generation process.
     * @throws InterruptedException Thrown when a thread is waiting, sleeping, or otherwise occupied, and the thread is interrupted, either before or during the activity.
     */
    @PublishedMethod
    EGenerationProcessResult generate(IGenerationSettingsApi settings) throws InterruptedException;

    /**
     * Starts the generation.<br/>
     * The last Settings block is used for generation or if no Settings block has been defined the standard project settings from the project file are used.
     *
     * @return The result of the generation process.
     * @throws InterruptedException Thrown when a thread is waiting, sleeping, or otherwise occupied, and the thread is interrupted, either before or during the activity.
     */
    @PublishedMethod
    EGenerationProcessResult generate() throws InterruptedException;

    /**
     * Starts the validation.<br/>
     * The last Settings block is used for generation or if no Settings block has been defined the standard project settings from the project file are used.
     *
     * @param settings IGenerationSettingsApi object
     * @return The result of the generation process.
     * @throws InterruptedException Thrown when a thread is waiting, sleeping, or otherwise occupied, and the thread is interrupted, either before or during the activity.
     */
    @PublishedMethod
    EGenerationProcessResult validate(IGenerationSettingsApi settings) throws InterruptedException;

    /**
     * Starts the validation.<br/>
     * The last Settings block is used for generation or if no Settings block has been defined the standard project settings from the project file are used.
     *
     * @return The result of the generation process.
     * @throws InterruptedException Thrown when a thread is waiting, sleeping, or otherwise occupied, and the thread is interrupted, either before or during the activity.
     */
    @PublishedMethod
    EGenerationProcessResult validate() throws InterruptedException;
}
