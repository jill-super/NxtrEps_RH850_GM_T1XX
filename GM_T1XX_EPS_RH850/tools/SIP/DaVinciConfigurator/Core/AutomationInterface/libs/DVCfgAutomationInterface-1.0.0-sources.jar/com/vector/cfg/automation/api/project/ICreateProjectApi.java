package com.vector.cfg.automation.api.project;

import java.nio.file.Path;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.api.Converters;
import com.vector.cfg.business.Constraints;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link ICreateProjectApi} provides means for parameterizing the creation of a new project.
 * <div class="extdoc" id="ICreateProjectApi"><!--Label:ICreateProjectApi-->{@link ICreateProjectApi} provides means for parameterizing the creation of a new project.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectApi {

    /**
     * See {@link EEcucFileStructure#SINGLE_FILE}.
     */
    @PublishedField
    EEcucFileStructure SINGLE_FILE = EEcucFileStructure.SINGLE_FILE;

    /**
     * See {@link EEcucFileStructure#ONE_FILE_PER_MODULE}.
     */
    @PublishedField
    EEcucFileStructure ONE_FILE_PER_MODULE = EEcucFileStructure.ONE_FILE_PER_MODULE;

    /**
     * See {@link EEcucFileStructure#ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE}.
     */
    @PublishedField
    EEcucFileStructure ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE = EEcucFileStructure.ONE_FILE_IN_SEPARATE_FOLDER_PER_MODULE;

    /**
     * See {@link ESelectiveImport#ALL}.
     */
    @PublishedField
    ESelectiveImport ALL = ESelectiveImport.ALL;

    /**
     * See {@link ESelectiveImport#COMMUNICATION_ONLY}.
     */
    @PublishedField
    ESelectiveImport COMMUNICATION_ONLY = ESelectiveImport.COMMUNICATION_ONLY;

    /**
     * Alias for {@link #setProjectName(String)}.
     */
    @PublishedMethod
    void projectName(@Nonnull String projectName);

    /**
     * Using {@link #setProjectName(String)} the name for the newly created project can be specified.
     * <div class="extdoc" id="setProjectName"><!--Label:ICreateProjectApi.setProjectName-->
     * <h5>Project Name</h5> Using {@link #setProjectName(String)} the name for the newly created project can be specified. The name given here is postfixed with ".dpa" for the
     * new project's .dpa file. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_VALID_PROJECT_NAME} <!--Ref:Constraints.IS_VALID_PROJECT_NAME--></li>
     * </ul>
     * </div>
     *
     * @param projectName the name of the new project
     */
    @PublishedMethod
    void setProjectName(@Nonnull String projectName);

    /**
     * Alias for {@link #setProjectFolder(Object)}.
     */
    @PublishedMethod
    void projectFolder(@Nonnull Object projectFolder);

    /**
     * Using {@link #setProjectFolder(Object)} the folder in which to create the new project can be specified.
     * <div class="extdoc" id="setProjectFolder"><!--Label:ICreateProjectApi.setProjectFolder-->
     * <h5>Project Folder</h5> Using {@link #setProjectFolder(Object)} the folder in which to create the new project can be specified. The value given here is converted to
     * {@link Path} using the converter {@link Converters#TO_SCRIPT_PATH} <!--Ref:Converters.TO_SCRIPT_PATH-->. The following constraints apply:
     * <ul>
     * <li>{@link Constraints#IS_CREATABLE_FOLDER} <!--Ref:Constraints.IS_CREATABLE_FOLDER--></li>
     * </ul>
     * </div>
     *
     * @param projectFolder the folder in which to create the new project
     */
    @PublishedMethod
    void setProjectFolder(@Nonnull Object projectFolder);

    /**
     * Using {@link #getGeneral()} the {@link ICreateProjectGeneralApi} for specifying the new project's general settings can be retrieved like a property.
     * <div class="extdoc" id="getGeneral"><!--Label:ICreateProjectApi.getGeneral-->Using {@link #getGeneral()} the {@link ICreateProjectGeneralApi} for specifying the new
     * project's general settings can be retrieved like a property.</div>
     */
    @PublishedMethod
    ICreateProjectGeneralApi getGeneral();

    /**
     * Using {@link #general(Closure)} the {@link ICreateProjectGeneralApi} for specifying the new project's general settings can be access in a scope-like way.
     * <div class="extdoc" id="general"><!--Label:ICreateProjectApi.general-->Using {@link #general(Closure)} the {@link ICreateProjectGeneralApi} for specifying the new
     * project's general settings can be access in a scope-like way.</div>
     *
     * @param code code providing the general settings for the new project
     */
    @PublishedMethod
    void general(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectGeneralApi.class) Closure<?> code);

    /**
     * Using {@link #getTarget()} the {@link ICreateProjectTargetApi} for specifying the new project's target settings can be retrieved like a property.
     * <div class="extdoc" id="getTarget"><!--Label:ICreateProjectApi.getTarget-->Using {@link #getTarget()} the {@link ICreateProjectTargetApi} for specifying the new project's
     * target settings can be retrieved like a property.</div>
     */
    @PublishedMethod
    ICreateProjectTargetApi getTarget();

    /**
     * Using {@link #target(Closure)} the {@link ICreateProjectTargetApi} for specifying the new project's target settings can be access in a scope-like way.
     * <div class="extdoc" id="target"><!--Label:ICreateProjectApi.target-->Using {@link #target(Closure)} the {@link ICreateProjectTargetApi} for specifying the new project's
     * target settings can be access in a scope-like way.</div>
     *
     * @param code code providing the target settings for the new project
     */
    @PublishedMethod
    void target(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectTargetApi.class) Closure<?> code);

    /**
     * Using {@link #getPostBuild()} the {@link ICreateProjectPostBuildApi} for specifying the new project's post build settings can be retrieved like a property.
     * <div class="extdoc" id="getPostBuild"><!--Label:ICreateProjectApi.getPostBuild-->Using {@link #getPostBuild()} the {@link ICreateProjectPostBuildApi} for specifying the
     * new project's post build settings can be retrieved like a property.</div>
     */
    @PublishedMethod
    ICreateProjectPostBuildApi getPostBuild();

    /**
     * Using {@link #postBuild(Closure)} the {@link ICreateProjectPostBuildApi} for specifying the new project's post build settings can be access in a scope-like way.
     * <div class="extdoc" id="postBuild"><!--Label:ICreateProjectApi.postBuild-->Using {@link #postBuild(Closure)} the {@link ICreateProjectPostBuildApi} for specifying the new
     * project's post build settings can be access in a scope-like way.</div>
     *
     * @param code code providing the target settings for the new project
     */
    @PublishedMethod
    void postBuild(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectPostBuildApi.class) Closure<?> code);

    /**
     * Using {@link #getFolders()} the {@link ICreateProjectFolderApi} for specifying the new project's folders settings can be retrieved like a property.
     * <div class="extdoc" id="getFolders"><!--Label:ICreateProjectApi.getFolders-->Using {@link #getFolders()} the {@link ICreateProjectFolderApi} for specifying the new
     * project's folders settings can be retrieved like a property.</div>
     */
    @PublishedMethod
    ICreateProjectFolderApi getFolders();

    /**
     * Using {@link #folders(Closure)} the {@link ICreateProjectFolderApi} for specifying the new project's folders settings can be access in a scope-like way.
     * <div class="extdoc" id="folders"><!--Label:ICreateProjectApi.folders-->Using {@link #folders(Closure)} the {@link ICreateProjectFolderApi} for specifying the new
     * project's folders settings can be access in a scope-like way.</div>
     *
     * @param code code providing the folders settings for the new project
     */
    @PublishedMethod
    void folders(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectFolderApi.class) Closure<?> code);

    /**
     * Using {@link #getDaVinciDeveloper()} the {@link ICreateProjectDaVinciDeveloperApi} for specifying the new project's DaVinci Developer settings can be retrieved like a
     * property. <div class="extdoc" id="getDaVinciDeveloper"><!--Label:ICreateProjectApi.getDaVinciDeveloper-->Using {@link #getDaVinciDeveloper()} the
     * {@link ICreateProjectDaVinciDeveloperApi} for specifying the new project's DaVinci Developer settings can be retrieved like a property.</div>
     */
    @PublishedMethod
    ICreateProjectDaVinciDeveloperApi getDaVinciDeveloper();

    /**
     * Using {@link #daVinciDeveloper(Closure)} the {@link ICreateProjectDaVinciDeveloperApi} for specifying the new project's DaVinci Developer settings can be access in a
     * scope-like way. <div class="extdoc" id="daVinciDeveloper"><!--Label:ICreateProjectApi.daVinciDeveloper-->Using {@link #daVinciDeveloper(Closure)} the
     * {@link ICreateProjectDaVinciDeveloperApi} for specifying the new project's DaVinci Developer settings can be access in a scope-like way.</div>
     *
     * @param code code providing the DaVinci Developer settings for the new project
     */
    @PublishedMethod
    void daVinciDeveloper(@Nonnull @VDelegatesToWithClosureParam(ICreateProjectDaVinciDeveloperApi.class) Closure<?> code);

}
