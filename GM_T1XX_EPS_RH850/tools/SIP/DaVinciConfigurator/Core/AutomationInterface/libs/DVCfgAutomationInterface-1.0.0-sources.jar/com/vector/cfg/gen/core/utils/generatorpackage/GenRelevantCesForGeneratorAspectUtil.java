package com.vector.cfg.gen.core.utils.generatorpackage;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.persistency.filters.IPersistencyExportFilter;
import com.vector.cfg.util.query.ElementFilter;

/**
 * Util class for IGenRelevantCesForGeneratorAspects to wrap {@link IPersistencyExportFilter}s for the IGeneratorPackage.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenRelevantCesForGeneratorAspectUtil {
    //  private static final ILogger logger = Logger.INSTANCE.createLogger(GenRelevantCesForGeneratorAspectUtil.class);

    /**
     * Wraps an {@link IPersistencyExportFilter} into an {@link ElementFilter}, which can be used for the IGenRelevantCesForGeneratorAspect as source.
     *
     * <p>
     * <b>Attention:</b><br />
     * You have to ensure, that the passed {@link IPersistencyExportFilter} is not depended on calling other methods then
     * {@link IPersistencyExportFilter#isContained(MIObject)}
     * </p>
     *
     * <p>
     * Note: The wrapped filter hold a lock during calls to accept.
     * </p>
     *
     * @param persistencyFilter the persistency filter
     * @return the element filter for IGenRelevantCesForGeneratorAspect
     */
    @PublishedMethod
    public static ElementFilter<MIObject> wrapPersistencyExportFilter(final IPersistencyExportFilter persistencyFilter) {
        return new ElementFilter<MIObject>() {

            @Override
            public synchronized boolean accept(MIObject elementToFilter) {
                return persistencyFilter.isContained(elementToFilter);
            }
        };
    }

    private GenRelevantCesForGeneratorAspectUtil() {

    }
}
