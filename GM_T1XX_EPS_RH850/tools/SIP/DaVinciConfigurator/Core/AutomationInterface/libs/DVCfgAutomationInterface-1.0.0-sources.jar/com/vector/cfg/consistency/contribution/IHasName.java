package com.vector.cfg.consistency.contribution;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasName {
    /**
     * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="getName"> The name should be a short string like "Com-Stack PDU ID Validator". The
     * name will be used to visualize a validator e.g. in the progress bar.</div>
     */
    @PublishedMethod
    String getName();
}
