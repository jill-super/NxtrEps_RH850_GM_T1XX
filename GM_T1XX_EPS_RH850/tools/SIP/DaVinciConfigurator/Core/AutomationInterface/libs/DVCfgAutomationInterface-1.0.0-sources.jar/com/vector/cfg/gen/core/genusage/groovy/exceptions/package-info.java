/**
 * AutomationInterface scripting API for client side groovy scripts. 
 * This package contains exceptions raised by the scripting API.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.genusage.groovy.exceptions;