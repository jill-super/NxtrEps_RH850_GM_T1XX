package com.vector.cfg.consistency.contribution.helper.modeltraverser;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import java.text.MessageFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javax.annotation.Nullable;
import javax.annotation.concurrent.ThreadSafe;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IPostConstructOnActivationOk;
import com.vector.cfg.consistency.contribution.IRuleEvent;
import com.vector.cfg.consistency.contribution.IRuleFilterContribution;
import com.vector.cfg.consistency.contribution.IValidationEvents;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.contribution.IValidator;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.IRuleAlgorithm;
import com.vector.cfg.consistency.contribution.helper.rulebuilding.preconditionsupport.IRuleAlgorithmResult;
import com.vector.cfg.consistency.internal.contribution.helper.RuleFilterBuilder;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IDeletedObjectsInfo;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.exceptions.ModelDefinitionInvalidException;
import com.vector.cfg.model.exceptions.ModelDefinitionNotFoundException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IInvalidTraverserView;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.ITraverseResult;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.ITraverserView;
import com.vector.cfg.model.query.modeltraverser.IModelTraverser.IValidTraverserView;
import com.vector.cfg.util.IDebugable;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.exceptions.InterruptedRuntimeException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.format.FormattingService;

/**
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Common_Part">
 *
 * The class {@link AbstractModelTraverserValidation} provides an abstract base implementation for the usage of the {@link IModelTraverser} class in a live
 * validation rule.
 *
 * <p>
 * You can adapt the execution by overriding the following methods:
 * <ul>
 * <li><code>executeValidationForValidView(IValidTraverserView)</code>
 * <ul>
 * <li>The method is called for each {@link IValidTraverserView} of the execution process.</li>
 * </ul>
 * </li>
 * <li><code>executeValidationForInvalidView(IValidTraverserView)</code>
 * <ul>
 * <li>The method is called for each {@link IInvalidTraverserView} of the execution process.</li>
 * </ul>
 * </li>
 * <li><code>executeValidation(ITraverseResult)</code>
 * <ul>
 * <li>The method is called after the execution process of the {@link IModelTraverser}. Please only use this method, if you need both {@link ITraverserView}
 * types and the connections between these views.</li>
 * </ul>
 * </li>
 *
 * <li><code>handleNonEcuCEvents(Collection, Set)</code>
 * <ul>
 * <li>Is used to process events from the system description for example.</li>
 * </ul>
 * </li>
 *
 * <li><code>buildFilter()</code>
 * <ul>
 * <li>Is used to adapt the filters in the system description used case.</li>
 * </ul>
 * </li>
 * </ul>
 * </p>
 * <p>
 * <b>Validation rule construction: </b><br/>
 * The code sample shows the constructor code of the validation rule <code>MyValidation</code> which extends {@link AbstractModelTraverserValidation}. The
 * constructor code is the initialization phase of the {@link IModelTraverser}.
 *
 * <pre>
 * <code class="Java" id="ModelTraverserValidation constructor sample">
 * public MyValidation(IProjectContext projectContext) {
 *   super(projectContext);
 *
 * }
 *
 * protected IModelTraverser createModelTraverser(){
 *   // @formatter:off
 *   final Path path= ...;
 *   // @formatter:on
 *
 *    return ModelTraverserFactory.create(ETraverserVersion.VERSION_2, getProjectContext(), path);
 * }
 * </code>
 * </pre>
 *
 * <b>Filter:</b><br/>
 * You don't have to specify any filter, because the filter is derived from the specified Path.
 *
 * <p>
 * <b>FullValidation threshold:</b><br/>
 * The constructor of the class provides the ability to specify a threshold, which will execute the ModelTraverser as a full validation over the whole model.
 * This Threshold should be chosen by testing the fired events for each implemented validation rule. This threshold is just an advice. If the threshold is 0 no
 * threshold is applied.
 * </p>
 *
 * </div>
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Validation">
 *
 * Your client code is then called for each change of the specified <code>Path</code>, and a {@link ITraverseResult} is created before your client code is
 * called. You have two possible ways to validate something.
 *
 * The first and common case you override the <code>executeValidationForValidView (IValidTraverserView)</code>. You only validate something, when
 * the model requested by the <code>Path</code> is valid, otherwise nothing is done. We assume that a base rule or another rule will report a problem.
 *
 * The second case you override <code>executeValidation(ITraverseResult)</code>. This method is called only once for each {@link ITraverseResult}.
 * There it can process {@link IValidTraverserView IValidTraverserViews} and {@link IInvalidTraverserView IInvalidTraverserViews}.
 *
 * <p>
 * You can use the method {@link ITraverserView#getGeneralCEs()} to append the necessary general CEs to the validation result. You should always use this
 * method, because this will prevent you from the problem of missing CEs which should trigger the revalidation.
 * </p>
 *
 * <p>
 * <b>Note for GeneratorResultSink:</b><br/>
 * The validation only provides a {@link IValidationResultSink}, this is sufficient in the most cases! <b>Please use the {@link IValidationResultSink}!</b> If
 * you really need an <code>IGeneratorResultSink</code>. You can create a sink by calling <code>GeneratorResultSinkWrapper .wrap(valSink)</code>.
 * </p>
 *
 *
 * </div>
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="Preconditions">
 * <p>
 * Preconditions can be used to constrain the execution of the validation rule to an successful execution of other rules, so called preconditions. This means a
 * precondition could inhibit, that a rule is executed at all.
 *
 * There is one restriction for the usage of preconditions from ModelTraverserValidations. <b>All ModelTraverser must have the same MainElement (root).</b>
 * </p>
 * <p>
 * You can assign preconditions to a <code>ModelTraverserValidation</code> rule (see {@link IRuleTraverserAlgorithm} for more details) by calling
 * <code>registerPreconditionRuleTraverserAlgorithms(yourPre)</code> with the precondition of your choice. Additionally you have to assign the ModelTraverser of
 * the precondition as a predecessor to the ModelTraverser of your rule.
 *
 * <pre>
 * <code class="Java" id="ModelTraverserValidation creation with a predecessor ModelTraverser">
 * public MyValidation(IProjectContext projectContext, IRuleTraverserAlgorithm precondition) {
 *   //Register the precondition at the current validation rule
 *   registerPreconditionRuleTraverserAlgorithms(precondition); //You can pass many "predecessor" ModelTraversers, when you create the dependent ModelTraverser
 *
 * }
 *
 * protected IModelTraverser createModelTraverser(){
 *   // @formatter:off
 *   final Path path= ...;
 *   // @formatter:on
 *
 *   final IModelTraverserBuilder modelTraverserBuilder = ModelTraverserFactory.newBuilder(ETraverserVersion.VERSION_2, getProjectContext(), logger, path);
 *   modelTraverserBuilder.addPredecessors(getModelTraversersFromPreconditions());
 *   final IModelTraverser modelTraverserOfYourRule = modelTraverserBuilder.build();
 *
 *   //Register the modelTraverser to the current validation rule
 *   return modelTraverserOfYourRule;
 * }
 * </code>
 * </pre>
 *
 *
 * <b>Note</b>: Please use instances of the interface {@link IRuleTraverserAlgorithm} for your preconditions. See
 * {@link AbstractModelTraverserAlgorithmValidation} for a default implementation of the {@link IRuleTraverserAlgorithm} interface.
 * </p>
 * </div>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see AbstractModelTraverserAlgorithmValidation
 * @see IModelTraverser
 * @see IRuleTraverserAlgorithm
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractModelTraverserValidation implements IValidator, IDebugable, IPostConstructOnActivationOk {
    /**
     * <code>DEFAULT_THRESHOLDFORFULLVALIDATION</code> describes the amount of events to trigger a FullValidation.
     */
    private static final int DEFAULT_THRESHOLDFORFULLVALIDATION = 250;

    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractModelTraverserValidation.class);

    private final IProjectContext projectContext;

    private final ThreadLocal<IValidationResultSink> resultSinkPrivate = new ThreadLocal<>();

    private final ThreadLocal<IValidationEvents> validationEventsPrivate = new ThreadLocal<>();

    private final long eventThresholdForFullValidation;

    private final IModelAccess ma;

    /*
     * Fields set after initialization
     */

    private volatile IRuleFilterContribution filter;

    private volatile IModelTraverser traverser;

    private volatile List<? extends IRuleAlgorithm<? extends MIHasDefinition>> preconditions;

    /**
     * This caches the thrown exception, when the initialization has failed. If the Initialization was successful this field is <code>null</code>.
     */
    @Nullable
    private volatile Throwable notCorrectlyInitializedException;

    /**
     * Instantiates a new abstract model traverser validation.
     *
     * <p>
     * Please use the {@link #AbstractModelTraverserValidation(IProjectContext, long)} constructor, if you can specify an event threshold!
     * </p>
     *
     * @param projectContext the project context
     */
    @PublishedMethod
    protected AbstractModelTraverserValidation(IProjectContext projectContext) {
        this(projectContext, DEFAULT_THRESHOLDFORFULLVALIDATION);

    }

    /**
     * Instantiates a new abstract model traverser validation.
     *
     * <p>
     * The FullValidation feature means, if the Event collection size is bigger then the passed eventThreshold, the internal logic will gather all MainElements by
     * {@link IModelAccess} instead of evaluation the {@link IRuleEvent}s.
     * </p>
     * <p>
     * If the threshold is 0 no threshold is applied, so no FullValidation is executed. <br />
     * Examples:
     * <ul>
     * <li>If you pass 0, then no FullValidation will be started at all</li>
     * <li>If you pass 1 the ModelTraverser will always execute a FullValidation.</li>
     * <li>If you pass >1 the event could will either trigger a FullValidation or a search from StartElements to MainElemets by the event collection.</li>
     * </ul>
     *
     * </p>
     *
     * @param projectContext the project context
     * @param eventThresholdForFullValidation
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the eventThresholdForFullValidation is negative</li>
     * </ul>
     * @exception NullPointerException
     * <ul>
     * <li>if the projectContext is null</li>
     * </ul>
     */
    @PublishedMethod
    protected AbstractModelTraverserValidation(IProjectContext projectContext, long eventThresholdForFullValidation) {
        this.projectContext = checkNotNull(projectContext);
        checkArgument(eventThresholdForFullValidation >= 0);
        this.eventThresholdForFullValidation = eventThresholdForFullValidation;

        ma = projectContext.getService(IModelAccess.class);
    }

    /**
     * Registers a model traverser for this validation rule. Only one {@link IModelTraverser} is allowed.
     * <p>
     * This method is called from the base class and should not be called by the subclass itself!
     * </p>
     *
     * @return the created traverser
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the returned traverser is null</li>
     * </ul>
     *
     */
    @PublishedMethod
    protected abstract IModelTraverser createModelTraverser();

    /**
     * Returns the assigned ModelTraverser.
     *
     *
     * @return the model traverser
     *
     *
     * @exception ModelDefinitionNotFoundException
     * <ul>
     * <li>if some of the Definitions are not present.</li>
     * </ul>
     *
     * @exception ModelDefinitionInvalidException
     * <ul>
     * <li>if some of the Definitions are invalid.</li>
     * </ul>
     *
     * @exception Throwable
     * <ul>
     * <li>if the initialization sequence has thrown an exception during initialization.</li>
     * </ul>
     *
     */
    @PublishedMethod
    protected IModelTraverser getModelTraverser() {
        synchronized (this) {
            if (!isModelTraverserCorrectlyInitialized()) {

                initializeModelTraverserInternal();
            }
            return checkNotNull(traverser, "The ModelTraverser was not registered yet. You could call this method only after initialization!");

        }
    }

    private boolean isModelTraverserCorrectlyInitialized() {
        synchronized (this) {
            if (this.traverser != null && notCorrectlyInitializedException == null) {
                return true;
            }
            return false;
        }
    }

    /**
     * Register model traverser internal.
     *
     * <p>
     * Attention: This method will throw several exception, if the initialization was not successful. Every subsequent call to this method will throw the same exception as at
     * the first time.
     * </p>
     */
    private void initializeModelTraverserInternal() {

        synchronized (this) {
            try {
                if (notCorrectlyInitializedException != null) {
                    /*
                     * The initialization has already failed=> So rethrow the initProblem
                     *
                     * Don't wrap this exception into another one, because the caller might have particular catch blocks.
                     *
                     */
                    if (notCorrectlyInitializedException instanceof RuntimeException) {
                        throw (RuntimeException) notCorrectlyInitializedException;
                    } else if (notCorrectlyInitializedException instanceof Error) {
                        throw (Error) notCorrectlyInitializedException;
                    } else {
                        // As the code doesn't throw checked exceptions, execution should not come here. But if things change, we should not swallow anything
                        throw new IllegalStateException("Previous intialization of the ModelTraverser already failed with unexpected exception.", notCorrectlyInitializedException);
                    }
                }

                if (this.traverser != null) {
                    /*
                     * Already initialized, so return without further initializations.
                     */
                    return;
                }

                IModelTraverser traverserLoc = null;
                try {

                    // This method call will throw an exception, if the precondition ModelTraverser is invalid.
                    checkExistingPreconditionTraversersBeforeInit();

                    traverserLoc = createModelTraverser();

                    checkState(traverserLoc != null, "You have to return a valid ModelTraverser from the method createModelTraverser() before you can use the ValidationRule ( "
                            + getClass().getName() + ")");
                    /*
                     * Initialization of the Traverser ok.
                     */

                } catch (final ModelDefinitionNotFoundException ex) {
                    final String msg = "Rule " + getName() + ": Some of the Definitions are not present. The ValidationRule " + getClass().getSimpleName() + " is ignored!";
                    // Some of the Definitions are not present =>
                    logger.debug(msg, ex);
                    Logger.INSTANCE.createLogger(getClass()).debug(msg, ex);

                    notCorrectlyInitializedException = ex;
                    throw ex;

                } catch (final ModelDefinitionInvalidException ex) {
                    final String msg = "Rule " + getName() + ": Some of the Definitions are invalid. The ValidationRule " + getClass().getSimpleName() + " is ignored!";
                    // Some of the Definitions are not valid =>
                    logger.debug(msg, ex);
                    Logger.INSTANCE.createLogger(getClass()).error(msg, ex);

                    notCorrectlyInitializedException = ex;
                    throw ex;
                } catch (final Throwable ex) {
                    InterruptedRuntimeException.throwExceptionIfRootCauseWasInterruptedException(ex);
                    final String msg = "Rule " + getName() + " has thrown an exception during initialization. The ValidationRule " + getClass().getSimpleName() + " is ignored!";
                    logger.debug(msg, ex);
                    Logger.INSTANCE.createLogger(getClass()).error(msg, ex);

                    notCorrectlyInitializedException = ex;
                    throw ex;
                }

                /*
                 * The operation, shall set the new created ModelTraverser into the field. This has to be a coordinated instruction, so that accesses to the
                 * volatile field is safely published after a possible notCorrectliyInit exception field write access.
                 */
                this.traverser = traverserLoc;

                try {

                    /*
                     * Build Filter in error case and in the successful case! The BuildFilter method has to handle the error case!
                     */

                    this.filter = buildFilter();

                } catch (final Throwable ex) {
                    final String msg = "Rule " + getName() + " has thrown an unhandled exception during buildFilter(). The ValidationRule " + getClass().getSimpleName()
                            + " is ignored!";
                    logger.debug(msg, ex);
                    Logger.INSTANCE.createLogger(getClass()).error(msg, ex);

                    this.traverser = null; // We have to reset the created traverser instance.
                    notCorrectlyInitializedException = ex;
                    throw ex;
                }

            } finally {
                if (this.filter == null) {
                    this.filter = buildNotCorrectlyInitializedFilter();
                }
            }
        }
    }

    /**
     * Builds the {@link IRuleFilterContribution}, if the initialization has failed.
     *
     * @return the i rule filter contribution
     */
    private IRuleFilterContribution buildNotCorrectlyInitializedFilter() {
        synchronized (this) {
            checkState(notCorrectlyInitializedException != null);

            final RuleFilterBuilder builder = new RuleFilterBuilder();
            builder.add(DefRef.INVALID_DEFREF);
            return builder.build();
        }
    }

    /**
     * Check existing precondition traversers before init.
     *
     * <p>
     * This will throw an exception, if a precondition ModelTraverser could not be correctly initialized.
     * </p>
     */
    private void checkExistingPreconditionTraversersBeforeInit() {
        getModelTraversersFromPreconditions();
    }

    /**
     * Register precondition rule traverser algorithms for this validation.
     *
     * <p>
     * Note: Please use instances of {@link IRuleTraverserAlgorithm} because this will enable some optimizations for the {@link IModelTraverser} execution. You should used the
     * {@link IRuleTraverserAlgorithm} interface if possible. See class {@link AbstractModelTraverserAlgorithmValidation} for a default implementation.
     * </p>
     *
     * @param <T> the generic type
     * @param preconditions the preconditions
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the preconditions is null</li>
     * </ul>
     * @exception IllegalStateException
     * <ul>
     * <li>if the validation rule was already initialized.</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if {@link #registerPreconditionRuleTraverserAlgorithms(List)} was already called</li>
     * </ul>
     */
    @PublishedMethod
    protected final <T extends IRuleAlgorithm<? extends MIHasDefinition>> void registerPreconditionRuleTraverserAlgorithms(List<T> preconditionsParam) {
        checkNotNull(preconditionsParam);

        synchronized (this) {
            checkArgument(this.preconditions == null, "Another preconditionList was already registered.");
            checkState(
                    this.traverser == null,
                    "The ModelTraverser was already registered. You have to call registerPreconditionRuleTraverserAlgorithms() before the consistency initializes your validation rule. Normally in your constructor.");

            this.preconditions = preconditionsParam;
        }

    }

    /**
     * Getter method for preconditions.
     *
     * @return Returns the preconditions.
     */
    @PublishedMethod
    protected final List<IModelTraverser> getModelTraversersFromPreconditions() {
        synchronized (this) {
            final List<IModelTraverser> algorithms = getTraversersFromAlgorithms(preconditions);
            return algorithms;
        }
    }

    /**
     * Gets all {@link IModelTraverser}s from the passed List of {@link IRuleTraverserAlgorithm}s.
     *
     * @param preconditionsLoc the {@link IRuleTraverserAlgorithm} instances, which have {@link IModelTraverser}s.
     * @return the List of {@link IModelTraverser}s
     */
    private List<IModelTraverser> getTraversersFromAlgorithms(List<? extends IRuleAlgorithm<?>> preconditionsLoc) {
        final List<IModelTraverser> preConditionTraverserList = Lists.newArrayList();
        if (preconditionsLoc != null) {
            for (final IRuleAlgorithm<?> rulePre : preconditionsLoc) {
                if (rulePre instanceof IRuleTraverserAlgorithm) {
                    final IRuleTraverserAlgorithm traverserRulePre = (IRuleTraverserAlgorithm) rulePre;
                    preConditionTraverserList.add(traverserRulePre.getModelTraverser());
                }
            }
        }
        return preConditionTraverserList;
    }

    /**
     * Getter method for projectContext.
     *
     * @return Returns the projectContext.
     */
    @PublishedMethod
    protected final IProjectContext getProjectContext() {
        return projectContext;
    }

    /**
     * {@inheritDoc}
     *
     */
    @PublishedMethod
    @Override
    public final IRuleFilterContribution getFilter() {
        if (filter == null) {
            /*
             * The Validation was not yet initialized, so init the validation now!
             */
            initModelTraverserFromConsistency();
        }
        checkState(filter != null, "The ModelTraverser was not registered yet. You could call this method only after initialization!");
        return filter;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void onActivationOk() {
        initModelTraverserFromConsistency();
    }

    private void initModelTraverserFromConsistency() {
        synchronized (this) {
            try {
                initializeModelTraverserInternal();
            } catch (final ModelDefinitionNotFoundException ex) {
                /*
                 * We shall ignore ModelDefinitionNotFoundException, because the Rule should be silently disabled in the Missing Definition case. The exception
                 * as already logged in the initializeModelTraverserInternal() method.
                 */
                logger.trace("Swallowing ModelDefinitionNotFoundException", ex);
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public final void onModelEvent(IValidationResultSink results, IValidationEvents validationEvents) {

        if (!isModelTraverserCorrectlyInitialized()) {
            return;
        }
        this.resultSinkPrivate.set(results);
        setCachedValidationEvents(validationEvents);
        try {

            processEventsForModelTraverser(validationEvents);

        } finally {
            this.resultSinkPrivate.remove();
            removeCachedValidationEvents();
        }

    }

    void setCachedValidationEvents(IValidationEvents validationEvents) {
        checkNotNull(validationEvents);
        this.validationEventsPrivate.set(validationEvents);

    }

    void removeCachedValidationEvents() {
        this.validationEventsPrivate.remove();
    }

    /**
     * Process events for model traverser.
     *
     * @param events the events
     */
    private void processEventsForModelTraverser(IValidationEvents validationEvents) {
        final Collection<MIHasDefinition> startElemSet = getStartElementsDependingOnEventSet(validationEvents);

        final ITraverseResult traverseResult = getModelTraverser().startTraverse(startElemSet);

        executeValidation(traverseResult);
    }

    /**
     * Gets the start elements depending on event set.
     *
     * @param events the events
     * @return the start elements depending on event set
     */
    private Collection<MIHasDefinition> getStartElementsDependingOnEventSet(IValidationEvents validationEvents) {
        final Collection<MIHasDefinition> startElemSet;
        if (validationEvents.getEvents().size() > eventThresholdForFullValidation && eventThresholdForFullValidation != 0) {
            startElemSet = getFullValidationStartElementsForModelTraverser();
        } else {
            startElemSet = getStartElementsForModelTraverser(validationEvents);
        }
        return startElemSet;
    }

    /**
     * Gets the start elements for model traverser.
     *
     * @param events the events
     * @return the start elements for model traverser
     */
    final Set<MIHasDefinition> getStartElementsForModelTraverser(IValidationEvents validationEvents) {
        final Set<MIHasDefinition> elemSet = Sets.newHashSet();
        for (final IRuleEvent event : validationEvents.getEvents()) {
            final MIObject source = event.getSource();
            if (source instanceof MIHasDefinition) {
                elemSet.add((MIHasDefinition) source);

            } else {
                /*
                 * Process Deleted Infos
                 */

                final IDeletedObjectsInfo sourceInfo = event.getSourceInfo();
                if (sourceInfo != null) {
                    final MIObject mdfObject = sourceInfo.getMDFObject();
                    if (mdfObject instanceof MIHasDefinition) {
                        elemSet.add((MIHasDefinition) mdfObject);
                    }
                }
            }
        }

        getStartElementsFromPreconditions(validationEvents, elemSet);

        /*
         * Call to subclass to determine, if the validation shall proceed. Additionally the client could insert new startElements. E.g. from the
         * SystemDescription
         */final Set<MIHasDefinition> startElemsFromClient = getEcuCStartElementsFromNonEcuCElements(validationEvents);
        if (startElemsFromClient != null && !startElemsFromClient.isEmpty()) {
            elemSet.addAll(startElemsFromClient);
        }

        return elemSet;
    }

    private void getStartElementsFromPreconditions(IValidationEvents validationEvents, Set<MIHasDefinition> elemSet) {
        if (preconditions == null || preconditions.isEmpty()) {
            return;
        }

        for (final IRuleAlgorithm<? extends MIHasDefinition> pre : preconditions) {
            if (pre instanceof IRuleTraverserAlgorithm) {
                /*
                 * The precondition is another ModelTraverser, so optimize the call by calling the special getEcuCStartElementsFromNonEcuCElements method!
                 */
                final Set<MIHasDefinition> startElements = ((IRuleTraverserAlgorithm) pre).getEcuCStartElementsFromNonEcuCElements(validationEvents);
                elemSet.addAll(startElements);
            } else {
                /*
                 * Any other precondition passed.
                 */
                final Collection<? extends MIHasDefinition> affectedContexts = pre.getAffectedContexts(validationEvents);
                elemSet.addAll(affectedContexts);
            }
        }
    }

    /**
     * Returns the list of all MainElement instances in the system.
     *
     * <p>
     * This method is package private so that subclasses in the same package could override this method. Subclasses have to call the super method! See DAVID00130711 for details.
     * </p>
     *
     * @param events the events
     * @return List of MainElements
     */
    Collection<MIHasDefinition> getFullValidationStartElementsForModelTraverser() {

        final IModelTraverser travLoc = getModelTraverser();
        final List<MIHasDefinition> allMain = ma.getAllWithDefinition(travLoc.getMainElementDefRef());
        return allMain;
    }

    /**
     * Gets the result sink.
     *
     * @return the result sink
     */
    @PublishedMethod
    protected final IValidationResultSink getResultSink() {
        final IValidationResultSink resultSink = resultSinkPrivate.get();
        checkNotNull(
                resultSink,
                "The IValidationResultSink is currently not available. Are you sure, that this validation rule is running (onModelEvent() in the stack)? You can not get a ResultSink, if this validation rule is not direclty called from the Consistency!");
        return resultSink;
    }

    /**
     * Gets the validation events.
     *
     * @return the validation events
     */
    @PublishedMethod
    protected final IValidationEvents getValidationEvents() {
        final IValidationEvents validationEvents = validationEventsPrivate.get();
        checkNotNull(
                validationEvents,
                "The IValidationEvents are currently not available. Are you sure, that this validation rule is running (onModelEvent() in the stack)? You can not get the IValidationEvents, if this validation rule is not direclty called from the Consistency!");
        return validationEvents;
    }

    /**
     * Checks if all preconditions associated with the {@link ITraverserView} of this {@link IModelTraverser}( {@link ITraverseResult#getSourceTraverser()}) are valid.
     *
     * <p>
     * Returns true, if all preconditions of the {@link ITraverserView} are satisfied, otherwise false.
     * </p>
     *
     * @param traverserView the traverser view of the Precondition.
     * @return true, if precondition is satisfied.
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    protected final boolean checkPreconditionRuleAlgorithmExecution(ITraverserView traverserView) {
        if (preconditions != null) {
            for (final IRuleAlgorithm<? extends MIHasDefinition> pre : preconditions) {

                final IRuleAlgorithmResult execResult;
                if (pre instanceof IRuleTraverserAlgorithm) {
                    final IRuleTraverserAlgorithm traversePreAlg = (IRuleTraverserAlgorithm) pre;
                    final IModelTraverser preModelTraverser = traversePreAlg.getModelTraverser();
                    final ITraverseResult preResult = traverserView.getPredecessorResult(preModelTraverser);

                    execResult = traversePreAlg.performByTraverser(preResult, this.getValidationEvents());
                } else {
                    final IRuleAlgorithm<MIHasDefinition> preCap = (IRuleAlgorithm<MIHasDefinition>) pre;
                    execResult = preCap.perform(traverserView.getMainElement(), this.getValidationEvents());
                }

                if (!execResult.isConditionFulfilled()) {
                    return false;

                }
            }
        }
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        String initMsg = "";
        if (!isModelTraverserCorrectlyInitialized()) {
            initMsg = "ValidationRule is not correctly initialized. The ModelTraverser has reported an initialization problem! ";
            if (notCorrectlyInitializedException != null) {
                initMsg += notCorrectlyInitializedException.getMessage();
            }
        }
        return MessageFormat.format("ModelTraverserValidation (Name={0}, Class={1} {2})", getName(), getClass().getName(), initMsg);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public String toDebugString() {
        return toString() + "\r\nAssigned Traverser: " + FormattingService.INSTANCE.formatObject(traverser);

    }

    /*
     * ------------------------------------------------------------------------------------------- Methods to override!
     * -------------------------------------------------------------------------------------------
     */

    /**
     * Handle NonEcuc Events.
     *
     * <p>
     * You can override this method to process non EcuC Elements.
     * </p>
     * <p>
     * This implementation will always return an empty collection, because the "start/parent" validation has already inserted all EcuC elements from the events collection.
     * </p>
     * <p>
     * CodeSample:
     *
     * <pre>
     * <code>Set&lt;MIHasDefinition&gt; set= Sets.newHashSet();
     *         handleNonEcuCEvents(events, set);
     *         return set;
     * </code>
     * </pre>
     *
     * </p>
     *
     * @param validationEvents the Consistency events to process for ModelTraverser StartElements.
     * @return the found StartElements
     */
    @PublishedMethod
    protected Set<MIHasDefinition> getEcuCStartElementsFromNonEcuCElements(IValidationEvents validationEvents) {
        /*
         * Empty collection is valid, because the "start" validation has already inserted all EcuC elements from the events collection
         */
        return Collections.emptySet();
    }

    /**
     * Execute validation.
     * <p>
     * You can override this method, if you want to analyze valid and invalid {@link ITraverserView}s and their connections!
     *
     * If you are only interested in valid Views, please use {@link #executeValidationForValidView(IValidTraverserView)}.
     *
     * If you are only interested in invalid Views, please use {@link #executeValidationForInvalidView(IInvalidTraverserView)}.
     * </p>
     *
     * <p>
     * Attention: If you override this method, you have to check the precondition with {@link #checkPreconditionRuleAlgorithmExecution(ITraverserView)} by yourself!
     * </p>
     *
     * @param result the traverse result, started at the passed events
     */
    @PublishedMethod
    protected void executeValidation(ITraverseResult result) {
        /*
         * Override this, if you need invalid views, valid views and their connections !
         */
        for (final IValidTraverserView view : result.getValidTraverserViews()) {

            if (!checkPreconditionRuleAlgorithmExecution(view)) {
                continue;
            }

            executeValidationForValidView(view);
        }

        for (final IInvalidTraverserView view : result.getInvalidTraverserViews()) {

            if (!checkPreconditionRuleAlgorithmExecution(view)) {
                continue;
            }

            executeValidationForInvalidView(view);
        }
    }

    /**
     * Execute validation for each valid view.
     * <p>
     * You can override this method, if the want to validate only {@link IValidTraverserView}s. Otherwise use {@link #executeValidation(ITraverseResult, Collection)}.
     * </p>
     *
     * <p>
     * Attention: This method is not called, if any Precondition of this validation (see {@link #registerPreconditionRuleTraverserAlgorithms(List)}) is not satisfied.
     * </p>
     *
     * @param validView the {@link IValidTraverserView} of the TraverseResult
     */
    @PublishedMethod
    protected void executeValidationForValidView(IValidTraverserView validView) {

    }

    /**
     * Execute validation for each invalid view.
     * <p>
     * You can override this method, if the want to validate only {@link IInvalidTraverserView}s. Otherwise use {@link #executeValidation(ITraverseResult, Collection)}.
     * </p>
     *
     * <p>
     * Attention: This method is not called, if any Precondition of this validation (see {@link #registerPreconditionRuleTraverserAlgorithms(List)}) is not satisfied.
     * </p>
     *
     * @param invalidView the {@link IValidTraverserView} of the TraverseResult
     * @param ruleEvents the events of the Consistency
     */
    @PublishedMethod
    protected void executeValidationForInvalidView(IInvalidTraverserView invalidView) {

    }

    /**
     * Builds the filter for the {@link IValidator} rule.
     *
     * <p>
     * You can override this method, if you need to change the filters for the validation rule.
     * </p>
     *
     * @return the created {@link IRuleFilterContribution}
     */
    @PublishedMethod
    protected IRuleFilterContribution buildFilter() {
        synchronized (this) {

            if (notCorrectlyInitializedException != null) {
                return buildNotCorrectlyInitializedFilter();
            }

            final RuleFilterBuilder builder = new RuleFilterBuilder();
            builder.addAllDefRefs(this.traverser.getAllDefRefs());

            if (preconditions != null) {
                for (final IRuleAlgorithm<?> preAlgo : preconditions) {
                    builder.add(preAlgo.getFilter());
                }
            }

            return builder.build();
        }
    }
}
