package com.vector.cfg.gen.core.utils.templateutils;

import java.util.Collections;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIModuleConfiguration;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.fileoutput.IJetTemplate;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.generatorpackage.GeneratorPackageUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * A generator specific utility class for {@link IJetTemplate}s.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class TemplateUtil {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(TemplateUtil.class);

    /*
     * Public section
     */
    @PublishedField
    @Deprecated
    /** Please use GenConstans.LINE_SEPARATOR */
    public static final String LINE_SPERATOR = GenConstants.LINE_SEPARATOR;

    /**
     * Generates a C-File Header for a template.
     *
     * @param generatorPackage
     * @param fileName Filename for the generated header
     * @return The header in String representation.
     */
    @PublishedMethod
    public static String generateFileHeader(final IGeneratorPackage generatorPackage, final String fileName) {
        return generateFileHeader(generatorPackage, fileName, Collections.<String> emptyList());
    }

    /**
     * Generates a C-File Header for a template.
     *
     * @param generatorPackage
     * @param fileName Filename for the generated header
     * @return The header in String representation.
     */
    @KeepSecretFromPublishedApi
    public static String generateFileHeader(final IGeneratorPackage generatorPackage, final String fileName, final List<String> descriptions) {
        return generatorPackage.getProjectContext().getInstance(IFileHeaderImplementation.class).generateFileHeader(generatorPackage, fileName, descriptions);

    }

    /**
     * Convert camel case to uppercase with under score.
     *
     * <p>
     * Leading moduleShortName of the element is preserved. E.g. NvMTestParam is converted to NVM_TEST_PARAM
     *
     * moduleShortName == null is allowed.
     * </p>
     *
     * @param text The element text in CamelCase.
     * @param moduleShortName the module short name
     * @return the string
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if shortName is null</li>
     * </ul>
     */
    @PublishedMethod
    public static String convertCamelCaseToUppercaseWithUnderScore(String text, final String moduleShortName) {
        if (text == null) {
            throw new IllegalArgumentException("s is null");
        }

        final StringBuilder constantNameBuilder = new StringBuilder();

        if (moduleShortName != null) {

            if (text.startsWith(moduleShortName)) {
                text = text.substring(moduleShortName.length(), text.length());

                if (!moduleShortName.isEmpty()) {
                    constantNameBuilder.append(moduleShortName.toUpperCase());
                    constantNameBuilder.append("_");
                }
            }
        }

        boolean isFirst = true;
        boolean lastCharWasUpper = false;
        for (final char shortNameChar : text.toCharArray()) {
            if (Character.isUpperCase(shortNameChar) && !isFirst && shortNameChar != '_' && !lastCharWasUpper) {
                constantNameBuilder.append("_");

            }
            constantNameBuilder.append(Character.toUpperCase(shortNameChar));
            isFirst = false;

            if (Character.isUpperCase(shortNameChar) || shortNameChar == '_') {
                lastCharWasUpper = true;
            } else {
                lastCharWasUpper = false;
            }

        }

        return constantNameBuilder.toString();
    }

    /**
     * Return following name: <Module short name>_<Vendor Id>_<Vendor specific Name>. See requirement BSW00347.<br/>
     * E.g. Eep_21_LDExt<br/>
     * If instances shall be accessed an index has to be appended manually. See requirement BSW00413.
     *
     * If no BSW Implementation Node, no VendorApiInfix or no VendorId are present, just the short name of the module definition is returned.<br/>
     * E.g. Eep<br/>
     *
     * CDD:<br/>
     * In case of CDD module the short name of the module configuration is returned or if apiServicePrefix is available, this value is used instead. <br/>
     * In case of CDD no VendorApiInfix or Vendor Id is applied. <br/>
     *
     * VTT:<br/>
     * If a VTT module is passed, the corresponding real module is used instead. <br/>
     * If no Real module could be found, the VTT module is used as default.<br/>
     * Only active module configuration are taken into account for the real module lookup. <br/>
     *
     * @throws IllegalArgumentException
     * @param GIModuleConfiguration. Needed to get information about the module and to access the project context.
     * @return String
     */
    @PublishedMethod
    public static String getModuleNameWithAPIInfix(final GIModuleConfiguration bswmdModelModuleConf) {
        if (bswmdModelModuleConf == null) {
            throw new IllegalArgumentException("Module Configuration must not be null.");
        }
        if (bswmdModelModuleConf.getMdfObject() == null) {
            throw new IllegalArgumentException("Module Configuration must not be null.");
        }
        return getModuleNameWithAPIInfix(bswmdModelModuleConf.getMdfObject());
    }

    /**
     * This method is identical to com.vector.cfg.gen.core.utils.generatorpackage.GeneratorPackageUtil.getMsn(MIModuleConfiguration). <br/>
     * Please use this instead. <br>
     * Returns the MSN with VendorApiInfix and Vendor Id for a the passed module configuration. <br/>
     *
     * Return following name: <Module short name>_<Vendor Id>_<Vendor specific Name>. See requirement BSW00347.<br/>
     * E.g. Eep_21_LDExt<br/>
     * If instances shall be accessed an index has to be appended manually. See requirement BSW00413.
     *
     * If no BSW Implementation Node, no VendorApiInfix or no VendorId are present, just the short name of the module definition is returned.<br/>
     * E.g. Eep<br/>
     *
     * CDD:<br/>
     * In case of CDD module the short name of the module configuration is returned or if apiServicePrefix is available, this value is used instead. <br/>
     * In case of CDD no VendorApiInfix or Vendor Id is applied. <br/>
     *
     * VTT:<br/>
     * If a VTT module is passed, the corresponding real module is used instead. <br/>
     * If no Real module could be found, the VTT module is used as default.<br/>
     * Only active module configuration are taken into account for the real module lookup. <br/>
     *
     * @param moduleConfig Module configuration
     * @return Module short name (MSN)
     */
    @PublishedMethod
    public static String getModuleNameWithAPIInfix(final MIModuleConfiguration moduleConf) {
        return GeneratorPackageUtil.getMsnWithVendorApiInfixAndIdReal(moduleConf);
    }

    private TemplateUtil() {

    }
}
