/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function cosf
//
// #pragma POLYSPACE_PURE "cosf"
// #pragma POLYSPACE_CLEAN "cosf"
// #pragma POLYSPACE_WORST "cosf"
//
// __PST__FLOAT32 cosf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function sinf
//
// #pragma POLYSPACE_PURE "sinf"
// #pragma POLYSPACE_CLEAN "sinf"
// #pragma POLYSPACE_WORST "sinf"
//
// __PST__FLOAT32 sinf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function log10f
//
// #pragma POLYSPACE_PURE "log10f"
// #pragma POLYSPACE_CLEAN "log10f"
// #pragma POLYSPACE_WORST "log10f"
//
// __PST__FLOAT32 log10f(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_HwAg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_HwAg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_HwAg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_HwAg_Val"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_HwAg_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_HwAgAuthy_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_HwAgAuthy_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_HwAgAuthy_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_HwAgAuthy_Val"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_HwAgAuthy_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_HwTq_Val"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_HwTq_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_HwVel_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_HwVel_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_HwVel_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_HwVel_Val"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_HwVel_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_MotTqCmdCrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_MotTqCmdCrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_MotTqCmdCrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_MotTqCmdCrf_Val"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_MotTqCmdCrf_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_VehSpd_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_VehSpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_VehSpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_VehSpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_VehSpdVld_Logl"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_VehSpdVld_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_VehYawRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_VehYawRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_VehYawRate_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_VehYawRate_Val"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_VehYawRate_Val(__PST__g__16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SnsrOffsLrng_VehYawRateVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_SnsrOffsLrng_VehYawRateVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_SnsrOffsLrng_VehYawRateVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_SnsrOffsLrng_VehYawRateVld_Logl"
//
// __PST__UINT8 Rte_Read_SnsrOffsLrng_VehYawRateVld_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_SnsrOffsLrng_HwAgOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_SnsrOffsLrng_HwAgOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_SnsrOffsLrng_HwAgOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Write_SnsrOffsLrng_HwAgOffs_Val"
//
// __PST__UINT8 Rte_Write_SnsrOffsLrng_HwAgOffs_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_SnsrOffsLrng_HwTqOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_SnsrOffsLrng_HwTqOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_SnsrOffsLrng_HwTqOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Write_SnsrOffsLrng_HwTqOffs_Val"
//
// __PST__UINT8 Rte_Write_SnsrOffsLrng_HwTqOffs_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_SnsrOffsLrng_VehYawRateOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_SnsrOffsLrng_VehYawRateOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_SnsrOffsLrng_VehYawRateOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Write_SnsrOffsLrng_VehYawRateOffs_Val"
//
// __PST__UINT8 Rte_Write_SnsrOffsLrng_VehYawRateOffs_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_SnsrOffsLrng_GetRefTmr100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_SnsrOffsLrng_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_SnsrOffsLrng_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_SnsrOffsLrng_GetRefTmr100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_SnsrOffsLrng_GetRefTmr100MicroSec32bit_Oper(__PST__g__32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_SnsrOffsLrng_GetTiSpan100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_SnsrOffsLrng_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_SnsrOffsLrng_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_SnsrOffsLrng_GetTiSpan100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_SnsrOffsLrng_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__32 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_GetErrorStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_GetErrorStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_GetErrorStatus"
// #pragma POLYSPACE_WORST "Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_GetErrorStatus"
//
// __PST__UINT8 Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_GetErrorStatus(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngDrvgDstThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngDrvgDstThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngDrvgDstThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngDrvgDstThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngDrvgDstThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngHwVelThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngHwVelThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngHwVelThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngHwVelThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngHwVelThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdMed_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdMed_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdMed_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdMed_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdMed_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdTrustd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdTrustd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdTrustd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdTrustd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdTrustd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdWide_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdWide_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdWide_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdWide_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdWide_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngTi_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngVehSpdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngVehSpdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngVehSpdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngVehSpdThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngVehSpdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawOffsDbnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawOffsDbnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawOffsDbnd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawOffsDbnd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawOffsDbnd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawRateThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawRateThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawRateThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawRateThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawRateThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgOffsLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgOffsLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgOffsLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgOffsLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgOffsLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEnaTiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEnaTiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEnaTiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEnaTiThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEnaTiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgDbnd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgDbnd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgDbnd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgDbnd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgDbnd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqZeroOffsThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqZeroOffsThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqZeroOffsThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqZeroOffsThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqZeroOffsThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwVelThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwVelThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwVelThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwVelThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwVelThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTi_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTiScar_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTiScar_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTiScar_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTiScar_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTiScar_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd1_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd2_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd2_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd2_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd2_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd2_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngTiWghtCoeff_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngTiWghtCoeff_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngTiWghtCoeff_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngTiWghtCoeff_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngTiWghtCoeff_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngVehSpdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngVehSpdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngVehSpdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngVehSpdThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngVehSpdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqOffsLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqOffsLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqOffsLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqOffsLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqOffsLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwVelFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwVelFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwVelFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwVelFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwVelFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqAndAgFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqAndAgFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqAndAgFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqAndAgFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqAndAgFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnHwTqFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnHwTqFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnHwTqFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnHwTqFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnHwTqFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnPwrEstimnThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnPwrEstimnThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnPwrEstimnThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnPwrEstimnThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnPwrEstimnThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrAmp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrAmp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrAmp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrAmp_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrAmp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1FilGain_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1FilGain_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1FilGain_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1FilGain_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1FilGain_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainCen_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainCen_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainCen_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainCen_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainCen_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainDwn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainDwn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainDwn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainDwn_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainDwn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainUp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainUp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainUp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainUp_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainUp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawACdngFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawACdngFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawACdngFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawACdngFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawACdngFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngHwAgThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngHwAgThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngHwAgThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngHwAgThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngHwAgThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngTi_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngYawAThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngYawAThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngYawAThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngYawAThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngYawAThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawOffsFrshTiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawOffsFrshTiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawOffsFrshTiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawOffsFrshTiThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawOffsFrshTiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateCdngFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateCdngFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateCdngFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateCdngFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateCdngFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateOffsLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateOffsLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateOffsLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateOffsLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateOffsLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SysGlbPrmSysTqRat_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SysGlbPrmSysTqRat_Val"
//
// __PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SysGlbPrmSysTqRat_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd1_Val"
//
// __PST__UINT16 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd2_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd2_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd2_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd2_Val"
//
// __PST__UINT16 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd2_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngSampleCntForHwTqLrngRst_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngSampleCntForHwTqLrngRst_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngSampleCntForHwTqLrngRst_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngSampleCntForHwTqLrngRst_Val"
//
// __PST__UINT16 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngSampleCntForHwTqLrngRst_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2WinSize_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2WinSize_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2WinSize_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2WinSize_Val"
//
// __PST__UINT16 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2WinSize_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1WinSize_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1WinSize_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1WinSize_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1WinSize_Val"
//
// __PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1WinSize_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngFctEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngFctEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngFctEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngFctEna_Logl"
//
// __PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngFctEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngEna_Logl"
//
// __PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEna_Logl"
//
// __PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngEna_Logl"
//
// __PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_SnsrOffsLrng_SnsrOffsLrngPer1_HwTqLrngSts
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_SnsrOffsLrng_SnsrOffsLrngPer1_HwTqLrngSts"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_SnsrOffsLrng_SnsrOffsLrngPer1_HwTqLrngSts"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_SnsrOffsLrng_SnsrOffsLrngPer1_HwTqLrngSts"
//
// __PST__VOID Rte_IrvWrite_SnsrOffsLrng_SnsrOffsLrngPer1_HwTqLrngSts(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_SnsrOffsLrng_SnsrOffsLrngPer2_HwTqLrngSts
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_SnsrOffsLrng_SnsrOffsLrngPer2_HwTqLrngSts"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_SnsrOffsLrng_SnsrOffsLrngPer2_HwTqLrngSts"
// #pragma POLYSPACE_WORST "Rte_IrvRead_SnsrOffsLrng_SnsrOffsLrngPer2_HwTqLrngSts"
//
// __PST__UINT8 Rte_IrvRead_SnsrOffsLrng_SnsrOffsLrngPer2_HwTqLrngSts(__PST__VOID)
// {
//    ...
// }

