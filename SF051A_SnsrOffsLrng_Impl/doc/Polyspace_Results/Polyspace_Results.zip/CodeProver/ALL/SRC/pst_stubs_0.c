#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * cosf
 */

#pragma POLYSPACE_POLYMORPHIC "cosf"


__PST__FLOAT32 cosf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * sinf
 */

#pragma POLYSPACE_POLYMORPHIC "sinf"


__PST__FLOAT32 sinf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * log10f
 */

#pragma POLYSPACE_POLYMORPHIC "log10f"


__PST__FLOAT32 log10f(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_HwAg_Val
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_HwAg_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_HwAgAuthy_Val
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_HwAgAuthy_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_HwTq_Val
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_HwTq_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_HwVel_Val
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_HwVel_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_MotTqCmdCrf_Val
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_MotTqCmdCrf_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_VehSpd_Val
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_VehSpd_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_VehSpdVld_Logl
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_VehSpdVld_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_VehYawRate_Val
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_VehYawRate_Val(__PST__g__16 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SnsrOffsLrng_VehYawRateVld_Logl
 */


__PST__UINT8 Rte_Read_SnsrOffsLrng_VehYawRateVld_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_SnsrOffsLrng_HwAgOffs_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_SnsrOffsLrng_HwAgOffs_Val"


__PST__UINT8 Rte_Write_SnsrOffsLrng_HwAgOffs_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_SnsrOffsLrng_HwTqOffs_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_SnsrOffsLrng_HwTqOffs_Val"


__PST__UINT8 Rte_Write_SnsrOffsLrng_HwTqOffs_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_SnsrOffsLrng_VehYawRateOffs_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_SnsrOffsLrng_VehYawRateOffs_Val"


__PST__UINT8 Rte_Write_SnsrOffsLrng_VehYawRateOffs_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SnsrOffsLrng_GetRefTmr100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_SnsrOffsLrng_GetRefTmr100MicroSec32bit_Oper(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SnsrOffsLrng_GetTiSpan100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_SnsrOffsLrng_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__32 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_8;
        }
        P_1[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_GetErrorStatus
 */


__PST__UINT8 Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_GetErrorStatus(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_SetRamBlockStatus"


__PST__UINT8 Rte_Call_SnsrOffsLrng_SnsrOffsLrnd_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngDrvgDstThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngDrvgDstThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngDrvgDstThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngHwVelThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngHwVelThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngHwVelThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdMed_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdMed_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdMed_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdTrustd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdTrustd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdTrustd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdWide_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdWide_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngSysTqThdWide_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngTi_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngVehSpdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngVehSpdThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngVehSpdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawOffsDbnd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawOffsDbnd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawOffsDbnd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawRateThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawRateThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngYawRateThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgOffsLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgOffsLim_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgOffsLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEnaTiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEnaTiThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEnaTiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgDbnd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgDbnd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgDbnd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwAgThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqZeroOffsThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqZeroOffsThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwTqZeroOffsThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwVelThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwVelThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngHwVelThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTi_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTiScar_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTiScar_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngMeasTiScar_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd1_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd1_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd1_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd2_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd2_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleImbThd2_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngTiWghtCoeff_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngTiWghtCoeff_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngTiWghtCoeff_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngVehSpdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngVehSpdThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngVehSpdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqOffsLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqOffsLim_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqOffsLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwVelFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwVelFilFrq_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwVelFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqAndAgFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqAndAgFilFrq_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqAndAgFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnHwTqFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnHwTqFilFrq_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnHwTqFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnPwrEstimnThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnPwrEstimnThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnPwrEstimnThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrAmp_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrAmp_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrAmp_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrFrq_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnSinGenrFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1FilGain_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1FilGain_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1FilGain_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainCen_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainCen_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainCen_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainDwn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainDwn_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainDwn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainUp_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainUp_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2FilGainUp_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawACdngFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawACdngFilFrq_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawACdngFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngHwAgThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngHwAgThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngHwAgThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngTi_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngYawAThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngYawAThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngYawAThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawOffsFrshTiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawOffsFrshTiThd_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawOffsFrshTiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateCdngFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateCdngFilFrq_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateCdngFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateOffsLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateOffsLim_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawRateOffsLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SysGlbPrmSysTqRat_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SysGlbPrmSysTqRat_Val"


__PST__FLOAT32 Rte_Prm_SnsrOffsLrng_SysGlbPrmSysTqRat_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd1_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd1_Val"


__PST__UINT16 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd1_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd2_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd2_Val"


__PST__UINT16 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngSampleThd2_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngSampleCntForHwTqLrngRst_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngSampleCntForHwTqLrngRst_Val"


__PST__UINT16 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngSampleCntForHwTqLrngRst_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2WinSize_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2WinSize_Val"


__PST__UINT16 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg2WinSize_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1WinSize_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1WinSize_Val"


__PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngTqInpDetnStg1WinSize_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngFctEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngFctEna_Logl"


__PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngFctEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngEna_Logl"


__PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwAgLrngEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEna_Logl"


__PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngHwTqLrngEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngEna_Logl"


__PST__UINT8 Rte_Prm_SnsrOffsLrng_SnsrOffsLrngYawLrngEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_SnsrOffsLrng_SnsrOffsLrngPer1_HwTqLrngSts
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_SnsrOffsLrng_SnsrOffsLrngPer1_HwTqLrngSts"


__PST__VOID Rte_IrvWrite_SnsrOffsLrng_SnsrOffsLrngPer1_HwTqLrngSts(__PST__UINT8 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvRead_SnsrOffsLrng_SnsrOffsLrngPer2_HwTqLrngSts
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_SnsrOffsLrng_SnsrOffsLrngPer2_HwTqLrngSts"


__PST__UINT8 Rte_IrvRead_SnsrOffsLrng_SnsrOffsLrngPer2_HwTqLrngSts(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

