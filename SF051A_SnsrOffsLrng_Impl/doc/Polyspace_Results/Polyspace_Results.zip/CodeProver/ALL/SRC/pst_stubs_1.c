#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern struct __PST__g__34 _main_gen_init_g34(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__31 _main_gen_init_g31(void);

extern struct Rte_CDS_SnsrOffsLrng _main_gen_init_g29(void);

struct __PST__g__31 _main_gen_init_g31(void)
{
    static struct __PST__g__31 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct __PST__g__34 _main_gen_init_g34(void)
{
    static struct __PST__g__34 x;
    /* struct/union type */
    { /* array type */
        __PST__UINT32 _main_gen_tmp_50_0;
        
        for (_main_gen_tmp_50_0 = 0; _main_gen_tmp_50_0 < 3; _main_gen_tmp_50_0++)
        {
            __PST__UINT32 _main_gen_tmp_50_1;
            
            for (_main_gen_tmp_50_1 = 0; _main_gen_tmp_50_1 < 3; _main_gen_tmp_50_1++)
            {
                /* base type */
                x.HwTqLrngCovariMtrx[_main_gen_tmp_50_0][_main_gen_tmp_50_1] = pst_random_g_10;
            }
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_51_0;
        
        for (_main_gen_tmp_51_0 = 0; _main_gen_tmp_51_0 < 3; _main_gen_tmp_51_0++)
        {
            /* base type */
            x.HwTqLrngEstimnVect[_main_gen_tmp_51_0] = pst_random_g_10;
        }
    }
    x.HwAgLrndTi = _main_gen_init_g10();
    x.YawRateElpdTi = _main_gen_init_g10();
    x.YawRateOffs = _main_gen_init_g3();
    x.HwAgOffs = _main_gen_init_g3();
    x.HwTqOffs = _main_gen_init_g3();
    x.HwAgLrngYawOffsRef = _main_gen_init_g3();
    x.HwAgLrngHwAgFilSt = _main_gen_init_g3();
    x.HwAgLrngSysTqFilSt = _main_gen_init_g3();
    x.HwTqLrngHwAgRef = _main_gen_init_g3();
    x.HwTqLrngSampleCntNeg = _main_gen_init_g7();
    x.HwTqLrngSampleCntPos = _main_gen_init_g7();
    x.HwTqLrngSts = _main_gen_init_g6();
    x.YawRateOffsVld = _main_gen_init_g6();
    return x;
}

struct Rte_CDS_SnsrOffsLrng _main_gen_init_g29(void)
{
    static struct Rte_CDS_SnsrOffsLrng x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g31();
        }
        x.Pim_HwAgCdngFil = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_16[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g10();
        }
        x.Pim_HwAgLrngDrvgDstPrev = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_18[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g31();
        }
        x.Pim_HwAgLrngFil1 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_20[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g31();
        }
        x.Pim_HwAgLrngFil2 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        x.Pim_HwAgLrngStRst = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_24[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g31();
        }
        x.Pim_HwAgLrngSysTqFil1 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_26[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g31();
        }
        x.Pim_HwAgLrngSysTqFil2 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_28[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g31();
        }
        x.Pim_HwAgMeasFil1 = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_30[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g31();
        }
        x.Pim_HwAgMeasFil2 = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g8();
        }
        x.Pim_HwTqLrngEnaTmrRef = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g8();
        }
        x.Pim_HwTqLrngMeasTmrRef = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g6();
        }
        x.Pim_HwTqLrngStRst = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_38[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g6();
        }
        x.Pim_HwTqLrngTqInpDetnEnaPrev = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_41;
        for (_i_main_gen_tmp_41 = 0; _i_main_gen_tmp_41 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_41++)
        {
            _main_gen_tmp_40[_i_main_gen_tmp_41] = _main_gen_init_g6();
        }
        x.Pim_HwTqLrngTqInpPrsnt = PST_TRUE() ? 0 : &_main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_42[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_43;
        for (_i_main_gen_tmp_43 = 0; _i_main_gen_tmp_43 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_43++)
        {
            _main_gen_tmp_42[_i_main_gen_tmp_43] = _main_gen_init_g31();
        }
        x.Pim_HwTqMeasFil1 = PST_TRUE() ? 0 : &_main_gen_tmp_42[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_44[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_45;
        for (_i_main_gen_tmp_45 = 0; _i_main_gen_tmp_45 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_45++)
        {
            _main_gen_tmp_44[_i_main_gen_tmp_45] = _main_gen_init_g31();
        }
        x.Pim_HwTqMeasFil2 = PST_TRUE() ? 0 : &_main_gen_tmp_44[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_46[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_47;
        for (_i_main_gen_tmp_47 = 0; _i_main_gen_tmp_47 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_47++)
        {
            _main_gen_tmp_46[_i_main_gen_tmp_47] = _main_gen_init_g31();
        }
        x.Pim_HwVelCdngFil = PST_TRUE() ? 0 : &_main_gen_tmp_46[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__34 _main_gen_tmp_48[ARRAY_NBELEM(struct __PST__g__34)];
        __PST__UINT32 _i_main_gen_tmp_49;
        for (_i_main_gen_tmp_49 = 0; _i_main_gen_tmp_49 < ARRAY_NBELEM(struct __PST__g__34); _i_main_gen_tmp_49++)
        {
            _main_gen_tmp_48[_i_main_gen_tmp_49] = _main_gen_init_g34();
        }
        x.Pim_SnsrOffsLrnd = PST_TRUE() ? 0 : &_main_gen_tmp_48[ARRAY_NBELEM(struct __PST__g__34) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_52[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_53;
        for (_i_main_gen_tmp_53 = 0; _i_main_gen_tmp_53 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_53++)
        {
            _main_gen_tmp_52[_i_main_gen_tmp_53] = _main_gen_init_g31();
        }
        x.Pim_SysTqCdngFil = PST_TRUE() ? 0 : &_main_gen_tmp_52[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_54[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_55;
        for (_i_main_gen_tmp_55 = 0; _i_main_gen_tmp_55 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_55++)
        {
            _main_gen_tmp_54[_i_main_gen_tmp_55] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnEnaTi = PST_TRUE() ? 0 : &_main_gen_tmp_54[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_56[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_57;
        for (_i_main_gen_tmp_57 = 0; _i_main_gen_tmp_57 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_57++)
        {
            _main_gen_tmp_56[_i_main_gen_tmp_57] = _main_gen_init_g31();
        }
        x.Pim_TqInpDetnHwTqFil = PST_TRUE() ? 0 : &_main_gen_tmp_56[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_58[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_59;
        for (_i_main_gen_tmp_59 = 0; _i_main_gen_tmp_59 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_59++)
        {
            _main_gen_tmp_58[_i_main_gen_tmp_59] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnHwTqPreProc = PST_TRUE() ? 0 : &_main_gen_tmp_58[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_61;
        for (_i_main_gen_tmp_61 = 0; _i_main_gen_tmp_61 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_61++)
        {
            _main_gen_tmp_60[_i_main_gen_tmp_61] = _main_gen_init_g7();
        }
        x.Pim_TqInpDetnPreProcEnaLoop = PST_TRUE() ? 0 : &_main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_62[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_63;
        for (_i_main_gen_tmp_63 = 0; _i_main_gen_tmp_63 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_63++)
        {
            _main_gen_tmp_62[_i_main_gen_tmp_63] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnSinGenrAg = PST_TRUE() ? 0 : &_main_gen_tmp_62[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__39 _main_gen_tmp_64[ARRAY_NBELEM(__PST__g__39)];
        __PST__UINT32 _i_main_gen_tmp_65;
        for (_i_main_gen_tmp_65 = 0; _i_main_gen_tmp_65 < ARRAY_NBELEM(__PST__g__39); _i_main_gen_tmp_65++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_66_0;
                
                for (_main_gen_tmp_66_0 = 0; _main_gen_tmp_66_0 < 72; _main_gen_tmp_66_0++)
                {
                    /* base type */
                    _main_gen_tmp_64[_i_main_gen_tmp_65][_main_gen_tmp_66_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_TqInpDetnStg1Buf = PST_TRUE() ? 0 : &_main_gen_tmp_64[ARRAY_NBELEM(__PST__g__39) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_67[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_68;
        for (_i_main_gen_tmp_68 = 0; _i_main_gen_tmp_68 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_68++)
        {
            _main_gen_tmp_67[_i_main_gen_tmp_68] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnStg1FilSt1 = PST_TRUE() ? 0 : &_main_gen_tmp_67[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_69[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_70;
        for (_i_main_gen_tmp_70 = 0; _i_main_gen_tmp_70 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_70++)
        {
            _main_gen_tmp_69[_i_main_gen_tmp_70] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnStg1FilSt2 = PST_TRUE() ? 0 : &_main_gen_tmp_69[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_71[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_72;
        for (_i_main_gen_tmp_72 = 0; _i_main_gen_tmp_72 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_72++)
        {
            _main_gen_tmp_71[_i_main_gen_tmp_72] = _main_gen_init_g6();
        }
        x.Pim_TqInpDetnStg1Idx = PST_TRUE() ? 0 : &_main_gen_tmp_71[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_73[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_74;
        for (_i_main_gen_tmp_74 = 0; _i_main_gen_tmp_74 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_74++)
        {
            _main_gen_tmp_73[_i_main_gen_tmp_74] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnStg2CenFilSt1 = PST_TRUE() ? 0 : &_main_gen_tmp_73[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_75[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_76;
        for (_i_main_gen_tmp_76 = 0; _i_main_gen_tmp_76 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_76++)
        {
            _main_gen_tmp_75[_i_main_gen_tmp_76] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnStg2CenFilSt2 = PST_TRUE() ? 0 : &_main_gen_tmp_75[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_77[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_78;
        for (_i_main_gen_tmp_78 = 0; _i_main_gen_tmp_78 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_78++)
        {
            _main_gen_tmp_77[_i_main_gen_tmp_78] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnStg2DwnFilSt1 = PST_TRUE() ? 0 : &_main_gen_tmp_77[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_79[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_80;
        for (_i_main_gen_tmp_80 = 0; _i_main_gen_tmp_80 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_80++)
        {
            _main_gen_tmp_79[_i_main_gen_tmp_80] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnStg2DwnFilSt2 = PST_TRUE() ? 0 : &_main_gen_tmp_79[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_81[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_82;
        for (_i_main_gen_tmp_82 = 0; _i_main_gen_tmp_82 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_82++)
        {
            _main_gen_tmp_81[_i_main_gen_tmp_82] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnStg2UpFilSt1 = PST_TRUE() ? 0 : &_main_gen_tmp_81[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_83[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_84;
        for (_i_main_gen_tmp_84 = 0; _i_main_gen_tmp_84 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_84++)
        {
            _main_gen_tmp_83[_i_main_gen_tmp_84] = _main_gen_init_g10();
        }
        x.Pim_TqInpDetnStg2UpFilSt2 = PST_TRUE() ? 0 : &_main_gen_tmp_83[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_85[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_86;
        for (_i_main_gen_tmp_86 = 0; _i_main_gen_tmp_86 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_86++)
        {
            _main_gen_tmp_85[_i_main_gen_tmp_86] = _main_gen_init_g6();
        }
        x.Pim_VehYawRateLrngStRst = PST_TRUE() ? 0 : &_main_gen_tmp_85[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_87[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_88;
        for (_i_main_gen_tmp_88 = 0; _i_main_gen_tmp_88 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_88++)
        {
            _main_gen_tmp_87[_i_main_gen_tmp_88] = _main_gen_init_g6();
        }
        x.Pim_VehYawRateOffsFrsh = PST_TRUE() ? 0 : &_main_gen_tmp_87[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_89[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_90;
        for (_i_main_gen_tmp_90 = 0; _i_main_gen_tmp_90 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_90++)
        {
            _main_gen_tmp_89[_i_main_gen_tmp_90] = _main_gen_init_g31();
        }
        x.Pim_YawACdngFil = PST_TRUE() ? 0 : &_main_gen_tmp_89[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_91[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_92;
        for (_i_main_gen_tmp_92 = 0; _i_main_gen_tmp_92 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_92++)
        {
            _main_gen_tmp_91[_i_main_gen_tmp_92] = _main_gen_init_g31();
        }
        x.Pim_YawCdngFil1 = PST_TRUE() ? 0 : &_main_gen_tmp_91[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_93[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_94;
        for (_i_main_gen_tmp_94 = 0; _i_main_gen_tmp_94 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_94++)
        {
            _main_gen_tmp_93[_i_main_gen_tmp_94] = _main_gen_init_g31();
        }
        x.Pim_YawCdngFil2 = PST_TRUE() ? 0 : &_main_gen_tmp_93[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_95[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_96;
        for (_i_main_gen_tmp_96 = 0; _i_main_gen_tmp_96 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_96++)
        {
            _main_gen_tmp_95[_i_main_gen_tmp_96] = _main_gen_init_g10();
        }
        x.Pim_YawLrngElpdLrngTi = PST_TRUE() ? 0 : &_main_gen_tmp_95[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_97[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_98;
        for (_i_main_gen_tmp_98 = 0; _i_main_gen_tmp_98 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_98++)
        {
            _main_gen_tmp_97[_i_main_gen_tmp_98] = _main_gen_init_g31();
        }
        x.Pim_YawLrngFil1 = PST_TRUE() ? 0 : &_main_gen_tmp_97[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__31 _main_gen_tmp_99[ARRAY_NBELEM(struct __PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_100;
        for (_i_main_gen_tmp_100 = 0; _i_main_gen_tmp_100 < ARRAY_NBELEM(struct __PST__g__31); _i_main_gen_tmp_100++)
        {
            _main_gen_tmp_99[_i_main_gen_tmp_100] = _main_gen_init_g31();
        }
        x.Pim_YawLrngFil2 = PST_TRUE() ? 0 : &_main_gen_tmp_99[ARRAY_NBELEM(struct __PST__g__31) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_101[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_102;
        for (_i_main_gen_tmp_102 = 0; _i_main_gen_tmp_102 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_102++)
        {
            _main_gen_tmp_101[_i_main_gen_tmp_102] = _main_gen_init_g10();
        }
        x.Pim_YawRatePrev = PST_TRUE() ? 0 : &_main_gen_tmp_101[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_103[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_104;
        for (_i_main_gen_tmp_104 = 0; _i_main_gen_tmp_104 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_104++)
        {
            _main_gen_tmp_103[_i_main_gen_tmp_104] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwAgFild = PST_TRUE() ? 0 : &_main_gen_tmp_103[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_105[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_106;
        for (_i_main_gen_tmp_106 = 0; _i_main_gen_tmp_106 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_106++)
        {
            _main_gen_tmp_105[_i_main_gen_tmp_106] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwAgLrngCdnVld = PST_TRUE() ? 0 : &_main_gen_tmp_105[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_107[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_108;
        for (_i_main_gen_tmp_108 = 0; _i_main_gen_tmp_108 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_108++)
        {
            _main_gen_tmp_107[_i_main_gen_tmp_108] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwAgLrngEna = PST_TRUE() ? 0 : &_main_gen_tmp_107[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_109[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_110;
        for (_i_main_gen_tmp_110 = 0; _i_main_gen_tmp_110 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_110++)
        {
            _main_gen_tmp_109[_i_main_gen_tmp_110] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwAgLrngRst = PST_TRUE() ? 0 : &_main_gen_tmp_109[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_111[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_112;
        for (_i_main_gen_tmp_112 = 0; _i_main_gen_tmp_112 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_112++)
        {
            _main_gen_tmp_111[_i_main_gen_tmp_112] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwAgLrngSysTqLoThd = PST_TRUE() ? 0 : &_main_gen_tmp_111[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_113[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_114;
        for (_i_main_gen_tmp_114 = 0; _i_main_gen_tmp_114 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_114++)
        {
            _main_gen_tmp_113[_i_main_gen_tmp_114] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwAgLrngSysTqUpThd = PST_TRUE() ? 0 : &_main_gen_tmp_113[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_115[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_116;
        for (_i_main_gen_tmp_116 = 0; _i_main_gen_tmp_116 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_116++)
        {
            _main_gen_tmp_115[_i_main_gen_tmp_116] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwAgLrngSysTqVldt = PST_TRUE() ? 0 : &_main_gen_tmp_115[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_117[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_118;
        for (_i_main_gen_tmp_118 = 0; _i_main_gen_tmp_118 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_118++)
        {
            _main_gen_tmp_117[_i_main_gen_tmp_118] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwAgLrngTiVldt = PST_TRUE() ? 0 : &_main_gen_tmp_117[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_119[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_120;
        for (_i_main_gen_tmp_120 = 0; _i_main_gen_tmp_120 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_120++)
        {
            _main_gen_tmp_119[_i_main_gen_tmp_120] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngEna = PST_TRUE() ? 0 : &_main_gen_tmp_119[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_121[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_122;
        for (_i_main_gen_tmp_122 = 0; _i_main_gen_tmp_122 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_122++)
        {
            _main_gen_tmp_121[_i_main_gen_tmp_122] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngEstimnVldt = PST_TRUE() ? 0 : &_main_gen_tmp_121[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_123[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_124;
        for (_i_main_gen_tmp_124 = 0; _i_main_gen_tmp_124 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_124++)
        {
            _main_gen_tmp_123[_i_main_gen_tmp_124] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngHwAgMeas = PST_TRUE() ? 0 : &_main_gen_tmp_123[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_125[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_126;
        for (_i_main_gen_tmp_126 = 0; _i_main_gen_tmp_126 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_126++)
        {
            _main_gen_tmp_125[_i_main_gen_tmp_126] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngHwTqMeas = PST_TRUE() ? 0 : &_main_gen_tmp_125[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_127[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_128;
        for (_i_main_gen_tmp_128 = 0; _i_main_gen_tmp_128 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_128++)
        {
            _main_gen_tmp_127[_i_main_gen_tmp_128] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngHwTqOffsRaw = PST_TRUE() ? 0 : &_main_gen_tmp_127[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_129[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_130;
        for (_i_main_gen_tmp_130 = 0; _i_main_gen_tmp_130 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_130++)
        {
            _main_gen_tmp_129[_i_main_gen_tmp_130] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngMeasEna = PST_TRUE() ? 0 : &_main_gen_tmp_129[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_131[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_132;
        for (_i_main_gen_tmp_132 = 0; _i_main_gen_tmp_132 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_132++)
        {
            _main_gen_tmp_131[_i_main_gen_tmp_132] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngSampleCntTot = PST_TRUE() ? 0 : &_main_gen_tmp_131[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_133[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_134;
        for (_i_main_gen_tmp_134 = 0; _i_main_gen_tmp_134 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_134++)
        {
            _main_gen_tmp_133[_i_main_gen_tmp_134] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngSampleImb = PST_TRUE() ? 0 : &_main_gen_tmp_133[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_135[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_136;
        for (_i_main_gen_tmp_136 = 0; _i_main_gen_tmp_136 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_136++)
        {
            _main_gen_tmp_135[_i_main_gen_tmp_136] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngTqInpPrsnt = PST_TRUE() ? 0 : &_main_gen_tmp_135[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_137[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_138;
        for (_i_main_gen_tmp_138 = 0; _i_main_gen_tmp_138 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_138++)
        {
            _main_gen_tmp_137[_i_main_gen_tmp_138] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngHwTqLrngTqInpPrsntVld = PST_TRUE() ? 0 : &_main_gen_tmp_137[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_139[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_140;
        for (_i_main_gen_tmp_140 = 0; _i_main_gen_tmp_140 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_140++)
        {
            _main_gen_tmp_139[_i_main_gen_tmp_140] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngHwVelFild = PST_TRUE() ? 0 : &_main_gen_tmp_139[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_141[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_142;
        for (_i_main_gen_tmp_142 = 0; _i_main_gen_tmp_142 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_142++)
        {
            _main_gen_tmp_141[_i_main_gen_tmp_142] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngSysTqFild = PST_TRUE() ? 0 : &_main_gen_tmp_141[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_143[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_144;
        for (_i_main_gen_tmp_144 = 0; _i_main_gen_tmp_144 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_144++)
        {
            _main_gen_tmp_143[_i_main_gen_tmp_144] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngTqInpDetnHwTqFild = PST_TRUE() ? 0 : &_main_gen_tmp_143[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_145[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_146;
        for (_i_main_gen_tmp_146 = 0; _i_main_gen_tmp_146 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_146++)
        {
            _main_gen_tmp_145[_i_main_gen_tmp_146] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngTqInpDetnStg1Outp = PST_TRUE() ? 0 : &_main_gen_tmp_145[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_147[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_148;
        for (_i_main_gen_tmp_148 = 0; _i_main_gen_tmp_148 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_148++)
        {
            _main_gen_tmp_147[_i_main_gen_tmp_148] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngTqInpPrsntRaw = PST_TRUE() ? 0 : &_main_gen_tmp_147[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_149[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_150;
        for (_i_main_gen_tmp_150 = 0; _i_main_gen_tmp_150 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_150++)
        {
            _main_gen_tmp_149[_i_main_gen_tmp_150] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngYawA = PST_TRUE() ? 0 : &_main_gen_tmp_149[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_151[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_152;
        for (_i_main_gen_tmp_152 = 0; _i_main_gen_tmp_152 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_152++)
        {
            _main_gen_tmp_151[_i_main_gen_tmp_152] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngYawLrngBiasEstimnRaw = PST_TRUE() ? 0 : &_main_gen_tmp_151[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_153[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_154;
        for (_i_main_gen_tmp_154 = 0; _i_main_gen_tmp_154 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_154++)
        {
            _main_gen_tmp_153[_i_main_gen_tmp_154] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngYawLrngCdnVld = PST_TRUE() ? 0 : &_main_gen_tmp_153[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_155[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_156;
        for (_i_main_gen_tmp_156 = 0; _i_main_gen_tmp_156 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_156++)
        {
            _main_gen_tmp_155[_i_main_gen_tmp_156] = _main_gen_init_g6();
        }
        x.Pim_dSnsrOffsLrngYawLrngEna = PST_TRUE() ? 0 : &_main_gen_tmp_155[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_157[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_158;
        for (_i_main_gen_tmp_158 = 0; _i_main_gen_tmp_158 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_158++)
        {
            _main_gen_tmp_157[_i_main_gen_tmp_158] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngYawRateFild = PST_TRUE() ? 0 : &_main_gen_tmp_157[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_159[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_160;
        for (_i_main_gen_tmp_160 = 0; _i_main_gen_tmp_160 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_160++)
        {
            _main_gen_tmp_159[_i_main_gen_tmp_160] = _main_gen_init_g10();
        }
        x.Pim_dSnsrOffsLrngYawRateFildCorrd = PST_TRUE() ? 0 : &_main_gen_tmp_159[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_SnsrOffsLrng(void)
{
    extern __PST__g__26 Rte_Inst_SnsrOffsLrng;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_SnsrOffsLrng _main_gen_tmp_12[ARRAY_NBELEM(struct Rte_CDS_SnsrOffsLrng)];
            __PST__UINT32 _i_main_gen_tmp_13;
            for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(struct Rte_CDS_SnsrOffsLrng); _i_main_gen_tmp_13++)
            {
                _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g29();
            }
            Rte_Inst_SnsrOffsLrng = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(struct Rte_CDS_SnsrOffsLrng) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_SnsrOffsLrng */
    _main_gen_init_sym_Rte_Inst_SnsrOffsLrng();
    
}
