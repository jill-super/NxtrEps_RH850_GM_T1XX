/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Det_ReportError
//
// #pragma POLYSPACE_PURE "Det_ReportError"
// #pragma POLYSPACE_CLEAN "Det_ReportError"
// #pragma POLYSPACE_WORST "Det_ReportError"
//
// __PST__UINT8 Det_ReportError(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT8 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_BrdgVltg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_BrdgVltg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_BrdgVltg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_BrdgVltg_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_BrdgVltg_Val(__PST__g__80 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_EcuTFild_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_EcuTFild_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_EcuTFild_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_EcuTFild_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_EcuTFild_Val(__PST__g__80 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_HwTq_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_HwTq_Val(__PST__g__80 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_IgnCntr_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_IgnCntr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_IgnCntr_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_IgnCntr_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_IgnCntr_Val(__PST__g__82 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_MfgDiagcInhb_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_MfgDiagcInhb_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_MfgDiagcInhb_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_MfgDiagcInhb_Logl"
//
// __PST__UINT8 Rte_Read_DiagcMgr_MfgDiagcInhb_Logl(__PST__g__23 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_MfgEnaSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_MfgEnaSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_MfgEnaSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_MfgEnaSt_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_MfgEnaSt_Val(__PST__g__23 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_MotTqCmdMrfScad_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_MotTqCmdMrfScad_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_MotTqCmdMrfScad_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_MotTqCmdMrfScad_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_MotTqCmdMrfScad_Val(__PST__g__80 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_RegInBRAMDAT1_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_RegInBRAMDAT1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_RegInBRAMDAT1_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_RegInBRAMDAT1_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_RegInBRAMDAT1_Val(__PST__g__82 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_SysSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_SysSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_SysSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_SysSt_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_SysSt_Val(__PST__g__23 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgr_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgr_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgr_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgr_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgr_VehSpd_Val(__PST__g__80 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_ClrDiagcFlgProxy_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_ClrDiagcFlgProxy_Val"
//
// __PST__UINT8 Rte_Write_DiagcMgr_ClrDiagcFlgProxy_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_DiagcStsCtrldShtDwnFltPrsnt_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_DiagcStsCtrldShtDwnFltPrsnt_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_DiagcStsCtrldShtDwnFltPrsnt_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_DiagcStsCtrldShtDwnFltPrsnt_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_DiagcStsCtrldShtDwnFltPrsnt_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_DiagcStsDftHwAg_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_DiagcStsDftHwAg_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_DiagcStsDftHwAg_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_DiagcStsDftHwAg_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_DiagcStsDftHwAg_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_DiagcStsDftHwAgSerlComExprtVal_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_DiagcStsDftHwAgSerlComExprtVal_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_DiagcStsDftHwAgSerlComExprtVal_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_DiagcStsDftHwAgSerlComExprtVal_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_DiagcStsDftHwAgSerlComExprtVal_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_DiagcStsDftVehSpd_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_DiagcStsDftVehSpd_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_DiagcStsDftVehSpd_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_DiagcStsDftVehSpd_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_DiagcStsDftVehSpd_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_DiagcStsIvtr1Inactv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_DiagcStsIvtr1Inactv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_DiagcStsIvtr1Inactv_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_DiagcStsIvtr1Inactv_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_DiagcStsIvtr1Inactv_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_DiagcStsIvtr2Inactv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_DiagcStsIvtr2Inactv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_DiagcStsIvtr2Inactv_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_DiagcStsIvtr2Inactv_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_DiagcStsIvtr2Inactv_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_DiagcStsLimdTPrfmnc_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_DiagcStsLimdTPrfmnc_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_DiagcStsLimdTPrfmnc_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_DiagcStsLimdTPrfmnc_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_DiagcStsLimdTPrfmnc_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_DiagcStsWhlImbRejctnDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_DiagcStsWhlImbRejctnDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_DiagcStsWhlImbRejctnDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_DiagcStsWhlImbRejctnDi_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_DiagcStsWhlImbRejctnDi_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_SysDiMotTqCmdSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_SysDiMotTqCmdSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_SysDiMotTqCmdSca_Val"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_SysDiMotTqCmdSca_Val"
//
// __PST__UINT8 Rte_Write_DiagcMgr_SysDiMotTqCmdSca_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_SysDiRampRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_SysDiRampRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_SysDiRampRate_Val"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_SysDiRampRate_Val"
//
// __PST__UINT8 Rte_Write_DiagcMgr_SysDiRampRate_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_DiagcMgr_SysStFltOutpReqDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_DiagcMgr_SysStFltOutpReqDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_DiagcMgr_SysStFltOutpReqDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_DiagcMgr_SysStFltOutpReqDi_Logl"
//
// __PST__UINT8 Rte_Write_DiagcMgr_SysStFltOutpReqDi_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl0_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl0_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl0_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl0_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl0_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl1_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl1_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl1_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl1_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl1_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl10_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl10_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl10_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl10_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl10_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl2_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl2_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl2_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl2_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl2_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl3_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl3_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl3_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl3_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl3_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl4_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl4_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl4_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl4_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl4_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl5_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl5_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl5_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl5_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl5_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl6_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl6_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl6_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl6_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl6_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl7_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl7_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl7_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl7_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl7_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl8_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl8_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl8_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl8_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl8_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetDiagcDataAppl9_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetDiagcDataAppl9_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetDiagcDataAppl9_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetDiagcDataAppl9_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl9_Oper(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl0_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl0_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl0_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl0_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl0_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl1_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl1_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl1_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl1_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl1_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl10_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl10_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl10_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl10_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl10_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl2_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl2_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl2_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl2_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl2_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl3_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl3_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl3_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl3_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl3_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl4_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl4_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl4_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl4_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl4_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl5_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl5_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl5_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl5_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl5_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl6_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl6_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl6_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl6_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl6_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl7_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl7_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl7_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl7_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl7_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl8_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl8_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl8_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl8_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl8_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcDebCntrAppl9_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcDebCntrAppl9_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcDebCntrAppl9_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcDebCntrAppl9_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl9_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl0_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl0_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl0_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl0_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl0_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl1_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl1_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl1_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl1_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl1_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl10_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl10_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl10_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl10_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl10_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl2_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl2_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl2_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl2_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl2_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl3_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl3_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl3_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl3_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl3_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl4_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl4_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl4_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl4_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl4_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl5_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl5_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl5_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl5_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl5_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl6_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl6_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl6_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl6_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl6_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl7_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl7_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl7_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl7_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl7_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl8_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl8_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl8_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl8_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl8_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_GetNtcInfoAppl9_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_GetNtcInfoAppl9_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_GetNtcInfoAppl9_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_GetNtcInfoAppl9_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl9_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_SnpshtDataAry_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_SnpshtDataAry_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_SnpshtDataAry_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_SnpshtDataAry_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_DiagcMgr_SnpshtDataAry_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_DiagcMgr_DiagcMgrFltResp_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_DiagcMgr_DiagcMgrFltResp_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_DiagcMgr_DiagcMgrFltResp_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_DiagcMgr_DiagcMgrFltResp_Ary1D"
//
// __PST__g__90 Rte_Prm_DiagcMgr_DiagcMgrFltResp_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea"
//
// __PST__VOID Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea"
//
// __PST__VOID Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Dem_ClearDTC
//
// #pragma POLYSPACE_PURE "Dem_ClearDTC"
// #pragma POLYSPACE_CLEAN "Dem_ClearDTC"
// #pragma POLYSPACE_WORST "Dem_ClearDTC"
//
// __PST__UINT8 Dem_ClearDTC(__PST__UINT32 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2)
// {
//    ...
// }


// Pragmas for function Dem_SetEventStatus
//
// #pragma POLYSPACE_PURE "Dem_SetEventStatus"
// #pragma POLYSPACE_CLEAN "Dem_SetEventStatus"
// #pragma POLYSPACE_WORST "Dem_SetEventStatus"
//
// __PST__UINT8 Dem_SetEventStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl0_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl0_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl0_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl0_Oper"
//
// __PST__VOID GetNtcInfoAppl0_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl1_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl1_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl1_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl1_Oper"
//
// __PST__VOID GetNtcInfoAppl1_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl2_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl2_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl2_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl2_Oper"
//
// __PST__VOID GetNtcInfoAppl2_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl3_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl3_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl3_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl3_Oper"
//
// __PST__VOID GetNtcInfoAppl3_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl4_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl4_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl4_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl4_Oper"
//
// __PST__VOID GetNtcInfoAppl4_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl5_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl5_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl5_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl5_Oper"
//
// __PST__VOID GetNtcInfoAppl5_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl7_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl7_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl7_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl7_Oper"
//
// __PST__VOID GetNtcInfoAppl7_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl8_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl8_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl8_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl8_Oper"
//
// __PST__VOID GetNtcInfoAppl8_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function GetNtcInfoAppl9_Oper
//
// #pragma POLYSPACE_PURE "GetNtcInfoAppl9_Oper"
// #pragma POLYSPACE_CLEAN "GetNtcInfoAppl9_Oper"
// #pragma POLYSPACE_WORST "GetNtcInfoAppl9_Oper"
//
// __PST__VOID GetNtcInfoAppl9_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function NvMProxy_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "NvMProxy_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "NvMProxy_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "NvMProxy_SetRamBlockStatus"
//
// __PST__UINT8 NvMProxy_SetRamBlockStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgrProxyAppl10_ClrDiagcFlgProxy_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgrProxyAppl10_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgrProxyAppl10_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgrProxyAppl10_ClrDiagcFlgProxy_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgrProxyAppl10_ClrDiagcFlgProxy_Val(__PST__g__23 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl10_DiagcMgrIninCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl10_DiagcMgrIninCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl10_DiagcMgrIninCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl10_DiagcMgrIninCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_DiagcMgrIninCore_Oper(__PST__UINT8 P_0, __PST__UINT8 P_1, __PST__g__17 P_2, __PST__g__19 P_3, __PST__g__19 P_4)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl10_GetNtcActvCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl10_GetNtcActvCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl10_GetNtcActvCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl10_GetNtcActvCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_GetNtcActvCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl10_GetNtcQlfrStsCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl10_GetNtcQlfrStsCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl10_GetNtcQlfrStsCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl10_GetNtcQlfrStsCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_GetNtcQlfrStsCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl10_GetNtcStsCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl10_GetNtcStsCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl10_GetNtcStsCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl10_GetNtcStsCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_GetNtcStsCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl10_SetNtcStsCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl10_SetNtcStsCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl10_SetNtcStsCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl10_SetNtcStsCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_SetNtcStsCore_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3, __PST__g__19 P_4, __PST__g__19 P_5, __PST__g__17 P_6, __PST__g__29 P_7)
// {
//    ...
// }


// Pragmas for function Rte_Prm_DiagcMgrProxyAppl10_DiagcMgrFltResp_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_DiagcMgrProxyAppl10_DiagcMgrFltResp_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_DiagcMgrProxyAppl10_DiagcMgrFltResp_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_DiagcMgrProxyAppl10_DiagcMgrFltResp_Ary1D"
//
// __PST__g__90 Rte_Prm_DiagcMgrProxyAppl10_DiagcMgrFltResp_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Read_DiagcMgrProxyAppl6_ClrDiagcFlgProxy_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_DiagcMgrProxyAppl6_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_DiagcMgrProxyAppl6_ClrDiagcFlgProxy_Val"
// #pragma POLYSPACE_WORST "Rte_Read_DiagcMgrProxyAppl6_ClrDiagcFlgProxy_Val"
//
// __PST__UINT8 Rte_Read_DiagcMgrProxyAppl6_ClrDiagcFlgProxy_Val(__PST__g__23 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl6_DiagcMgrIninCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl6_DiagcMgrIninCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl6_DiagcMgrIninCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl6_DiagcMgrIninCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_DiagcMgrIninCore_Oper(__PST__UINT8 P_0, __PST__UINT8 P_1, __PST__g__17 P_2, __PST__g__19 P_3, __PST__g__19 P_4)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl6_GetNtcActvCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl6_GetNtcActvCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl6_GetNtcActvCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl6_GetNtcActvCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_GetNtcActvCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl6_GetNtcQlfrStsCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl6_GetNtcQlfrStsCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl6_GetNtcQlfrStsCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl6_GetNtcQlfrStsCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_GetNtcQlfrStsCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl6_GetNtcStsCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl6_GetNtcStsCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl6_GetNtcStsCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl6_GetNtcStsCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_GetNtcStsCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgrProxyAppl6_SetNtcStsCore_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgrProxyAppl6_SetNtcStsCore_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgrProxyAppl6_SetNtcStsCore_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgrProxyAppl6_SetNtcStsCore_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_SetNtcStsCore_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3, __PST__g__19 P_4, __PST__g__19 P_5, __PST__g__17 P_6, __PST__g__29 P_7)
// {
//    ...
// }


// Pragmas for function Rte_Prm_DiagcMgrProxyAppl6_DiagcMgrFltResp_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_DiagcMgrProxyAppl6_DiagcMgrFltResp_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_DiagcMgrProxyAppl6_DiagcMgrFltResp_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_DiagcMgrProxyAppl6_DiagcMgrFltResp_Ary1D"
//
// __PST__g__90 Rte_Prm_DiagcMgrProxyAppl6_DiagcMgrFltResp_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6(__PST__VOID)
// {
//    ...
// }

