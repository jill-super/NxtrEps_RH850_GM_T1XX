#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Det_ReportError
 */

#pragma POLYSPACE_POLYMORPHIC "Det_ReportError"


__PST__UINT8 Det_ReportError(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT8 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_BrdgVltg_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_BrdgVltg_Val(__PST__g__80 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_EcuTFild_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_EcuTFild_Val(__PST__g__80 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_HwTq_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_HwTq_Val(__PST__g__80 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_IgnCntr_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_IgnCntr_Val(__PST__g__82 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_MfgDiagcInhb_Logl
 */


__PST__UINT8 Rte_Read_DiagcMgr_MfgDiagcInhb_Logl(__PST__g__23 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_MfgEnaSt_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_MfgEnaSt_Val(__PST__g__23 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_MotTqCmdMrfScad_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_MotTqCmdMrfScad_Val(__PST__g__80 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_RegInBRAMDAT1_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_RegInBRAMDAT1_Val(__PST__g__82 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_SysSt_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_SysSt_Val(__PST__g__23 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgr_VehSpd_Val
 */


__PST__UINT8 Rte_Read_DiagcMgr_VehSpd_Val(__PST__g__80 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_ClrDiagcFlgProxy_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_ClrDiagcFlgProxy_Val"


__PST__UINT8 Rte_Write_DiagcMgr_ClrDiagcFlgProxy_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_DiagcStsCtrldShtDwnFltPrsnt_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_DiagcStsCtrldShtDwnFltPrsnt_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_DiagcStsCtrldShtDwnFltPrsnt_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_DiagcStsDftHwAg_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_DiagcStsDftHwAg_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_DiagcStsDftHwAg_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_DiagcStsDftHwAgSerlComExprtVal_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_DiagcStsDftHwAgSerlComExprtVal_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_DiagcStsDftHwAgSerlComExprtVal_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_DiagcStsDftVehSpd_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_DiagcStsDftVehSpd_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_DiagcStsDftVehSpd_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_DiagcStsIvtr1Inactv_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_DiagcStsIvtr1Inactv_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_DiagcStsIvtr1Inactv_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_DiagcStsIvtr2Inactv_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_DiagcStsIvtr2Inactv_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_DiagcStsIvtr2Inactv_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_DiagcStsLimdTPrfmnc_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_DiagcStsLimdTPrfmnc_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_DiagcStsLimdTPrfmnc_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_DiagcStsWhlImbRejctnDi_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_DiagcStsWhlImbRejctnDi_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_DiagcStsWhlImbRejctnDi_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_SysDiMotTqCmdSca_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_SysDiMotTqCmdSca_Val"


__PST__UINT8 Rte_Write_DiagcMgr_SysDiMotTqCmdSca_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_SysDiRampRate_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_SysDiRampRate_Val"


__PST__UINT8 Rte_Write_DiagcMgr_SysDiRampRate_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DiagcMgr_SysStFltOutpReqDi_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DiagcMgr_SysStFltOutpReqDi_Logl"


__PST__UINT8 Rte_Write_DiagcMgr_SysStFltOutpReqDi_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl0_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl0_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl1_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl1_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl10_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl10_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl2_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl2_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl3_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl3_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl4_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl4_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl5_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl5_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl6_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl6_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl7_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl7_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl8_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl8_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetDiagcDataAppl9_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetDiagcDataAppl9_Oper(__PST__g__19 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl0_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl0_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl1_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl1_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl10_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl10_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl2_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl2_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl3_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl3_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl4_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl4_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl5_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl5_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl6_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl6_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl7_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl7_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl8_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl8_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcDebCntrAppl9_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcDebCntrAppl9_Oper(__PST__UINT8 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_3;
        }
        P_1[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl0_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl0_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl1_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl1_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl10_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl10_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl2_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl2_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl3_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl3_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl4_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl4_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl5_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl5_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl6_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl6_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl7_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl7_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl8_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl8_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_GetNtcInfoAppl9_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgr_GetNtcInfoAppl9_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_SnpshtDataAry_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_DiagcMgr_SnpshtDataAry_SetRamBlockStatus"


__PST__UINT8 Rte_Call_DiagcMgr_SnpshtDataAry_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DiagcMgr_DiagcMgrFltResp_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DiagcMgr_DiagcMgrFltResp_Ary1D"


__PST__g__90 Rte_Prm_DiagcMgr_DiagcMgrFltResp_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__90 real_random_for_return ;
        __PST__g__90 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea"


__PST__VOID Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea"


__PST__VOID Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Dem_ClearDTC
 */

#pragma POLYSPACE_POLYMORPHIC "Dem_ClearDTC"


__PST__UINT8 Dem_ClearDTC(__PST__UINT32 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Dem_SetEventStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Dem_SetEventStatus"


__PST__UINT8 Dem_SetEventStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * GetNtcInfoAppl0_Oper
 */


__PST__VOID GetNtcInfoAppl0_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * GetNtcInfoAppl1_Oper
 */


__PST__VOID GetNtcInfoAppl1_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * GetNtcInfoAppl2_Oper
 */


__PST__VOID GetNtcInfoAppl2_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * GetNtcInfoAppl3_Oper
 */


__PST__VOID GetNtcInfoAppl3_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * GetNtcInfoAppl4_Oper
 */


__PST__VOID GetNtcInfoAppl4_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * GetNtcInfoAppl5_Oper
 */


__PST__VOID GetNtcInfoAppl5_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * GetNtcInfoAppl7_Oper
 */


__PST__VOID GetNtcInfoAppl7_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * GetNtcInfoAppl8_Oper
 */


__PST__VOID GetNtcInfoAppl8_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * GetNtcInfoAppl9_Oper
 */


__PST__VOID GetNtcInfoAppl9_Oper(__PST__UINT8 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_1;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    return;
}

/*
 * NvMProxy_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "NvMProxy_SetRamBlockStatus"


__PST__UINT8 NvMProxy_SetRamBlockStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DiagcMgrProxyAppl10_ClrDiagcFlgProxy_Val
 */


__PST__UINT8 Rte_Read_DiagcMgrProxyAppl10_ClrDiagcFlgProxy_Val(__PST__g__23 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl10_DiagcMgrIninCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_DiagcMgrIninCore_Oper(__PST__UINT8 P_0, __PST__UINT8 P_1, __PST__g__17 P_2, __PST__g__19 P_3, __PST__g__19 P_4)
{
    /* parameter 0 is constant */

    /* parameter 1 is constant */

    /* parameter 2 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_2;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 3 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_3;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 4 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_4;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl10_GetNtcActvCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_GetNtcActvCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl10_GetNtcQlfrStsCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_GetNtcQlfrStsCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl10_GetNtcStsCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_GetNtcStsCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl10_SetNtcStsCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl10_SetNtcStsCore_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3, __PST__g__19 P_4, __PST__g__19 P_5, __PST__g__17 P_6, __PST__g__29 P_7)
{
    /* parameter 0 is constant */

    /* parameter 1 is constant */

    /* parameter 2 is constant */

    /* parameter 3 is constant */

    /* parameter 4 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_4;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 5 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_5;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 6 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_6;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 7 */

    if (P_7 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_7[pst_random_int] = pst_random_g_3;
        }
        P_7[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DiagcMgrProxyAppl10_DiagcMgrFltResp_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DiagcMgrProxyAppl10_DiagcMgrFltResp_Ary1D"


__PST__g__90 Rte_Prm_DiagcMgrProxyAppl10_DiagcMgrFltResp_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__90 real_random_for_return ;
        __PST__g__90 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Read_DiagcMgrProxyAppl6_ClrDiagcFlgProxy_Val
 */


__PST__UINT8 Rte_Read_DiagcMgrProxyAppl6_ClrDiagcFlgProxy_Val(__PST__g__23 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl6_DiagcMgrIninCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_DiagcMgrIninCore_Oper(__PST__UINT8 P_0, __PST__UINT8 P_1, __PST__g__17 P_2, __PST__g__19 P_3, __PST__g__19 P_4)
{
    /* parameter 0 is constant */

    /* parameter 1 is constant */

    /* parameter 2 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_2;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 3 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_3;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 4 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_4;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl6_GetNtcActvCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_GetNtcActvCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl6_GetNtcQlfrStsCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_GetNtcQlfrStsCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl6_GetNtcStsCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_GetNtcStsCore_Oper(__PST__UINT16 P_0, __PST__g__23 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgrProxyAppl6_SetNtcStsCore_Oper
 */


__PST__UINT8 Rte_Call_DiagcMgrProxyAppl6_SetNtcStsCore_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3, __PST__g__19 P_4, __PST__g__19 P_5, __PST__g__17 P_6, __PST__g__29 P_7)
{
    /* parameter 0 is constant */

    /* parameter 1 is constant */

    /* parameter 2 is constant */

    /* parameter 3 is constant */

    /* parameter 4 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_4;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 5 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_5;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 6 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_6;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* parameter 7 */

    if (P_7 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_7[pst_random_int] = pst_random_g_3;
        }
        P_7[0] = pst_random_g_3;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DiagcMgrProxyAppl6_DiagcMgrFltResp_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DiagcMgrProxyAppl6_DiagcMgrFltResp_Ary1D"


__PST__g__90 Rte_Prm_DiagcMgrProxyAppl6_DiagcMgrFltResp_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__90 real_random_for_return ;
        __PST__g__90 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6(__PST__VOID)
{
    /* function is pure */

    return;
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

