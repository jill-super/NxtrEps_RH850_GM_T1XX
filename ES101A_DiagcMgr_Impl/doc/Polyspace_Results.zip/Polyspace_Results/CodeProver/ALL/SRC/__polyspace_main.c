#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__32 _main_gen_init_g32(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern struct __PST__g__26 _main_gen_init_g26(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern struct __PST__g__20 _main_gen_init_g20(void);

extern struct __PST__g__18 _main_gen_init_g18(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__18 _main_gen_init_g18(void)
{
    static struct __PST__g__18 x;
    /* struct/union type */
    x.NtcStInfo = _main_gen_init_g6();
    x.Sts = _main_gen_init_g6();
    x.AgiCntr = _main_gen_init_g6();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__20 _main_gen_init_g20(void)
{
    static struct __PST__g__20 x;
    /* struct/union type */
    x.DiagcSts = _main_gen_init_g7();
    x.ActvRampRate = _main_gen_init_g10();
    x.ActvMotTqCmdSca = _main_gen_init_g10();
    return x;
}

struct __PST__g__26 _main_gen_init_g26(void)
{
    static struct __PST__g__26 x;
    /* struct/union type */
    x.NtcNr = _main_gen_init_g7();
    x.AgiCntr = _main_gen_init_g6();
    x.Sts = _main_gen_init_g6();
    x.NtcStInfo = _main_gen_init_g6();
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct __PST__g__32 _main_gen_init_g32(void)
{
    static struct __PST__g__32 x;
    /* struct/union type */
    x.MicroDiagcData = _main_gen_init_g8();
    x.HwTq = _main_gen_init_g3();
    x.MotTq = _main_gen_init_g3();
    x.IgnCntr = _main_gen_init_g8();
    x.BrdgVltg = _main_gen_init_g7();
    x.EcuT = _main_gen_init_g3();
    x.NtcNr = _main_gen_init_g7();
    x.NtcStInfo = _main_gen_init_g6();
    x.SysSt = _main_gen_init_g6();
    x.VehSpd = _main_gen_init_g7();
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_DiagcMgrIninCore_Oper(void)
{
    extern __PST__VOID DiagcMgrIninCore_Oper(__PST__UINT8, __PST__UINT8, __PST__g__17, __PST__g__19, __PST__g__19);

    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__g__17 __arg__2;
    __PST__g__19 __arg__3;
    __PST__g__19 __arg__4;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    /* pointer */
    {
        static struct __PST__g__18 _main_gen_tmp_0[ARRAY_NBELEM(struct __PST__g__18)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct __PST__g__18); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g18();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct __PST__g__18) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g20();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g20();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    
    /* call it */
    DiagcMgrIninCore_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4);
}

static void _main_gen_call_GetNtcActvCore_Oper(void)
{
    extern __PST__VOID GetNtcActvCore_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    GetNtcActvCore_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcQlfrStsCore_Oper(void)
{
    extern __PST__VOID GetNtcQlfrStsCore_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    GetNtcQlfrStsCore_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcStsCore_Oper(void)
{
    extern __PST__VOID GetNtcStsCore_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    GetNtcStsCore_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_ReadNtcFltAry_Oper(void)
{
    extern __PST__VOID ReadNtcFltAry_Oper(__PST__g__25);

    __PST__g__25 __arg__0;
    
    /* pointer */
    {
        static struct __PST__g__26 _main_gen_tmp_12[ARRAY_NBELEM(struct __PST__g__26)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(struct __PST__g__26); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g26();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(struct __PST__g__26) / 2];
    }
    
    /* call it */
    ReadNtcFltAry_Oper(__arg__0);
}

static void _main_gen_call_ReadNtcInfoAndDebCntr_Oper(void)
{
    extern __PST__VOID ReadNtcInfoAndDebCntr_Oper(__PST__UINT16, __PST__g__17, __PST__g__29);

    __PST__UINT16 __arg__0;
    __PST__g__17 __arg__1;
    __PST__g__29 __arg__2;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static struct __PST__g__18 _main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__18)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(struct __PST__g__18); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g18();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__18) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_16[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g3();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    
    /* call it */
    ReadNtcInfoAndDebCntr_Oper(__arg__0, __arg__1, __arg__2);
}

static void _main_gen_call_ReadSnpshtData_Oper(void)
{
    extern __PST__VOID ReadSnpshtData_Oper(__PST__g__31);

    __PST__g__31 __arg__0;
    
    /* pointer */
    {
        static struct __PST__g__32 _main_gen_tmp_18[ARRAY_NBELEM(struct __PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(struct __PST__g__32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g32();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(struct __PST__g__32) / 2];
    }
    
    /* call it */
    ReadSnpshtData_Oper(__arg__0);
}

static void _main_gen_call_SetNtcStsCore_Oper(void)
{
    extern __PST__UINT8 SetNtcStsCore_Oper(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16, __PST__g__19, __PST__g__19, __PST__g__17, __PST__g__29);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__19 __arg__4;
    __PST__g__19 __arg__5;
    __PST__g__17 __arg__6;
    __PST__g__29 __arg__7;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_20[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g20();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_22[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g20();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__18 _main_gen_tmp_24[ARRAY_NBELEM(struct __PST__g__18)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(struct __PST__g__18); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g18();
        }
        __arg__6 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(struct __PST__g__18) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_26[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g3();
        }
        __arg__7 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    
    /* call it */
    __ret__ = SetNtcStsCore_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6, __arg__7);
}

static void _main_gen_call_UpdDtcEnaCdn(void)
{
    extern __PST__VOID UpdDtcEnaCdn(__PST__UINT8, __PST__UINT8);

    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    
    /* call it */
    UpdDtcEnaCdn(__arg__0, __arg__1);
}

static void _main_gen_call_GetDiagcDataAppl10_Oper(void)
{
    extern __PST__VOID GetDiagcDataAppl10_Oper(__PST__g__19);

    __PST__g__19 __arg__0;
    
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_28[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g20();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    
    /* call it */
    GetDiagcDataAppl10_Oper(__arg__0);
}

static void _main_gen_call_GetNtcActv10_Oper(void)
{
    extern __PST__UINT8 GetNtcActv10_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = GetNtcActv10_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcDebCntrAppl10_Oper(void)
{
    extern __PST__VOID GetNtcDebCntrAppl10_Oper(__PST__UINT8, __PST__g__29);

    __PST__UINT8 __arg__0;
    __PST__g__29 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_32[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    
    /* call it */
    GetNtcDebCntrAppl10_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcQlfrSts10_Oper(void)
{
    extern __PST__UINT8 GetNtcQlfrSts10_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = GetNtcQlfrSts10_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcSts10_Oper(void)
{
    extern __PST__UINT8 GetNtcSts10_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = GetNtcSts10_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_SetNtcSts10_Oper(void)
{
    extern __PST__UINT8 SetNtcSts10_Oper(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    __PST__UINT16 __arg__3;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = SetNtcSts10_Oper(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_GetDiagcDataAppl6_Oper(void)
{
    extern __PST__VOID GetDiagcDataAppl6_Oper(__PST__g__19);

    __PST__g__19 __arg__0;
    
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_38[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g20();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    
    /* call it */
    GetDiagcDataAppl6_Oper(__arg__0);
}

static void _main_gen_call_GetNtcActv6_Oper(void)
{
    extern __PST__UINT8 GetNtcActv6_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_41;
        for (_i_main_gen_tmp_41 = 0; _i_main_gen_tmp_41 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_41++)
        {
            _main_gen_tmp_40[_i_main_gen_tmp_41] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = GetNtcActv6_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcDebCntrAppl6_Oper(void)
{
    extern __PST__VOID GetNtcDebCntrAppl6_Oper(__PST__UINT8, __PST__g__29);

    __PST__UINT8 __arg__0;
    __PST__g__29 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_42[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_43;
        for (_i_main_gen_tmp_43 = 0; _i_main_gen_tmp_43 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_43++)
        {
            _main_gen_tmp_42[_i_main_gen_tmp_43] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_42[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    
    /* call it */
    GetNtcDebCntrAppl6_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcQlfrSts6_Oper(void)
{
    extern __PST__UINT8 GetNtcQlfrSts6_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_45;
        for (_i_main_gen_tmp_45 = 0; _i_main_gen_tmp_45 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_45++)
        {
            _main_gen_tmp_44[_i_main_gen_tmp_45] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = GetNtcQlfrSts6_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcSts6_Oper(void)
{
    extern __PST__UINT8 GetNtcSts6_Oper(__PST__UINT16, __PST__g__23);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__23 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_46[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_47;
        for (_i_main_gen_tmp_47 = 0; _i_main_gen_tmp_47 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_47++)
        {
            _main_gen_tmp_46[_i_main_gen_tmp_47] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_46[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    __ret__ = GetNtcSts6_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_SetNtcSts6_Oper(void)
{
    extern __PST__UINT8 SetNtcSts6_Oper(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);

    __PST__UINT8 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    __PST__UINT16 __arg__3;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = SetNtcSts6_Oper(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_GetDiagcDataStub_Oper(void)
{
    extern __PST__VOID GetDiagcDataStub_Oper(__PST__g__19);

    __PST__g__19 __arg__0;
    
    /* pointer */
    {
        static struct __PST__g__20 _main_gen_tmp_48[ARRAY_NBELEM(struct __PST__g__20)];
        __PST__UINT32 _i_main_gen_tmp_49;
        for (_i_main_gen_tmp_49 = 0; _i_main_gen_tmp_49 < ARRAY_NBELEM(struct __PST__g__20); _i_main_gen_tmp_49++)
        {
            _main_gen_tmp_48[_i_main_gen_tmp_49] = _main_gen_init_g20();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_48[ARRAY_NBELEM(struct __PST__g__20) / 2];
    }
    
    /* call it */
    GetDiagcDataStub_Oper(__arg__0);
}

static void _main_gen_call_GetNtcDebCntrStub_Oper(void)
{
    extern __PST__VOID GetNtcDebCntrStub_Oper(__PST__UINT8, __PST__g__29);

    __PST__UINT8 __arg__0;
    __PST__g__29 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_50[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_51;
        for (_i_main_gen_tmp_51 = 0; _i_main_gen_tmp_51 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_51++)
        {
            _main_gen_tmp_50[_i_main_gen_tmp_51] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_50[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    
    /* call it */
    GetNtcDebCntrStub_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_GetNtcInfoStub_Oper(void)
{
    extern __PST__VOID GetNtcInfoStub_Oper(__PST__UINT8, __PST__g__17);

    __PST__UINT8 __arg__0;
    __PST__g__17 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static struct __PST__g__18 _main_gen_tmp_52[ARRAY_NBELEM(struct __PST__g__18)];
        __PST__UINT32 _i_main_gen_tmp_53;
        for (_i_main_gen_tmp_53 = 0; _i_main_gen_tmp_53 < ARRAY_NBELEM(struct __PST__g__18); _i_main_gen_tmp_53++)
        {
            _main_gen_tmp_52[_i_main_gen_tmp_53] = _main_gen_init_g18();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_52[ARRAY_NBELEM(struct __PST__g__18) / 2];
    }
    
    /* call it */
    GetNtcInfoStub_Oper(__arg__0, __arg__1);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function ClrAllDiagc_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID ClrAllDiagc_Oper(__PST__VOID);

            ClrAllDiagc_Oper();
        }
        
        /* call of function ClrSnpshtData_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID ClrSnpshtData_Oper(__PST__VOID);

            ClrSnpshtData_Oper();
        }
        
        /* call of function DiagcMgrIninCore_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_DiagcMgrIninCore_Oper();
        }
        
        /* call of function DiagcMgrPer1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID DiagcMgrPer1(__PST__VOID);

            DiagcMgrPer1();
        }
        
        /* call of function DiagcMgrPer2 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID DiagcMgrPer2(__PST__VOID);

            DiagcMgrPer2();
        }
        
        /* call of function GetNtcActvCore_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcActvCore_Oper();
        }
        
        /* call of function GetNtcQlfrStsCore_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcQlfrStsCore_Oper();
        }
        
        /* call of function GetNtcStsCore_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcStsCore_Oper();
        }
        
        /* call of function ReadNtcFltAry_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_ReadNtcFltAry_Oper();
        }
        
        /* call of function ReadNtcInfoAndDebCntr_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_ReadNtcInfoAndDebCntr_Oper();
        }
        
        /* call of function ReadSnpshtData_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_ReadSnpshtData_Oper();
        }
        
        /* call of function SetNtcStsCore_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetNtcStsCore_Oper();
        }
        
        /* call of function DiagcMgrPwrDwn */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID DiagcMgrPwrDwn(__PST__VOID);

            DiagcMgrPwrDwn();
        }
        
        /* call of function RestoreNtcFltAryDft */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID RestoreNtcFltAryDft(__PST__VOID);

            RestoreNtcFltAryDft();
        }
        
        /* call of function RestoreSnpshtAryDft */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID RestoreSnpshtAryDft(__PST__VOID);

            RestoreSnpshtAryDft();
        }
        
        /* call of function UpdDtcEnaCdn */
        if (PST_TRUE())
        {
            _main_gen_call_UpdDtcEnaCdn();
        }
        
        /* call of function DiagcMgrProxyAppl10Init1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID DiagcMgrProxyAppl10Init1(__PST__VOID);

            DiagcMgrProxyAppl10Init1();
        }
        
        /* call of function DiagcMgrProxyAppl10Per1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID DiagcMgrProxyAppl10Per1(__PST__VOID);

            DiagcMgrProxyAppl10Per1();
        }
        
        /* call of function GetDiagcDataAppl10_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetDiagcDataAppl10_Oper();
        }
        
        /* call of function GetNtcActv10_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcActv10_Oper();
        }
        
        /* call of function GetNtcDebCntrAppl10_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcDebCntrAppl10_Oper();
        }
        
        /* call of function GetNtcQlfrSts10_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcQlfrSts10_Oper();
        }
        
        /* call of function GetNtcSts10_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcSts10_Oper();
        }
        
        /* call of function SetNtcSts10_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetNtcSts10_Oper();
        }
        
        /* call of function DiagcMgrProxyAppl6Init1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID DiagcMgrProxyAppl6Init1(__PST__VOID);

            DiagcMgrProxyAppl6Init1();
        }
        
        /* call of function DiagcMgrProxyAppl6Per1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID DiagcMgrProxyAppl6Per1(__PST__VOID);

            DiagcMgrProxyAppl6Per1();
        }
        
        /* call of function GetDiagcDataAppl6_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetDiagcDataAppl6_Oper();
        }
        
        /* call of function GetNtcActv6_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcActv6_Oper();
        }
        
        /* call of function GetNtcDebCntrAppl6_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcDebCntrAppl6_Oper();
        }
        
        /* call of function GetNtcQlfrSts6_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcQlfrSts6_Oper();
        }
        
        /* call of function GetNtcSts6_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcSts6_Oper();
        }
        
        /* call of function SetNtcSts6_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetNtcSts6_Oper();
        }
        
        /* call of function DiagcMgrStubInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID DiagcMgrStubInit1(__PST__VOID);

            DiagcMgrStubInit1();
        }
        
        /* call of function GetDiagcDataStub_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetDiagcDataStub_Oper();
        }
        
        /* call of function GetNtcDebCntrStub_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcDebCntrStub_Oper();
        }
        
        /* call of function GetNtcInfoStub_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetNtcInfoStub_Oper();
        }
        
    }
}
