#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_CDD_CurrMeas_BrdgVltg_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_BrdgVltg_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_DiagcStsIvtr1Inactv_Logl
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_DiagcStsIvtr1Inactv_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_DiagcStsIvtr2Inactv_Logl
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_DiagcStsIvtr2Inactv_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_MotCurrAdcVlyA_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyA_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_MotCurrAdcVlyB_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyB_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_MotCurrAdcVlyC_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyC_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_MotCurrAdcVlyD_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyD_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_MotCurrAdcVlyE_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyE_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_MotCurrAdcVlyF_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyF_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_MotVelMrf_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_MotVelMrf_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_Ntc5DErrCnt_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_Ntc5DErrCnt_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_Ntc6DErrCnt_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_Ntc6DErrCnt_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_7;
        }
        P_0[0] = pst_random_g_7;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_StrtUpSt_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_StrtUpSt_Val(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_SysSt_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_SysSt_Val(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_VehSpd_Val
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_VehSpd_Val(__PST__g__19 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_CDD_CurrMeas_VehSpdVld_Logl
 */


__PST__UINT8 Rte_Read_CDD_CurrMeas_VehSpdVld_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_CurrMeas_CurrMeasWrmIninTestCmpl_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_CurrMeas_CurrMeasWrmIninTestCmpl_Logl"


__PST__UINT8 Rte_Write_CDD_CurrMeas_CurrMeasWrmIninTestCmpl_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_CurrMeas_MotCurrEolCalSt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_CurrMeas_MotCurrEolCalSt_Val"


__PST__UINT8 Rte_Write_CDD_CurrMeas_MotCurrEolCalSt_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_CurrMeas_MotCurrQlfr1_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_CurrMeas_MotCurrQlfr1_Val"


__PST__UINT8 Rte_Write_CDD_CurrMeas_MotCurrQlfr1_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_CDD_CurrMeas_MotCurrQlfr2_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_CDD_CurrMeas_MotCurrQlfr2_Val"


__PST__UINT8 Rte_Write_CDD_CurrMeas_MotCurrQlfr2_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_CDD_CurrMeas_CurrMeasEolGainCalSet_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_CDD_CurrMeas_CurrMeasEolGainCalSet_SetRamBlockStatus"


__PST__UINT8 Rte_Call_CDD_CurrMeas_CurrMeasEolGainCalSet_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_CDD_CurrMeas_CurrMeasEolOffsCalSet_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_CDD_CurrMeas_CurrMeasEolOffsCalSet_SetRamBlockStatus"


__PST__UINT8 Rte_Call_CDD_CurrMeas_CurrMeasEolOffsCalSet_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_CDD_CurrMeas_GetNtcQlfrSts_Oper
 */


__PST__UINT8 Rte_Call_CDD_CurrMeas_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__17 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_CDD_CurrMeas_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_CDD_CurrMeas_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_CDD_CurrMeas_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMax_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMin_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMin_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMin_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNumer_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNumer_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNumer_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolMaxMotVel_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolMaxMotVel_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolMaxMotVel_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiBrdgVltgMin_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiBrdgVltgMin_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiBrdgVltgMin_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMax_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMin_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMin_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMin_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMax_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMin_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMin_Val"


__PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMin_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiCmuOffs_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiCmuOffs_Val"


__PST__UINT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiCmuOffs_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsLoCmuOffs_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsLoCmuOffs_Val"


__PST__UINT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsLoCmuOffs_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasMinRqrdPhaOnTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasMinRqrdPhaOnTi_Val"


__PST__UINT32 Rte_Prm_CDD_CurrMeas_CurrMeasMinRqrdPhaOnTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasMotAgCompuDly_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasMotAgCompuDly_Val"


__PST__UINT32 Rte_Prm_CDD_CurrMeas_CurrMeasMotAgCompuDly_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNrOfSample_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNrOfSample_Val"


__PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNrOfSample_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsNrOfSample_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsNrOfSample_Val"


__PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsNrOfSample_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DFailStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DFailStep_Val"


__PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DFailStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DPassStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DPassStep_Val"


__PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DPassStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DFailStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DFailStep_Val"


__PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DFailStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DPassStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DPassStep_Val"


__PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DPassStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_CurrMeasEolTranCntrThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_CurrMeasEolTranCntrThd_Val"


__PST__UINT8 Rte_Prm_CDD_CurrMeas_CurrMeasEolTranCntrThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_CDD_CurrMeas_SysGlbPrmMotPoleCnt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_CDD_CurrMeas_SysGlbPrmMotPoleCnt_Val"


__PST__UINT8 Rte_Prm_CDD_CurrMeas_SysGlbPrmMotPoleCnt_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * FltInj_f32_Oper
 */


__PST__UINT8 FltInj_f32_Oper(__PST__g__19 P_0, __PST__UINT16 P_1)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* parameter 1 is constant */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * FltInj_u08_Oper
 */


__PST__UINT8 FltInj_u08_Oper(__PST__g__17 P_0, __PST__UINT16 P_1)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* parameter 1 is constant */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

