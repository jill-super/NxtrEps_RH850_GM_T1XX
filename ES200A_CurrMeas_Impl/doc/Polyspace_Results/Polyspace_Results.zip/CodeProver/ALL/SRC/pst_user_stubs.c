/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_CDD_CurrMeas_BrdgVltg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_BrdgVltg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_BrdgVltg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_BrdgVltg_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_BrdgVltg_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_DiagcStsIvtr1Inactv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_DiagcStsIvtr1Inactv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_DiagcStsIvtr1Inactv_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_DiagcStsIvtr1Inactv_Logl"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_DiagcStsIvtr1Inactv_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_DiagcStsIvtr2Inactv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_DiagcStsIvtr2Inactv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_DiagcStsIvtr2Inactv_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_DiagcStsIvtr2Inactv_Logl"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_DiagcStsIvtr2Inactv_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_MotCurrAdcVlyA_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyA_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyA_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyA_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyA_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_MotCurrAdcVlyB_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyB_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyB_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyB_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyB_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_MotCurrAdcVlyC_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyC_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyC_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyC_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyC_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_MotCurrAdcVlyD_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyD_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyD_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyD_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyD_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_MotCurrAdcVlyE_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyE_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyE_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyE_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyE_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_MotCurrAdcVlyF_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyF_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyF_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_MotCurrAdcVlyF_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_MotCurrAdcVlyF_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_MotVelMrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_MotVelMrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_MotVelMrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_MotVelMrf_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_MotVelMrf_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_Ntc5DErrCnt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_Ntc5DErrCnt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_Ntc5DErrCnt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_Ntc5DErrCnt_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_Ntc5DErrCnt_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_Ntc6DErrCnt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_Ntc6DErrCnt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_Ntc6DErrCnt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_Ntc6DErrCnt_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_Ntc6DErrCnt_Val(__PST__g__37 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_StrtUpSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_StrtUpSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_StrtUpSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_StrtUpSt_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_StrtUpSt_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_SysSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_SysSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_SysSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_SysSt_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_SysSt_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_VehSpd_Val(__PST__g__19 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_CDD_CurrMeas_VehSpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_CurrMeas_VehSpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_CurrMeas_VehSpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_CurrMeas_VehSpdVld_Logl"
//
// __PST__UINT8 Rte_Read_CDD_CurrMeas_VehSpdVld_Logl(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_CurrMeas_CurrMeasWrmIninTestCmpl_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_CurrMeas_CurrMeasWrmIninTestCmpl_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_CurrMeas_CurrMeasWrmIninTestCmpl_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_CurrMeas_CurrMeasWrmIninTestCmpl_Logl"
//
// __PST__UINT8 Rte_Write_CDD_CurrMeas_CurrMeasWrmIninTestCmpl_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_CurrMeas_MotCurrEolCalSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_CurrMeas_MotCurrEolCalSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_CurrMeas_MotCurrEolCalSt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_CurrMeas_MotCurrEolCalSt_Val"
//
// __PST__UINT8 Rte_Write_CDD_CurrMeas_MotCurrEolCalSt_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_CurrMeas_MotCurrQlfr1_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_CurrMeas_MotCurrQlfr1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_CurrMeas_MotCurrQlfr1_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_CurrMeas_MotCurrQlfr1_Val"
//
// __PST__UINT8 Rte_Write_CDD_CurrMeas_MotCurrQlfr1_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_CurrMeas_MotCurrQlfr2_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_CurrMeas_MotCurrQlfr2_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_CurrMeas_MotCurrQlfr2_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_CurrMeas_MotCurrQlfr2_Val"
//
// __PST__UINT8 Rte_Write_CDD_CurrMeas_MotCurrQlfr2_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_CurrMeas_CurrMeasEolGainCalSet_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_CurrMeas_CurrMeasEolGainCalSet_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_CurrMeas_CurrMeasEolGainCalSet_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_CurrMeas_CurrMeasEolGainCalSet_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_CDD_CurrMeas_CurrMeasEolGainCalSet_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_CurrMeas_CurrMeasEolOffsCalSet_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_CurrMeas_CurrMeasEolOffsCalSet_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_CurrMeas_CurrMeasEolOffsCalSet_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_CurrMeas_CurrMeasEolOffsCalSet_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_CDD_CurrMeas_CurrMeasEolOffsCalSet_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_CurrMeas_GetNtcQlfrSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_CurrMeas_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_CurrMeas_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_CurrMeas_GetNtcQlfrSts_Oper"
//
// __PST__UINT8 Rte_Call_CDD_CurrMeas_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__17 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_CurrMeas_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_CurrMeas_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_CurrMeas_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_CurrMeas_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_CDD_CurrMeas_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMax_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMax_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMax_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMax_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMin_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMin_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMin_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMin_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolGainMin_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNumer_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNumer_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNumer_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNumer_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNumer_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolMaxMotVel_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolMaxMotVel_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolMaxMotVel_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolMaxMotVel_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolMaxMotVel_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiBrdgVltgMin_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiBrdgVltgMin_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiBrdgVltgMin_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiBrdgVltgMin_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiBrdgVltgMin_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMax_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMax_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMax_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMax_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMin_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMin_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMin_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMin_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsMin_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMax_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMax_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMax_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMax_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMax_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMin_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMin_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMin_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMin_Val"
//
// __PST__FLOAT32 Rte_Prm_CDD_CurrMeas_CurrMeasMotCurrAdcVlyWrmIninMin_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiCmuOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiCmuOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiCmuOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiCmuOffs_Val"
//
// __PST__UINT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsHiCmuOffs_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsLoCmuOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsLoCmuOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsLoCmuOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsLoCmuOffs_Val"
//
// __PST__UINT32 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsLoCmuOffs_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasMinRqrdPhaOnTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasMinRqrdPhaOnTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasMinRqrdPhaOnTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasMinRqrdPhaOnTi_Val"
//
// __PST__UINT32 Rte_Prm_CDD_CurrMeas_CurrMeasMinRqrdPhaOnTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasMotAgCompuDly_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasMotAgCompuDly_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasMotAgCompuDly_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasMotAgCompuDly_Val"
//
// __PST__UINT32 Rte_Prm_CDD_CurrMeas_CurrMeasMotAgCompuDly_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNrOfSample_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNrOfSample_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNrOfSample_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNrOfSample_Val"
//
// __PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasEolGainNrOfSample_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsNrOfSample_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsNrOfSample_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsNrOfSample_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsNrOfSample_Val"
//
// __PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasEolOffsNrOfSample_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DFailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DFailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DFailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DFailStep_Val"
//
// __PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DFailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DPassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DPassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DPassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DPassStep_Val"
//
// __PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x05DPassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DFailStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DFailStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DFailStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DFailStep_Val"
//
// __PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DFailStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DPassStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DPassStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DPassStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DPassStep_Val"
//
// __PST__UINT16 Rte_Prm_CDD_CurrMeas_CurrMeasNtc0x06DPassStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_CurrMeasEolTranCntrThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_CurrMeasEolTranCntrThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_CurrMeasEolTranCntrThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_CurrMeasEolTranCntrThd_Val"
//
// __PST__UINT8 Rte_Prm_CDD_CurrMeas_CurrMeasEolTranCntrThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_CDD_CurrMeas_SysGlbPrmMotPoleCnt_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_CDD_CurrMeas_SysGlbPrmMotPoleCnt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_CDD_CurrMeas_SysGlbPrmMotPoleCnt_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_CDD_CurrMeas_SysGlbPrmMotPoleCnt_Val"
//
// __PST__UINT8 Rte_Prm_CDD_CurrMeas_SysGlbPrmMotPoleCnt_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function FltInj_f32_Oper
//
// #pragma POLYSPACE_PURE "FltInj_f32_Oper"
// #pragma POLYSPACE_CLEAN "FltInj_f32_Oper"
// #pragma POLYSPACE_WORST "FltInj_f32_Oper"
//
// __PST__UINT8 FltInj_f32_Oper(__PST__g__19 P_0, __PST__UINT16 P_1)
// {
//    ...
// }


// Pragmas for function FltInj_u08_Oper
//
// #pragma POLYSPACE_PURE "FltInj_u08_Oper"
// #pragma POLYSPACE_CLEAN "FltInj_u08_Oper"
// #pragma POLYSPACE_WORST "FltInj_u08_Oper"
//
// __PST__UINT8 FltInj_u08_Oper(__PST__g__17 P_0, __PST__UINT16 P_1)
// {
//    ...
// }

