#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__36 _main_gen_init_g36(void);

extern struct __PST__g__34 _main_gen_init_g34(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct Rte_CDS_CDD_CurrMeas _main_gen_init_g32(void);

struct __PST__g__34 _main_gen_init_g34(void)
{
    static struct __PST__g__34 x;
    /* struct/union type */
    x.CurrMeasMotCurrEolGainA = _main_gen_init_g10();
    x.CurrMeasMotCurrEolGainB = _main_gen_init_g10();
    x.CurrMeasMotCurrEolGainC = _main_gen_init_g10();
    x.CurrMeasMotCurrEolGainD = _main_gen_init_g10();
    x.CurrMeasMotCurrEolGainE = _main_gen_init_g10();
    x.CurrMeasMotCurrEolGainF = _main_gen_init_g10();
    return x;
}

struct __PST__g__36 _main_gen_init_g36(void)
{
    static struct __PST__g__36 x;
    /* struct/union type */
    x.CurrMeasEolOffsHiBrdgVltg = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifA = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifB = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifC = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifD = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifE = _main_gen_init_g10();
    x.CurrMeasMotCurrEolOffsDifF = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgA = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgB = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgC = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgD = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgE = _main_gen_init_g10();
    x.CurrMeasMotCurrOffsLoAvrgF = _main_gen_init_g10();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct Rte_CDS_CDD_CurrMeas _main_gen_init_g32(void)
{
    static struct Rte_CDS_CDD_CurrMeas x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_48[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_49;
        for (_i_main_gen_tmp_49 = 0; _i_main_gen_tmp_49 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_49++)
        {
            _main_gen_tmp_48[_i_main_gen_tmp_49] = _main_gen_init_g10();
        }
        x.Pim_BrdgVltgSumPrev = PST_TRUE() ? 0 : &_main_gen_tmp_48[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__34 _main_gen_tmp_50[ARRAY_NBELEM(struct __PST__g__34)];
        __PST__UINT32 _i_main_gen_tmp_51;
        for (_i_main_gen_tmp_51 = 0; _i_main_gen_tmp_51 < ARRAY_NBELEM(struct __PST__g__34); _i_main_gen_tmp_51++)
        {
            _main_gen_tmp_50[_i_main_gen_tmp_51] = _main_gen_init_g34();
        }
        x.Pim_CurrMeasEolGainCalSet = PST_TRUE() ? 0 : &_main_gen_tmp_50[ARRAY_NBELEM(struct __PST__g__34) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__36 _main_gen_tmp_52[ARRAY_NBELEM(struct __PST__g__36)];
        __PST__UINT32 _i_main_gen_tmp_53;
        for (_i_main_gen_tmp_53 = 0; _i_main_gen_tmp_53 < ARRAY_NBELEM(struct __PST__g__36); _i_main_gen_tmp_53++)
        {
            _main_gen_tmp_52[_i_main_gen_tmp_53] = _main_gen_init_g36();
        }
        x.Pim_CurrMeasEolOffsCalSet = PST_TRUE() ? 0 : &_main_gen_tmp_52[ARRAY_NBELEM(struct __PST__g__36) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_54[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_55;
        for (_i_main_gen_tmp_55 = 0; _i_main_gen_tmp_55 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_55++)
        {
            _main_gen_tmp_54[_i_main_gen_tmp_55] = _main_gen_init_g6();
        }
        x.Pim_EolGainSts = PST_TRUE() ? 0 : &_main_gen_tmp_54[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_56[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_57;
        for (_i_main_gen_tmp_57 = 0; _i_main_gen_tmp_57 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_57++)
        {
            _main_gen_tmp_56[_i_main_gen_tmp_57] = _main_gen_init_g10();
        }
        x.Pim_EolOffsHiBrdgVltg = PST_TRUE() ? 0 : &_main_gen_tmp_56[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_59;
        for (_i_main_gen_tmp_59 = 0; _i_main_gen_tmp_59 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_59++)
        {
            _main_gen_tmp_58[_i_main_gen_tmp_59] = _main_gen_init_g6();
        }
        x.Pim_EolOffsSts = PST_TRUE() ? 0 : &_main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_61;
        for (_i_main_gen_tmp_61 = 0; _i_main_gen_tmp_61 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_61++)
        {
            _main_gen_tmp_60[_i_main_gen_tmp_61] = _main_gen_init_g6();
        }
        x.Pim_EolTranCntrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_62[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_63;
        for (_i_main_gen_tmp_63 = 0; _i_main_gen_tmp_63 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_63++)
        {
            _main_gen_tmp_62[_i_main_gen_tmp_63] = _main_gen_init_g7();
        }
        x.Pim_GainEolAvrgCntrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_62[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_64[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_65;
        for (_i_main_gen_tmp_65 = 0; _i_main_gen_tmp_65 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_65++)
        {
            _main_gen_tmp_64[_i_main_gen_tmp_65] = _main_gen_init_g7();
        }
        x.Pim_MotCtrlNtc5DErrCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_64[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_67;
        for (_i_main_gen_tmp_67 = 0; _i_main_gen_tmp_67 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_67++)
        {
            _main_gen_tmp_66[_i_main_gen_tmp_67] = _main_gen_init_g7();
        }
        x.Pim_MotCtrlNtc6DErrCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_68[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_69;
        for (_i_main_gen_tmp_69 = 0; _i_main_gen_tmp_69 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_69++)
        {
            _main_gen_tmp_68[_i_main_gen_tmp_69] = _main_gen_init_g6();
        }
        x.Pim_MotCurrEolCalStPrev = PST_TRUE() ? 0 : &_main_gen_tmp_68[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_70[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_71;
        for (_i_main_gen_tmp_71 = 0; _i_main_gen_tmp_71 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_71++)
        {
            _main_gen_tmp_70[_i_main_gen_tmp_71] = _main_gen_init_g10();
        }
        x.Pim_MotCurrEolGainA = PST_TRUE() ? 0 : &_main_gen_tmp_70[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_72[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_73;
        for (_i_main_gen_tmp_73 = 0; _i_main_gen_tmp_73 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_73++)
        {
            _main_gen_tmp_72[_i_main_gen_tmp_73] = _main_gen_init_g10();
        }
        x.Pim_MotCurrEolGainB = PST_TRUE() ? 0 : &_main_gen_tmp_72[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_74[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_75;
        for (_i_main_gen_tmp_75 = 0; _i_main_gen_tmp_75 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_75++)
        {
            _main_gen_tmp_74[_i_main_gen_tmp_75] = _main_gen_init_g10();
        }
        x.Pim_MotCurrEolGainC = PST_TRUE() ? 0 : &_main_gen_tmp_74[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_76[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_77;
        for (_i_main_gen_tmp_77 = 0; _i_main_gen_tmp_77 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_77++)
        {
            _main_gen_tmp_76[_i_main_gen_tmp_77] = _main_gen_init_g10();
        }
        x.Pim_MotCurrEolGainD = PST_TRUE() ? 0 : &_main_gen_tmp_76[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_78[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_79;
        for (_i_main_gen_tmp_79 = 0; _i_main_gen_tmp_79 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_79++)
        {
            _main_gen_tmp_78[_i_main_gen_tmp_79] = _main_gen_init_g10();
        }
        x.Pim_MotCurrEolGainE = PST_TRUE() ? 0 : &_main_gen_tmp_78[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_80[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_81;
        for (_i_main_gen_tmp_81 = 0; _i_main_gen_tmp_81 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_81++)
        {
            _main_gen_tmp_80[_i_main_gen_tmp_81] = _main_gen_init_g10();
        }
        x.Pim_MotCurrEolGainF = PST_TRUE() ? 0 : &_main_gen_tmp_80[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_82[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_83;
        for (_i_main_gen_tmp_83 = 0; _i_main_gen_tmp_83 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_83++)
        {
            _main_gen_tmp_82[_i_main_gen_tmp_83] = _main_gen_init_g6();
        }
        x.Pim_MotCurrEolOffsProcFlg = PST_TRUE() ? 0 : &_main_gen_tmp_82[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_84[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_85;
        for (_i_main_gen_tmp_85 = 0; _i_main_gen_tmp_85 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_85++)
        {
            _main_gen_tmp_84[_i_main_gen_tmp_85] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsDeltaA = PST_TRUE() ? 0 : &_main_gen_tmp_84[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_86[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_87;
        for (_i_main_gen_tmp_87 = 0; _i_main_gen_tmp_87 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_87++)
        {
            _main_gen_tmp_86[_i_main_gen_tmp_87] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsDeltaB = PST_TRUE() ? 0 : &_main_gen_tmp_86[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_88[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_89;
        for (_i_main_gen_tmp_89 = 0; _i_main_gen_tmp_89 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_89++)
        {
            _main_gen_tmp_88[_i_main_gen_tmp_89] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsDeltaC = PST_TRUE() ? 0 : &_main_gen_tmp_88[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_90[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_91;
        for (_i_main_gen_tmp_91 = 0; _i_main_gen_tmp_91 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_91++)
        {
            _main_gen_tmp_90[_i_main_gen_tmp_91] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsDeltaD = PST_TRUE() ? 0 : &_main_gen_tmp_90[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_92[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_93;
        for (_i_main_gen_tmp_93 = 0; _i_main_gen_tmp_93 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_93++)
        {
            _main_gen_tmp_92[_i_main_gen_tmp_93] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsDeltaE = PST_TRUE() ? 0 : &_main_gen_tmp_92[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_94[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_95;
        for (_i_main_gen_tmp_95 = 0; _i_main_gen_tmp_95 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_95++)
        {
            _main_gen_tmp_94[_i_main_gen_tmp_95] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsDeltaF = PST_TRUE() ? 0 : &_main_gen_tmp_94[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_96[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_97;
        for (_i_main_gen_tmp_97 = 0; _i_main_gen_tmp_97 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_97++)
        {
            _main_gen_tmp_96[_i_main_gen_tmp_97] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsHiAvrgA = PST_TRUE() ? 0 : &_main_gen_tmp_96[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_98[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_99;
        for (_i_main_gen_tmp_99 = 0; _i_main_gen_tmp_99 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_99++)
        {
            _main_gen_tmp_98[_i_main_gen_tmp_99] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsHiAvrgB = PST_TRUE() ? 0 : &_main_gen_tmp_98[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_100[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_101;
        for (_i_main_gen_tmp_101 = 0; _i_main_gen_tmp_101 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_101++)
        {
            _main_gen_tmp_100[_i_main_gen_tmp_101] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsHiAvrgC = PST_TRUE() ? 0 : &_main_gen_tmp_100[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_102[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_103;
        for (_i_main_gen_tmp_103 = 0; _i_main_gen_tmp_103 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_103++)
        {
            _main_gen_tmp_102[_i_main_gen_tmp_103] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsHiAvrgD = PST_TRUE() ? 0 : &_main_gen_tmp_102[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_104[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_105;
        for (_i_main_gen_tmp_105 = 0; _i_main_gen_tmp_105 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_105++)
        {
            _main_gen_tmp_104[_i_main_gen_tmp_105] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsHiAvrgE = PST_TRUE() ? 0 : &_main_gen_tmp_104[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_106[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_107;
        for (_i_main_gen_tmp_107 = 0; _i_main_gen_tmp_107 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_107++)
        {
            _main_gen_tmp_106[_i_main_gen_tmp_107] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsHiAvrgF = PST_TRUE() ? 0 : &_main_gen_tmp_106[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_108[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_109;
        for (_i_main_gen_tmp_109 = 0; _i_main_gen_tmp_109 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_109++)
        {
            _main_gen_tmp_108[_i_main_gen_tmp_109] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsLoAvrgA = PST_TRUE() ? 0 : &_main_gen_tmp_108[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_110[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_111;
        for (_i_main_gen_tmp_111 = 0; _i_main_gen_tmp_111 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_111++)
        {
            _main_gen_tmp_110[_i_main_gen_tmp_111] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsLoAvrgB = PST_TRUE() ? 0 : &_main_gen_tmp_110[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_112[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_113;
        for (_i_main_gen_tmp_113 = 0; _i_main_gen_tmp_113 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_113++)
        {
            _main_gen_tmp_112[_i_main_gen_tmp_113] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsLoAvrgC = PST_TRUE() ? 0 : &_main_gen_tmp_112[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_114[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_115;
        for (_i_main_gen_tmp_115 = 0; _i_main_gen_tmp_115 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_115++)
        {
            _main_gen_tmp_114[_i_main_gen_tmp_115] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsLoAvrgD = PST_TRUE() ? 0 : &_main_gen_tmp_114[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_116[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_117;
        for (_i_main_gen_tmp_117 = 0; _i_main_gen_tmp_117 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_117++)
        {
            _main_gen_tmp_116[_i_main_gen_tmp_117] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsLoAvrgE = PST_TRUE() ? 0 : &_main_gen_tmp_116[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_118[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_119;
        for (_i_main_gen_tmp_119 = 0; _i_main_gen_tmp_119 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_119++)
        {
            _main_gen_tmp_118[_i_main_gen_tmp_119] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsLoAvrgF = PST_TRUE() ? 0 : &_main_gen_tmp_118[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_120[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_121;
        for (_i_main_gen_tmp_121 = 0; _i_main_gen_tmp_121 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_121++)
        {
            _main_gen_tmp_120[_i_main_gen_tmp_121] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsZeroAvrgA = PST_TRUE() ? 0 : &_main_gen_tmp_120[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_122[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_123;
        for (_i_main_gen_tmp_123 = 0; _i_main_gen_tmp_123 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_123++)
        {
            _main_gen_tmp_122[_i_main_gen_tmp_123] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsZeroAvrgB = PST_TRUE() ? 0 : &_main_gen_tmp_122[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_124[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_125;
        for (_i_main_gen_tmp_125 = 0; _i_main_gen_tmp_125 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_125++)
        {
            _main_gen_tmp_124[_i_main_gen_tmp_125] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsZeroAvrgC = PST_TRUE() ? 0 : &_main_gen_tmp_124[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_126[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_127;
        for (_i_main_gen_tmp_127 = 0; _i_main_gen_tmp_127 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_127++)
        {
            _main_gen_tmp_126[_i_main_gen_tmp_127] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsZeroAvrgD = PST_TRUE() ? 0 : &_main_gen_tmp_126[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_128[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_129;
        for (_i_main_gen_tmp_129 = 0; _i_main_gen_tmp_129 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_129++)
        {
            _main_gen_tmp_128[_i_main_gen_tmp_129] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsZeroAvrgE = PST_TRUE() ? 0 : &_main_gen_tmp_128[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_130[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_131;
        for (_i_main_gen_tmp_131 = 0; _i_main_gen_tmp_131 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_131++)
        {
            _main_gen_tmp_130[_i_main_gen_tmp_131] = _main_gen_init_g10();
        }
        x.Pim_MotCurrOffsZeroAvrgF = PST_TRUE() ? 0 : &_main_gen_tmp_130[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_132[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_133;
        for (_i_main_gen_tmp_133 = 0; _i_main_gen_tmp_133 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_133++)
        {
            _main_gen_tmp_132[_i_main_gen_tmp_133] = _main_gen_init_g6();
        }
        x.Pim_MotCurrRollgCnt1Prev = PST_TRUE() ? 0 : &_main_gen_tmp_132[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_134[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_135;
        for (_i_main_gen_tmp_135 = 0; _i_main_gen_tmp_135 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_135++)
        {
            _main_gen_tmp_134[_i_main_gen_tmp_135] = _main_gen_init_g6();
        }
        x.Pim_MotCurrRollgCnt2Prev = PST_TRUE() ? 0 : &_main_gen_tmp_134[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_136[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_137;
        for (_i_main_gen_tmp_137 = 0; _i_main_gen_tmp_137 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_137++)
        {
            _main_gen_tmp_136[_i_main_gen_tmp_137] = _main_gen_init_g10();
        }
        x.Pim_MotCurrSumAPrev = PST_TRUE() ? 0 : &_main_gen_tmp_136[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_138[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_139;
        for (_i_main_gen_tmp_139 = 0; _i_main_gen_tmp_139 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_139++)
        {
            _main_gen_tmp_138[_i_main_gen_tmp_139] = _main_gen_init_g10();
        }
        x.Pim_MotCurrSumBPrev = PST_TRUE() ? 0 : &_main_gen_tmp_138[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_140[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_141;
        for (_i_main_gen_tmp_141 = 0; _i_main_gen_tmp_141 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_141++)
        {
            _main_gen_tmp_140[_i_main_gen_tmp_141] = _main_gen_init_g10();
        }
        x.Pim_MotCurrSumCPrev = PST_TRUE() ? 0 : &_main_gen_tmp_140[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_142[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_143;
        for (_i_main_gen_tmp_143 = 0; _i_main_gen_tmp_143 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_143++)
        {
            _main_gen_tmp_142[_i_main_gen_tmp_143] = _main_gen_init_g10();
        }
        x.Pim_MotCurrSumDPrev = PST_TRUE() ? 0 : &_main_gen_tmp_142[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_144[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_145;
        for (_i_main_gen_tmp_145 = 0; _i_main_gen_tmp_145 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_145++)
        {
            _main_gen_tmp_144[_i_main_gen_tmp_145] = _main_gen_init_g10();
        }
        x.Pim_MotCurrSumEPrev = PST_TRUE() ? 0 : &_main_gen_tmp_144[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_146[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_147;
        for (_i_main_gen_tmp_147 = 0; _i_main_gen_tmp_147 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_147++)
        {
            _main_gen_tmp_146[_i_main_gen_tmp_147] = _main_gen_init_g10();
        }
        x.Pim_MotCurrSumFPrev = PST_TRUE() ? 0 : &_main_gen_tmp_146[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_148[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_149;
        for (_i_main_gen_tmp_149 = 0; _i_main_gen_tmp_149 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_149++)
        {
            _main_gen_tmp_148[_i_main_gen_tmp_149] = _main_gen_init_g7();
        }
        x.Pim_Ntc5DErrCnt2MilliSecPrev = PST_TRUE() ? 0 : &_main_gen_tmp_148[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_150[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_151;
        for (_i_main_gen_tmp_151 = 0; _i_main_gen_tmp_151 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_151++)
        {
            _main_gen_tmp_150[_i_main_gen_tmp_151] = _main_gen_init_g7();
        }
        x.Pim_Ntc6DErrCnt2MilliSecPrev = PST_TRUE() ? 0 : &_main_gen_tmp_150[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_152[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_153;
        for (_i_main_gen_tmp_153 = 0; _i_main_gen_tmp_153 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_153++)
        {
            _main_gen_tmp_152[_i_main_gen_tmp_153] = _main_gen_init_g7();
        }
        x.Pim_OffsEolAvrgCntrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_152[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_154[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_155;
        for (_i_main_gen_tmp_155 = 0; _i_main_gen_tmp_155 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_155++)
        {
            _main_gen_tmp_154[_i_main_gen_tmp_155] = _main_gen_init_g7();
        }
        x.Pim_PhaOnTiErrCntPrev = PST_TRUE() ? 0 : &_main_gen_tmp_154[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_156[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_157;
        for (_i_main_gen_tmp_157 = 0; _i_main_gen_tmp_157 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_157++)
        {
            _main_gen_tmp_156[_i_main_gen_tmp_157] = _main_gen_init_g10();
        }
        x.Pim_TempMotCurrAdcVlySum1Prev = PST_TRUE() ? 0 : &_main_gen_tmp_156[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_158[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_159;
        for (_i_main_gen_tmp_159 = 0; _i_main_gen_tmp_159 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_159++)
        {
            _main_gen_tmp_158[_i_main_gen_tmp_159] = _main_gen_init_g10();
        }
        x.Pim_TempMotCurrAdcVlySum2Prev = PST_TRUE() ? 0 : &_main_gen_tmp_158[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_160[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_161;
        for (_i_main_gen_tmp_161 = 0; _i_main_gen_tmp_161 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_161++)
        {
            _main_gen_tmp_160[_i_main_gen_tmp_161] = _main_gen_init_g6();
        }
        x.Pim_WrmIninTestCmplPrev = PST_TRUE() ? 0 : &_main_gen_tmp_160[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_CurrMeas(void)
{
    extern __PST__g__29 Rte_Inst_CDD_CurrMeas;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_CurrMeas _main_gen_tmp_46[ARRAY_NBELEM(struct Rte_CDS_CDD_CurrMeas)];
            __PST__UINT32 _i_main_gen_tmp_47;
            for (_i_main_gen_tmp_47 = 0; _i_main_gen_tmp_47 < ARRAY_NBELEM(struct Rte_CDS_CDD_CurrMeas); _i_main_gen_tmp_47++)
            {
                _main_gen_tmp_46[_i_main_gen_tmp_47] = _main_gen_init_g32();
            }
            Rte_Inst_CDD_CurrMeas = PST_TRUE() ? 0 : &_main_gen_tmp_46[ARRAY_NBELEM(struct Rte_CDS_CDD_CurrMeas) / 2];
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlBrdgVltg(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlBrdgVltg;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlBrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlDiagcStsIvtr2Inactv(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlDiagcStsIvtr2Inactv;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlDiagcStsIvtr2Inactv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElec(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlMotAgElec;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgElec = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyA(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyB(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyB = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyC(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyC = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyD(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyD;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyD = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyE(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyE;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyE = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyF(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrAdcVlyF;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyF = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotElecMeclPolarity(void)
{
    extern __PST__SINT8 MOTCTRLMGR_MotCtrlMotElecMeclPolarity;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotElecMeclPolarity = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVelMrf(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotVelMrf;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotVelMrf = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiA = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiB;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiB = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPhaOnTiC;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPhaOnTiC = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlPwmPerd;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlPwmPerd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlSysSt(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlSysSt;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlSysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyDAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyDAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyDAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyEAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyEAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyEAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyFAdcFaild(void)
{
    extern __PST__UINT8 MOTCTRLMGR_MotCtrlMotCurrAdcVlyFAdcFaild;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrAdcVlyFAdcFaild = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdA(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdA;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdA = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdD(void)
{
    extern __PST__FLOAT32 MOTCTRLMGR_MotCtrlMotCurrCorrdD;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotCurrCorrdD = _main_gen_init_g10();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_CurrMeas */
    _main_gen_init_sym_Rte_Inst_CDD_CurrMeas();
    
    /* init for variable MOTCTRLMGR_MotCtrlBrdgVltg */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlBrdgVltg();
    
    /* init for variable MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlDiagcStsIvtr1Inactv();
    
    /* init for variable MOTCTRLMGR_MotCtrlDiagcStsIvtr2Inactv */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlDiagcStsIvtr2Inactv();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElec */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgElec();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyA();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyB();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyC();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyD */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyD();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyE */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyE();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyF */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyF();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotElecMeclPolarity */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotElecMeclPolarity();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotVelMrf */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotVelMrf();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiA();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiB */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiB();
    
    /* init for variable MOTCTRLMGR_MotCtrlPhaOnTiC */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPhaOnTiC();
    
    /* init for variable MOTCTRLMGR_MotCtrlPwmPerd */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlPwmPerd();
    
    /* init for variable MOTCTRLMGR_MotCtrlSysSt */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlSysSt();
    
    /* init for variable MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlCurrMeasWrmIninTestCmpl();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyAAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyBAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyCAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyDAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyDAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyEAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyEAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrAdcVlyFAdcFaild */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrAdcVlyFAdcFaild();
    
    /* init for variable MOTCTRLMGR_MotCtrlCurrMeasMotAgCorrd : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrRollgCntr1 : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrRollgCntr2 : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdA */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdA();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdB : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdC : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdD */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotCurrCorrdD();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdE : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotCurrCorrdF : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlNtc5DErrCnt : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlNtc6DErrCnt : useless (never read) */

}
