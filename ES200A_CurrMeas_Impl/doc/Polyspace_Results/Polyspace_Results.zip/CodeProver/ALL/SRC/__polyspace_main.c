#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_CurrMeasEolGainStsReq_Oper(void)
{
    extern __PST__VOID CurrMeasEolGainStsReq_Oper(__PST__g__17);

    __PST__g__17 __arg__0;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    CurrMeasEolGainStsReq_Oper(__arg__0);
}

static void _main_gen_call_CurrMeasEolOffsStsReq_Oper(void)
{
    extern __PST__VOID CurrMeasEolOffsStsReq_Oper(__PST__g__17);

    __PST__g__17 __arg__0;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    CurrMeasEolOffsStsReq_Oper(__arg__0);
}

static void _main_gen_call_CurrMeasGainReadReq_Oper(void)
{
    extern __PST__VOID CurrMeasGainReadReq_Oper(__PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19);

    __PST__g__19 __arg__0;
    __PST__g__19 __arg__1;
    __PST__g__19 __arg__2;
    __PST__g__19 __arg__3;
    __PST__g__19 __arg__4;
    __PST__g__19 __arg__5;
    
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g10();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g10();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g10();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g10();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_12[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g10();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_14[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g10();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    
    /* call it */
    CurrMeasGainReadReq_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5);
}

static void _main_gen_call_CurrMeasGainWrReq_Oper(void)
{
    extern __PST__VOID CurrMeasGainWrReq_Oper(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__g__17);

    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    __PST__FLOAT32 __arg__2;
    __PST__FLOAT32 __arg__3;
    __PST__FLOAT32 __arg__4;
    __PST__FLOAT32 __arg__5;
    __PST__g__17 __arg__6;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    __arg__2 = _main_gen_init_g10();
    __arg__3 = _main_gen_init_g10();
    __arg__4 = _main_gen_init_g10();
    __arg__5 = _main_gen_init_g10();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g6();
        }
        __arg__6 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    CurrMeasGainWrReq_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_CurrMeasOffsReadReq_Oper(void)
{
    extern __PST__VOID CurrMeasOffsReadReq_Oper(__PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19, __PST__g__19);

    __PST__g__19 __arg__0;
    __PST__g__19 __arg__1;
    __PST__g__19 __arg__2;
    __PST__g__19 __arg__3;
    __PST__g__19 __arg__4;
    __PST__g__19 __arg__5;
    __PST__g__19 __arg__6;
    __PST__g__19 __arg__7;
    __PST__g__19 __arg__8;
    __PST__g__19 __arg__9;
    __PST__g__19 __arg__10;
    __PST__g__19 __arg__11;
    __PST__g__19 __arg__12;
    
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g10();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g10();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_22[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g10();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_24[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g10();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_26[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g10();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_28[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g10();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_30[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g10();
        }
        __arg__6 = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_32[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g10();
        }
        __arg__7 = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_34[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g10();
        }
        __arg__8 = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_36[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g10();
        }
        __arg__9 = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_38[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g10();
        }
        __arg__10 = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_40[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_41;
        for (_i_main_gen_tmp_41 = 0; _i_main_gen_tmp_41 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_41++)
        {
            _main_gen_tmp_40[_i_main_gen_tmp_41] = _main_gen_init_g10();
        }
        __arg__11 = PST_TRUE() ? 0 : &_main_gen_tmp_40[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_42[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_43;
        for (_i_main_gen_tmp_43 = 0; _i_main_gen_tmp_43 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_43++)
        {
            _main_gen_tmp_42[_i_main_gen_tmp_43] = _main_gen_init_g10();
        }
        __arg__12 = PST_TRUE() ? 0 : &_main_gen_tmp_42[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    
    /* call it */
    CurrMeasOffsReadReq_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6, __arg__7, __arg__8, __arg__9, __arg__10, __arg__11, __arg__12);
}

static void _main_gen_call_CurrMeasOffsWrReq_Oper(void)
{
    extern __PST__VOID CurrMeasOffsWrReq_Oper(__PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__FLOAT32, __PST__g__17);

    __PST__FLOAT32 __arg__0;
    __PST__FLOAT32 __arg__1;
    __PST__FLOAT32 __arg__2;
    __PST__FLOAT32 __arg__3;
    __PST__FLOAT32 __arg__4;
    __PST__FLOAT32 __arg__5;
    __PST__FLOAT32 __arg__6;
    __PST__FLOAT32 __arg__7;
    __PST__FLOAT32 __arg__8;
    __PST__FLOAT32 __arg__9;
    __PST__FLOAT32 __arg__10;
    __PST__FLOAT32 __arg__11;
    __PST__FLOAT32 __arg__12;
    __PST__g__17 __arg__13;
    
    __arg__0 = _main_gen_init_g10();
    __arg__1 = _main_gen_init_g10();
    __arg__2 = _main_gen_init_g10();
    __arg__3 = _main_gen_init_g10();
    __arg__4 = _main_gen_init_g10();
    __arg__5 = _main_gen_init_g10();
    __arg__6 = _main_gen_init_g10();
    __arg__7 = _main_gen_init_g10();
    __arg__8 = _main_gen_init_g10();
    __arg__9 = _main_gen_init_g10();
    __arg__10 = _main_gen_init_g10();
    __arg__11 = _main_gen_init_g10();
    __arg__12 = _main_gen_init_g10();
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_45;
        for (_i_main_gen_tmp_45 = 0; _i_main_gen_tmp_45 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_45++)
        {
            _main_gen_tmp_44[_i_main_gen_tmp_45] = _main_gen_init_g6();
        }
        __arg__13 = PST_TRUE() ? 0 : &_main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    CurrMeasOffsWrReq_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6, __arg__7, __arg__8, __arg__9, __arg__10, __arg__11, __arg__12, __arg__13);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function CurrMeasEolGainReq_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CurrMeasEolGainReq_Oper(__PST__VOID);

            CurrMeasEolGainReq_Oper();
        }
        
        /* call of function CurrMeasEolGainStsReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_CurrMeasEolGainStsReq_Oper();
        }
        
        /* call of function CurrMeasEolOffsReq_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CurrMeasEolOffsReq_Oper(__PST__VOID);

            CurrMeasEolOffsReq_Oper();
        }
        
        /* call of function CurrMeasEolOffsStsReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_CurrMeasEolOffsStsReq_Oper();
        }
        
        /* call of function CurrMeasGainReadReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_CurrMeasGainReadReq_Oper();
        }
        
        /* call of function CurrMeasGainWrReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_CurrMeasGainWrReq_Oper();
        }
        
        /* call of function CurrMeasInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CurrMeasInit1(__PST__VOID);

            CurrMeasInit1();
        }
        
        /* call of function CurrMeasOffsReadReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_CurrMeasOffsReadReq_Oper();
        }
        
        /* call of function CurrMeasOffsWrReq_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_CurrMeasOffsWrReq_Oper();
        }
        
        /* call of function CurrMeasPer1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CurrMeasPer1(__PST__VOID);

            CurrMeasPer1();
        }
        
        /* call of function CurrMeasPer3 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CurrMeasPer3(__PST__VOID);

            CurrMeasPer3();
        }
        
        /* call of function CurrMeasPer2 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID CurrMeasPer2(__PST__VOID);

            CurrMeasPer2();
        }
        
    }
}
