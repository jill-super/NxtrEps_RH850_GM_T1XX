@echo off
REM Host: SAGL80ZD8W1
"C:\Program Files\MATLAB\R2013b\polyspace\bin\terminate-polyspace-job.exe" 6172 "C:\Component\SF042A_HwAgSnsrls_Impl\doc\Polyspace_Results\CodeProver\Polyspace_R2013b_Polyspace_11_22_2016-14h40.log" %1
RMDIR /S /Q "C:\Temp\Polyspace\181C_1479843645" > NUL: 2>&1
