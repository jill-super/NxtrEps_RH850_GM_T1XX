#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_CmplncErrMotToPinion_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_CmplncErrMotToPinion_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_HwTq_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_HwTq_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_MotAgCumvAlgndCrf_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_MotAgCumvAlgndCrf_Val(__PST__g__38 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_4;
        }
        P_0[0] = pst_random_g_4;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_MotAgCumvAlgndVld_Logl
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_MotAgCumvAlgndVld_Logl(__PST__g__27 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_MotTqCmdCrf_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_MotTqCmdCrf_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_MotVelCrf_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_MotVelCrf_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_PinionAg_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_PinionAg_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_PinionAgConf_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_PinionAgConf_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_VehSpd_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_VehSpd_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_VehSpdVld_Logl
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_VehSpdVld_Logl(__PST__g__27 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_VehYawRate_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_VehYawRate_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_WhlFrqVld_Logl
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_WhlFrqVld_Logl(__PST__g__27 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_WhlLeFrq_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_WhlLeFrq_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_HwAgSnsrls_WhlRiFrq_Val
 */


__PST__UINT8 Rte_Read_HwAgSnsrls_WhlRiFrq_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_HwAgSnsrls_HwAgSnsrls_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_HwAgSnsrls_HwAgSnsrls_Val"


__PST__UINT8 Rte_Write_HwAgSnsrls_HwAgSnsrls_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_HwAgSnsrls_HwAgSnsrlsConf_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_HwAgSnsrls_HwAgSnsrlsConf_Val"


__PST__UINT8 Rte_Write_HwAgSnsrls_HwAgSnsrlsConf_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_HwAgSnsrls_GetNtcQlfrSts_Oper
 */


__PST__UINT8 Rte_Call_HwAgSnsrls_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__27 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_HwAgSnsrls_GetRefTmr100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_HwAgSnsrls_GetRefTmr100MicroSec32bit_Oper(__PST__g__33 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_HwAgSnsrls_GetTiSpan100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_HwAgSnsrls_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__33 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_8;
        }
        P_1[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_HwAgSnsrls_NvmStordLstPrm_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_HwAgSnsrls_NvmStordLstPrm_SetRamBlockStatus"


__PST__UINT8 Rte_Call_HwAgSnsrls_NvmStordLstPrm_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsCorrdPinionAgHwConf_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsCorrdPinionAgHwConf_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsCorrdPinionAgHwConf_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsFCentrHwConf_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsFCentrHwConf_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsFCentrHwConf_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsPinionTqFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsPinionTqFilFrq_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsPinionTqFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil1Frq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil1Frq_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil1Frq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil2Frq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil2Frq_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil2Frq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngCoeff_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngCoeff_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngCoeff_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngStepThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngStepThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngStepThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConf_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConf_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConf_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConfThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConfThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConfThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynDifThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynDifThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynDifThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynHwConf_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynHwConf_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynHwConf_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynMotVelThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynMotVelThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynMotVelThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynPinionTqThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynPinionTqThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynPinionTqThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynVehSpdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynVehSpdThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynVehSpdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynYawRateThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynYawRateThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynYawRateThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlFrqThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlFrqThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlFrqThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff1_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff1_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff1_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff2_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff2_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff2_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwConf_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwConf_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwConf_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdRatThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdRatThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdRatThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdVehSpdThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdVehSpdThd_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdVehSpdThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsYawRateFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsYawRateFilFrq_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsYawRateFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_SysGlbPrmSysKineRat_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_SysGlbPrmSysKineRat_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_SysGlbPrmSysKineRat_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_SysGlbPrmSysTqRat_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_SysGlbPrmSysTqRat_Val"


__PST__FLOAT32 Rte_Prm_HwAgSnsrls_SysGlbPrmSysTqRat_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr1Thd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr1Thd_Val"


__PST__UINT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr1Thd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr2Thd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr2Thd_Val"


__PST__UINT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr2Thd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdTmrThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdTmrThd_Val"


__PST__UINT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdTmrThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwAg
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwAg"


__PST__VOID Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwAg(__PST__FLOAT32 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwConf
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwConf"


__PST__VOID Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwConf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwAg
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwAg"


__PST__FLOAT32 Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwAg(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwConf
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwConf"


__PST__FLOAT32 Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwConf(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

