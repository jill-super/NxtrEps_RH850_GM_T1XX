/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_CmplncErrMotToPinion_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_CmplncErrMotToPinion_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_CmplncErrMotToPinion_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_CmplncErrMotToPinion_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_CmplncErrMotToPinion_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_HwTq_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_HwTq_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_MotAgCumvAlgndCrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_MotAgCumvAlgndCrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_MotAgCumvAlgndCrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_MotAgCumvAlgndCrf_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_MotAgCumvAlgndCrf_Val(__PST__g__38 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_MotAgCumvAlgndVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_MotAgCumvAlgndVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_MotAgCumvAlgndVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_MotAgCumvAlgndVld_Logl"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_MotAgCumvAlgndVld_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_MotTqCmdCrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_MotTqCmdCrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_MotTqCmdCrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_MotTqCmdCrf_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_MotTqCmdCrf_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_MotVelCrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_MotVelCrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_MotVelCrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_MotVelCrf_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_MotVelCrf_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_PinionAg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_PinionAg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_PinionAg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_PinionAg_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_PinionAg_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_PinionAgConf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_PinionAgConf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_PinionAgConf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_PinionAgConf_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_PinionAgConf_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_VehSpd_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_VehSpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_VehSpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_VehSpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_VehSpdVld_Logl"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_VehSpdVld_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_VehYawRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_VehYawRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_VehYawRate_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_VehYawRate_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_VehYawRate_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_WhlFrqVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_WhlFrqVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_WhlFrqVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_WhlFrqVld_Logl"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_WhlFrqVld_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_WhlLeFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_WhlLeFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_WhlLeFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_WhlLeFrq_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_WhlLeFrq_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_HwAgSnsrls_WhlRiFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_HwAgSnsrls_WhlRiFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_HwAgSnsrls_WhlRiFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_HwAgSnsrls_WhlRiFrq_Val"
//
// __PST__UINT8 Rte_Read_HwAgSnsrls_WhlRiFrq_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_HwAgSnsrls_HwAgSnsrls_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_HwAgSnsrls_HwAgSnsrls_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_HwAgSnsrls_HwAgSnsrls_Val"
// #pragma POLYSPACE_WORST "Rte_Write_HwAgSnsrls_HwAgSnsrls_Val"
//
// __PST__UINT8 Rte_Write_HwAgSnsrls_HwAgSnsrls_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_HwAgSnsrls_HwAgSnsrlsConf_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_HwAgSnsrls_HwAgSnsrlsConf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_HwAgSnsrls_HwAgSnsrlsConf_Val"
// #pragma POLYSPACE_WORST "Rte_Write_HwAgSnsrls_HwAgSnsrlsConf_Val"
//
// __PST__UINT8 Rte_Write_HwAgSnsrls_HwAgSnsrlsConf_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAgSnsrls_GetNtcQlfrSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAgSnsrls_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAgSnsrls_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_HwAgSnsrls_GetNtcQlfrSts_Oper"
//
// __PST__UINT8 Rte_Call_HwAgSnsrls_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__27 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAgSnsrls_GetRefTmr100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAgSnsrls_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAgSnsrls_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_HwAgSnsrls_GetRefTmr100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_HwAgSnsrls_GetRefTmr100MicroSec32bit_Oper(__PST__g__33 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAgSnsrls_GetTiSpan100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAgSnsrls_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAgSnsrls_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_HwAgSnsrls_GetTiSpan100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_HwAgSnsrls_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__33 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_HwAgSnsrls_NvmStordLstPrm_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_HwAgSnsrls_NvmStordLstPrm_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_HwAgSnsrls_NvmStordLstPrm_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_HwAgSnsrls_NvmStordLstPrm_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_HwAgSnsrls_NvmStordLstPrm_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsCorrdPinionAgHwConf_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsCorrdPinionAgHwConf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsCorrdPinionAgHwConf_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsCorrdPinionAgHwConf_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsCorrdPinionAgHwConf_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsFCentrHwConf_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsFCentrHwConf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsFCentrHwConf_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsFCentrHwConf_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsFCentrHwConf_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsPinionTqFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsPinionTqFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsPinionTqFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsPinionTqFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsPinionTqFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil1Frq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil1Frq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil1Frq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil1Frq_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil1Frq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil2Frq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil2Frq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil2Frq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil2Frq_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsRelHwAgFil2Frq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngCoeff_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngCoeff_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngCoeff_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngCoeff_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngCoeff_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngStepThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngStepThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngStepThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngStepThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsSmotngStepThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConf_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConf_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConf_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConf_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConfThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConfThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConfThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConfThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsStordPinionConfThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynDifThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynDifThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynDifThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynDifThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynDifThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynHwConf_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynHwConf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynHwConf_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynHwConf_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynHwConf_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynMotVelThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynMotVelThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynMotVelThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynMotVelThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynMotVelThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynPinionTqThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynPinionTqThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynPinionTqThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynPinionTqThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynPinionTqThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynVehSpdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynVehSpdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynVehSpdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynVehSpdThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynVehSpdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynYawRateThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynYawRateThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynYawRateThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynYawRateThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynYawRateThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlFrqThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlFrqThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlFrqThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlFrqThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlFrqThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff1_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff1_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff1_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff1_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff1_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff2_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff2_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff2_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff2_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgCoeff2_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwAgThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwConf_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwConf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwConf_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwConf_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdHwConf_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdRatThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdRatThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdRatThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdRatThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdRatThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdVehSpdThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdVehSpdThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdVehSpdThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdVehSpdThd_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdVehSpdThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsYawRateFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsYawRateFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsYawRateFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsYawRateFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsYawRateFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_SysGlbPrmSysKineRat_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_SysGlbPrmSysKineRat_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_SysGlbPrmSysKineRat_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_SysGlbPrmSysKineRat_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_SysGlbPrmSysKineRat_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_SysGlbPrmSysTqRat_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_SysGlbPrmSysTqRat_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_SysGlbPrmSysTqRat_Val"
//
// __PST__FLOAT32 Rte_Prm_HwAgSnsrls_SysGlbPrmSysTqRat_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr1Thd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr1Thd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr1Thd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr1Thd_Val"
//
// __PST__UINT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr1Thd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr2Thd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr2Thd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr2Thd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr2Thd_Val"
//
// __PST__UINT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsVehDynTmr2Thd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdTmrThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdTmrThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdTmrThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdTmrThd_Val"
//
// __PST__UINT32 Rte_Prm_HwAgSnsrls_HwAgSnsrlsWhlSpdTmrThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwAg
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwAg"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwAg"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwAg"
//
// __PST__VOID Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwAg(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwConf
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwConf"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwConf"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwConf"
//
// __PST__VOID Rte_IrvWrite_HwAgSnsrls_HwAgSnsrlsInit1_StordHwConf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwAg
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwAg"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwAg"
// #pragma POLYSPACE_WORST "Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwAg"
//
// __PST__FLOAT32 Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwAg(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwConf
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwConf"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwConf"
// #pragma POLYSPACE_WORST "Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwConf"
//
// __PST__FLOAT32 Rte_IrvRead_HwAgSnsrls_HwAgSnsrlsPer1_StordHwConf(__PST__VOID)
// {
//    ...
// }

