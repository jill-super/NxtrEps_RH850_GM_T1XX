#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__52 _main_gen_init_g52(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__46 _main_gen_init_g46(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__40 _main_gen_init_g40(void);

extern struct Rte_CDS_SysFricLrng _main_gen_init_g38(void);

struct __PST__g__40 _main_gen_init_g40(void)
{
    static struct __PST__g__40 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

struct __PST__g__46 _main_gen_init_g46(void)
{
    static struct __PST__g__46 x;
    /* struct/union type */
    { /* array type */
        __PST__UINT32 _main_gen_tmp_54_0;
        
        for (_main_gen_tmp_54_0 = 0; _main_gen_tmp_54_0 < 4; _main_gen_tmp_54_0++)
        {
            /* base type */
            x.BasLineFric[_main_gen_tmp_54_0] = pst_random_g_10;
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_55_0;
        
        for (_main_gen_tmp_55_0 = 0; _main_gen_tmp_55_0 < 4; _main_gen_tmp_55_0++)
        {
            /* base type */
            x.VehLrndFric[_main_gen_tmp_55_0] = pst_random_g_10;
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_56_0;
        
        for (_main_gen_tmp_56_0 = 0; _main_gen_tmp_56_0 < 8; _main_gen_tmp_56_0++)
        {
            __PST__UINT32 _main_gen_tmp_56_1;
            
            for (_main_gen_tmp_56_1 = 0; _main_gen_tmp_56_1 < 4; _main_gen_tmp_56_1++)
            {
                /* base type */
                x.Hys[_main_gen_tmp_56_0][_main_gen_tmp_56_1] = pst_random_g_10;
            }
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_57_0;
        
        for (_main_gen_tmp_57_0 = 0; _main_gen_tmp_57_0 < 8; _main_gen_tmp_57_0++)
        {
            __PST__UINT32 _main_gen_tmp_57_1;
            
            for (_main_gen_tmp_57_1 = 0; _main_gen_tmp_57_1 < 3; _main_gen_tmp_57_1++)
            {
                /* base type */
                x.RngCntr[_main_gen_tmp_57_0][_main_gen_tmp_57_1] = pst_random_g_7;
            }
        }
    }
    x.FricOffs = _main_gen_init_g10();
    x.SysFricLrngOperMod = _main_gen_init_g6();
    return x;
}

struct __PST__g__52 _main_gen_init_g52(void)
{
    static struct __PST__g__52 x;
    /* struct/union type */
    x.EolFric = _main_gen_init_g10();
    x.EnaFricLrng = _main_gen_init_g6();
    x.EnaFricOffsOutp = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_SysFricLrng _main_gen_init_g38(void)
{
    static struct Rte_CDS_SysFricLrng x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_30[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g40();
        }
        x.Pim_AssiMechTLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_32[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g40();
        }
        x.Pim_AvrgFricLpFil1 = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_34[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g40();
        }
        x.Pim_AvrgFricLpFil2 = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_36[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g40();
        }
        x.Pim_AvrgFricLpFil3 = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_38[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g40();
        }
        x.Pim_AvrgFricLpFil4 = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static __PST__g__42 _main_gen_tmp_40[ARRAY_NBELEM(__PST__g__42)];
        __PST__UINT32 _i_main_gen_tmp_41;
        for (_i_main_gen_tmp_41 = 0; _i_main_gen_tmp_41 < ARRAY_NBELEM(__PST__g__42); _i_main_gen_tmp_41++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_42_0;
                
                for (_main_gen_tmp_42_0 = 0; _main_gen_tmp_42_0 < 12; _main_gen_tmp_42_0++)
                {
                    /* base type */
                    _main_gen_tmp_40[_i_main_gen_tmp_41][_main_gen_tmp_42_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_ColTqAry = PST_TRUE() ? 0 : &_main_gen_tmp_40[ARRAY_NBELEM(__PST__g__42) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_43[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_44;
        for (_i_main_gen_tmp_44 = 0; _i_main_gen_tmp_44 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_44++)
        {
            _main_gen_tmp_43[_i_main_gen_tmp_44] = _main_gen_init_g40();
        }
        x.Pim_ColTqLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_43[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_45[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_46;
        for (_i_main_gen_tmp_46 = 0; _i_main_gen_tmp_46 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_46++)
        {
            _main_gen_tmp_45[_i_main_gen_tmp_46] = _main_gen_init_g10();
        }
        x.Pim_EstimdFric = PST_TRUE() ? 0 : &_main_gen_tmp_45[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__44 _main_gen_tmp_47[ARRAY_NBELEM(__PST__g__44)];
        __PST__UINT32 _i_main_gen_tmp_48;
        for (_i_main_gen_tmp_48 = 0; _i_main_gen_tmp_48 < ARRAY_NBELEM(__PST__g__44); _i_main_gen_tmp_48++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_49_0;
                
                for (_main_gen_tmp_49_0 = 0; _main_gen_tmp_49_0 < 4; _main_gen_tmp_49_0++)
                {
                    /* base type */
                    _main_gen_tmp_47[_i_main_gen_tmp_48][_main_gen_tmp_49_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_FilAvrgFric = PST_TRUE() ? 0 : &_main_gen_tmp_47[ARRAY_NBELEM(__PST__g__44) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_50[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_51;
        for (_i_main_gen_tmp_51 = 0; _i_main_gen_tmp_51 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_51++)
        {
            _main_gen_tmp_50[_i_main_gen_tmp_51] = _main_gen_init_g40();
        }
        x.Pim_FricChgLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_50[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__46 _main_gen_tmp_52[ARRAY_NBELEM(struct __PST__g__46)];
        __PST__UINT32 _i_main_gen_tmp_53;
        for (_i_main_gen_tmp_53 = 0; _i_main_gen_tmp_53 < ARRAY_NBELEM(struct __PST__g__46); _i_main_gen_tmp_53++)
        {
            _main_gen_tmp_52[_i_main_gen_tmp_53] = _main_gen_init_g46();
        }
        x.Pim_FricLrngData = PST_TRUE() ? 0 : &_main_gen_tmp_52[ARRAY_NBELEM(struct __PST__g__46) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_59;
        for (_i_main_gen_tmp_59 = 0; _i_main_gen_tmp_59 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_59++)
        {
            _main_gen_tmp_58[_i_main_gen_tmp_59] = _main_gen_init_g6();
        }
        x.Pim_FricLrngOperModPrev = PST_TRUE() ? 0 : &_main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_61;
        for (_i_main_gen_tmp_61 = 0; _i_main_gen_tmp_61 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_61++)
        {
            _main_gen_tmp_60[_i_main_gen_tmp_61] = _main_gen_init_g6();
        }
        x.Pim_FricLrngRunOneTi = PST_TRUE() ? 0 : &_main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__52 _main_gen_tmp_62[ARRAY_NBELEM(struct __PST__g__52)];
        __PST__UINT32 _i_main_gen_tmp_63;
        for (_i_main_gen_tmp_63 = 0; _i_main_gen_tmp_63 < ARRAY_NBELEM(struct __PST__g__52); _i_main_gen_tmp_63++)
        {
            _main_gen_tmp_62[_i_main_gen_tmp_63] = _main_gen_init_g52();
        }
        x.Pim_FricNonLrngData = PST_TRUE() ? 0 : &_main_gen_tmp_62[ARRAY_NBELEM(struct __PST__g__52) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_64[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_65;
        for (_i_main_gen_tmp_65 = 0; _i_main_gen_tmp_65 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_65++)
        {
            _main_gen_tmp_64[_i_main_gen_tmp_65] = _main_gen_init_g10();
        }
        x.Pim_FricOffs = PST_TRUE() ? 0 : &_main_gen_tmp_64[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_67;
        for (_i_main_gen_tmp_67 = 0; _i_main_gen_tmp_67 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_67++)
        {
            _main_gen_tmp_66[_i_main_gen_tmp_67] = _main_gen_init_g6();
        }
        x.Pim_FricOffsOutpDi = PST_TRUE() ? 0 : &_main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_68[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_69;
        for (_i_main_gen_tmp_69 = 0; _i_main_gen_tmp_69 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_69++)
        {
            _main_gen_tmp_68[_i_main_gen_tmp_69] = _main_gen_init_g40();
        }
        x.Pim_HwAgAuthyLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_68[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static __PST__g__42 _main_gen_tmp_70[ARRAY_NBELEM(__PST__g__42)];
        __PST__UINT32 _i_main_gen_tmp_71;
        for (_i_main_gen_tmp_71 = 0; _i_main_gen_tmp_71 < ARRAY_NBELEM(__PST__g__42); _i_main_gen_tmp_71++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_72_0;
                
                for (_main_gen_tmp_72_0 = 0; _main_gen_tmp_72_0 < 12; _main_gen_tmp_72_0++)
                {
                    /* base type */
                    _main_gen_tmp_70[_i_main_gen_tmp_71][_main_gen_tmp_72_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_HwAgBuf = PST_TRUE() ? 0 : &_main_gen_tmp_70[ARRAY_NBELEM(__PST__g__42) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_73[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_74;
        for (_i_main_gen_tmp_74 = 0; _i_main_gen_tmp_74 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_74++)
        {
            _main_gen_tmp_73[_i_main_gen_tmp_74] = _main_gen_init_g40();
        }
        x.Pim_HwAgLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_73[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static __PST__g__42 _main_gen_tmp_75[ARRAY_NBELEM(__PST__g__42)];
        __PST__UINT32 _i_main_gen_tmp_76;
        for (_i_main_gen_tmp_76 = 0; _i_main_gen_tmp_76 < ARRAY_NBELEM(__PST__g__42); _i_main_gen_tmp_76++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_77_0;
                
                for (_main_gen_tmp_77_0 = 0; _main_gen_tmp_77_0 < 12; _main_gen_tmp_77_0++)
                {
                    /* base type */
                    _main_gen_tmp_75[_i_main_gen_tmp_76][_main_gen_tmp_77_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_HwVelBuf = PST_TRUE() ? 0 : &_main_gen_tmp_75[ARRAY_NBELEM(__PST__g__42) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_78[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_79;
        for (_i_main_gen_tmp_79 = 0; _i_main_gen_tmp_79 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_79++)
        {
            _main_gen_tmp_78[_i_main_gen_tmp_79] = _main_gen_init_g40();
        }
        x.Pim_HwVelLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_78[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_80[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_81;
        for (_i_main_gen_tmp_81 = 0; _i_main_gen_tmp_81 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_81++)
        {
            _main_gen_tmp_80[_i_main_gen_tmp_81] = _main_gen_init_g40();
        }
        x.Pim_LatALpFil = PST_TRUE() ? 0 : &_main_gen_tmp_80[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_82[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_83;
        for (_i_main_gen_tmp_83 = 0; _i_main_gen_tmp_83 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_83++)
        {
            _main_gen_tmp_82[_i_main_gen_tmp_83] = _main_gen_init_g10();
        }
        x.Pim_PrevFricOffs = PST_TRUE() ? 0 : &_main_gen_tmp_82[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_84[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_85;
        for (_i_main_gen_tmp_85 = 0; _i_main_gen_tmp_85 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_85++)
        {
            _main_gen_tmp_84[_i_main_gen_tmp_85] = _main_gen_init_g10();
        }
        x.Pim_PrevMaxRawAvrgFric = PST_TRUE() ? 0 : &_main_gen_tmp_84[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__44 _main_gen_tmp_86[ARRAY_NBELEM(__PST__g__44)];
        __PST__UINT32 _i_main_gen_tmp_87;
        for (_i_main_gen_tmp_87 = 0; _i_main_gen_tmp_87 < ARRAY_NBELEM(__PST__g__44); _i_main_gen_tmp_87++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_88_0;
                
                for (_main_gen_tmp_88_0 = 0; _main_gen_tmp_88_0 < 4; _main_gen_tmp_88_0++)
                {
                    /* base type */
                    _main_gen_tmp_86[_i_main_gen_tmp_87][_main_gen_tmp_88_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_RawAvrgFric = PST_TRUE() ? 0 : &_main_gen_tmp_86[ARRAY_NBELEM(__PST__g__44) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_89[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_90;
        for (_i_main_gen_tmp_90 = 0; _i_main_gen_tmp_90 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_90++)
        {
            _main_gen_tmp_89[_i_main_gen_tmp_90] = _main_gen_init_g8();
        }
        x.Pim_RefTmrLrngConstr = PST_TRUE() ? 0 : &_main_gen_tmp_89[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_91[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_92;
        for (_i_main_gen_tmp_92 = 0; _i_main_gen_tmp_92 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_92++)
        {
            _main_gen_tmp_91[_i_main_gen_tmp_92] = _main_gen_init_g8();
        }
        x.Pim_RefTmrNtc = PST_TRUE() ? 0 : &_main_gen_tmp_91[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__44 _main_gen_tmp_93[ARRAY_NBELEM(__PST__g__44)];
        __PST__UINT32 _i_main_gen_tmp_94;
        for (_i_main_gen_tmp_94 = 0; _i_main_gen_tmp_94 < ARRAY_NBELEM(__PST__g__44); _i_main_gen_tmp_94++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_95_0;
                
                for (_main_gen_tmp_95_0 = 0; _main_gen_tmp_95_0 < 4; _main_gen_tmp_95_0++)
                {
                    /* base type */
                    _main_gen_tmp_93[_i_main_gen_tmp_94][_main_gen_tmp_95_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_SatnAvrgFric = PST_TRUE() ? 0 : &_main_gen_tmp_93[ARRAY_NBELEM(__PST__g__44) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_96[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_97;
        for (_i_main_gen_tmp_97 = 0; _i_main_gen_tmp_97 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_97++)
        {
            _main_gen_tmp_96[_i_main_gen_tmp_97] = _main_gen_init_g10();
        }
        x.Pim_SatnEstimdFric = PST_TRUE() ? 0 : &_main_gen_tmp_96[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__44 _main_gen_tmp_98[ARRAY_NBELEM(__PST__g__44)];
        __PST__UINT32 _i_main_gen_tmp_99;
        for (_i_main_gen_tmp_99 = 0; _i_main_gen_tmp_99 < ARRAY_NBELEM(__PST__g__44); _i_main_gen_tmp_99++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_100_0;
                
                for (_main_gen_tmp_100_0 = 0; _main_gen_tmp_100_0 < 4; _main_gen_tmp_100_0++)
                {
                    /* base type */
                    _main_gen_tmp_98[_i_main_gen_tmp_99][_main_gen_tmp_100_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_VehBasLineFric = PST_TRUE() ? 0 : &_main_gen_tmp_98[ARRAY_NBELEM(__PST__g__44) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__40 _main_gen_tmp_101[ARRAY_NBELEM(struct __PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_102;
        for (_i_main_gen_tmp_102 = 0; _i_main_gen_tmp_102 < ARRAY_NBELEM(struct __PST__g__40); _i_main_gen_tmp_102++)
        {
            _main_gen_tmp_101[_i_main_gen_tmp_102] = _main_gen_init_g40();
        }
        x.Pim_VehSpdLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_101[ARRAY_NBELEM(struct __PST__g__40) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_SysFricLrng(void)
{
    extern __PST__g__35 Rte_Inst_SysFricLrng;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_SysFricLrng _main_gen_tmp_28[ARRAY_NBELEM(struct Rte_CDS_SysFricLrng)];
            __PST__UINT32 _i_main_gen_tmp_29;
            for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(struct Rte_CDS_SysFricLrng); _i_main_gen_tmp_29++)
            {
                _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g38();
            }
            Rte_Inst_SysFricLrng = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(struct Rte_CDS_SysFricLrng) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_SysFricLrng */
    _main_gen_init_sym_Rte_Inst_SysFricLrng();
    
}
