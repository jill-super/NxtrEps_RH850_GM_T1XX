#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_GetFricData_Oper(void)
{
    extern __PST__VOID GetFricData_Oper(__PST__g__17, __PST__g__17, __PST__g__17, __PST__g__17, __PST__g__18);

    __PST__g__17 __arg__0;
    __PST__g__17 __arg__1;
    __PST__g__17 __arg__2;
    __PST__g__17 __arg__3;
    __PST__g__18 __arg__4;
    
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_0[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g10();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g10();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g10();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g10();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g7();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    
    /* call it */
    GetFricData_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4);
}

static void _main_gen_call_GetFricLrngData_Oper(void)
{
    extern __PST__VOID GetFricLrngData_Oper(__PST__g__20, __PST__g__20, __PST__g__20, __PST__g__17);

    __PST__g__20 __arg__0;
    __PST__g__20 __arg__1;
    __PST__g__20 __arg__2;
    __PST__g__17 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g6();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g6();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_16[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g10();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    
    /* call it */
    GetFricLrngData_Oper(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_GetFricOffsOutpDi_Oper(void)
{
    extern __PST__VOID GetFricOffsOutpDi_Oper(__PST__g__20);

    __PST__g__20 __arg__0;
    
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g6();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    
    /* call it */
    GetFricOffsOutpDi_Oper(__arg__0);
}

static void _main_gen_call_SetFricData_Oper(void)
{
    extern __PST__VOID SetFricData_Oper(__PST__FLOAT32, __PST__g__23, __PST__g__23, __PST__g__23, __PST__g__25);

    __PST__FLOAT32 __arg__0;
    __PST__g__23 __arg__1;
    __PST__g__23 __arg__2;
    __PST__g__23 __arg__3;
    __PST__g__25 __arg__4;
    
    __arg__0 = _main_gen_init_g10();
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g10();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_22[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g10();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_24[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g10();
        }
        __arg__3 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g7();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    
    /* call it */
    SetFricData_Oper(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4);
}

static void _main_gen_call_SetFricLrngData_Oper(void)
{
    extern __PST__VOID SetFricLrngData_Oper(__PST__UINT8, __PST__UINT8, __PST__UINT8, __PST__FLOAT32);

    __PST__UINT8 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    __PST__FLOAT32 __arg__3;
    
    __arg__0 = _main_gen_init_g6();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    __arg__3 = _main_gen_init_g10();
    
    /* call it */
    SetFricLrngData_Oper(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_SetFricOffsOutpDi_Oper(void)
{
    extern __PST__VOID SetFricOffsOutpDi_Oper(__PST__UINT8);

    __PST__UINT8 __arg__0;
    
    __arg__0 = _main_gen_init_g6();
    
    /* call it */
    SetFricOffsOutpDi_Oper(__arg__0);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function ClrFricLrngOperMod_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID ClrFricLrngOperMod_Oper(__PST__VOID);

            ClrFricLrngOperMod_Oper();
        }
        
        /* call of function GetFricData_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetFricData_Oper();
        }
        
        /* call of function GetFricLrngData_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetFricLrngData_Oper();
        }
        
        /* call of function GetFricOffsOutpDi_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetFricOffsOutpDi_Oper();
        }
        
        /* call of function InitFricLrngTbl_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID InitFricLrngTbl_Oper(__PST__VOID);

            InitFricLrngTbl_Oper();
        }
        
        /* call of function SetFricData_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetFricData_Oper();
        }
        
        /* call of function SetFricLrngData_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetFricLrngData_Oper();
        }
        
        /* call of function SetFricOffsOutpDi_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_SetFricOffsOutpDi_Oper();
        }
        
        /* call of function SysFricLrngInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID SysFricLrngInit1(__PST__VOID);

            SysFricLrngInit1();
        }
        
        /* call of function SysFricLrngPer1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID SysFricLrngPer1(__PST__VOID);

            SysFricLrngPer1();
        }
        
    }
}
