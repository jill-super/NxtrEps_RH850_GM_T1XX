/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_AssiMechT_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_AssiMechT_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_AssiMechT_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_AssiMechT_Val"
//
// __PST__UINT8 Rte_Read_SysFricLrng_AssiMechT_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_FricLrngCustEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_FricLrngCustEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_FricLrngCustEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_FricLrngCustEna_Logl"
//
// __PST__UINT8 Rte_Read_SysFricLrng_FricLrngCustEna_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_FricLrngDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_FricLrngDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_FricLrngDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_FricLrngDi_Logl"
//
// __PST__UINT8 Rte_Read_SysFricLrng_FricLrngDi_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_HwAg_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_HwAg_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_HwAg_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_HwAg_Val"
//
// __PST__UINT8 Rte_Read_SysFricLrng_HwAg_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_HwAgAuthy_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_HwAgAuthy_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_HwAgAuthy_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_HwAgAuthy_Val"
//
// __PST__UINT8 Rte_Read_SysFricLrng_HwAgAuthy_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_HwTq_Val"
//
// __PST__UINT8 Rte_Read_SysFricLrng_HwTq_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_HwVel_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_HwVel_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_HwVel_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_HwVel_Val"
//
// __PST__UINT8 Rte_Read_SysFricLrng_HwVel_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_MotTqCmdCrf_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_MotTqCmdCrf_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_MotTqCmdCrf_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_MotTqCmdCrf_Val"
//
// __PST__UINT8 Rte_Read_SysFricLrng_MotTqCmdCrf_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_VehLatA_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_VehLatA_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_VehLatA_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_VehLatA_Val"
//
// __PST__UINT8 Rte_Read_SysFricLrng_VehLatA_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_SysFricLrng_VehSpd_Val(__PST__g__17 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_SysFricLrng_VehSpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_SysFricLrng_VehSpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_SysFricLrng_VehSpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_SysFricLrng_VehSpdVld_Logl"
//
// __PST__UINT8 Rte_Read_SysFricLrng_VehSpdVld_Logl(__PST__g__20 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_SysFricLrng_MaxLrndFric_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_SysFricLrng_MaxLrndFric_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_SysFricLrng_MaxLrndFric_Val"
// #pragma POLYSPACE_WORST "Rte_Write_SysFricLrng_MaxLrndFric_Val"
//
// __PST__UINT8 Rte_Write_SysFricLrng_MaxLrndFric_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_SysFricLrng_SysFricEstimd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_SysFricLrng_SysFricEstimd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_SysFricLrng_SysFricEstimd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_SysFricLrng_SysFricEstimd_Val"
//
// __PST__UINT8 Rte_Write_SysFricLrng_SysFricEstimd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_SysFricLrng_SysFricOffs_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_SysFricLrng_SysFricOffs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_SysFricLrng_SysFricOffs_Val"
// #pragma POLYSPACE_WORST "Rte_Write_SysFricLrng_SysFricOffs_Val"
//
// __PST__UINT8 Rte_Write_SysFricLrng_SysFricOffs_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_SysFricLrng_SysSatnFricEstimd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_SysFricLrng_SysSatnFricEstimd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_SysFricLrng_SysSatnFricEstimd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_SysFricLrng_SysSatnFricEstimd_Val"
//
// __PST__UINT8 Rte_Write_SysFricLrng_SysSatnFricEstimd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_SysFricLrng_FricLrngData_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_SysFricLrng_FricLrngData_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_SysFricLrng_FricLrngData_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_SysFricLrng_FricLrngData_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_SysFricLrng_FricLrngData_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_SysFricLrng_FricNonLrngData_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_SysFricLrng_FricNonLrngData_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_SysFricLrng_FricNonLrngData_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_SysFricLrng_FricNonLrngData_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_SysFricLrng_FricNonLrngData_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_SysFricLrng_GetRefTmr100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_SysFricLrng_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_SysFricLrng_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_SysFricLrng_GetRefTmr100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_SysFricLrng_GetRefTmr100MicroSec32bit_Oper(__PST__g__54 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_SysFricLrng_GetTiSpan100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_SysFricLrng_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_SysFricLrng_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_SysFricLrng_GetTiSpan100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_SysFricLrng_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__54 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_SysFricLrng_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_SysFricLrng_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_SysFricLrng_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_SysFricLrng_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_SysFricLrng_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngAvrgFricFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngAvrgFricFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngAvrgFricFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngAvrgFricFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngAvrgFricFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngBasLineEolFric_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngBasLineEolFric_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngBasLineEolFric_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngBasLineEolFric_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngBasLineEolFric_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngDataPrepLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngDataPrepLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngDataPrepLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngDataPrepLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngDataPrepLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngEolFricDifHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngEolFricDifHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngEolFricDifLoLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifLoLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifLoLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifLoLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngEolFricDifLoLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngEolFricDifScagFac_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifScagFac_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifScagFac_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifScagFac_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngEolFricDifScagFac_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngFricDiagcThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngFricDiagcThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngFricDiagcThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngFricDiagcThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricDiagcThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngFricDiagcTiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngFricDiagcTiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngFricDiagcTiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngFricDiagcTiThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricDiagcTiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngFricOffsHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngFricOffsHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngFricOffsHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngFricOffsHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricOffsHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngFricOffsLoLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngFricOffsLoLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngFricOffsLoLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngFricOffsLoLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricOffsLoLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngFricOffsLpFilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngFricOffsLpFilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngFricOffsLpFilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngFricOffsLpFilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricOffsLpFilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngGain_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngGain_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngGain_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngGain_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngGain_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngHwPosnAuthyThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngHwPosnAuthyThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngHwPosnAuthyThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngHwPosnAuthyThd_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngHwPosnAuthyThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngHwVelConstrLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngHwVelConstrLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngHwVelConstrLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngHwVelConstrLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngHwVelConstrLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngHwVelHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngHwVelHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngHwVelHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngHwVelHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngHwVelHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngHwVelLoLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngHwVelLoLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngHwVelLoLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngHwVelLoLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngHwVelLoLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngIgnCycFricChgLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngIgnCycFricChgLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngIgnCycFricChgLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngIgnCycFricChgLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngIgnCycFricChgLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngLatAHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngLatAHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngLatAHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngLatAHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngLatAHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngLatALoLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngLatALoLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngLatALoLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngLatALoLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngLatALoLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngTHiLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngTHiLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngTHiLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngTHiLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngTHiLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngTLoLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngTLoLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngTLoLim_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngTLoLim_Val"
//
// __PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngTLoLim_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngThd_Val"
//
// __PST__UINT32 Rte_Prm_SysFricLrng_SysFricLrngThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngRngCntrThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngRngCntrThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngRngCntrThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngRngCntrThd_Val"
//
// __PST__UINT16 Rte_Prm_SysFricLrng_SysFricLrngRngCntrThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngBasLineFric_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngBasLineFric_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngBasLineFric_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngBasLineFric_Ary1D"
//
// __PST__g__23 Rte_Prm_SysFricLrng_SysFricLrngBasLineFric_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngBasLineHys_Ary2D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngBasLineHys_Ary2D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngBasLineHys_Ary2D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngBasLineHys_Ary2D"
//
// __PST__g__23 Rte_Prm_SysFricLrng_SysFricLrngBasLineHys_Ary2D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngBasLineRngCntr_Ary2D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngBasLineRngCntr_Ary2D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngBasLineRngCntr_Ary2D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngBasLineRngCntr_Ary2D"
//
// __PST__g__25 Rte_Prm_SysFricLrng_SysFricLrngBasLineRngCntr_Ary2D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngFricChgWght_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngFricChgWght_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngFricChgWght_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngFricChgWght_Ary1D"
//
// __PST__g__23 Rte_Prm_SysFricLrng_SysFricLrngFricChgWght_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngFricHysHwAgPt_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngFricHysHwAgPt_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngFricHysHwAgPt_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngFricHysHwAgPt_Ary1D"
//
// __PST__g__23 Rte_Prm_SysFricLrng_SysFricLrngFricHysHwAgPt_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatX_Ary1D"
//
// __PST__g__25 Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatY_Ary1D"
//
// __PST__g__25 Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngMaskVehSpd_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngMaskVehSpd_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngMaskVehSpd_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngMaskVehSpd_Ary1D"
//
// __PST__g__70 Rte_Prm_SysFricLrng_SysFricLrngMaskVehSpd_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_SysFricLrng_SysFricLrngVehSpd_Ary2D
//
// #pragma POLYSPACE_PURE "Rte_Prm_SysFricLrng_SysFricLrngVehSpd_Ary2D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_SysFricLrng_SysFricLrngVehSpd_Ary2D"
// #pragma POLYSPACE_WORST "Rte_Prm_SysFricLrng_SysFricLrngVehSpd_Ary2D"
//
// __PST__g__23 Rte_Prm_SysFricLrng_SysFricLrngVehSpd_Ary2D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_u16_u16VariXu16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_u16_u16VariXu16VariY"
//
// __PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__25 P_0, __PST__g__25 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }

