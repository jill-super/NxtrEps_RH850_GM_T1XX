#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * cosf
 */

#pragma POLYSPACE_POLYMORPHIC "cosf"


__PST__FLOAT32 cosf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * sinf
 */

#pragma POLYSPACE_POLYMORPHIC "sinf"


__PST__FLOAT32 sinf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * sqrtf
 */

#pragma POLYSPACE_POLYMORPHIC "sqrtf"


__PST__FLOAT32 sqrtf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_HwTq_Val
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_HwTq_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_SysSt_Val
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_SysSt_Val(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_VehSpd_Val
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_VehSpd_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_VehSpdVld_Logl
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_VehSpdVld_Logl(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_WhlFrqVld_Logl
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_WhlFrqVld_Logl(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_WhlImbRejctnCustEna_Logl
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_WhlImbRejctnCustEna_Logl(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_WhlImbRejctnDi_Logl
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_WhlImbRejctnDi_Logl(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_WhlLeFrq_Val
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_WhlLeFrq_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_WhlImbRejctn_WhlRiFrq_Val
 */


__PST__UINT8 Rte_Read_WhlImbRejctn_WhlRiFrq_Val(__PST__g__35 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_WhlImbRejctn_WhlImbRejctnActv_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_WhlImbRejctn_WhlImbRejctnActv_Logl"


__PST__UINT8 Rte_Write_WhlImbRejctn_WhlImbRejctnActv_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_WhlImbRejctn_WhlImbRejctnAmp_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_WhlImbRejctn_WhlImbRejctnAmp_Val"


__PST__UINT8 Rte_Write_WhlImbRejctn_WhlImbRejctnAmp_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_WhlImbRejctn_WhlImbRejctnCmd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_WhlImbRejctn_WhlImbRejctnCmd_Val"


__PST__UINT8 Rte_Write_WhlImbRejctn_WhlImbRejctnCmd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_WhlImbRejctn_CmpPeakData_GetErrorStatus
 */


__PST__UINT8 Rte_Call_WhlImbRejctn_CmpPeakData_GetErrorStatus(__PST__g__30 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_WhlImbRejctn_CmpPeakData_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_WhlImbRejctn_CmpPeakData_SetRamBlockStatus"


__PST__UINT8 Rte_Call_WhlImbRejctn_CmpPeakData_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_WhlImbRejctn_GetRefTmr100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_WhlImbRejctn_GetRefTmr100MicroSec32bit_Oper(__PST__g__34 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_WhlImbRejctn_GetTiSpan100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_WhlImbRejctn_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__34 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_8;
        }
        P_1[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_WhlImbRejctn_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_WhlImbRejctn_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_WhlImbRejctn_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnAdpvFac_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnAdpvFac_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnAdpvFac_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaTar_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaTar_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaTar_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp1FilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp1FilFrq_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp1FilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp2FilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp2FilFrq_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp2FilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp1FilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp1FilFrq_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp1FilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp2FilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp2FilFrq_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp2FilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnCurrMgnSlewPerLoop_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnCurrMgnSlewPerLoop_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnCurrMgnSlewPerLoop_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryDly_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryDly_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryDly_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryNegStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryNegStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryNegStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryPosStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryPosStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryPosStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendLpFil_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendLpFil_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendLpFil_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTh2Tq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTh2Tq_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTh2Tq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendThTq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendThTq_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendThTq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTi2Sec_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTi2Sec_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTi2Sec_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTiSec_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTiSec_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTiSec_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnDistbnMgnLpFil_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnDistbnMgnLpFil_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDistbnMgnLpFil_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnEnaSlewPerLoop_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnEnaSlewPerLoop_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnEnaSlewPerLoop_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcAmpThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcAmpThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcAmpThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryDly_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryDly_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryDly_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryNegStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryNegStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryNegStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryPosStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryPosStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryPosStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcLpFil_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcLpFil_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcLpFil_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcUgrPoleMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcUgrPoleMgn_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcUgrPoleMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgn_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltNegStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltNegStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltNegStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltPosStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltPosStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltPosStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryDly_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryDly_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryDly_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryNegStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryNegStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryNegStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryPosStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryPosStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryPosStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDeltaSca_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDeltaSca_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDeltaSca_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDiThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnEnaThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnEnaThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnEnaThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrq_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrqDelta_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrqDelta_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrqDelta_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnLeak_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnLeak_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnLeak_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnScaCncl_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnScaCncl_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnScaCncl_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnUgrPoleMgn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnUgrPoleMgn_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnUgrPoleMgn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnVehSpdEna_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnVehSpdEna_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnVehSpdEna_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryDly_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryDly_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryDly_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryNegStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryNegStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryNegStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryPosStep_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryPosStep_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryPosStep_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnThd_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdLpFil_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdLpFil_Val"


__PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdLpFil_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcTout_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcTout_Val"


__PST__UINT16 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcTout_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxDurn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxDurn_Val"


__PST__UINT16 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxDurn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnRampDwnTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnRampDwnTi_Val"


__PST__UINT16 Rte_Prm_WhlImbRejctn_WhlImbRejctnRampDwnTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnTi_Val"


__PST__UINT16 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaEna_Logl"


__PST__UINT8 Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFctEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFctEna_Logl"


__PST__UINT8 Rte_Prm_WhlImbRejctn_WhlImbRejctnFctEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcEna_Logl"


__PST__UINT8 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblX_Ary1D"


__PST__g__51 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__51 real_random_for_return ;
        __PST__g__51 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblY_Ary1D"


__PST__g__51 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__51 real_random_for_return ;
        __PST__g__51 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjX_Ary1D"


__PST__g__51 Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__51 real_random_for_return ;
        __PST__g__51 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjY_Ary1D"


__PST__g__54 Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__54 real_random_for_return ;
        __PST__g__54 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_CurrMgnSlewRate
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_CurrMgnSlewRate"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_CurrMgnSlewRate(__PST__FLOAT32 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_EnaSlewRate
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_EnaSlewRate"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_EnaSlewRate(__PST__FLOAT32 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_IniCmpFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_IniCmpFlt"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_IniCmpFlt(__PST__UINT8 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_CurrMgnSlewRate
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_CurrMgnSlewRate"


__PST__FLOAT32 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_CurrMgnSlewRate(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_EnaSlewRate
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_EnaSlewRate"


__PST__FLOAT32 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_EnaSlewRate(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_IniCmpFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_IniCmpFlt"


__PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_IniCmpFlt(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_SlowSpdDiagc
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_SlowSpdDiagc"


__PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_SlowSpdDiagc(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_CmdAmp
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_CmdAmp"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_CmdAmp(__PST__FLOAT32 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_DcTrendFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_DcTrendFlt"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_DcTrendFlt(__PST__UINT8 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_FrqDiagcFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_FrqDiagcFlt"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_FrqDiagcFlt(__PST__UINT8 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_MaxMgnFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_MaxMgnFlt"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_MaxMgnFlt(__PST__UINT8 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_WhlSpdCorrlnFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_WhlSpdCorrlnFlt"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_WhlSpdCorrlnFlt(__PST__UINT8 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_CmdAmp
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_CmdAmp"


__PST__FLOAT32 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_CmdAmp(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_DcTrendFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_DcTrendFlt"


__PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_DcTrendFlt(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_FrqDiagcFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_FrqDiagcFlt"


__PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_FrqDiagcFlt(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_MaxMgnFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_MaxMgnFlt"


__PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_MaxMgnFlt(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_WhlSpdCorrlnFlt
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_WhlSpdCorrlnFlt"


__PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_WhlSpdCorrlnFlt(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer2_SlowSpdDiagc
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer2_SlowSpdDiagc"


__PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer2_SlowSpdDiagc(__PST__UINT8 P_0)
{
    /* function is pure */

    return;
}

/*
 * LnrIntrpn_u16_u16VariXu16VariY
 */

#pragma POLYSPACE_POLYMORPHIC "LnrIntrpn_u16_u16VariXu16VariY"


__PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__51 P_0, __PST__g__51 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * LnrIntrpn_s16_u16VariXs16VariY
 */

#pragma POLYSPACE_POLYMORPHIC "LnrIntrpn_s16_u16VariXs16VariY"


__PST__SINT16 LnrIntrpn_s16_u16VariXs16VariY(__PST__g__51 P_0, __PST__g__54 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT16 real_random_for_return  = 0;
        __PST__SINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

