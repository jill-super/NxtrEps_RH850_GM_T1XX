/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function cosf
//
// #pragma POLYSPACE_PURE "cosf"
// #pragma POLYSPACE_CLEAN "cosf"
// #pragma POLYSPACE_WORST "cosf"
//
// __PST__FLOAT32 cosf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function sinf
//
// #pragma POLYSPACE_PURE "sinf"
// #pragma POLYSPACE_CLEAN "sinf"
// #pragma POLYSPACE_WORST "sinf"
//
// __PST__FLOAT32 sinf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function expf
//
// #pragma POLYSPACE_PURE "expf"
// #pragma POLYSPACE_CLEAN "expf"
// #pragma POLYSPACE_WORST "expf"
//
// __PST__FLOAT32 expf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function sqrtf
//
// #pragma POLYSPACE_PURE "sqrtf"
// #pragma POLYSPACE_CLEAN "sqrtf"
// #pragma POLYSPACE_WORST "sqrtf"
//
// __PST__FLOAT32 sqrtf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_HwTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_HwTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_HwTq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_HwTq_Val"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_HwTq_Val(__PST__g__35 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_SysSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_SysSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_SysSt_Val"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_SysSt_Val"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_SysSt_Val(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_VehSpd_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_VehSpd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_VehSpd_Val"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_VehSpd_Val"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_VehSpd_Val(__PST__g__35 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_VehSpdVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_VehSpdVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_VehSpdVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_VehSpdVld_Logl"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_VehSpdVld_Logl(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_WhlFrqVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_WhlFrqVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_WhlFrqVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_WhlFrqVld_Logl"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_WhlFrqVld_Logl(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_WhlImbRejctnCustEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_WhlImbRejctnCustEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_WhlImbRejctnCustEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_WhlImbRejctnCustEna_Logl"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_WhlImbRejctnCustEna_Logl(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_WhlImbRejctnDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_WhlImbRejctnDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_WhlImbRejctnDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_WhlImbRejctnDi_Logl"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_WhlImbRejctnDi_Logl(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_WhlLeFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_WhlLeFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_WhlLeFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_WhlLeFrq_Val"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_WhlLeFrq_Val(__PST__g__35 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_WhlImbRejctn_WhlRiFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_WhlImbRejctn_WhlRiFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_WhlImbRejctn_WhlRiFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Read_WhlImbRejctn_WhlRiFrq_Val"
//
// __PST__UINT8 Rte_Read_WhlImbRejctn_WhlRiFrq_Val(__PST__g__35 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_WhlImbRejctn_WhlImbRejctnActv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_WhlImbRejctn_WhlImbRejctnActv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_WhlImbRejctn_WhlImbRejctnActv_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_WhlImbRejctn_WhlImbRejctnActv_Logl"
//
// __PST__UINT8 Rte_Write_WhlImbRejctn_WhlImbRejctnActv_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_WhlImbRejctn_WhlImbRejctnAmp_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_WhlImbRejctn_WhlImbRejctnAmp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_WhlImbRejctn_WhlImbRejctnAmp_Val"
// #pragma POLYSPACE_WORST "Rte_Write_WhlImbRejctn_WhlImbRejctnAmp_Val"
//
// __PST__UINT8 Rte_Write_WhlImbRejctn_WhlImbRejctnAmp_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_WhlImbRejctn_WhlImbRejctnCmd_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_WhlImbRejctn_WhlImbRejctnCmd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_WhlImbRejctn_WhlImbRejctnCmd_Val"
// #pragma POLYSPACE_WORST "Rte_Write_WhlImbRejctn_WhlImbRejctnCmd_Val"
//
// __PST__UINT8 Rte_Write_WhlImbRejctn_WhlImbRejctnCmd_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_WhlImbRejctn_CmpPeakData_GetErrorStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_WhlImbRejctn_CmpPeakData_GetErrorStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_WhlImbRejctn_CmpPeakData_GetErrorStatus"
// #pragma POLYSPACE_WORST "Rte_Call_WhlImbRejctn_CmpPeakData_GetErrorStatus"
//
// __PST__UINT8 Rte_Call_WhlImbRejctn_CmpPeakData_GetErrorStatus(__PST__g__30 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_WhlImbRejctn_CmpPeakData_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_WhlImbRejctn_CmpPeakData_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_WhlImbRejctn_CmpPeakData_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_WhlImbRejctn_CmpPeakData_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_WhlImbRejctn_CmpPeakData_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_WhlImbRejctn_GetRefTmr100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_WhlImbRejctn_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_WhlImbRejctn_GetRefTmr100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_WhlImbRejctn_GetRefTmr100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_WhlImbRejctn_GetRefTmr100MicroSec32bit_Oper(__PST__g__34 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_WhlImbRejctn_GetTiSpan100MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_WhlImbRejctn_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_WhlImbRejctn_GetTiSpan100MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_WhlImbRejctn_GetTiSpan100MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_WhlImbRejctn_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__34 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_WhlImbRejctn_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_WhlImbRejctn_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_WhlImbRejctn_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_WhlImbRejctn_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_WhlImbRejctn_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnAdpvFac_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnAdpvFac_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnAdpvFac_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnAdpvFac_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnAdpvFac_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaTar_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaTar_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaTar_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaTar_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaTar_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp1FilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp1FilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp1FilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp1FilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp1FilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp2FilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp2FilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp2FilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp2FilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnBlndCmdMgnLp2FilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp1FilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp1FilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp1FilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp1FilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp1FilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp2FilFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp2FilFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp2FilFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp2FilFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnCmdMgnLp2FilFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnCurrMgnSlewPerLoop_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnCurrMgnSlewPerLoop_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnCurrMgnSlewPerLoop_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnCurrMgnSlewPerLoop_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnCurrMgnSlewPerLoop_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryDly_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryDly_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryDly_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryDly_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryDly_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryNegStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryNegStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryNegStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryNegStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryNegStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryPosStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryPosStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryPosStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryPosStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryPosStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendFltRcvryThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendLpFil_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendLpFil_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendLpFil_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendLpFil_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendLpFil_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTh2Tq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTh2Tq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTh2Tq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTh2Tq_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTh2Tq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendThTq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendThTq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendThTq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendThTq_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendThTq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTi2Sec_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTi2Sec_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTi2Sec_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTi2Sec_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTi2Sec_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTiSec_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTiSec_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTiSec_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTiSec_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDcTrendTiSec_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnDistbnMgnLpFil_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnDistbnMgnLpFil_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnDistbnMgnLpFil_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnDistbnMgnLpFil_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnDistbnMgnLpFil_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnEnaSlewPerLoop_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnEnaSlewPerLoop_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnEnaSlewPerLoop_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnEnaSlewPerLoop_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnEnaSlewPerLoop_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcAmpThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcAmpThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcAmpThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcAmpThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcAmpThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryDly_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryDly_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryDly_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryDly_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryDly_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryNegStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryNegStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryNegStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryNegStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryNegStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryPosStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryPosStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryPosStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryPosStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryPosStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcFltRcvryThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcLpFil_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcLpFil_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcLpFil_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcLpFil_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcLpFil_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcUgrPoleMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcUgrPoleMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcUgrPoleMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcUgrPoleMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcUgrPoleMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltNegStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltNegStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltNegStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltNegStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltNegStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltPosStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltPosStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltPosStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltPosStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltPosStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryDly_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryDly_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryDly_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryDly_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryDly_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryNegStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryNegStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryNegStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryNegStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryNegStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryPosStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryPosStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryPosStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryPosStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryPosStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltRcvryThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxMgnFltThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDeltaSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDeltaSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDeltaSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDeltaSca_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDeltaSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDiThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDiThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDiThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDiThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnDiThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnEnaThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnEnaThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnEnaThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnEnaThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnEnaThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrq_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrq_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrq_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrq_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrqDelta_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrqDelta_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrqDelta_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrqDelta_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnFrqDelta_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnLeak_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnLeak_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnLeak_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnLeak_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnMgnEstimnLeak_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnScaCncl_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnScaCncl_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnScaCncl_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnScaCncl_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnScaCncl_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnUgrPoleMgn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnUgrPoleMgn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnUgrPoleMgn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnUgrPoleMgn_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnUgrPoleMgn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnVehSpdEna_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnVehSpdEna_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnVehSpdEna_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnVehSpdEna_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnVehSpdEna_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryDly_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryDly_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryDly_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryDly_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryDly_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryNegStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryNegStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryNegStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryNegStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryNegStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryPosStep_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryPosStep_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryPosStep_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryPosStep_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryPosStep_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnFltRcvryThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnThd_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdLpFil_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdLpFil_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdLpFil_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdLpFil_Val"
//
// __PST__FLOAT32 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdLpFil_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcTout_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcTout_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcTout_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcTout_Val"
//
// __PST__UINT16 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcTout_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxDurn_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxDurn_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxDurn_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxDurn_Val"
//
// __PST__UINT16 Rte_Prm_WhlImbRejctn_WhlImbRejctnMaxDurn_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnRampDwnTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnRampDwnTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnRampDwnTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnRampDwnTi_Val"
//
// __PST__UINT16 Rte_Prm_WhlImbRejctn_WhlImbRejctnRampDwnTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnTi_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnTi_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnTi_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnTi_Val"
//
// __PST__UINT16 Rte_Prm_WhlImbRejctn_WhlImbRejctnWhlSpdCorrlnTi_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaEna_Logl"
//
// __PST__UINT8 Rte_Prm_WhlImbRejctn_WhlImbRejctnAutScaEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFctEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFctEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFctEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFctEna_Logl"
//
// __PST__UINT8 Rte_Prm_WhlImbRejctn_WhlImbRejctnFctEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcEna_Logl"
//
// __PST__UINT8 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqDiagcEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblX_Ary1D"
//
// __PST__g__51 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblY_Ary1D"
//
// __PST__g__51 Rte_Prm_WhlImbRejctn_WhlImbRejctnFrqScaTblY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjX_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjX_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjX_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjX_Ary1D"
//
// __PST__g__51 Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjX_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjY_Ary1D
//
// #pragma POLYSPACE_PURE "Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjY_Ary1D"
// #pragma POLYSPACE_CLEAN "Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjY_Ary1D"
// #pragma POLYSPACE_WORST "Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjY_Ary1D"
//
// __PST__g__54 Rte_Prm_WhlImbRejctn_WhlImbRejctnPhaAdjY_Ary1D(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_CurrMgnSlewRate
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_CurrMgnSlewRate"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_CurrMgnSlewRate"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_CurrMgnSlewRate"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_CurrMgnSlewRate(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_EnaSlewRate
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_EnaSlewRate"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_EnaSlewRate"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_EnaSlewRate"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_EnaSlewRate(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_IniCmpFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_IniCmpFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_IniCmpFlt"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_IniCmpFlt"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnInit1_IniCmpFlt(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_CurrMgnSlewRate
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_CurrMgnSlewRate"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_CurrMgnSlewRate"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_CurrMgnSlewRate"
//
// __PST__FLOAT32 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_CurrMgnSlewRate(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_EnaSlewRate
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_EnaSlewRate"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_EnaSlewRate"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_EnaSlewRate"
//
// __PST__FLOAT32 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_EnaSlewRate(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_IniCmpFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_IniCmpFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_IniCmpFlt"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_IniCmpFlt"
//
// __PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_IniCmpFlt(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_SlowSpdDiagc
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_SlowSpdDiagc"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_SlowSpdDiagc"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_SlowSpdDiagc"
//
// __PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer1_SlowSpdDiagc(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_CmdAmp
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_CmdAmp"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_CmdAmp"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_CmdAmp"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_CmdAmp(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_DcTrendFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_DcTrendFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_DcTrendFlt"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_DcTrendFlt"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_DcTrendFlt(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_FrqDiagcFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_FrqDiagcFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_FrqDiagcFlt"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_FrqDiagcFlt"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_FrqDiagcFlt(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_MaxMgnFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_MaxMgnFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_MaxMgnFlt"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_MaxMgnFlt"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_MaxMgnFlt(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_WhlSpdCorrlnFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_WhlSpdCorrlnFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_WhlSpdCorrlnFlt"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_WhlSpdCorrlnFlt"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer1_WhlSpdCorrlnFlt(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_CmdAmp
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_CmdAmp"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_CmdAmp"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_CmdAmp"
//
// __PST__FLOAT32 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_CmdAmp(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_DcTrendFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_DcTrendFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_DcTrendFlt"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_DcTrendFlt"
//
// __PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_DcTrendFlt(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_FrqDiagcFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_FrqDiagcFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_FrqDiagcFlt"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_FrqDiagcFlt"
//
// __PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_FrqDiagcFlt(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_MaxMgnFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_MaxMgnFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_MaxMgnFlt"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_MaxMgnFlt"
//
// __PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_MaxMgnFlt(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_WhlSpdCorrlnFlt
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_WhlSpdCorrlnFlt"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_WhlSpdCorrlnFlt"
// #pragma POLYSPACE_WORST "Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_WhlSpdCorrlnFlt"
//
// __PST__UINT8 Rte_IrvRead_WhlImbRejctn_WhlImbRejctnPer2_WhlSpdCorrlnFlt(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer2_SlowSpdDiagc
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer2_SlowSpdDiagc"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer2_SlowSpdDiagc"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer2_SlowSpdDiagc"
//
// __PST__VOID Rte_IrvWrite_WhlImbRejctn_WhlImbRejctnPer2_SlowSpdDiagc(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_u16_u16VariXu16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_u16_u16VariXu16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_u16_u16VariXu16VariY"
//
// __PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__51 P_0, __PST__g__51 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function LnrIntrpn_s16_u16VariXs16VariY
//
// #pragma POLYSPACE_PURE "LnrIntrpn_s16_u16VariXs16VariY"
// #pragma POLYSPACE_CLEAN "LnrIntrpn_s16_u16VariXs16VariY"
// #pragma POLYSPACE_WORST "LnrIntrpn_s16_u16VariXs16VariY"
//
// __PST__SINT16 LnrIntrpn_s16_u16VariXs16VariY(__PST__g__51 P_0, __PST__g__54 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
// {
//    ...
// }

