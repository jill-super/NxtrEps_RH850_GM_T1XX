#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__29 _main_gen_init_g29(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__27 _main_gen_init_g27(void);

extern struct Rte_CDS_WhlImbRejctn _main_gen_init_g25(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__27 _main_gen_init_g27(void)
{
    static struct __PST__g__27 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct __PST__g__29 _main_gen_init_g29(void)
{
    static struct __PST__g__29 x;
    /* struct/union type */
    x.LePeakPrev = _main_gen_init_g10();
    x.RiPeakPrev = _main_gen_init_g10();
    x.MaxCompPerc = _main_gen_init_g10();
    x.ActvCmpBand1 = _main_gen_init_g8();
    x.ActvCmpBand2 = _main_gen_init_g8();
    x.ActvCmpBand3 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__32 _main_gen_init_g32(void)
{
    static struct __PST__g__32 x;
    /* struct/union type */
    x.Cntr = _main_gen_init_g10();
    x.Thd = _main_gen_init_g10();
    x.NegStep = _main_gen_init_g10();
    x.PosStep = _main_gen_init_g10();
    x.Sts = _main_gen_init_g6();
    return x;
}

struct Rte_CDS_WhlImbRejctn _main_gen_init_g25(void)
{
    static struct Rte_CDS_WhlImbRejctn x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g27();
        }
        x.Pim_BlndCmdMgnLp1Fil = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g27();
        }
        x.Pim_BlndCmdMgnLp2Fil = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_6[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g27();
        }
        x.Pim_CmdMgnLp1Fil = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_8[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g27();
        }
        x.Pim_CmdMgnLp2Fil = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__29 _main_gen_tmp_10[ARRAY_NBELEM(struct __PST__g__29)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(struct __PST__g__29); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g29();
        }
        x.Pim_CmpPeakData = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(struct __PST__g__29) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g6();
        }
        x.Pim_DcTrendFltFaild = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__32 _main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(struct __PST__g__32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g32();
        }
        x.Pim_DcTrendFltRcvry = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g6();
        }
        x.Pim_DcTrendFltRst = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_18[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g27();
        }
        x.Pim_DcTrendLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g6();
        }
        x.Pim_DcTrendLrngEnaPrev = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        x.Pim_DcTrendLrngEnaPrevTmr1 = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g6();
        }
        x.Pim_DcTrendLrngEnaPrevTmr2 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g8();
        }
        x.Pim_DcTrendRefTiEnaLrng = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g8();
        }
        x.Pim_DcTrendRefTiEnaLrngTmr1 = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g8();
        }
        x.Pim_DcTrendRefTiEnaLrngTmr2 = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g6();
        }
        x.Pim_DistbnMagEnadPrev = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_34[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g27();
        }
        x.Pim_DistbnMgnLeLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_36[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g27();
        }
        x.Pim_DistbnMgnRiLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_38[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g10();
        }
        x.Pim_EnaSlewPerLoop = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_41;
        for (_i_main_gen_tmp_41 = 0; _i_main_gen_tmp_41 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_41++)
        {
            _main_gen_tmp_40[_i_main_gen_tmp_41] = _main_gen_init_g6();
        }
        x.Pim_FrqDiagcFltFaild = PST_TRUE() ? 0 : &_main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__32 _main_gen_tmp_42[ARRAY_NBELEM(struct __PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_43;
        for (_i_main_gen_tmp_43 = 0; _i_main_gen_tmp_43 < ARRAY_NBELEM(struct __PST__g__32); _i_main_gen_tmp_43++)
        {
            _main_gen_tmp_42[_i_main_gen_tmp_43] = _main_gen_init_g32();
        }
        x.Pim_FrqDiagcFltRcvry = PST_TRUE() ? 0 : &_main_gen_tmp_42[ARRAY_NBELEM(struct __PST__g__32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_45;
        for (_i_main_gen_tmp_45 = 0; _i_main_gen_tmp_45 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_45++)
        {
            _main_gen_tmp_44[_i_main_gen_tmp_45] = _main_gen_init_g6();
        }
        x.Pim_FrqDiagcFltRst = PST_TRUE() ? 0 : &_main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_46[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_47;
        for (_i_main_gen_tmp_47 = 0; _i_main_gen_tmp_47 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_47++)
        {
            _main_gen_tmp_46[_i_main_gen_tmp_47] = _main_gen_init_g27();
        }
        x.Pim_FrqDiagcLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_46[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_48[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_49;
        for (_i_main_gen_tmp_49 = 0; _i_main_gen_tmp_49 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_49++)
        {
            _main_gen_tmp_48[_i_main_gen_tmp_49] = _main_gen_init_g6();
        }
        x.Pim_FrqDiagcLrngEnaPrev = PST_TRUE() ? 0 : &_main_gen_tmp_48[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_50[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_51;
        for (_i_main_gen_tmp_51 = 0; _i_main_gen_tmp_51 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_51++)
        {
            _main_gen_tmp_50[_i_main_gen_tmp_51] = _main_gen_init_g6();
        }
        x.Pim_FrqDiagcLrngEnaPrevTiOut = PST_TRUE() ? 0 : &_main_gen_tmp_50[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_52[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_53;
        for (_i_main_gen_tmp_53 = 0; _i_main_gen_tmp_53 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_53++)
        {
            _main_gen_tmp_52[_i_main_gen_tmp_53] = _main_gen_init_g8();
        }
        x.Pim_FrqDiagcRefTiEnaLrng = PST_TRUE() ? 0 : &_main_gen_tmp_52[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_54[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_55;
        for (_i_main_gen_tmp_55 = 0; _i_main_gen_tmp_55 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_55++)
        {
            _main_gen_tmp_54[_i_main_gen_tmp_55] = _main_gen_init_g8();
        }
        x.Pim_FrqDiagcRefTiEnaLrngTiOut = PST_TRUE() ? 0 : &_main_gen_tmp_54[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_56[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_57;
        for (_i_main_gen_tmp_57 = 0; _i_main_gen_tmp_57 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_57++)
        {
            _main_gen_tmp_56[_i_main_gen_tmp_57] = _main_gen_init_g10();
        }
        x.Pim_FrqDiagcUgr1 = PST_TRUE() ? 0 : &_main_gen_tmp_56[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_58[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_59;
        for (_i_main_gen_tmp_59 = 0; _i_main_gen_tmp_59 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_59++)
        {
            _main_gen_tmp_58[_i_main_gen_tmp_59] = _main_gen_init_g10();
        }
        x.Pim_FrqDiagcUgr2 = PST_TRUE() ? 0 : &_main_gen_tmp_58[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_60[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_61;
        for (_i_main_gen_tmp_61 = 0; _i_main_gen_tmp_61 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_61++)
        {
            _main_gen_tmp_60[_i_main_gen_tmp_61] = _main_gen_init_g10();
        }
        x.Pim_LeCurrMgnSlewPerLoop = PST_TRUE() ? 0 : &_main_gen_tmp_60[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_62[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_63;
        for (_i_main_gen_tmp_63 = 0; _i_main_gen_tmp_63 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_63++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_64_0;
                
                for (_main_gen_tmp_64_0 = 0; _main_gen_tmp_64_0 < 30; _main_gen_tmp_64_0++)
                {
                    /* base type */
                    _main_gen_tmp_62[_i_main_gen_tmp_63][_main_gen_tmp_64_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_LeStDlyUpd = PST_TRUE() ? 0 : &_main_gen_tmp_62[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_65[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_66;
        for (_i_main_gen_tmp_66 = 0; _i_main_gen_tmp_66 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_66++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_67_0;
                
                for (_main_gen_tmp_67_0 = 0; _main_gen_tmp_67_0 < 30; _main_gen_tmp_67_0++)
                {
                    /* base type */
                    _main_gen_tmp_65[_i_main_gen_tmp_66][_main_gen_tmp_67_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_LeStVariUpd = PST_TRUE() ? 0 : &_main_gen_tmp_65[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_68[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_69;
        for (_i_main_gen_tmp_69 = 0; _i_main_gen_tmp_69 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_69++)
        {
            _main_gen_tmp_68[_i_main_gen_tmp_69] = _main_gen_init_g6();
        }
        x.Pim_MaxMgnFltFaild = PST_TRUE() ? 0 : &_main_gen_tmp_68[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__32 _main_gen_tmp_70[ARRAY_NBELEM(struct __PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_71;
        for (_i_main_gen_tmp_71 = 0; _i_main_gen_tmp_71 < ARRAY_NBELEM(struct __PST__g__32); _i_main_gen_tmp_71++)
        {
            _main_gen_tmp_70[_i_main_gen_tmp_71] = _main_gen_init_g32();
        }
        x.Pim_MaxMgnFltRcvry = PST_TRUE() ? 0 : &_main_gen_tmp_70[ARRAY_NBELEM(struct __PST__g__32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_72[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_73;
        for (_i_main_gen_tmp_73 = 0; _i_main_gen_tmp_73 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_73++)
        {
            _main_gen_tmp_72[_i_main_gen_tmp_73] = _main_gen_init_g6();
        }
        x.Pim_MaxMgnFltRst = PST_TRUE() ? 0 : &_main_gen_tmp_72[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_74[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_75;
        for (_i_main_gen_tmp_75 = 0; _i_main_gen_tmp_75 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_75++)
        {
            _main_gen_tmp_74[_i_main_gen_tmp_75] = _main_gen_init_g6();
        }
        x.Pim_MaxMgnLrngEnaPrev = PST_TRUE() ? 0 : &_main_gen_tmp_74[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_76[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_77;
        for (_i_main_gen_tmp_77 = 0; _i_main_gen_tmp_77 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_77++)
        {
            _main_gen_tmp_76[_i_main_gen_tmp_77] = _main_gen_init_g8();
        }
        x.Pim_MaxMgnRefTiEnaLrng = PST_TRUE() ? 0 : &_main_gen_tmp_76[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_78[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_79;
        for (_i_main_gen_tmp_79 = 0; _i_main_gen_tmp_79 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_79++)
        {
            _main_gen_tmp_78[_i_main_gen_tmp_79] = _main_gen_init_g10();
        }
        x.Pim_PhaAdjFil1Coeff1 = PST_TRUE() ? 0 : &_main_gen_tmp_78[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_80[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_81;
        for (_i_main_gen_tmp_81 = 0; _i_main_gen_tmp_81 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_81++)
        {
            _main_gen_tmp_80[_i_main_gen_tmp_81] = _main_gen_init_g10();
        }
        x.Pim_PhaAdjFil1Coeff2 = PST_TRUE() ? 0 : &_main_gen_tmp_80[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_82[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_83;
        for (_i_main_gen_tmp_83 = 0; _i_main_gen_tmp_83 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_83++)
        {
            _main_gen_tmp_82[_i_main_gen_tmp_83] = _main_gen_init_g10();
        }
        x.Pim_PhaAdjFil2Coeff1 = PST_TRUE() ? 0 : &_main_gen_tmp_82[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_84[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_85;
        for (_i_main_gen_tmp_85 = 0; _i_main_gen_tmp_85 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_85++)
        {
            _main_gen_tmp_84[_i_main_gen_tmp_85] = _main_gen_init_g10();
        }
        x.Pim_PhaAdjFil2Coeff2 = PST_TRUE() ? 0 : &_main_gen_tmp_84[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_86[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_87;
        for (_i_main_gen_tmp_87 = 0; _i_main_gen_tmp_87 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_87++)
        {
            _main_gen_tmp_86[_i_main_gen_tmp_87] = _main_gen_init_g10();
        }
        x.Pim_PrevFlt = PST_TRUE() ? 0 : &_main_gen_tmp_86[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_88[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_89;
        for (_i_main_gen_tmp_89 = 0; _i_main_gen_tmp_89 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_89++)
        {
            _main_gen_tmp_88[_i_main_gen_tmp_89] = _main_gen_init_g10();
        }
        x.Pim_PrevHwTq = PST_TRUE() ? 0 : &_main_gen_tmp_88[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_90[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_91;
        for (_i_main_gen_tmp_91 = 0; _i_main_gen_tmp_91 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_91++)
        {
            _main_gen_tmp_90[_i_main_gen_tmp_91] = _main_gen_init_g6();
        }
        x.Pim_PrevSts = PST_TRUE() ? 0 : &_main_gen_tmp_90[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_92[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_93;
        for (_i_main_gen_tmp_93 = 0; _i_main_gen_tmp_93 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_93++)
        {
            _main_gen_tmp_92[_i_main_gen_tmp_93] = _main_gen_init_g6();
        }
        x.Pim_RampNo = PST_TRUE() ? 0 : &_main_gen_tmp_92[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_94[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_95;
        for (_i_main_gen_tmp_95 = 0; _i_main_gen_tmp_95 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_95++)
        {
            _main_gen_tmp_94[_i_main_gen_tmp_95] = _main_gen_init_g6();
        }
        x.Pim_RampYes = PST_TRUE() ? 0 : &_main_gen_tmp_94[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_96[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_97;
        for (_i_main_gen_tmp_97 = 0; _i_main_gen_tmp_97 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_97++)
        {
            _main_gen_tmp_96[_i_main_gen_tmp_97] = _main_gen_init_g10();
        }
        x.Pim_RiCurrMgnSlewPerLoop = PST_TRUE() ? 0 : &_main_gen_tmp_96[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_98[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_99;
        for (_i_main_gen_tmp_99 = 0; _i_main_gen_tmp_99 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_99++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_100_0;
                
                for (_main_gen_tmp_100_0 = 0; _main_gen_tmp_100_0 < 30; _main_gen_tmp_100_0++)
                {
                    /* base type */
                    _main_gen_tmp_98[_i_main_gen_tmp_99][_main_gen_tmp_100_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_RiStDlyUpd = PST_TRUE() ? 0 : &_main_gen_tmp_98[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_101[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_102;
        for (_i_main_gen_tmp_102 = 0; _i_main_gen_tmp_102 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_102++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_103_0;
                
                for (_main_gen_tmp_103_0 = 0; _main_gen_tmp_103_0 < 30; _main_gen_tmp_103_0++)
                {
                    /* base type */
                    _main_gen_tmp_101[_i_main_gen_tmp_102][_main_gen_tmp_103_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_RiStVariUpd = PST_TRUE() ? 0 : &_main_gen_tmp_101[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_104[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_105;
        for (_i_main_gen_tmp_105 = 0; _i_main_gen_tmp_105 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_105++)
        {
            _main_gen_tmp_104[_i_main_gen_tmp_105] = _main_gen_init_g10();
        }
        x.Pim_ScaLe = PST_TRUE() ? 0 : &_main_gen_tmp_104[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_106[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_107;
        for (_i_main_gen_tmp_107 = 0; _i_main_gen_tmp_107 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_107++)
        {
            _main_gen_tmp_106[_i_main_gen_tmp_107] = _main_gen_init_g10();
        }
        x.Pim_ScaRi = PST_TRUE() ? 0 : &_main_gen_tmp_106[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_108[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_109;
        for (_i_main_gen_tmp_109 = 0; _i_main_gen_tmp_109 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_109++)
        {
            _main_gen_tmp_108[_i_main_gen_tmp_109] = _main_gen_init_g6();
        }
        x.Pim_SlowSpdDiagcLrngEnaPrevTmr = PST_TRUE() ? 0 : &_main_gen_tmp_108[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_110[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_111;
        for (_i_main_gen_tmp_111 = 0; _i_main_gen_tmp_111 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_111++)
        {
            _main_gen_tmp_110[_i_main_gen_tmp_111] = _main_gen_init_g8();
        }
        x.Pim_SlowSpdDiagcRefTiEnaLrngTmr = PST_TRUE() ? 0 : &_main_gen_tmp_110[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_112[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_113;
        for (_i_main_gen_tmp_113 = 0; _i_main_gen_tmp_113 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_113++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_114_0;
                
                for (_main_gen_tmp_114_0 = 0; _main_gen_tmp_114_0 < 30; _main_gen_tmp_114_0++)
                {
                    /* base type */
                    _main_gen_tmp_112[_i_main_gen_tmp_113][_main_gen_tmp_114_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_StordValLe = PST_TRUE() ? 0 : &_main_gen_tmp_112[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_115[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_116;
        for (_i_main_gen_tmp_116 = 0; _i_main_gen_tmp_116 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_116++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_117_0;
                
                for (_main_gen_tmp_117_0 = 0; _main_gen_tmp_117_0 < 30; _main_gen_tmp_117_0++)
                {
                    /* base type */
                    _main_gen_tmp_115[_i_main_gen_tmp_116][_main_gen_tmp_117_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_StordValRi = PST_TRUE() ? 0 : &_main_gen_tmp_115[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_118[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_119;
        for (_i_main_gen_tmp_119 = 0; _i_main_gen_tmp_119 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_119++)
        {
            _main_gen_tmp_118[_i_main_gen_tmp_119] = _main_gen_init_g10();
        }
        x.Pim_UgrLe1 = PST_TRUE() ? 0 : &_main_gen_tmp_118[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_120[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_121;
        for (_i_main_gen_tmp_121 = 0; _i_main_gen_tmp_121 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_121++)
        {
            _main_gen_tmp_120[_i_main_gen_tmp_121] = _main_gen_init_g10();
        }
        x.Pim_UgrLe2 = PST_TRUE() ? 0 : &_main_gen_tmp_120[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_122[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_123;
        for (_i_main_gen_tmp_123 = 0; _i_main_gen_tmp_123 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_123++)
        {
            _main_gen_tmp_122[_i_main_gen_tmp_123] = _main_gen_init_g10();
        }
        x.Pim_UgrRi1 = PST_TRUE() ? 0 : &_main_gen_tmp_122[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_124[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_125;
        for (_i_main_gen_tmp_125 = 0; _i_main_gen_tmp_125 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_125++)
        {
            _main_gen_tmp_124[_i_main_gen_tmp_125] = _main_gen_init_g10();
        }
        x.Pim_UgrRi2 = PST_TRUE() ? 0 : &_main_gen_tmp_124[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_126[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_127;
        for (_i_main_gen_tmp_127 = 0; _i_main_gen_tmp_127 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_127++)
        {
            _main_gen_tmp_126[_i_main_gen_tmp_127] = _main_gen_init_g6();
        }
        x.Pim_WhlSpdCorrFltFaild = PST_TRUE() ? 0 : &_main_gen_tmp_126[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_128[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_129;
        for (_i_main_gen_tmp_129 = 0; _i_main_gen_tmp_129 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_129++)
        {
            _main_gen_tmp_128[_i_main_gen_tmp_129] = _main_gen_init_g6();
        }
        x.Pim_WhlSpdCorrFltRst = PST_TRUE() ? 0 : &_main_gen_tmp_128[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_130[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_131;
        for (_i_main_gen_tmp_131 = 0; _i_main_gen_tmp_131 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_131++)
        {
            _main_gen_tmp_130[_i_main_gen_tmp_131] = _main_gen_init_g6();
        }
        x.Pim_WhlSpdCorrlnDiagcLrngEnaPrev = PST_TRUE() ? 0 : &_main_gen_tmp_130[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_132[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_133;
        for (_i_main_gen_tmp_133 = 0; _i_main_gen_tmp_133 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_133++)
        {
            _main_gen_tmp_132[_i_main_gen_tmp_133] = _main_gen_init_g8();
        }
        x.Pim_WhlSpdCorrlnDiagcRefTiEnaLrng = PST_TRUE() ? 0 : &_main_gen_tmp_132[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__32 _main_gen_tmp_134[ARRAY_NBELEM(struct __PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_135;
        for (_i_main_gen_tmp_135 = 0; _i_main_gen_tmp_135 < ARRAY_NBELEM(struct __PST__g__32); _i_main_gen_tmp_135++)
        {
            _main_gen_tmp_134[_i_main_gen_tmp_135] = _main_gen_init_g32();
        }
        x.Pim_WhlSpdCorrlnFltRcvry = PST_TRUE() ? 0 : &_main_gen_tmp_134[ARRAY_NBELEM(struct __PST__g__32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_136[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_137;
        for (_i_main_gen_tmp_137 = 0; _i_main_gen_tmp_137 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_137++)
        {
            _main_gen_tmp_136[_i_main_gen_tmp_137] = _main_gen_init_g6();
        }
        x.Pim_WhlSpdCorrlnLrngEnaPrevTmr = PST_TRUE() ? 0 : &_main_gen_tmp_136[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_138[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_139;
        for (_i_main_gen_tmp_139 = 0; _i_main_gen_tmp_139 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_139++)
        {
            _main_gen_tmp_138[_i_main_gen_tmp_139] = _main_gen_init_g8();
        }
        x.Pim_WhlSpdCorrlnRefTiEnaLrngTmr = PST_TRUE() ? 0 : &_main_gen_tmp_138[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_140[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_141;
        for (_i_main_gen_tmp_141 = 0; _i_main_gen_tmp_141 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_141++)
        {
            _main_gen_tmp_140[_i_main_gen_tmp_141] = _main_gen_init_g27();
        }
        x.Pim_WhlSpdLeLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_140[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__27 _main_gen_tmp_142[ARRAY_NBELEM(struct __PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_143;
        for (_i_main_gen_tmp_143 = 0; _i_main_gen_tmp_143 < ARRAY_NBELEM(struct __PST__g__27); _i_main_gen_tmp_143++)
        {
            _main_gen_tmp_142[_i_main_gen_tmp_143] = _main_gen_init_g27();
        }
        x.Pim_WhlSpdRiLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_142[ARRAY_NBELEM(struct __PST__g__27) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_144[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_145;
        for (_i_main_gen_tmp_145 = 0; _i_main_gen_tmp_145 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_145++)
        {
            _main_gen_tmp_144[_i_main_gen_tmp_145] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnCnclTqOutp = PST_TRUE() ? 0 : &_main_gen_tmp_144[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_146[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_147;
        for (_i_main_gen_tmp_147 = 0; _i_main_gen_tmp_147 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_147++)
        {
            _main_gen_tmp_146[_i_main_gen_tmp_147] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnCurrMgnLe = PST_TRUE() ? 0 : &_main_gen_tmp_146[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_148[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_149;
        for (_i_main_gen_tmp_149 = 0; _i_main_gen_tmp_149 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_149++)
        {
            _main_gen_tmp_148[_i_main_gen_tmp_149] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnCurrMgnRi = PST_TRUE() ? 0 : &_main_gen_tmp_148[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_150[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_151;
        for (_i_main_gen_tmp_151 = 0; _i_main_gen_tmp_151 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_151++)
        {
            _main_gen_tmp_150[_i_main_gen_tmp_151] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnFildWhlSpdLe = PST_TRUE() ? 0 : &_main_gen_tmp_150[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_152[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_153;
        for (_i_main_gen_tmp_153 = 0; _i_main_gen_tmp_153 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_153++)
        {
            _main_gen_tmp_152[_i_main_gen_tmp_153] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnFildWhlSpdRi = PST_TRUE() ? 0 : &_main_gen_tmp_152[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_154[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_155;
        for (_i_main_gen_tmp_155 = 0; _i_main_gen_tmp_155 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_155++)
        {
            _main_gen_tmp_154[_i_main_gen_tmp_155] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnLMSqdOutLe = PST_TRUE() ? 0 : &_main_gen_tmp_154[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_156[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_157;
        for (_i_main_gen_tmp_157 = 0; _i_main_gen_tmp_157 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_157++)
        {
            _main_gen_tmp_156[_i_main_gen_tmp_157] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnLMSqdOutRi = PST_TRUE() ? 0 : &_main_gen_tmp_156[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_158[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_159;
        for (_i_main_gen_tmp_159 = 0; _i_main_gen_tmp_159 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_159++)
        {
            _main_gen_tmp_158[_i_main_gen_tmp_159] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnScaLe = PST_TRUE() ? 0 : &_main_gen_tmp_158[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_160[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_161;
        for (_i_main_gen_tmp_161 = 0; _i_main_gen_tmp_161 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_161++)
        {
            _main_gen_tmp_160[_i_main_gen_tmp_161] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnScaRi = PST_TRUE() ? 0 : &_main_gen_tmp_160[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_162[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_163;
        for (_i_main_gen_tmp_163 = 0; _i_main_gen_tmp_163 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_163++)
        {
            _main_gen_tmp_162[_i_main_gen_tmp_163] = _main_gen_init_g10();
        }
        x.Pim_dWhlImbRejctnWhlSpdCorrPerc = PST_TRUE() ? 0 : &_main_gen_tmp_162[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_WhlImbRejctn(void)
{
    extern __PST__g__22 Rte_Inst_WhlImbRejctn;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_WhlImbRejctn _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_WhlImbRejctn)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_WhlImbRejctn); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g25();
            }
            Rte_Inst_WhlImbRejctn = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_WhlImbRejctn) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_WhlImbRejctn */
    _main_gen_init_sym_Rte_Inst_WhlImbRejctn();
    
}
